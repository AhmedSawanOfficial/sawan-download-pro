@echo off
setlocal enabledelayedexpansion
REM ============================================================================
REM  Sawan Download Pro v1.0 — Publish Script
REM  Creates a distributable folder with all required runtime files.
REM
REM  USAGE:
REM    publish.bat              — publishes x64 build to dist\SawanDownloadPro\
REM    publish.bat x86          — publishes x86 build
REM
REM  PREREQUISITE: Run build_release.bat first.
REM ============================================================================

set PLATFORM=%1
if "%PLATFORM%"=="" set PLATFORM=x64
set SOLUTION_DIR=%~dp0
set "BUILD_OUT=%SOLUTION_DIR%src\SawanDownloadPro.App\bin\Release\%PLATFORM%"
set "DIST_OUT=%SOLUTION_DIR%dist\SawanDownloadPro"

echo ============================================================
echo  Sawan Download Pro — Publish
echo  Platform: %PLATFORM%
echo  Source:   %BUILD_OUT%
echo  Target:   %DIST_OUT%
echo ============================================================

REM --- Verify the build output exists ---
if not exist "%BUILD_OUT%\SawanDownloadPro.exe" (
    echo.
    echo [ERROR] Build output not found: %BUILD_OUT%\SawanDownloadPro.exe
    echo Run build_release.bat first.
    exit /b 1
)

REM --- Clean previous dist ---
if exist "%DIST_OUT%" rmdir /S /Q "%DIST_OUT%"

REM --- Create dist folder ---
mkdir "%DIST_OUT%"
if errorlevel 1 (
    echo [ERROR] Could not create dist folder.
    exit /b 1
)

REM --- Copy all files ---
echo.
echo Copying files...
xcopy "%BUILD_OUT%\*" "%DIST_OUT%\" /E /I /Q /Y
if errorlevel 1 (
    echo [ERROR] File copy failed.
    exit /b 1
)

REM --- Remove unnecessary files ---
echo Cleaning up...
del /Q "%DIST_OUT%\*.pdb" 2>nul
del /Q "%DIST_OUT%\*.xml" 2>nul
rmdir /S /Q "%DIST_OUT%\cs" 2>nul
rmdir /S /Q "%DIST_OUT%\de" 2>nul
rmdir /S /Q "%DIST_OUT%\es" 2>nul
rmdir /S /Q "%DIST_OUT%\fr" 2>nul
rmdir /S /Q "%DIST_OUT%\it" 2>nul
rmdir /S /Q "%DIST_OUT%\ja" 2>nul
rmdir /S /Q "%DIST_OUT%\ko" 2>nul
rmdir /S /Q "%DIST_OUT%\pl" 2>nul
rmdir /S /Q "%DIST_OUT%\pt-BR" 2>nul
rmdir /S /Q "%DIST_OUT%\ru" 2>nul
rmdir /S /Q "%DIST_OUT%\tr" 2>nul
rmdir /S /Q "%DIST_OUT%\zh-Hans" 2>nul
rmdir /S /Q "%DIST_OUT%\zh-Hant" 2>nul

REM --- Verify the result ---
if not exist "%DIST_OUT%\SawanDownloadPro.exe" (
    echo [ERROR] SawanDownloadPro.exe missing from dist folder!
    exit /b 1
)

echo.
echo ============================================================
echo  PUBLISH SUCCEEDED
echo ============================================================
echo.
echo  Distributable folder:
echo    %DIST_OUT%\
echo.
echo  To run:
echo    %DIST_OUT%\SawanDownloadPro.exe
echo.
echo  To create a ZIP archive:
echo    powershell Compress-Archive -Path "%DIST_OUT%\*" -DestinationPath "%SOLUTION_DIR%dist\SawanDownloadPro-%PLATFORM%.zip"
echo.

REM --- Optionally create a ZIP ---
where powershell >nul 2>nul
if not errorlevel 1 (
    echo Creating ZIP archive...
    powershell -Command "Compress-Archive -Path '%DIST_OUT%\*' -DestinationPath '%SOLUTION_DIR%dist\SawanDownloadPro-%PLATFORM%.zip' -Force"
    if exist "%SOLUTION_DIR%dist\SawanDownloadPro-%PLATFORM%.zip" (
        echo [OK] ZIP created:
        echo   %SOLUTION_DIR%dist\SawanDownloadPro-%PLATFORM%.zip
    )
)

echo.
echo Done.
exit /b 0
