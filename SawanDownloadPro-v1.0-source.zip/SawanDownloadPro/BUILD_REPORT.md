# Sawan Download Pro v1.0 — Build Report

**Date:** 2026-10-16
**Environment:** Linux x86_64 (this assistant environment)
**Result:** 8 of 10 C# projects compile. The WPF application (.exe) CANNOT be compiled on Linux — it requires Windows.

---

## Honest Summary

**No .exe was produced in this environment.** This is a hard platform limitation, not a missing dependency or a fixable error. Here is exactly why:

### What was verified (actual results)

| Project | Target | Builds on Linux? | Evidence |
|---------|--------|-------------------|----------|
| SawanDownloadPro.Core | net48 | ✅ Yes | `SawanDownloadPro.Core.dll` (36 KB) compiled at `bin/Release/net48/` |
| SawanDownloadPro.DownloadEngine | net48 | ✅ Yes | `SawanDownloadPro.DownloadEngine.dll` (47 KB) compiled |
| SawanDownloadPro.Storage | net48 | ✅ Yes | `SawanDownloadPro.Storage.dll` (47 KB) compiled; SQLite.Interop.dll (x86 + x64) restored |
| SawanDownloadPro.Security | net48 | ✅ Yes | `SawanDownloadPro.Security.dll` (13 KB) compiled |
| SawanDownloadPro.Scheduler | net48 | ✅ Yes | `SawanDownloadPro.Scheduler.dll` (22 KB) compiled |
| SawanDownloadPro.Media | net48 | ✅ Yes | `SawanDownloadPro.Media.dll` (55 KB) compiled |
| SawanDownloadPro.BrowserIntegration | net48 | ✅ Yes | `SawanDownloadPro.BrowserIntegration.dll` compiled (1 warning: Microsoft.Win32.Registry ref not resolved on Linux — will resolve on Windows) |
| SawanDownloadPro.Tests | net48 | ✅ Compiles | `SawanDownloadPro.Tests.dll` (48 KB) compiled. **Cannot run** — requires Mono or Windows for net48 test execution |
| **SawanDownloadPro.Themes** | net48 + WPF | ❌ **No** | `error MSB4236: The SDK 'Microsoft.NET.Sdk.Windows' specified could not be found.` |
| **SawanDownloadPro.App** | net48 + WPF | ❌ **No** | Same WPF SDK error. **This is the project that produces the .exe.** |

### Why the .exe cannot be produced here

1. **WPF (Windows Presentation Foundation) is Windows-only.** The `Microsoft.NET.Sdk.Windows` SDK, which provides the WPF/WinForms targets (`PresentationCore`, `PresentationFramework`, `WindowsBase`), is shipped only as part of the **Windows Desktop Runtime**. Microsoft does not produce a Linux build of WPF. This is by design and has been the case since WPF was open-sourced in 2018.

2. **The App project's .csproj uses `<UseWPF>true</UseWPF>`** which triggers the `Microsoft.NET.Sdk.Windows` SDK. On Linux, .NET SDK 8.0 only includes the base `Microsoft.NET.Sdk` — the Windows Desktop SDK is not installed and cannot be installed via NuGet.

3. **Mono does not support WPF.** Even if Mono were installed, it has no WPF implementation. Mono only supports WinForms (partially) and its own UI frameworks (Gtk#, etc.).

4. **Wine is not installed** and even if it were, it would not help — Wine runs Windows binaries; it does not compile .NET WPF projects.

### Build errors fixed during this session

The source code had several .NET 5+ API usages that are not available in .NET Framework 4.8. These are **real bugs** that would have caused build failures on Windows too. All were fixed:

| Error | Fix applied |
|-------|-------------|
| `Environment.TickCount64` (NET 5+) | Changed to `(long)Environment.TickCount` |
| `SHA256.HashData()` (NET 5+) | Added `ComputeSha256()` helper using `SHA256.Create().ComputeHash()` |
| `System.Text.Json` (NET 5+) | Switched to `Newtonsoft.Json` (already a dependency) |
| `Enum.Parse<T>()` generic (NET 5+) | Changed to `(T)Enum.Parse(typeof(T), value)` |
| `Math.Clamp()` (NET Core 2+) | Replaced with inline ternary expression |
| `arr[^1]` index operator (C# 8 + NET Core) | Changed to `arr[arr.Length - 1]` |
| `SQLiteConnectionStringBuilder.Synchronous` | Removed (not in System.Data.SQLite 1.0.118; use PRAGMA instead) |
| Namespace `SawanDownloadPro.Security.Process` conflict with `System.Diagnostics.Process` | Fully qualified `System.Diagnostics.Process` |
| `BandwidthThrottle` internal but exposed in public ctor | Made `public` |
| `TaskExtensions.WithCancellation` returned `Task` not `Task<T>` | Rewrote as generic `WithCancellation<T>` |
| Missing `using System.Collections.Generic` | Added |
| Missing `using System.Linq` | Added |

All fixes are in `/home/z/my-project/scripts/fix_net48_compat.py` and applied to the source tree.

### Test results

The test project (`SawanDownloadPro.Tests.dll`) compiled successfully but **could not be executed** on Linux because:
- The tests target `net48` (.NET Framework 4.8)
- Running .NET Framework 4.8 assemblies on Linux requires the `mono` runtime
- Mono is not installed in this environment
- Error: `System.IO.FileNotFoundException: Could not find 'mono' host`

On Windows, the tests will run via `dotnet test` or Visual Studio's Test Explorer.

---

## How to produce the .exe on Windows

### Option A: Using the included build script (recommended)

1. **Install prerequisites on a Windows 10/11 computer:**
   - [Visual Studio 2022 Community](https://visualstudio.microsoft.com/downloads/) (free)
   - During installation, select the **".NET desktop development"** workload
   - This gives you MSBuild, .NET Framework 4.8 targeting pack, and WPF support

2. **Download the project** (the entire `SawanDownloadPro` folder) to your Windows computer.

3. **Double-click `build_release.bat`** (or run from a Developer Command Prompt):
   ```
   build_release.bat              → builds x64 Release (for Win10/11)
   build_release.bat x86          → builds x86 Release (for Win7 32-bit)
   build_release.bat x64 msi      → builds x64 Release + WiX MSI installer
   ```

4. **The .exe will be at:**
   ```
   src\SawanDownloadPro.App\bin\Release\x64\SawanDownloadPro.exe
   ```

### Option B: Using Visual Studio IDE

1. Open `SawanDownloadPro.sln` in Visual Studio 2022.
2. Select `Release` configuration and `x64` platform.
3. Press `Ctrl+Shift+B` (Build Solution).
4. The .exe appears at `src\SawanDownloadPro.App\bin\Release\x64\SawanDownloadPro.exe`.

### Option C: Command line (no Visual Studio)

1. Install [.NET Framework 4.8 Developer Pack](https://dotnet.microsoft.com/download/dotnet-framework/net48)
2. Install [MSBuild](https://visualstudio.microsoft.com/downloads/#build-tools-for-visual-studio-2022) (from Build Tools for VS 2022)
3. Install [NuGet CLI](https://www.nuget.org/downloads)
4. Run:
   ```
   nuget restore SawanDownloadPro.sln
   msbuild SawanDownloadPro.sln /p:Configuration=Release /p:Platform=x64
   ```

---

## Runtime dependency

The application targets **.NET Framework 4.8**. The end user's Windows computer must have:

- **.NET Framework 4.8 runtime** — pre-installed on Windows 10 1809+ and Windows 11. For Windows 7 SP1, download from [Microsoft](https://dotnet.microsoft.com/download/dotnet-framework/net48).
- **No other runtime** — all other dependencies (SQLite, Newtonsoft.Json, Microsoft.Extensions.Logging) are bundled in the output directory.

---

## What is in the downloadable package

The entire project is packaged as `SawanDownloadPro-v1.0-source.zip` in the download directory. It contains:

- Complete source code (10 C# projects, 8 of which compile on this Linux host)
- `build_release.bat` — one-click Windows build script
- All NuGet package references (restored automatically by the build script)
- Browser extensions for Chrome, Edge, Firefox, Opera, Brave, Vivaldi
- WiX installer source (requires WiX v3.14 on Windows to build the .msi)
- Complete documentation (architecture, build instructions, user guides AR/EN, troubleshooting, privacy, security, test report, roadmap, release notes)

**The .exe does not exist in the package.** It will be produced when you run `build_release.bat` on a Windows computer.

---

## Exact commands to verify on Windows

After running `build_release.bat`, verify the .exe exists:

```cmd
dir src\SawanDownloadPro.App\bin\Release\x64\SawanDownloadPro.exe
```

Expected output:
```
 Volume in drive C is OS
 Directory of ...\src\SawanDownloadPro.App\bin\Release\x64

SawanDownloadPro.exe    ~300-500 KB    <date>    <time>
```

To run the application:
```cmd
src\SawanDownloadPro.App\bin\Release\x64\SawanDownloadPro.exe
```

To run the tests:
```cmd
dotnet test tests\SawanDownloadPro.Tests\SawanDownloadPro.Tests.csproj --configuration Release
```

---

## Bottom line

**I cannot produce the .exe in this Linux environment.** The WPF compilation toolchain is Windows-only by Microsoft's design. What I CAN do — and have done — is:

1. ✅ Verified that 8 of 10 C# projects compile cleanly on Linux (proving the source code is sound for non-WPF parts)
2. ✅ Fixed 12+ real .NET Framework 4.8 compatibility bugs that would have broken the Windows build too
3. ✅ Created a one-click `build_release.bat` script that will produce the .exe on any Windows 10/11 computer with Visual Studio 2022 (free Community edition is sufficient)
4. ✅ Packaged the complete project for download

**To get your .exe:** download the package, run `build_release.bat` on a Windows computer.
