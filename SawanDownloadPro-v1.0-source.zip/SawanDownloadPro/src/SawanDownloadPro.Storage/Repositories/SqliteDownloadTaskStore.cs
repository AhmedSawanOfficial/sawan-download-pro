using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Exceptions;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.Storage.Repositories
{
    /// <summary>
    /// SQLite-backed implementation of <see cref="IDownloadTaskStore"/>.
    /// </summary>
    public sealed class SqliteDownloadTaskStore : IDownloadTaskStore
    {
        private readonly SQLiteConnection _conn;
        private readonly ILogger _logger;
        private readonly ISecretProtector? _secretProtector;
        private readonly object _writeLock = new();

        public SqliteDownloadTaskStore(SQLiteConnection conn, ILogger logger, ISecretProtector? secretProtector = null)
        {
            _conn = conn;
            _logger = logger;
            _secretProtector = secretProtector;
        }

        public async Task<DownloadTask?> GetByIdAsync(string id)
        {
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM downloads WHERE id = @id";
            cmd.Parameters.AddWithValue("@id", id);
            using var reader = await cmd.ExecuteReaderAsync().ConfigureAwait(false);
            if (await reader.ReadAsync().ConfigureAwait(false))
            {
                var task = MapReader(reader);
                task.Segments = (await GetSegmentsAsync(id).ConfigureAwait(false)).ToList();
                return task;
            }
            return null;
        }

        public async Task<IReadOnlyList<DownloadTask>> GetAllAsync()
        {
            var list = new List<DownloadTask>();
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM downloads ORDER BY created_at DESC";
            using var reader = await cmd.ExecuteReaderAsync().ConfigureAwait(false);
            while (await reader.ReadAsync().ConfigureAwait(false)) list.Add(MapReader(reader));
            return list;
        }

        public async Task<IReadOnlyList<DownloadTask>> GetByStatusAsync(DownloadStatus status)
        {
            var list = new List<DownloadTask>();
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM downloads WHERE status = @s ORDER BY created_at DESC";
            cmd.Parameters.AddWithValue("@s", status.ToString());
            using var reader = await cmd.ExecuteReaderAsync().ConfigureAwait(false);
            while (await reader.ReadAsync().ConfigureAwait(false)) list.Add(MapReader(reader));
            return list;
        }

        public Task UpsertAsync(DownloadTask task) => Task.Run(() =>
        {
            lock (_writeLock)
            {
                byte[]? encPwd = null;
                if (!string.IsNullOrEmpty(task.AuthPassword) && _secretProtector != null)
                    encPwd = _secretProtector.Protect(task.AuthPassword);

                using var cmd = _conn.CreateCommand();
                cmd.CommandText = @"
INSERT OR REPLACE INTO downloads
(id, url, final_url, file_name, save_path, category, status, total_bytes, downloaded_bytes,
 created_at, started_at, completed_at, error_message, etag, last_modified, accept_ranges,
 connection_count, max_connections, priority, auth_scheme, auth_username, auth_password_enc,
 custom_headers_json, source, speed_limit_bps, part_file_path, meta_file_path, is_private)
VALUES
(@id, @url, @final_url, @file_name, @save_path, @category, @status, @total_bytes, @downloaded_bytes,
 @created_at, @started_at, @completed_at, @error_message, @etag, @last_modified, @accept_ranges,
 @connection_count, @max_connections, @priority, @auth_scheme, @auth_username, @auth_password_enc,
 @custom_headers_json, @source, @speed_limit_bps, @part_file_path, @meta_file_path, @is_private);";
                AddParam(cmd, "@id", task.Id);
                AddParam(cmd, "@url", task.Url);
                AddParam(cmd, "@final_url", task.FinalUrl);
                AddParam(cmd, "@file_name", task.FileName);
                AddParam(cmd, "@save_path", task.SavePath);
                AddParam(cmd, "@category", task.Category.ToString());
                AddParam(cmd, "@status", task.Status.ToString());
                AddParam(cmd, "@total_bytes", (object?)task.TotalBytes ?? DBNull.Value);
                AddParam(cmd, "@downloaded_bytes", task.DownloadedBytes);
                AddParam(cmd, "@created_at", task.CreatedAt.ToString("O"));
                AddParam(cmd, "@started_at", task.StartedAt.HasValue ? (object)task.StartedAt.Value.ToString("O") : DBNull.Value);
                AddParam(cmd, "@completed_at", task.CompletedAt.HasValue ? (object)task.CompletedAt.Value.ToString("O") : DBNull.Value);
                AddParam(cmd, "@error_message", (object?)task.ErrorMessage ?? DBNull.Value);
                AddParam(cmd, "@etag", (object?)task.ETag ?? DBNull.Value);
                AddParam(cmd, "@last_modified", (object?)task.LastModified ?? DBNull.Value);
                AddParam(cmd, "@accept_ranges", task.AcceptRanges ? 1 : 0);
                AddParam(cmd, "@connection_count", task.ActiveConnections);
                AddParam(cmd, "@max_connections", task.MaxConnections);
                AddParam(cmd, "@priority", (int)task.Priority);
                AddParam(cmd, "@auth_scheme", task.AuthScheme.ToString());
                AddParam(cmd, "@auth_username", (object?)task.AuthUsername ?? DBNull.Value);
                AddParam(cmd, "@auth_password_enc", (object?)encPwd ?? DBNull.Value);
                AddParam(cmd, "@custom_headers_json", task.CustomHeaders.Count > 0 ? JsonConvert.SerializeObject(task.CustomHeaders) : (object)DBNull.Value);
                AddParam(cmd, "@source", task.Source.ToString());
                AddParam(cmd, "@speed_limit_bps", (object?)task.SpeedLimitBytesPerSec ?? DBNull.Value);
                AddParam(cmd, "@part_file_path", (object?)task.PartFilePath ?? DBNull.Value);
                AddParam(cmd, "@meta_file_path", (object?)task.MetaFilePath ?? DBNull.Value);
                AddParam(cmd, "@is_private", task.IsPrivate ? 1 : 0);
                cmd.ExecuteNonQuery();
            }
            return Task.CompletedTask;
        });

        public async Task DeleteAsync(string id)
        {
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "DELETE FROM downloads WHERE id = @id; DELETE FROM segments WHERE download_id = @id;";
            cmd.Parameters.AddWithValue("@id", id);
            await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
        }

        public async Task UpdateStatusAsync(string id, DownloadStatus status, long downloadedBytes, string? errorMessage)
        {
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "UPDATE downloads SET status = @s, downloaded_bytes = @d, error_message = @e WHERE id = @id";
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@s", status.ToString());
            cmd.Parameters.AddWithValue("@d", downloadedBytes);
            cmd.Parameters.AddWithValue("@e", (object?)errorMessage ?? DBNull.Value);
            await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
        }

        public async Task UpdateSegmentsAsync(string downloadId, IEnumerable<SegmentInfo> segments)
        {
            using var tx = _conn.BeginTransaction();
            try
            {
                using (var del = _conn.CreateCommand())
                {
                    del.Transaction = tx;
                    del.CommandText = "DELETE FROM segments WHERE download_id = @id";
                    del.Parameters.AddWithValue("@id", downloadId);
                    del.ExecuteNonQuery();
                }
                foreach (var s in segments)
                {
                    using var ins = _conn.CreateCommand();
                    ins.Transaction = tx;
                    ins.CommandText = @"INSERT INTO segments (id, download_id, start_byte, end_byte, downloaded_bytes, position, status)
                                        VALUES (@id, @dl, @sb, @eb, @db, @pos, @st)";
                    ins.Parameters.AddWithValue("@id", s.Id);
                    ins.Parameters.AddWithValue("@dl", downloadId);
                    ins.Parameters.AddWithValue("@sb", s.StartByte);
                    ins.Parameters.AddWithValue("@eb", s.EndByte);
                    ins.Parameters.AddWithValue("@db", s.DownloadedBytes);
                    ins.Parameters.AddWithValue("@pos", s.Position);
                    ins.Parameters.AddWithValue("@st", s.Status.ToString());
                    ins.ExecuteNonQuery();
                }
                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
            await Task.CompletedTask;
        }

        public async Task<IReadOnlyList<SegmentInfo>> GetSegmentsAsync(string downloadId)
        {
            var list = new List<SegmentInfo>();
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM segments WHERE download_id = @id ORDER BY position";
            cmd.Parameters.AddWithValue("@id", downloadId);
            using var reader = await cmd.ExecuteReaderAsync().ConfigureAwait(false);
            while (await reader.ReadAsync().ConfigureAwait(false))
            {
                list.Add(new SegmentInfo
                {
                    Id = reader.GetString(reader.GetOrdinal("id")),
                    DownloadId = downloadId,
                    StartByte = reader.GetInt64(reader.GetOrdinal("start_byte")),
                    EndByte = reader.GetInt64(reader.GetOrdinal("end_byte")),
                    DownloadedBytes = reader.GetInt64(reader.GetOrdinal("downloaded_bytes")),
                    Position = reader.GetInt32(reader.GetOrdinal("position")),
                    Status = (SegmentStatus)Enum.Parse(typeof(SegmentStatus), reader.GetString(reader.GetOrdinal("status")))
                });
            }
            return list;
        }

        private DownloadTask MapReader(System.Data.Common.DbDataReader r)
        {
            var task = new DownloadTask
            {
                Id = r.GetString(r.GetOrdinal("id")),
                Url = r.GetString(r.GetOrdinal("url")),
                FinalUrl = r.IsDBNull(r.GetOrdinal("final_url")) ? string.Empty : r.GetString(r.GetOrdinal("final_url")),
                FileName = r.GetString(r.GetOrdinal("file_name")),
                SavePath = r.GetString(r.GetOrdinal("save_path")),
                Category = (DownloadCategory)Enum.Parse(typeof(DownloadCategory), r.GetString(r.GetOrdinal("category"))),
                Status = (DownloadStatus)Enum.Parse(typeof(DownloadStatus), r.GetString(r.GetOrdinal("status"))),
                TotalBytes = r.IsDBNull(r.GetOrdinal("total_bytes")) ? null : (long?)r.GetInt64(r.GetOrdinal("total_bytes")),
                DownloadedBytes = r.GetInt64(r.GetOrdinal("downloaded_bytes")),
                CreatedAt = DateTime.Parse(r.GetString(r.GetOrdinal("created_at")), null, System.Globalization.DateTimeStyles.RoundtripKind),
                StartedAt = r.IsDBNull(r.GetOrdinal("started_at")) ? null : (DateTime?)DateTime.Parse(r.GetString(r.GetOrdinal("started_at")), null, System.Globalization.DateTimeStyles.RoundtripKind),
                CompletedAt = r.IsDBNull(r.GetOrdinal("completed_at")) ? null : (DateTime?)DateTime.Parse(r.GetString(r.GetOrdinal("completed_at")), null, System.Globalization.DateTimeStyles.RoundtripKind),
                ErrorMessage = r.IsDBNull(r.GetOrdinal("error_message")) ? null : r.GetString(r.GetOrdinal("error_message")),
                ETag = r.IsDBNull(r.GetOrdinal("etag")) ? null : r.GetString(r.GetOrdinal("etag")),
                LastModified = r.IsDBNull(r.GetOrdinal("last_modified")) ? null : r.GetString(r.GetOrdinal("last_modified")),
                AcceptRanges = r.GetInt32(r.GetOrdinal("accept_ranges")) != 0,
                ActiveConnections = r.GetInt32(r.GetOrdinal("connection_count")),
                MaxConnections = r.GetInt32(r.GetOrdinal("max_connections")),
                Priority = (DownloadPriority)r.GetInt32(r.GetOrdinal("priority")),
                AuthScheme = (AuthenticationScheme)Enum.Parse(typeof(AuthenticationScheme), r.GetString(r.GetOrdinal("auth_scheme"))),
                AuthUsername = r.IsDBNull(r.GetOrdinal("auth_username")) ? null : r.GetString(r.GetOrdinal("auth_username")),
                Source = (DownloadSource)Enum.Parse(typeof(DownloadSource), r.GetString(r.GetOrdinal("source"))),
                SpeedLimitBytesPerSec = r.IsDBNull(r.GetOrdinal("speed_limit_bps")) ? null : (long?)r.GetInt64(r.GetOrdinal("speed_limit_bps")),
                PartFilePath = r.IsDBNull(r.GetOrdinal("part_file_path")) ? null : r.GetString(r.GetOrdinal("part_file_path")),
                MetaFilePath = r.IsDBNull(r.GetOrdinal("meta_file_path")) ? null : r.GetString(r.GetOrdinal("meta_file_path"))
            };

            // is_private was added in schema v2; tolerate its absence (legacy v1 rows).
            try
            {
                var idx = r.GetOrdinal("is_private");
                if (!r.IsDBNull(idx)) task.IsPrivate = r.GetInt32(idx) != 0;
            }
            catch { /* column not present on legacy v1 databases without the v2 migration */ }

            if (!r.IsDBNull(r.GetOrdinal("auth_password_enc")) && _secretProtector != null)
            {
                var enc = (byte[])r["auth_password_enc"];
                try { task.AuthPassword = _secretProtector.Unprotect(enc); } catch { /* wrong user/machine */ }
            }

            if (!r.IsDBNull(r.GetOrdinal("custom_headers_json")))
            {
                var json = r.GetString(r.GetOrdinal("custom_headers_json"));
                task.CustomHeaders = JsonConvert.DeserializeObject<Dictionary<string, string>>(json) ?? new();
            }
            return task;
        }

        private static void AddParam(SQLiteCommand cmd, string name, object value)
        {
            cmd.Parameters.AddWithValue(name, value ?? DBNull.Value);
        }
    }
}
