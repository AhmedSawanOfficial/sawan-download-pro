using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.Storage.Repositories
{
    /// <summary>
    /// SQLite-backed implementation of <see cref="ISettingsStore"/>. Stores the entire
    /// <see cref="AppSettings"/> object as a single JSON blob in the <c>settings</c> table.
    /// </summary>
    public sealed class SqliteSettingsStore : ISettingsStore
    {
        private readonly SQLiteConnection _conn;
        private readonly ILogger _logger;
        private const string Key = "app_settings_v1";

        public SqliteSettingsStore(SQLiteConnection conn, ILogger logger)
        {
            _conn = conn;
            _logger = logger;
        }

        public async Task<AppSettings> LoadAsync()
        {
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "SELECT value FROM settings WHERE key = @k";
            cmd.Parameters.AddWithValue("@k", Key);
            var result = await cmd.ExecuteScalarAsync().ConfigureAwait(false);
            if (result == null || result == DBNull.Value) return new AppSettings();
            try
            {
                return JsonConvert.DeserializeObject<AppSettings>((string)result) ?? new AppSettings();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Settings JSON deserialization failed; returning defaults");
                return new AppSettings();
            }
        }

        public async Task SaveAsync(AppSettings settings)
        {
            var json = JsonConvert.SerializeObject(settings, Formatting.Indented);
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (@k, @v, @t)";
            cmd.Parameters.AddWithValue("@k", Key);
            cmd.Parameters.AddWithValue("@v", json);
            cmd.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("O"));
            await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
        }

        public async Task ResetAsync()
        {
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "DELETE FROM settings WHERE key = @k";
            cmd.Parameters.AddWithValue("@k", Key);
            await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
        }
    }

    /// <summary>
    /// SQLite-backed implementation of <see cref="IHistoryStore"/>.
    /// </summary>
    public sealed class SqliteHistoryStore : IHistoryStore
    {
        private readonly SQLiteConnection _conn;
        private readonly ILogger _logger;

        public SqliteHistoryStore(SQLiteConnection conn, ILogger logger)
        {
            _conn = conn;
            _logger = logger;
        }

        public async Task AddAsync(HistoryEntry entry)
        {
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = @"INSERT OR REPLACE INTO history (id, download_id, url, file_name, category, completed_at, total_bytes, deleted)
                                VALUES (@id, @dl, @url, @fn, @cat, @ts, @tb, @del)";
            cmd.Parameters.AddWithValue("@id", entry.Id);
            cmd.Parameters.AddWithValue("@dl", (object?)entry.DownloadId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@url", entry.Url);
            cmd.Parameters.AddWithValue("@fn", entry.FileName);
            cmd.Parameters.AddWithValue("@cat", (object?)entry.Category?.ToString() ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@ts", entry.CompletedAt.ToString("O"));
            cmd.Parameters.AddWithValue("@tb", (object?)entry.TotalBytes ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@del", entry.Deleted ? 1 : 0);
            await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
        }

        public async Task<IReadOnlyList<HistoryEntry>> GetRecentAsync(int limit = 100)
        {
            var list = new System.Collections.Generic.List<HistoryEntry>();
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM history ORDER BY completed_at DESC LIMIT @l";
            cmd.Parameters.AddWithValue("@l", limit);
            using var reader = await cmd.ExecuteReaderAsync().ConfigureAwait(false);
            while (await reader.ReadAsync().ConfigureAwait(false))
            {
                list.Add(new HistoryEntry
                {
                    Id = reader.GetString(reader.GetOrdinal("id")),
                    DownloadId = reader.IsDBNull(reader.GetOrdinal("download_id")) ? null : reader.GetString(reader.GetOrdinal("download_id")),
                    Url = reader.GetString(reader.GetOrdinal("url")),
                    FileName = reader.GetString(reader.GetOrdinal("file_name")),
                    Category = reader.IsDBNull(reader.GetOrdinal("category")) ? null : (Core.Enums.DownloadCategory)Enum.Parse(typeof(Core.Enums.DownloadCategory), reader.GetString(reader.GetOrdinal("category"))),
                    CompletedAt = DateTime.Parse(reader.GetString(reader.GetOrdinal("completed_at")), null, System.Globalization.DateTimeStyles.RoundtripKind),
                    TotalBytes = reader.IsDBNull(reader.GetOrdinal("total_bytes")) ? null : (long?)reader.GetInt64(reader.GetOrdinal("total_bytes")),
                    Deleted = reader.GetInt32(reader.GetOrdinal("deleted")) != 0
                });
            }
            return list;
        }

        public async Task DeleteAsync(string id)
        {
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "DELETE FROM history WHERE id = @id";
            cmd.Parameters.AddWithValue("@id", id);
            await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
        }

        public async Task ClearAsync()
        {
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "DELETE FROM history";
            await cmd.ExecuteNonQueryAsync().ConfigureAwait(false);
        }
    }

    /// <summary>
    /// Creates and owns a single SQLiteConnection for the application lifetime.
    /// </summary>
    public sealed class SQLiteDatabase : IDisposable
    {
        public SQLiteConnection Connection { get; }

        public SQLiteDatabase(string dbPath, ILogger logger)
        {
            var dir = Path.GetDirectoryName(dbPath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);

            var csb = new SQLiteConnectionStringBuilder
            {
                DataSource = dbPath,
                Version = 3,
                JournalMode = SQLiteJournalModeEnum.Wal,
                // Synchronous mode is set via PRAGMA below (SQLiteConnectionStringBuilder
                // in System.Data.SQLite 1.0.118 does not expose a Synchronous property).
                Pooling = false,
                DefaultTimeout = 15
            };
            Connection = new SQLiteConnection(csb.ConnectionString);
            Connection.Open();

            // Apply PRAGMAs that must run per-connection.
            using (var pragma = Connection.CreateCommand())
            {
                pragma.CommandText = "PRAGMA foreign_keys = ON;";
                pragma.ExecuteNonQuery();
            }

            var migrator = new Migrations.MigrationRunner(Connection, logger);
            migrator.Run();
            logger.LogInformation("SQLite database opened at {Path}", dbPath);
        }

        public void Dispose()
        {
            try { Connection.Dispose(); } catch { /* swallow */ }
        }
    }
}
