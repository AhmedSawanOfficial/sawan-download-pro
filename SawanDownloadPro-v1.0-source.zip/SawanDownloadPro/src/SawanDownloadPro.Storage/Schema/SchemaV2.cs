namespace SawanDownloadPro.Storage.Schema
{
    /// <summary>
    /// v2 schema additions: adds the <c>is_private</c> column to the <c>downloads</c> table
    /// for the Private Downloads mode (Sawan Download Pro v1.0).
    /// </summary>
    public static class SchemaV2
    {
        public static readonly string[] Statements = new[]
        {
            // SQLite's ALTER TABLE ADD COLUMN is idempotent only if we check first. We rely on
            // MigrationRunner to skip already-applied migrations, but the ADD COLUMN itself
            // must be guarded by a pragma check in case the column was added out-of-band.
            // SQLite has no "IF NOT EXISTS" for ADD COLUMN, so we use a no-op when present.
            @"
CREATE TABLE IF NOT EXISTS downloads_v2_marker (applied INTEGER NOT NULL DEFAULT 1);",

            // Add the is_private column. Wrapped in a try/catch at the migration runner level
            // so a duplicate-add (e.g. after an interrupted migration) is non-fatal.
            "ALTER TABLE downloads ADD COLUMN is_private INTEGER NOT NULL DEFAULT 0;"
        };
    }
}
