namespace SawanDownloadPro.Storage.Schema
{
    /// <summary>
    /// Embedded SQL schema for v1. Applied on first run by <see cref="Migrations.MigrationRunner"/>.
    /// </summary>
    public static class SchemaV1
    {
        public const string CreateDownloads = @"
CREATE TABLE IF NOT EXISTS downloads (
    id                   TEXT PRIMARY KEY,
    url                  TEXT NOT NULL,
    final_url            TEXT,
    file_name            TEXT NOT NULL,
    save_path            TEXT NOT NULL,
    category             TEXT NOT NULL,
    status               TEXT NOT NULL,
    total_bytes          INTEGER,
    downloaded_bytes     INTEGER NOT NULL DEFAULT 0,
    created_at           TEXT NOT NULL,
    started_at           TEXT,
    completed_at         TEXT,
    error_message        TEXT,
    etag                 TEXT,
    last_modified        TEXT,
    accept_ranges        INTEGER NOT NULL DEFAULT 0,
    connection_count     INTEGER NOT NULL DEFAULT 0,
    max_connections      INTEGER NOT NULL DEFAULT 1,
    priority             INTEGER NOT NULL DEFAULT 1,
    auth_scheme          TEXT NOT NULL DEFAULT 'None',
    auth_username        TEXT,
    auth_password_enc    BLOB,
    custom_headers_json  TEXT,
    source               TEXT NOT NULL DEFAULT 'Manual',
    speed_limit_bps      INTEGER,
    part_file_path       TEXT,
    meta_file_path       TEXT
);";

        public const string CreateSegments = @"
CREATE TABLE IF NOT EXISTS segments (
    id                 TEXT PRIMARY KEY,
    download_id        TEXT NOT NULL,
    start_byte         INTEGER NOT NULL,
    end_byte           INTEGER NOT NULL,
    downloaded_bytes   INTEGER NOT NULL DEFAULT 0,
    position           INTEGER NOT NULL,
    status             TEXT NOT NULL,
    FOREIGN KEY (download_id) REFERENCES downloads(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_segments_download_id ON segments(download_id);";

        public const string CreateSettings = @"
CREATE TABLE IF NOT EXISTS settings (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at TEXT NOT NULL
);";

        public const string CreateHistory = @"
CREATE TABLE IF NOT EXISTS history (
    id           TEXT PRIMARY KEY,
    download_id  TEXT,
    url          TEXT NOT NULL,
    file_name    TEXT NOT NULL,
    category     TEXT,
    completed_at TEXT NOT NULL,
    total_bytes  INTEGER,
    deleted      INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_history_completed_at ON history(completed_at DESC);";

        public const string CreateSchemaMigrations = @"
CREATE TABLE IF NOT EXISTS schema_migrations (
    version     INTEGER PRIMARY KEY,
    applied_at  TEXT NOT NULL
);";
    }
}
