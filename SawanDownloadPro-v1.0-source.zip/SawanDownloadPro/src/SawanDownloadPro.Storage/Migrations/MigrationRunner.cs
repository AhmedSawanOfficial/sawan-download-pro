using System;
using System.Data.SQLite;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Storage.Schema;

namespace SawanDownloadPro.Storage.Migrations
{
    /// <summary>
    /// Applies schema migrations on startup. Tracks applied versions in the schema_migrations table.
    /// </summary>
    public sealed class MigrationRunner
    {
        private readonly SQLiteConnection _conn;
        private readonly ILogger _logger;

        public MigrationRunner(SQLiteConnection conn, ILogger logger)
        {
            _conn = conn;
            _logger = logger;
        }

        public void Run()
        {
            EnsureMigrationsTable();
            Apply(1, "Initial schema", new[]
            {
                SchemaV1.CreateDownloads,
                SchemaV1.CreateSegments,
                SchemaV1.CreateSettings,
                SchemaV1.CreateHistory
            });

            // v2 adds the is_private column for the Private Downloads mode (v1.0 feature).
            // ALTER TABLE ADD COLUMN is non-transactional in SQLite and throws if the column
            // already exists, so we guard it with a column-existence probe and tolerate the
            // duplicate-add case (e.g. when a v1.0 install was upgraded mid-migration).
            if (!IsApplied(2))
            {
                if (!ColumnExists("downloads", "is_private"))
                {
                    Apply(2, "Add is_private column to downloads", SchemaV2.Statements);
                }
                else
                {
                    // Column already present (e.g. restored from backup) — just record the migration.
                    MarkApplied(2);
                }
            }
        }

        private bool ColumnExists(string tableName, string columnName)
        {
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = $"PRAGMA table_info({tableName});";
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                var name = reader["name"] as string;
                if (string.Equals(name, columnName, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        private void MarkApplied(int version)
        {
            using var ins = _conn.CreateCommand();
            ins.CommandText = "INSERT OR IGNORE INTO schema_migrations (version, applied_at) VALUES (@v, @t)";
            ins.Parameters.AddWithValue("@v", version);
            ins.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("O"));
            ins.ExecuteNonQuery();
        }

        private void EnsureMigrationsTable()
        {
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = SchemaV1.CreateSchemaMigrations;
            cmd.ExecuteNonQuery();
        }

        private void Apply(int version, string description, string[] sqlStatements)
        {
            if (IsApplied(version)) return;
            _logger.LogInformation("Applying schema migration v{Version}: {Description}", version, description);

            using var tx = _conn.BeginTransaction();
            try
            {
                foreach (var sql in sqlStatements)
                {
                    using var cmd = _conn.CreateCommand();
                    cmd.Transaction = tx;
                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();
                }

                using var ins = _conn.CreateCommand();
                ins.Transaction = tx;
                ins.CommandText = "INSERT INTO schema_migrations (version, applied_at) VALUES (@v, @t)";
                ins.Parameters.AddWithValue("@v", version);
                ins.Parameters.AddWithValue("@t", DateTime.UtcNow.ToString("O"));
                ins.ExecuteNonQuery();

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        private bool IsApplied(int version)
        {
            using var cmd = _conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM schema_migrations WHERE version = @v";
            cmd.Parameters.AddWithValue("@v", version);
            return Convert.ToInt64(cmd.ExecuteScalar()) > 0;
        }
    }
}
