using System;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.App.ViewModels
{
    /// <summary>
    /// View model for the Settings window. Loads and saves <see cref="AppSettings"/>.
    /// </summary>
    public sealed partial class SettingsViewModel : ObservableObject
    {
        private readonly ISettingsStore _store;
        private readonly ILogger<SettingsViewModel> _logger;

        // General
        [ObservableProperty] private bool _startWithWindows;
        [ObservableProperty] private bool _minimizeToTray;
        [ObservableProperty] private bool _startMinimized;
        [ObservableProperty] private bool _closeToTray;
        [ObservableProperty] private bool _confirmExit;
        [ObservableProperty] private bool _confirmDelete;

        // Downloads
        [ObservableProperty] private string _defaultDownloadDirectory = string.Empty;
        [ObservableProperty] private string _tempDirectory = string.Empty;
        [ObservableProperty] private int _maxSimultaneousDownloads;
        [ObservableProperty] private int _maxConnectionsPerDownload;
        [ObservableProperty] private int _maxRetryAttempts;

        // Network
        [ObservableProperty] private long _globalSpeedLimitBytesPerSec;
        [ObservableProperty] private int _connectionTimeoutSec;
        [ObservableProperty] private bool _forceTls12;
        [ObservableProperty] private bool _useProxy;
        [ObservableProperty] private string _proxyHost = string.Empty;
        [ObservableProperty] private int _proxyPort;

        // Browser integration
        [ObservableProperty] private bool _enableChromeIntegration;
        [ObservableProperty] private bool _enableEdgeIntegration;
        [ObservableProperty] private bool _enableFirefoxIntegration;
        [ObservableProperty] private bool _enableOperaIntegration;
        [ObservableProperty] private bool _enableBraveIntegration;
        [ObservableProperty] private bool _enableVivaldiIntegration;

        // Appearance
        [ObservableProperty] private AppTheme _theme;
        [ObservableProperty] private AppLanguage _language;
        [ObservableProperty] private int _fontSize;
        [ObservableProperty] private string? _customAccentColor;

        // Privacy / Private Downloads
        [ObservableProperty] private bool _enablePrivateDownloadsMode;
        [ObservableProperty] private bool _enableBrowserPrivateModeIntegration;
        [ObservableProperty] private bool _autoDeletePrivateSessionMetadataOnExit;
        [ObservableProperty] private bool _retainPrivateSessionDownloadedFiles;
        [ObservableProperty] private bool _neverMixPrivateUrlsIntoStandardHistory;
        [ObservableProperty] private int  _historyRetentionDays;
        [ObservableProperty] private bool _enableTelemetry;

        // First-run
        [ObservableProperty] private bool _firstRunCompleted;

        // Notifications
        [ObservableProperty] private bool _notifyOnComplete;
        [ObservableProperty] private bool _notifyOnFailure;
        [ObservableProperty] private bool _notifyOnQueueComplete;
        [ObservableProperty] private bool _playSoundOnComplete;
        [ObservableProperty] private bool _playSoundOnFailure;

        // Advanced
        [ObservableProperty] private string _logDirectory = string.Empty;
        [ObservableProperty] private bool _verboseLogging;

        // Media
        [ObservableProperty] private string _ffmpegPath = string.Empty;
        [ObservableProperty] private string _ytDlpPath = string.Empty;

        // Security
        [ObservableProperty] private bool _warnOnDangerousExtensions;

        public AppSettings? BackingSettings { get; private set; }

        public SettingsViewModel(ISettingsStore store, ILogger<SettingsViewModel> logger)
        {
            _store = store;
            _logger = logger;
        }

        public async Task LoadAsync()
        {
            BackingSettings = await _store.LoadAsync().ConfigureAwait(true);
            var s = BackingSettings;

            StartWithWindows = s.StartWithWindows;
            MinimizeToTray = s.MinimizeToTray;
            StartMinimized = s.StartMinimized;
            CloseToTray = s.CloseToTray;
            ConfirmExit = s.ConfirmBeforeExit;
            ConfirmDelete = s.ConfirmBeforeDeleteFile;

            DefaultDownloadDirectory = s.DefaultDownloadDirectory;
            TempDirectory = s.TempDirectory;
            MaxSimultaneousDownloads = s.MaxSimultaneousDownloads;
            MaxConnectionsPerDownload = s.MaxConnectionsPerDownload;
            MaxRetryAttempts = s.MaxRetryAttempts;

            GlobalSpeedLimitBytesPerSec = s.GlobalSpeedLimitBytesPerSec;
            ConnectionTimeoutSec = s.ConnectionTimeoutSec;
            ForceTls12 = s.ForceTls12;
            UseProxy = s.UseProxy;
            ProxyHost = s.ProxyHost;
            ProxyPort = s.ProxyPort;

            EnableChromeIntegration = s.EnableChromeIntegration;
            EnableEdgeIntegration = s.EnableEdgeIntegration;
            EnableFirefoxIntegration = s.EnableFirefoxIntegration;
            EnableOperaIntegration = s.EnableOperaIntegration;
            EnableBraveIntegration = s.EnableBraveIntegration;
            EnableVivaldiIntegration = s.EnableVivaldiIntegration;

            Theme = s.Theme;
            Language = s.Language;
            FontSize = s.FontSize;
            CustomAccentColor = s.CustomAccentColor;

            EnablePrivateDownloadsMode = s.EnablePrivateDownloadsMode;
            EnableBrowserPrivateModeIntegration = s.EnableBrowserPrivateModeIntegration;
            AutoDeletePrivateSessionMetadataOnExit = s.AutoDeletePrivateSessionMetadataOnExit;
            RetainPrivateSessionDownloadedFiles = s.RetainPrivateSessionDownloadedFiles;
            NeverMixPrivateUrlsIntoStandardHistory = s.NeverMixPrivateUrlsIntoStandardHistory;
            HistoryRetentionDays = s.HistoryRetentionDays;
            EnableTelemetry = s.EnableTelemetry;
            FirstRunCompleted = s.FirstRunCompleted;

            NotifyOnComplete = s.NotifyOnComplete;
            NotifyOnFailure = s.NotifyOnFailure;
            NotifyOnQueueComplete = s.NotifyOnQueueComplete;
            PlaySoundOnComplete = s.PlaySoundOnComplete;
            PlaySoundOnFailure = s.PlaySoundOnFailure;

            LogDirectory = s.LogDirectory;
            VerboseLogging = s.VerboseLogging;

            FFmpegPath = s.FFmpegPath;
            YtDlpPath = s.YtDlpPath;

            WarnOnDangerousExtensions = s.WarnOnDangerousExtensions;
        }

        [RelayCommand]
        private async Task SaveAsync()
        {
            if (BackingSettings == null) return;
            BackingSettings.StartWithWindows = StartWithWindows;
            BackingSettings.MinimizeToTray = MinimizeToTray;
            BackingSettings.StartMinimized = StartMinimized;
            BackingSettings.CloseToTray = CloseToTray;
            BackingSettings.ConfirmBeforeExit = ConfirmExit;
            BackingSettings.ConfirmBeforeDeleteFile = ConfirmDelete;

            BackingSettings.DefaultDownloadDirectory = DefaultDownloadDirectory;
            BackingSettings.TempDirectory = TempDirectory;
            BackingSettings.MaxSimultaneousDownloads = MaxSimultaneousDownloads;
            BackingSettings.MaxConnectionsPerDownload = MaxConnectionsPerDownload;
            BackingSettings.MaxRetryAttempts = MaxRetryAttempts;

            BackingSettings.GlobalSpeedLimitBytesPerSec = GlobalSpeedLimitBytesPerSec;
            BackingSettings.ConnectionTimeoutSec = ConnectionTimeoutSec;
            BackingSettings.ForceTls12 = ForceTls12;
            BackingSettings.UseProxy = UseProxy;
            BackingSettings.ProxyHost = ProxyHost;
            BackingSettings.ProxyPort = ProxyPort;

            BackingSettings.EnableChromeIntegration = EnableChromeIntegration;
            BackingSettings.EnableEdgeIntegration = EnableEdgeIntegration;
            BackingSettings.EnableFirefoxIntegration = EnableFirefoxIntegration;
            BackingSettings.EnableOperaIntegration = EnableOperaIntegration;
            BackingSettings.EnableBraveIntegration = EnableBraveIntegration;
            BackingSettings.EnableVivaldiIntegration = EnableVivaldiIntegration;

            BackingSettings.Theme = Theme;
            BackingSettings.Language = Language;
            BackingSettings.FontSize = FontSize;
            BackingSettings.CustomAccentColor = CustomAccentColor;

            BackingSettings.EnablePrivateDownloadsMode = EnablePrivateDownloadsMode;
            BackingSettings.EnableBrowserPrivateModeIntegration = EnableBrowserPrivateModeIntegration;
            BackingSettings.AutoDeletePrivateSessionMetadataOnExit = AutoDeletePrivateSessionMetadataOnExit;
            BackingSettings.RetainPrivateSessionDownloadedFiles = RetainPrivateSessionDownloadedFiles;
            BackingSettings.NeverMixPrivateUrlsIntoStandardHistory = NeverMixPrivateUrlsIntoStandardHistory;
            BackingSettings.HistoryRetentionDays = HistoryRetentionDays;
            BackingSettings.EnableTelemetry = EnableTelemetry;
            BackingSettings.FirstRunCompleted = FirstRunCompleted;

            BackingSettings.NotifyOnComplete = NotifyOnComplete;
            BackingSettings.NotifyOnFailure = NotifyOnFailure;
            BackingSettings.NotifyOnQueueComplete = NotifyOnQueueComplete;
            BackingSettings.PlaySoundOnComplete = PlaySoundOnComplete;
            BackingSettings.PlaySoundOnFailure = PlaySoundOnFailure;

            BackingSettings.LogDirectory = LogDirectory;
            BackingSettings.VerboseLogging = VerboseLogging;

            BackingSettings.FFmpegPath = FFmpegPath;
            BackingSettings.YtDlpPath = YtDlpPath;

            BackingSettings.WarnOnDangerousExtensions = WarnOnDangerousExtensions;

            await _store.SaveAsync(BackingSettings).ConfigureAwait(true);
            _logger.LogInformation("Settings saved");
        }

        [RelayCommand]
        private async Task ResetAsync()
        {
            await _store.ResetAsync().ConfigureAwait(true);
            await LoadAsync().ConfigureAwait(true);
        }
    }
}
