using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;
using SawanDownloadPro.Security.Validation;

namespace SawanDownloadPro.App.ViewModels
{
    /// <summary>
    /// View model for the "Add Download" dialog.
    /// Probes the URL on user request, then returns a populated DownloadTask when the user confirms.
    /// </summary>
    public sealed partial class AddDownloadViewModel : ObservableObject
    {
        private readonly IDownloadEngine _engine;
        private readonly ISettingsStore _settingsStore;
        private readonly IUrlValidator _urlValidator;
        private readonly IPathSanitizer _pathSanitizer;
        private readonly ILogger<AddDownloadViewModel> _logger;

        [ObservableProperty] private string _url = string.Empty;
        [ObservableProperty] private string _fileName = string.Empty;
        [ObservableProperty] private string _saveLocation = string.Empty;
        [ObservableProperty] private DownloadCategory _category = DownloadCategory.Other;
        [ObservableProperty] private int _connectionLimit = 8;
        [ObservableProperty] private bool _useAuth;
        [ObservableProperty] private string _username = string.Empty;
        [ObservableProperty] private string _password = string.Empty;
        [ObservableProperty] private string _customHeadersJson = string.Empty;

        [ObservableProperty] private bool _isProbing;
        [ObservableProperty] private string _probeStatus = string.Empty;
        [ObservableProperty] private string _detectedSize = string.Empty;
        [ObservableProperty] private bool _acceptRanges;
        [ObservableProperty] private bool _canDownload;

        public ObservableCollection<DownloadCategory> Categories { get; } = new()
        {
            DownloadCategory.Other, DownloadCategory.Videos, DownloadCategory.Music,
            DownloadCategory.Documents, DownloadCategory.Compressed, DownloadCategory.Programs
        };

        public DownloadTask? Result { get; private set; }
        public bool StartImmediately { get; private set; }

        public AddDownloadViewModel(IDownloadEngine engine,
                                      ISettingsStore settingsStore,
                                      IUrlValidator urlValidator,
                                      IPathSanitizer pathSanitizer,
                                      ILogger<AddDownloadViewModel> logger)
        {
            _engine = engine;
            _settingsStore = settingsStore;
            _urlValidator = urlValidator;
            _pathSanitizer = pathSanitizer;
            _logger = logger;

            _ = LoadDefaultsAsync();
        }

        private async Task LoadDefaultsAsync()
        {
            var s = await _settingsStore.LoadAsync().ConfigureAwait(true);
            SaveLocation = s.DefaultDownloadDirectory;
        }

        [RelayCommand]
        private async Task ProbeAsync()
        {
            if (string.IsNullOrWhiteSpace(Url)) return;
            if (!_urlValidator.IsValid(Url))
            {
                ProbeStatus = "Invalid URL";
                CanDownload = false;
                return;
            }

            IsProbing = true;
            ProbeStatus = "Probing...";
            CanDownload = false;
            try
            {
                var meta = await _engine.ProbeAsync(Url, AuthenticationScheme.None, null, null, null, default).ConfigureAwait(true);
                if (!meta.Success)
                {
                    ProbeStatus = $"Probe failed: {meta.ErrorMessage}";
                    return;
                }
                if (!string.IsNullOrWhiteSpace(meta.FileName)) FileName = meta.FileName;
                DetectedSize = meta.ContentLength.HasValue ? FormatBytes(meta.ContentLength.Value) : "Unknown";
                AcceptRanges = meta.AcceptRanges;
                ProbeStatus = "Ready";
                CanDownload = true;
            }
            catch (Exception ex)
            {
                ProbeStatus = $"Probe failed: {ex.Message}";
            }
            finally
            {
                IsProbing = false;
            }
        }

        [RelayCommand]
        private void DownloadNow() => Confirm(startImmediately: true);

        [RelayCommand]
        private void AddToQueue() => Confirm(startImmediately: false);

        private void Confirm(bool startImmediately)
        {
            if (string.IsNullOrWhiteSpace(Url) || string.IsNullOrWhiteSpace(FileName))
            {
                MessageBox.Show("URL and file name are required.", "Sawan", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            try
            {
                var safeName = _pathSanitizer.SanitizeFileName(FileName);
                var combined = _pathSanitizer.SanitizeAndCombinePath(SaveLocation, safeName);

                Result = new DownloadTask
                {
                    Url = Url,
                    FileName = safeName,
                    SavePath = SaveLocation,
                    Category = Category,
                    MaxConnections = ConnectionLimit,
                    Priority = DownloadPriority.Normal,
                    AuthScheme = UseAuth ? AuthenticationScheme.Basic : AuthenticationScheme.None,
                    AuthUsername = UseAuth ? Username : null,
                    AuthPassword = UseAuth ? Password : null,
                    Source = DownloadSource.Manual,
                    Status = DownloadStatus.Queued
                };
                StartImmediately = startImmediately;
                _logger.LogInformation("Add dialog confirmed: {Url} → {File}", Url, safeName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Sawan — Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private static string FormatBytes(long bytes)
        {
            if (bytes < 1024) return $"{bytes} B";
            if (bytes < 1024 * 1024) return $"{bytes / 1024.0:F1} KB";
            if (bytes < 1024L * 1024 * 1024) return $"{bytes / (1024.0 * 1024):F1} MB";
            return $"{bytes / (1024.0 * 1024 * 1024):F2} GB";
        }
    }
}
