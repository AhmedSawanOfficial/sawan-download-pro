using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Events;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;
using SawanDownloadPro.Scheduler;

namespace SawanDownloadPro.App.ViewModels
{
    /// <summary>
    /// Main window view model. Binds to the download list, sidebar filter, status bar,
    /// and exposes commands for all toolbar/context-menu actions.
    /// </summary>
    public sealed partial class MainViewModel : ObservableObject, IDisposable
    {
        private readonly DownloadScheduler _scheduler;
        private readonly IDownloadTaskStore _store;
        private readonly ISettingsStore _settingsStore;
        private readonly IUrlValidator _urlValidator;
        private readonly IPathSanitizer _pathSanitizer;
        private readonly ILogger<MainViewModel> _logger;
        private readonly SemaphoreSlim _refreshLock = new(1, 1);

        public ObservableCollection<DownloadTaskViewModel> Downloads { get; } = new();

        [ObservableProperty]
        private string _searchText = string.Empty;

        [ObservableProperty]
        private SidebarFilter _currentFilter = SidebarFilter.All;

        [ObservableProperty]
        private int _activeCount;

        [ObservableProperty]
        private long _aggregateSpeedBytesPerSec;

        [ObservableProperty]
        private long _totalDownloadedBytes;

        [ObservableProperty]
        private string _queueStatusText = string.Empty;

        [ObservableProperty]
        private DownloadTaskViewModel? _selectedTask;

        public MainViewModel(DownloadScheduler scheduler,
                              IDownloadTaskStore store,
                              ISettingsStore settingsStore,
                              IUrlValidator urlValidator,
                              IPathSanitizer pathSanitizer,
                              ILogger<MainViewModel> logger)
        {
            _scheduler = scheduler;
            _store = store;
            _settingsStore = settingsStore;
            _urlValidator = urlValidator;
            _pathSanitizer = pathSanitizer;
            _logger = logger;

            _scheduler.QueueStateChanged += OnQueueStateChanged;
        }

        public async Task LoadAsync()
        {
            var all = await _store.GetAllAsync().ConfigureAwait(true);
            Downloads.Clear();
            foreach (var t in all) Downloads.Add(new DownloadTaskViewModel(t));
        }

        public void ApplyFilter()
        {
            foreach (var vm in Downloads) vm.IsVisible = MatchesFilter(vm.Task));
        }

        private bool MatchesFilter(DownloadTask t)
        {
            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                if (!t.FileName.Contains(SearchText, StringComparison.OrdinalIgnoreCase) &&
                    !t.Url.Contains(SearchText, StringComparison.OrdinalIgnoreCase)) return false;
            }
            return CurrentFilter switch
            {
                SidebarFilter.All => true,
                SidebarFilter.Downloading => t.Status == DownloadStatus.Downloading || t.Status == DownloadStatus.Resolving || t.Status == DownloadStatus.WaitingForRetry,
                SidebarFilter.Queued => t.Status == DownloadStatus.Queued,
                SidebarFilter.Completed => t.Status == DownloadStatus.Completed,
                SidebarFilter.Paused => t.Status == DownloadStatus.Paused,
                SidebarFilter.Failed => t.Status == DownloadStatus.Failed,
                SidebarFilter.Videos => t.Category == DownloadCategory.Videos,
                SidebarFilter.Music => t.Category == DownloadCategory.Music,
                SidebarFilter.Documents => t.Category == DownloadCategory.Documents,
                SidebarFilter.Compressed => t.Category == DownloadCategory.Compressed,
                SidebarFilter.Programs => t.Category == DownloadCategory.Programs,
                _ => true
            };
        }

        [RelayCommand]
        private async Task AddDownloadAsync(DownloadTask task)
        {
            if (!_urlValidator.IsValid(task.Url))
            {
                MessageBox.Show("Invalid URL. Only http, https, and ftp are supported.", "Sawan", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            try
            {
                task.FileName = _pathSanitizer.SanitizeFileName(task.FileName);
                await _store.UpsertAsync(task).ConfigureAwait(true);
                Downloads.Insert(0, new DownloadTaskViewModel(task));
                _scheduler.Enqueue(task);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to add download");
                MessageBox.Show(ex.Message, "Sawan — Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        [RelayCommand]
        private void StartAll() => _scheduler.StartAll();

        [RelayCommand]
        private void PauseAll() => _scheduler.PauseAll();

        [RelayCommand]
        private void StopAll() => _scheduler.StopAll();

        [RelayCommand]
        private void PauseSelected()
        {
            if (SelectedTask != null) _scheduler.Pause(SelectedTask.Task);
        }

        [RelayCommand]
        private void ResumeSelected()
        {
            if (SelectedTask != null) _scheduler.Resume(SelectedTask.Task);
        }

        [RelayCommand]
        private void CancelSelected()
        {
            if (SelectedTask != null) _scheduler.Cancel(SelectedTask.Task);
        }

        [RelayCommand]
        private async Task RemoveSelectedAsync(bool deleteFile)
        {
            if (SelectedTask == null) return;
            if (deleteFile && SelectedTask.Task.Status == DownloadStatus.Completed)
            {
                var msg = "Are you sure you want to delete the downloaded file? This cannot be undone.";
                if (MessageBox.Show(msg, "Confirm delete", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
                try { System.IO.File.Delete(System.IO.Path.Combine(SelectedTask.Task.SavePath, SelectedTask.Task.FileName)); } catch (Exception ex) { _logger.LogWarning(ex, "Could not delete file"); }
            }
            _scheduler.Cancel(SelectedTask.Task);
            await _store.DeleteAsync(SelectedTask.Task.Id).ConfigureAwait(true);
            Downloads.Remove(SelectedTask);
        }

        [RelayCommand]
        private void OpenFolder()
        {
            if (SelectedTask != null)
            {
                var path = System.IO.Path.Combine(SelectedTask.Task.SavePath, SelectedTask.Task.FileName);
                if (!System.IO.File.Exists(path)) path = SelectedTask.Task.SavePath;
                try { System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{path}\""); } catch { }
            }
        }

        [RelayCommand]
        private void CopyUrl()
        {
            if (SelectedTask != null) Clipboard.SetText(SelectedTask.Task.Url);
        }

        // --- Toolbar navigation commands (open child windows) ---

        [RelayCommand]
        private void ShowAddDownload()
        {
            var dialog = new Views.Dialogs.AddDownloadDialog(App.Services.GetRequiredService<AddDownloadViewModel>());
            dialog.ShowDialog();
            if (dialog.ViewModel.Result != null)
            {
                _ = AddDownloadAsync(dialog.ViewModel.Result);
                if (dialog.ViewModel.StartImmediately) _scheduler.Resume(dialog.ViewModel.Result);
            }
        }

        [RelayCommand]
        private void PasteFromClipboard()
        {
            if (Clipboard.ContainsText())
            {
                var text = Clipboard.GetText().Trim();
                if (_urlValidator.IsValid(text))
                {
                    var addVm = App.Services.GetRequiredService<AddDownloadViewModel>();
                    addVm.Url = text;
                    var dialog = new Views.Dialogs.AddDownloadDialog(addVm);
                    dialog.ShowDialog();
                    if (addVm.Result != null)
                    {
                        _ = AddDownloadAsync(addVm.Result);
                        if (addVm.StartImmediately) _scheduler.Resume(addVm.Result);
                    }
                }
                else
                {
                    MessageBox.Show("Clipboard does not contain a valid download URL.",
                        "Sawan", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        [RelayCommand]
        private void ShowSettings()
        {
            var settingsVm = App.Services.GetRequiredService<SettingsViewModel>();
            _ = settingsVm.LoadAsync().ContinueWith(_ => { });
            var window = new Views.Windows.SettingsWindow(settingsVm);
            window.ShowDialog();
        }

        [RelayCommand]
        private void ShowVideoDownloader()
        {
            var vm = App.Services.GetRequiredService<VideoDownloaderViewModel>();
            var window = new Views.Windows.VideoDownloaderWindow(vm);
            window.ShowDialog();
        }

        [RelayCommand]
        private void ShowScheduler()
        {
            MessageBox.Show("Scheduler window — to be implemented in v1.1. The scheduler is already running in the background; use Start All / Pause All / Stop All to control it.",
                "Sawan", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void OnQueueStateChanged(object? sender, QueueStateChangedEventArgs e)
        {
            ActiveCount = e.ActiveCount;
            AggregateSpeedBytesPerSec = e.AggregateSpeedBytesPerSec;
            QueueStatusText = $"{e.ActiveCount} active, {e.QueuedCount} queued";
        }

        public void Dispose()
        {
            _scheduler.QueueStateChanged -= OnQueueStateChanged;
            _refreshLock.Dispose();
        }
    }

    public enum SidebarFilter
    {
        All,
        Downloading,
        Queued,
        Completed,
        Paused,
        Failed,
        Videos,
        Music,
        Documents,
        Compressed,
        Programs
    }

    /// <summary>
    /// Per-row view model. Wraps a DownloadTask and exposes bindable progress/speed/status.
    /// </summary>
    public sealed class DownloadTaskViewModel : ObservableObject
    {
        public DownloadTask Task { get; }

        public DownloadTaskViewModel(DownloadTask task) => Task = task;

        public string FileName => Task.FileName;
        public string Url => Task.Url;
        public string Host => Uri.TryCreate(Task.Url, UriKind.Absolute, out var u) ? u.Host : Task.Url;

        public DownloadStatus Status
        {
            get => Task.Status;
            set { Task.Status = value; OnPropertyChanged(); OnPropertyChanged(nameof(StatusText)); OnPropertyChanged(nameof(IsCompleted)); OnPropertyChanged(nameof(IsFailed)); }
        }

        public string StatusText => Task.Status switch
        {
            DownloadStatus.Queued => "Queued",
            DownloadStatus.Downloading => "Downloading",
            DownloadStatus.Paused => "Paused",
            DownloadStatus.Completed => "Completed",
            DownloadStatus.Failed => "Failed",
            DownloadStatus.Stopped => "Stopped",
            DownloadStatus.WaitingForRetry => "Waiting for retry",
            DownloadStatus.Resolving => "Resolving",
            _ => Task.Status.ToString()
        };

        public long? TotalBytes => Task.TotalBytes;
        public long DownloadedBytes
        {
            get => Task.DownloadedBytes;
            set { Task.DownloadedBytes = value; OnPropertyChanged(); OnPropertyChanged(nameof(ProgressPercent)); OnPropertyChanged(nameof(ProgressText)); }
        }

        public double ProgressPercent => Task.TotalBytes.HasValue && Task.TotalBytes.Value > 0
            ? Math.Min(100.0, Task.DownloadedBytes * 100.0 / Task.TotalBytes.Value)
            : 0;

        public string ProgressText => Task.TotalBytes.HasValue
            ? $"{FormatBytes(Task.DownloadedBytes)} / {FormatBytes(Task.TotalBytes.Value)} ({ProgressPercent:F1}%)"
            : $"{FormatBytes(Task.DownloadedBytes)} (size unknown)";

        public long CurrentSpeed
        {
            get => Task.CurrentSpeed;
            set { Task.CurrentSpeed = value; OnPropertyChanged(); OnPropertyChanged(nameof(SpeedText)); }
        }
        public string SpeedText => Task.Status == DownloadStatus.Downloading && Task.CurrentSpeed > 0
            ? FormatBytes(Task.CurrentSpeed) + "/s"
            : "—";

        public int ActiveConnections
        {
            get => Task.ActiveConnections;
            set { Task.ActiveConnections = value; OnPropertyChanged(); }
        }

        public bool IsCompleted => Task.Status == DownloadStatus.Completed;
        public bool IsFailed => Task.Status == DownloadStatus.Failed;

        private bool _isVisible = true;
        public bool IsVisible { get => _isVisible; set => SetProperty(ref _isVisible, value); }

        public string CategoryIcon => Task.Category switch
        {
            DownloadCategory.Videos => "🎬",
            DownloadCategory.Music => "🎵",
            DownloadCategory.Documents => "📄",
            DownloadCategory.Compressed => "🗜",
            DownloadCategory.Programs => "⚙",
            _ => "📁"
        };

        private static string FormatBytes(long bytes)
        {
            if (bytes < 1024) return $"{bytes} B";
            if (bytes < 1024 * 1024) return $"{bytes / 1024.0:F1} KB";
            if (bytes < 1024L * 1024 * 1024) return $"{bytes / (1024.0 * 1024):F1} MB";
            return $"{bytes / (1024.0 * 1024 * 1024):F2} GB";
        }
    }
}
