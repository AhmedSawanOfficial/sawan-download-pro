using System;
using System.Collections.ObjectModel;
using System.Threading;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;
using SawanDownloadPro.Media;
using SawanDownloadPro.Media.Extractors;

namespace SawanDownloadPro.App.ViewModels
{
    /// <summary>
    /// View model for the Video Downloader dialog. Uses <see cref="MediaConverter"/> to probe
    /// and download supported video sources, with explicit authorization caveats.
    /// </summary>
    public sealed partial class VideoDownloaderViewModel : ObservableObject
    {
        private readonly MediaConverter _converter;
        private readonly ISettingsStore _settingsStore;
        private readonly ILogger<VideoDownloaderViewModel> _logger;

        [ObservableProperty] private string _url = string.Empty;
        [ObservableProperty] private bool _isBusy;
        [ObservableProperty] private string _status = string.Empty;
        [ObservableProperty] private string _videoTitle = string.Empty;
        [ObservableProperty] private string _videoThumbnailUrl = string.Empty;
        [ObservableProperty] private string _videoDuration = string.Empty;
        [ObservableProperty] private string _videoAuthor = string.Empty;
        [ObservableProperty] private VideoFormat? _selectedFormat;
        [ObservableProperty] private int _downloadProgress;

        public ObservableCollection<VideoFormat> Formats { get; } = new();

        public VideoDownloaderViewModel(MediaConverter converter, ISettingsStore settingsStore, ILogger<VideoDownloaderViewModel> logger)
        {
            _converter = converter;
            _settingsStore = settingsStore;
            _logger = logger;
        }

        [RelayCommand]
        private async Task FetchInfoAsync()
        {
            if (string.IsNullOrWhiteSpace(Url)) return;
            IsBusy = true;
            Status = "Fetching video info...";
            Formats.Clear();
            try
            {
                var info = await _converter.ProbeAsync(Url, CancellationToken.None).ConfigureAwait(true);
                VideoTitle = info.Title ?? "(unknown)";
                VideoThumbnailUrl = info.ThumbnailUrl ?? string.Empty;
                VideoDuration = info.Duration.HasValue ? info.Duration.Value.ToString(@"hh\:mm\:ss") : "—";
                VideoAuthor = info.Author ?? "—";
                foreach (var f in info.AvailableFormats) Formats.Add(f);
                Status = Formats.Count > 0 ? $"Found {Formats.Count} formats" : "No formats available";
            }
            catch (Exception ex)
            {
                Status = $"Error: {ex.Message}";
                _logger.LogWarning(ex, "Video probe failed for {Url}", Url);
            }
            finally
            {
                IsBusy = false;
            }
        }

        [RelayCommand]
        private async Task DownloadAsync()
        {
            if (SelectedFormat == null)
            {
                Status = "Please select a format";
                return;
            }
            var settings = await _settingsStore.LoadAsync().ConfigureAwait(true);
            var savePath = System.IO.Path.Combine(settings.DefaultDownloadDirectory, "Videos");

            IsBusy = true;
            Status = "Downloading...";
            DownloadProgress = 0;
            try
            {
                var progress = new Progress<int>(p =>
                {
                    DownloadProgress = p;
                    Status = $"Downloading... {p}%";
                });
                var result = await _converter.DownloadAsync(Url, SelectedFormat, savePath, progress, CancellationToken.None).ConfigureAwait(true);
                Status = result.Success ? $"Saved to {result.FinalFilePath}" : $"Failed: {result.ErrorMessage}";
            }
            catch (Exception ex)
            {
                Status = $"Error: {ex.Message}";
                _logger.LogError(ex, "Video download failed for {Url}", Url);
            }
            finally
            {
                IsBusy = false;
            }
        }
    }
}
