using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.App.ViewModels
{
    /// <summary>
    /// View model for the Dashboard view. Surfaces REAL application state — never fabricated.
    /// The dashboard is shown when the user clicks "Dashboard" in the sidebar.
    /// </summary>
    public sealed partial class DashboardViewModel : ObservableObject
    {
        private readonly IDownloadTaskStore _store;
        private readonly ISettingsStore _settingsStore;
        private readonly IHistoryStore _historyStore;
        private readonly ILogger<DashboardViewModel> _logger;

        // Live counters
        [ObservableProperty] private int _totalDownloads;
        [ObservableProperty] private int _activeDownloads;
        [ObservableProperty] private int _completedDownloads;
        [ObservableProperty] private int _pausedDownloads;
        [ObservableProperty] private int _failedDownloads;
        [ObservableProperty] private int _queuedDownloads;
        [ObservableProperty] private long _aggregateSpeedBytesPerSec;
        [ObservableProperty] private long _totalDownloadedBytes;
        [ObservableProperty] private long _availableDiskSpaceBytes;
        [ObservableProperty] private string _activeQueueText = "Idle";
        [ObservableProperty] private string _networkActivityText = "—";

        // Browser integration status (best-effort detection; not a guarantee)
        [ObservableProperty] private bool _chromeIntegrationActive;
        [ObservableProperty] private bool _edgeIntegrationActive;
        [ObservableProperty] private bool _firefoxIntegrationActive;
        [ObservableProperty] private bool _operaIntegrationActive;
        [ObservableProperty] private bool _braveIntegrationActive;
        [ObservableProperty] private bool _vivaldiIntegrationActive;
        [ObservableProperty] private string _nativeMessagingStatusText = "Unknown";

        // Recent activity
        public ObservableCollection<DashboardRecentItem> RecentDownloads { get; } = new();
        public ObservableCollection<DashboardNotification> Notifications { get; } = new();

        // Formatted convenience properties for the XAML
        public string AggregateSpeedText => FormatBytes(AggregateSpeedBytesPerSec) + "/s";
        public string TotalDownloadedText => FormatBytes(TotalDownloadedBytes);
        public string AvailableDiskSpaceText => AvailableDiskSpaceBytes > 0 ? FormatBytes(AvailableDiskSpaceBytes) : "—";
        public string CompletedPercentageText => TotalDownloads > 0
            ? $"{(CompletedDownloads * 100.0 / TotalDownloads):F1}%"
            : "—";

        public DashboardViewModel(IDownloadTaskStore store,
                                    ISettingsStore settingsStore,
                                    IHistoryStore historyStore,
                                    ILogger<DashboardViewModel> logger)
        {
            _store = store;
            _settingsStore = settingsStore;
            _historyStore = historyStore;
            _logger = logger;
        }

        /// <summary>
        /// Refreshes every counter from the actual stores. Called by the main window on a
        /// 1-second timer and whenever the user opens the Dashboard.
        /// </summary>
        public async Task RefreshAsync()
        {
            try
            {
                var all = (await _store.GetAllAsync().ConfigureAwait(true)).ToList();
                TotalDownloads = all.Count;
                ActiveDownloads = all.Count(t => t.Status == DownloadStatus.Downloading || t.Status == DownloadStatus.Resolving || t.Status == DownloadStatus.WaitingForRetry);
                CompletedDownloads = all.Count(t => t.Status == DownloadStatus.Completed);
                PausedDownloads = all.Count(t => t.Status == DownloadStatus.Paused);
                FailedDownloads = all.Count(t => t.Status == DownloadStatus.Failed);
                QueuedDownloads = all.Count(t => t.Status == DownloadStatus.Queued);

                AggregateSpeedBytesPerSec = all
                    .Where(t => t.Status == DownloadStatus.Downloading)
                    .Sum(t => t.CurrentSpeed);

                TotalDownloadedBytes = all
                    .Where(t => t.Status == DownloadStatus.Completed)
                    .Sum(t => t.TotalBytes ?? 0);

                ActiveQueueText = ActiveDownloads > 0
                    ? $"{ActiveDownloads} active, {QueuedDownloads} queued"
                    : QueuedDownloads > 0 ? $"{QueuedDownloads} queued" : "Idle";

                NetworkActivityText = AggregateSpeedBytesPerSec > 0
                    ? $"↓ {FormatBytes(AggregateSpeedBytesPerSec)}/s"
                    : "—";

                // Disk space — try the default download directory's drive.
                var settings = await _settingsStore.LoadAsync().ConfigureAwait(true);
                try
                {
                    var root = Path.GetPathRoot(settings.DefaultDownloadDirectory);
                    if (!string.IsNullOrEmpty(root) && Directory.Exists(root))
                    {
                        var drive = new DriveInfo(root);
                        AvailableDiskSpaceBytes = drive.IsReady ? drive.AvailableFreeSpace : 0;
                    }
                }
                catch (Exception ex) { _logger.LogDebug(ex, "Could not query disk space"); }

                // Refresh recent activity (top 5 most recent by created_at desc).
                RecentDownloads.Clear();
                foreach (var t in all.OrderByDescending(x => x.CreatedAt).Take(5))
                    RecentDownloads.Add(new DashboardRecentItem(t));

                // Browser integration status — check the registry for native-messaging entries.
                RefreshBrowserIntegrationStatus();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Dashboard refresh failed");
            }
        }

        private void RefreshBrowserIntegrationStatus()
        {
            try
            {
                ChromeIntegrationActive = RegistryKeyExists(@"Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro");
                EdgeIntegrationActive = RegistryKeyExists(@"Software\Microsoft\Edge\NativeMessagingHosts\com.sawan.downloadpro");
                OperaIntegrationActive = ChromeIntegrationActive; // Opera uses Chrome's registry path
                BraveIntegrationActive = RegistryKeyExists(@"Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\com.sawan.downloadpro");
                VivaldiIntegrationActive = RegistryKeyExists(@"Software\Vivaldi\NativeMessagingHosts\com.sawan.downloadpro");
                var firefoxManifest = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "Mozilla", "NativeMessagingHosts", "com.sawan.downloadpro.json");
                FirefoxIntegrationActive = File.Exists(firefoxManifest);

                NativeMessagingStatusText = (ChromeIntegrationActive || EdgeIntegrationActive || FirefoxIntegrationActive)
                    ? "Registered"
                    : "Not registered";
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Browser integration status check failed");
            }
        }

        private static bool RegistryKeyExists(string path)
        {
            try
            {
                using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(path);
                return k != null;
            }
            catch { return false; }
        }

        public void AddNotification(string title, string message, NotificationLevel level = NotificationLevel.Info)
        {
            Notifications.Insert(0, new DashboardNotification
            {
                Title = title,
                Message = message,
                Level = level,
                Timestamp = DateTime.Now
            });
            // Keep the list bounded — last 25 entries.
            while (Notifications.Count > 25) Notifications.RemoveAt(Notifications.Count - 1);
            OnPropertyChanged(nameof(Notifications));
        }

        [RelayCommand]
        private void ClearNotifications()
        {
            Notifications.Clear();
        }

        private static string FormatBytes(long bytes)
        {
            if (bytes < 1024) return $"{bytes} B";
            if (bytes < 1024 * 1024) return $"{bytes / 1024.0:F1} KB";
            if (bytes < 1024L * 1024 * 1024) return $"{bytes / (1024.0 * 1024):F1} MB";
            return $"{bytes / (1024.0 * 1024 * 1024):F2} GB";
        }
    }

    public enum NotificationLevel { Info, Success, Warning, Error }

    public sealed class DashboardRecentItem
    {
        public string FileName { get; }
        public string Status { get; }
        public string SpeedText { get; }
        public string ProgressText { get; }
        public DateTime CreatedAt { get; }

        public DashboardRecentItem(DownloadTask t)
        {
            FileName = t.FileName;
            Status = t.Status.ToString();
            CreatedAt = t.CreatedAt;
            SpeedText = t.CurrentSpeed > 0 ? $"{t.CurrentSpeed / 1024.0:F1} KB/s" : "—";
            if (t.TotalBytes.HasValue && t.TotalBytes.Value > 0)
                ProgressText = $"{t.DownloadedBytes * 100.0 / t.TotalBytes.Value:F1}%";
            else
                ProgressText = "—";
        }
    }

    public sealed class DashboardNotification
    {
        public string Title { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public NotificationLevel Level { get; set; } = NotificationLevel.Info;
        public DateTime Timestamp { get; set; }
        public string LevelIcon => Level switch
        {
            NotificationLevel.Success => "✓",
            NotificationLevel.Warning => "!",
            NotificationLevel.Error => "✕",
            _ => "i"
        };
    }
}
