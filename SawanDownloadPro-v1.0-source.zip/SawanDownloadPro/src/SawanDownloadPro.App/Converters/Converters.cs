using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace SawanDownloadPro.App.Converters
{
    /// <summary>
    /// Standard bool-to-Visibility converter with optional inversion and zero-handling.
    /// ConverterParameter="invert" inverts; "invertZero" treats integer 0 as false.
    /// </summary>
    public sealed class BoolToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool? b = value as bool?;
            if (b == null && value is int i) b = i != 0;
            if (b == null && value is long l) b = l != 0;
            if (b == null && value is System.Collections.ICollection c) b = c.Count > 0;

            bool visible = b ?? false;

            string? param = parameter as string;
            if (param == "invert" || param == "invertZero") visible = !visible;

            return visible ? Visibility.Visible : Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool v = value is Visibility vis && vis == Visibility.Visible;
            string? param = parameter as string;
            if (param == "invert" || param == "invertZero") v = !v;
            return v;
        }
    }

    /// <summary>
    /// Inverts a boolean. Useful for IsEnabled bindings.
    /// </summary>
    public sealed class InvertBooleanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            => value is bool b ? !b : value;

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => value is bool b ? !b : value;
    }

    /// <summary>
    /// Compares a bound enum value to the ConverterParameter and returns true when they match.
    /// Used to bind RadioButtons to enum properties.
    /// </summary>
    public sealed class EnumMatchConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || parameter == null) return false;
            return value.Equals(parameter);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool b && b && parameter != null) return parameter;
            return Binding.DoNothing;
        }
    }

    /// <summary>
    /// Generic enum-to-Visibility converter. Visible when the bound enum equals any of the
    /// comma-separated values in ConverterParameter.
    /// </summary>
    public sealed class EnumToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null) return Visibility.Collapsed;
            var s = parameter as string;
            if (string.IsNullOrEmpty(s)) return Visibility.Visible;
            foreach (var p in s.Split(','))
            {
                if (string.Equals(value.ToString(), p.Trim(), StringComparison.OrdinalIgnoreCase))
                    return Visibility.Visible;
            }
            return Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => Binding.DoNothing;
    }
}
