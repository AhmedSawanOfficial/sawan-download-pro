using System;
using System.IO;
using System.Threading;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.App.Services;
using SawanDownloadPro.BrowserIntegration.NativeMessaging;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.DownloadEngine;
using SawanDownloadPro.DownloadEngine.Throttling;
using SawanDownloadPro.Scheduler;
using SawanDownloadPro.Security.Process;
using SawanDownloadPro.Security.Validation;
using SawanDownloadPro.Storage.Repositories;
using SawanDownloadPro.Themes;

namespace SawanDownloadPro.App
{
    public partial class App : Application
    {
        public static IServiceProvider Services { get; private set; } = null!;
        public static ILogger<App> Logger { get; private set; } = null!;

        // Held for the application lifetime to keep single-instance semantics.
        private static Mutex? _singleInstanceMutex;

        protected override async void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Ensure single instance.
            bool createdNew;
            _singleInstanceMutex = new Mutex(true, "Global\\SawanDownloadPro_SingleInstance", out createdNew);
            if (!createdNew)
            {
                MessageBox.Show("Sawan Download Pro is already running.", "Sawan Download Pro", MessageBoxButton.OK, MessageBoxImage.Information);
                Shutdown(1);
                return;
            }

            var services = new ServiceCollection();
            ConfigureServices(services);
            Services = services.BuildServiceProvider();
            Logger = Services.GetRequiredService<ILogger<App>>();

            Logger.LogInformation("Sawan Download Pro v1.0 starting up. Created by Ahmed Sawan.");

            // Initialize scheduler asynchronously.
            var scheduler = Services.GetRequiredService<DownloadScheduler>();
            _ = scheduler.InitializeAsync().ContinueWith(t =>
            {
                if (t.IsFaulted) Logger.LogError(t.Exception, "Scheduler initialization failed");
            });

            // Initialize the Private Downloads service (loads any persisted private tasks).
            var privateSvc = Services.GetRequiredService<PrivateDownloadsService>();
            _ = privateSvc.InitializeAsync().ContinueWith(t =>
            {
                if (t.IsFaulted) Logger.LogError(t.Exception, "Private Downloads service initialization failed");
            });

            // Hook unhandled-exception handler so we log crashes.
            DispatcherUnhandledException += (_, args) =>
            {
                Logger.LogError(args.Exception, "Unhandled UI exception");
                MessageBox.Show(args.Exception.Message, "Sawan Download Pro — Error", MessageBoxButton.OK, MessageBoxImage.Error);
                args.Handled = true;
            };

            ShutdownMode = ShutdownMode.OnExplicitShutdown;

            // Apply the saved theme and custom accent before showing any window.
            try
            {
                var settingsStore = Services.GetRequiredService<ISettingsStore>();
                var settings = await settingsStore.LoadAsync().ConfigureAwait(true);
                ThemeManager.ApplyTheme(settings.Theme);
                ThemeManager.ApplyCustomAccent(settings.CustomAccentColor);
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, "Failed to apply saved theme on startup; falling back to default Dark Eggplant.");
                ThemeManager.ApplyTheme(Core.Enums.AppTheme.DarkEggplant);
            }

            // First-run detection: if FirstRunCompleted is false, show the welcome wizard first.
            try
            {
                var settingsStore = Services.GetRequiredService<ISettingsStore>();
                var settings = await settingsStore.LoadAsync().ConfigureAwait(true);
                if (!settings.FirstRunCompleted)
                {
                    Logger.LogInformation("First run detected — showing welcome wizard.");
                    var settingsVm = Services.GetRequiredService<ViewModels.SettingsViewModel>();
                    await settingsVm.LoadAsync().ConfigureAwait(true);
                    var wizard = new Views.Windows.FirstRunWelcomeWindow(settingsVm);
                    wizard.ShowDialog();
                    // Re-apply theme in case the user changed it in the wizard.
                    var refreshed = await settingsStore.LoadAsync().ConfigureAwait(true);
                    ThemeManager.ApplyTheme(refreshed.Theme);
                    ThemeManager.ApplyCustomAccent(refreshed.CustomAccentColor);
                }
            }
            catch (Exception ex)
            {
                Logger.LogWarning(ex, "First-run wizard failed; continuing to main window.");
            }

            // Build and show the main window from DI.
            var mainWindow = Services.GetRequiredService<Views.Windows.MainWindow>();
            MainWindow = mainWindow;
            mainWindow.Show();
        }

        private static void ConfigureServices(IServiceCollection services)
        {
            // Logging
            services.AddLogging(builder =>
            {
                builder.SetMinimumLevel(LogLevel.Information);
                builder.AddProvider(new SawanFileLoggerProvider(Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "SawanDownloadPro", "logs")));
            });

            // Security
            services.AddSingleton<ISecretProtector, DpapiSecretProtector>();
            services.AddSingleton<IPathSanitizer, PathSanitizer>();
            services.AddSingleton<IUrlValidator, UrlValidator>();
            services.AddSingleton<ISafeProcessLauncher, SafeProcessLauncher>();

            // Storage
            var dbPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "SawanDownloadPro", "data", "sawan.db");
            services.AddSingleton<SQLiteDatabase>(_ => new SQLiteDatabase(dbPath,
                _.GetRequiredService<ILogger<SQLiteDatabase>>()));
            services.AddSingleton<IDownloadTaskStore>(sp =>
                new SqliteDownloadTaskStore(sp.GetRequiredService<SQLiteDatabase>().Connection,
                    sp.GetRequiredService<ILogger<SqliteDownloadTaskStore>>(),
                    sp.GetRequiredService<ISecretProtector>()));
            services.AddSingleton<ISettingsStore>(sp =>
                new SqliteSettingsStore(sp.GetRequiredService<SQLiteDatabase>().Connection,
                    sp.GetRequiredService<ILogger<SqliteSettingsStore>>()));
            services.AddSingleton<IHistoryStore>(sp =>
                new SqliteHistoryStore(sp.GetRequiredService<SQLiteDatabase>().Connection,
                    sp.GetRequiredService<ILogger<SqliteHistoryStore>>()));

            // Download engine
            services.AddSingleton<BandwidthThrottle>();
            services.AddSingleton<IDownloadEngine, DownloadEngine>();

            // Scheduler
            services.AddSingleton<DownloadScheduler>();

            // Media
            services.AddSingleton<SawanDownloadPro.Media.MediaConverter>();

            // Application services
            services.AddSingleton<ClipboardMonitorService>();
            services.AddSingleton<TrayIconService>();
            services.AddSingleton<DownloadOrchestrator>();
            services.AddSingleton<PrivateDownloadsService>();
            services.AddSingleton<SecurityPrivacyService>();

            // ViewModels
            services.AddSingleton<ViewModels.MainViewModel>();
            services.AddSingleton<ViewModels.AddDownloadViewModel>();
            services.AddSingleton<ViewModels.SettingsViewModel>();
            services.AddSingleton<ViewModels.VideoDownloaderViewModel>();
            services.AddSingleton<ViewModels.DashboardViewModel>();

            // Windows
            services.AddSingleton<Views.Windows.MainWindow>();
        }
    }
}
