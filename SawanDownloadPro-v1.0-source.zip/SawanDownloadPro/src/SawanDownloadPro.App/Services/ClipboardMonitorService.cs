using System;
using System.Threading;
using System.Windows;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.App.Services
{
    /// <summary>
    /// Polls the clipboard for download-looking URLs at 1 Hz. When the user copies a URL,
    /// we offer to add it (we never auto-add; that requires user opt-in via settings).
    /// </summary>
    public sealed class ClipboardMonitorService : IDisposable
    {
        private readonly IUrlValidator _urlValidator;
        private readonly ILogger<ClipboardMonitorService> _logger;
        private Timer? _timer;
        private string _lastSeen = string.Empty;

        public event EventHandler<string>? DownloadDetected;

        public ClipboardMonitorService(IUrlValidator urlValidator, ILogger<ClipboardMonitorService> logger)
        {
            _urlValidator = urlValidator;
            _logger = logger;
        }

        public void Start()
        {
            _timer = new Timer(_ => Poll(), null, 2000, 1000);
            _logger.LogInformation("Clipboard monitor started");
        }

        private void Poll()
        {
            try
            {
                if (!Application.Current?.Dispatcher.CheckAccess() ?? false)
                {
                    Application.Current?.Dispatcher.BeginInvoke(new Action(Poll));
                    return;
                }

                var text = Clipboard.ContainsText() ? Clipboard.GetText() : string.Empty;
                if (string.IsNullOrEmpty(text) || text == _lastSeen) return;
                _lastSeen = text;

                var trimmed = text.Trim();
                if (_urlValidator.IsValid(trimmed))
                {
                    _logger.LogInformation("Detected URL on clipboard: {Url}", trimmed);
                    DownloadDetected?.Invoke(this, trimmed);
                }
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Clipboard poll failed");
            }
        }

        public void Dispose() => _timer?.Dispose();
    }
}
