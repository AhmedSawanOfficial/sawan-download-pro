using System;
using System.Windows;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Interfaces;
using WinForms = System.Windows.Forms;

namespace SawanDownloadPro.App.Services
{
    /// <summary>
    /// System tray icon backed by System.Windows.Forms.NotifyIcon (allowed via &lt;UseWindowsForms&gt;).
    /// Provides show/hide and exit. Used by minimize-to-tray and close-to-tray.
    /// </summary>
    public sealed class TrayIconService : IDisposable
    {
        private readonly ILogger<TrayIconService> _logger;
        private WinForms.NotifyIcon? _notifyIcon;
        private bool _disposed;

        public TrayIconService(ILogger<TrayIconService> logger) => _logger = logger;

        public void Initialize()
        {
            try
            {
                _notifyIcon = new WinForms.NotifyIcon
                {
                    Icon = System.Drawing.SystemIcons.Application,
                    Visible = true,
                    Text = "Sawan Download Pro"
                };

                var menu = new WinForms.ContextMenuStrip();
                menu.Items.Add("Show", null, (_, _) => ShowMainWindow());
                menu.Items.Add("Hide", null, (_, _) => HideMainWindow());
                menu.Items.Add("-");
                menu.Items.Add("Exit", null, (_, _) => ExitApplication());

                _notifyIcon.ContextMenuStrip = menu;
                _notifyIcon.DoubleClick += (_, _) => ShowMainWindow();

                _logger.LogInformation("Tray icon initialized");
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Tray icon init failed; continuing without tray");
            }
        }

        public void ShowMainWindow() => Application.Current?.Dispatcher.Invoke(() =>
        {
            var m = Application.Current.MainWindow;
            if (m != null) { m.Show(); m.WindowState = WindowState.Normal; m.Activate(); }
        });

        public void HideMainWindow() => Application.Current?.Dispatcher.Invoke(() =>
        {
            var m = Application.Current.MainWindow;
            if (m != null) m.Hide();
        });

        public void ExitApplication() => Application.Current?.Dispatcher.Invoke(() => Application.Current.Shutdown());

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            try { if (_notifyIcon != null) { _notifyIcon.Visible = false; _notifyIcon.Dispose(); } } catch { }
        }
    }
}
