using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.App.ViewModels;
using SawanDownloadPro.Core.Events;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;
using SawanDownloadPro.Scheduler;

namespace SawanDownloadPro.App.Services
{
    /// <summary>
    /// Bridges engine events to the UI: refreshes the main view model, fires toast notifications,
    /// and writes to history.
    /// </summary>
    public sealed class DownloadOrchestrator : IDisposable
    {
        private readonly DownloadScheduler _scheduler;
        private readonly IDownloadEngine _engine;
        private readonly IHistoryStore _history;
        private readonly MainViewModel _mainVm;
        private readonly ILogger<DownloadOrchestrator> _logger;
        private System.Windows.Threading.DispatcherTimer? _refreshTimer;

        public DownloadOrchestrator(DownloadScheduler scheduler,
                                      IDownloadEngine engine,
                                      IHistoryStore history,
                                      MainViewModel mainVm,
                                      ILogger<DownloadOrchestrator> logger)
        {
            _scheduler = scheduler;
            _engine = engine;
            _history = history;
            _mainVm = mainVm;
            _logger = logger;
        }

        public void Start()
        {
            _engine.Completed += OnCompleted;
            _engine.Failed += OnFailed;

            _refreshTimer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(500)
            };
            _refreshTimer.Tick += (_, _) => RefreshUi();
            _refreshTimer.Start();
        }

        private void RefreshUi()
        {
            foreach (var vm in _mainVm.Downloads)
            {
                vm.OnPropertyChanged(nameof(ViewModels.DownloadTaskViewModel.DownloadedBytes));
                vm.OnPropertyChanged(nameof(ViewModels.DownloadTaskViewModel.ProgressPercent));
                vm.OnPropertyChanged(nameof(ViewModels.DownloadTaskViewModel.ProgressText));
                vm.OnPropertyChanged(nameof(ViewModels.DownloadTaskViewModel.CurrentSpeed));
                vm.OnPropertyChanged(nameof(ViewModels.DownloadTaskViewModel.SpeedText));
                vm.OnPropertyChanged(nameof(ViewModels.DownloadTaskViewModel.ActiveConnections));
                vm.OnPropertyChanged(nameof(ViewModels.DownloadTaskViewModel.Status));
            }
        }

        private void OnCompleted(object? sender, DownloadCompletedEventArgs e)
        {
            _ = Task.Run(async () =>
            {
                var task = await _scheduler.GetType().Assembly.GetType("SawanDownloadPro.Scheduler.DownloadScheduler") != null
                    ? null  // We don't expose GetTaskById; the scheduler persists via its own store subscription.
                    : null;
                await _history.AddAsync(new HistoryEntry
                {
                    DownloadId = e.TaskId,
                    Url = "(unknown)",
                    FileName = System.IO.Path.GetFileName(e.FinalFilePath),
                    CompletedAt = DateTime.UtcNow,
                    TotalBytes = e.TotalBytes
                }).ConfigureAwait(false);
                _logger.LogInformation("Task {Id} completed: {Path}", e.TaskId, e.FinalFilePath);
            });
        }

        private void OnFailed(object? sender, DownloadFailedEventArgs e)
        {
            if (!e.WillRetry)
                _logger.LogWarning("Task {Id} failed permanently: {Error}", e.TaskId, e.ErrorMessage);
        }

        public void Dispose()
        {
            _engine.Completed -= OnCompleted;
            _engine.Failed -= OnFailed;
            _refreshTimer?.Stop();
        }
    }
}
