using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.App.Services
{
    /// <summary>
    /// Manages the Private Downloads session. Private tasks are kept in a separate in-memory
    /// list and never written to the standard download history. Persistence of private tasks
    /// to the SQLite database is governed by AutoDeletePrivateSessionMetadataOnExit and
    /// RetainPrivateSessionDownloadedFiles.
    /// </summary>
    /// <remarks>
    /// IMPORTANT — what this service does NOT do:
    /// - It does NOT clear the browser's history or private-browsing records.
    /// - It does NOT delete files from the file system unless the user explicitly asks.
    /// - It does NOT provide anonymity from ISPs, network admins, or website operators.
    /// - It does NOT securely erase (shred) files. The OS delete is used.
    /// See docs/PRIVACY.md for the full honest statement.
    /// </remarks>
    public sealed class PrivateDownloadsService
    {
        private readonly IDownloadTaskStore _store;
        private readonly IHistoryStore _historyStore;
        private readonly ISettingsStore _settingsStore;
        private readonly ILogger<PrivateDownloadsService> _logger;

        // In-memory list of private tasks. Rebuilt from the DB on startup (filtered by IsPrivate=true).
        public ObservableCollection<DownloadTask> PrivateTasks { get; } = new();

        public bool IsEnabled { get; private set; }

        public PrivateDownloadsService(IDownloadTaskStore store,
                                         IHistoryStore historyStore,
                                         ISettingsStore settingsStore,
                                         ILogger<PrivateDownloadsService> logger)
        {
            _store = store;
            _historyStore = historyStore;
            _settingsStore = settingsStore;
            _logger = logger;
        }

        public async Task InitializeAsync()
        {
            var settings = await _settingsStore.LoadAsync().ConfigureAwait(true);
            IsEnabled = settings.EnablePrivateDownloadsMode;
            await ReloadPrivateTasksAsync().ConfigureAwait(true);
        }

        public async Task ReloadPrivateTasksAsync()
        {
            var all = await _store.GetAllAsync().ConfigureAwait(true);
            PrivateTasks.Clear();
            foreach (var t in all.Where(x => x.IsPrivate)) PrivateTasks.Add(t);
        }

        /// <summary>
        /// Adds a task as a private download. The task is persisted with IsPrivate=true.
        /// </summary>
        public async Task AddPrivateTaskAsync(DownloadTask task)
        {
            task.IsPrivate = true;
            await _store.UpsertAsync(task).ConfigureAwait(true);
            PrivateTasks.Insert(0, task);
            _logger.LogInformation("Added private task: {File}", task.FileName);
        }

        /// <summary>
        /// Clears the private session. Behavior:
        /// - Always removes private tasks from the in-memory list.
        /// - Removes private tasks from the SQLite database.
        /// - If retainFiles is false, ALSO deletes the downloaded files from disk (after confirmation).
        /// - Never touches the standard download history (private URLs were never written there
        ///   when NeverMixPrivateUrlsIntoStandardHistory was true, which is the default).
        /// Returns the number of tasks cleared.
        /// </summary>
        public async Task<int> ClearPrivateSessionAsync(bool retainFiles)
        {
            var count = PrivateTasks.Count;
            foreach (var t in PrivateTasks.ToList())
            {
                if (!retainFiles && t.Status == Core.Enums.DownloadStatus.Completed)
                {
                    try
                    {
                        var path = System.IO.Path.Combine(t.SavePath, t.FileName);
                        if (System.IO.File.Exists(path)) System.IO.File.Delete(path);
                    }
                    catch (Exception ex) { _logger.LogWarning(ex, "Could not delete private-session file {File}", t.FileName); }
                }
                await _store.DeleteAsync(t.Id).ConfigureAwait(true);
            }
            PrivateTasks.Clear();
            _logger.LogInformation("Private session cleared: {Count} tasks removed, retainFiles={Retain}", count, retainFiles);
            return count;
        }

        /// <summary>
        /// Called on application exit when AutoDeletePrivateSessionMetadataOnExit is true.
        /// Removes private task rows from the SQLite database. Files are retained or deleted
        /// based on RetainPrivateSessionDownloadedFiles.
        /// </summary>
        public async Task OnApplicationExitAsync()
        {
            var settings = await _settingsStore.LoadAsync().ConfigureAwait(true);
            if (!settings.AutoDeletePrivateSessionMetadataOnExit) return;
            await ClearPrivateSessionAsync(settings.RetainPrivateSessionDownloadedFiles).ConfigureAwait(true);
        }

        public async Task SetEnabledAsync(bool enabled)
        {
            IsEnabled = enabled;
            var settings = await _settingsStore.LoadAsync().ConfigureAwait(true);
            settings.EnablePrivateDownloadsMode = enabled;
            await _settingsStore.SaveAsync(settings).ConfigureAwait(true);
        }
    }
}
