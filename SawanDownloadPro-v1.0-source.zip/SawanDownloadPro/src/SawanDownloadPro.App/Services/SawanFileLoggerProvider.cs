using System;
using System.IO;
using System.Text;
using Microsoft.Extensions.Logging;

namespace SawanDownloadPro.App.Services
{
    /// <summary>
    /// File-based logger provider. Writes one log file per day, rolls over at midnight.
    /// Never logs secrets, cookies, auth tokens, or passwords — those should never appear in
    /// log calls in the first place, and we additionally scrub a small set of patterns here.
    /// </summary>
    public sealed class SawanFileLoggerProvider : ILoggerProvider
    {
        private readonly string _logDir;

        public SawanFileLoggerProvider(string logDir)
        {
            _logDir = logDir;
            if (!Directory.Exists(logDir)) Directory.CreateDirectory(logDir);
        }

        public ILogger CreateLogger(string categoryName) => new FileLogger(categoryName, _logDir);

        public void Dispose() { }

        private sealed class FileLogger : ILogger
        {
            private readonly string _category;
            private readonly string _logDir;
            private static readonly object WriteLock = new();

            public FileLogger(string category, string logDir)
            {
                _category = category;
                _logDir = logDir;
            }

            public IDisposable BeginScope<TState>(TState state) where TState : notnull => NullScope.Instance;

            public bool IsEnabled(LogLevel logLevel) => logLevel >= LogLevel.Information;

            public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
            {
                if (!IsEnabled(logLevel)) return;
                var message = formatter(state, exception);
                if (string.IsNullOrEmpty(message)) return;

                // Scrub obvious secret patterns. This is a defensive measure; production code
                // should never log secrets in the first place.
                message = ScrubSecrets(message);

                var line = $"{DateTime.UtcNow:O} [{logLevel}] [{_category}] {message}";
                if (exception != null) line += Environment.NewLine + exception;

                var fileName = $"sawan-{DateTime.UtcNow:yyyy-MM-dd}.log";
                var path = Path.Combine(_logDir, fileName);

                lock (WriteLock)
                {
                    try { File.AppendAllText(path, line + Environment.NewLine, Encoding.UTF8); } catch { /* swallow */ }
                }
            }

            private static string ScrubSecrets(string s)
            {
                if (string.IsNullOrEmpty(s)) return s;
                // Strip password=...; user:pass@host; Bearer ...
                s = System.Text.RegularExpressions.Regex.Replace(s, @"(password|pwd)\s*=\s*[^\s;]+", "$1=***", RegexOptions.IgnoreCase);
                s = System.Text.RegularExpressions.Regex.Replace(s, @"://([^:/@\s]+):([^/@\s]+)@", "://$1:***@", RegexOptions.IgnoreCase);
                s = System.Text.RegularExpressions.Regex.Replace(s, @"(bearer|token|authorization)\s*[:=]\s*[^\s;]+", "$1=***", RegexOptions.IgnoreCase);
                return s;
            }
        }

        private sealed class NullScope : IDisposable
        {
            public static readonly NullScope Instance = new();
            public void Dispose() { }
        }
    }
}
