using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.App.Services
{
    /// <summary>
    /// Backs the Security &amp; Privacy dashboard view. Surfaces real status — not a mockup.
    /// </summary>
    public sealed class SecurityPrivacyService
    {
        private readonly ISettingsStore _settingsStore;
        private readonly ILogger<SecurityPrivacyService> _logger;

        public ObservableCollection<SecurityWarning> Warnings { get; } = new();

        public SecurityPrivacyService(ISettingsStore settingsStore, ILogger<SecurityPrivacyService> logger)
        {
            _settingsStore = settingsStore;
            _logger = logger;
        }

        public async Task<SecurityPrivacySnapshot> GetSnapshotAsync()
        {
            var settings = await _settingsStore.LoadAsync().ConfigureAwait(true);
            Warnings.Clear();

            var snap = new SecurityPrivacySnapshot
            {
                // Browser integration
                ChromeRegistered  = RegistryKeyExists(@"Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro"),
                EdgeRegistered    = RegistryKeyExists(@"Software\Microsoft\Edge\NativeMessagingHosts\com.sawan.downloadpro"),
                FirefoxRegistered = File.Exists(Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "Mozilla", "NativeMessagingHosts", "com.sawan.downloadpro.json")),
                OperaRegistered   = RegistryKeyExists(@"Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro"),
                BraveRegistered   = RegistryKeyExists(@"Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\com.sawan.downloadpro"),
                VivaldiRegistered = RegistryKeyExists(@"Software\Vivaldi\NativeMessagingHosts\com.sawan.downloadpro"),

                // Privacy settings
                PrivateDownloadsModeEnabled = settings.EnablePrivateDownloadsMode,
                BrowserPrivateModeIntegration = settings.EnableBrowserPrivateModeIntegration,
                AutoDeletePrivateSessionMetadataOnExit = settings.AutoDeletePrivateSessionMetadataOnExit,
                RetainPrivateSessionDownloadedFiles = settings.RetainPrivateSessionDownloadedFiles,
                NeverMixPrivateUrlsIntoStandardHistory = settings.NeverMixPrivateUrlsIntoStandardHistory,
                HistoryRetentionDays = settings.HistoryRetentionDays,
                TelemetryEnabled = settings.EnableTelemetry,

                // Diagnostics
                LogDirectory = settings.LogDirectory,
                DatabasePath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "SawanDownloadPro", "data", "sawan.db"),
                WarnOnDangerousExtensions = settings.WarnOnDangerousExtensions,
                AntivirusScanEnabled = settings.ScanWithAntivirus,
                AntivirusPath = settings.AntivirusPath
            };

            // Build warnings
            if (snap.TelemetryEnabled)
                Warnings.Add(new SecurityWarning { Level = WarningLevel.Info, Title = "Telemetry enabled",
                    Message = "Optional telemetry is ON. v1.0 ships with no telemetry implementation; this flag is reserved for future opt-in crash reporting." });

            if (!snap.WarnOnDangerousExtensions)
                Warnings.Add(new SecurityWarning { Level = WarningLevel.Warning, Title = "Dangerous-extension warnings disabled",
                    Message = "Sawan will not warn you when downloading .exe/.bat/.ps1/.js files. Re-enable this in Settings → Security." });

            if (!snap.ChromeRegistered && !snap.EdgeRegistered && !snap.FirefoxRegistered)
                Warnings.Add(new SecurityWarning { Level = WarningLevel.Info, Title = "No browser integration registered",
                    Message = "Open Settings → Browser Integration to install the native messaging host for at least one browser." });

            if (snap.BrowserPrivateModeIntegration)
                Warnings.Add(new SecurityWarning { Level = WarningLevel.Info, Title = "Private-mode integration enabled",
                    Message = "Sawan will accept downloads from browser private modes. Remember: this does not provide anonymity from your ISP, employer, or network administrator." });

            return snap;
        }

        private static bool RegistryKeyExists(string path)
        {
            try
            {
                using var k = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(path);
                return k != null;
            }
            catch { return false; }
        }
    }

    public sealed class SecurityPrivacySnapshot
    {
        public bool ChromeRegistered { get; set; }
        public bool EdgeRegistered { get; set; }
        public bool FirefoxRegistered { get; set; }
        public bool OperaRegistered { get; set; }
        public bool BraveRegistered { get; set; }
        public bool VivaldiRegistered { get; set; }

        public bool PrivateDownloadsModeEnabled { get; set; }
        public bool BrowserPrivateModeIntegration { get; set; }
        public bool AutoDeletePrivateSessionMetadataOnExit { get; set; }
        public bool RetainPrivateSessionDownloadedFiles { get; set; }
        public bool NeverMixPrivateUrlsIntoStandardHistory { get; set; }
        public int  HistoryRetentionDays { get; set; }
        public bool TelemetryEnabled { get; set; }

        public string LogDirectory { get; set; } = string.Empty;
        public string DatabasePath { get; set; } = string.Empty;
        public bool WarnOnDangerousExtensions { get; set; }
        public bool AntivirusScanEnabled { get; set; }
        public string AntivirusPath { get; set; } = string.Empty;
    }

    public enum WarningLevel { Info, Warning, Error }

    public sealed class SecurityWarning
    {
        public WarningLevel Level { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string LevelIcon => Level switch
        {
            WarningLevel.Warning => "!",
            WarningLevel.Error => "✕",
            _ => "i"
        };
    }
}
