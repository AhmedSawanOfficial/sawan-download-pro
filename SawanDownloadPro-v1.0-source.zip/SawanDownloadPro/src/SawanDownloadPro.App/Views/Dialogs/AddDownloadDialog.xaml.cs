using System.Windows;
using Microsoft.Win32;
using SawanDownloadPro.App.ViewModels;

namespace SawanDownloadPro.App.Views.Dialogs
{
    public partial class AddDownloadDialog : Window
    {
        public AddDownloadViewModel ViewModel => (AddDownloadViewModel)DataContext;

        public AddDownloadDialog()
        {
            InitializeComponent();
        }

        public AddDownloadDialog(AddDownloadViewModel vm) : this()
        {
            DataContext = vm;
            Loaded += (_, _) =>
            {
                // Mirror PasswordBox into the view model.
                PasswordBox.PasswordChanged += (_, __) => ViewModel.Password = PasswordBox.Password;
            };
        }

        private void Browse_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new FolderBrowserDialogWrapper();
            if (dlg.ShowDialog() == true)
            {
                ViewModel.SaveLocation = dlg.SelectedPath;
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e) => Close();

        private void OnDownloadNow_Click(object sender, RoutedEventArgs e)
        {
            if (ViewModel.Result != null) Close();
        }

        private void OnAddToQueue_Click(object sender, RoutedEventArgs e)
        {
            if (ViewModel.Result != null) Close();
        }
    }

    /// <summary>
    /// Thin wrapper to use WinForms FolderBrowserDialog from WPF (better than the WPF
    /// CommonOpenFileDialog which requires Windows API Code Pack).
    /// </summary>
    internal sealed class FolderBrowserDialogWrapper
    {
        private readonly System.Windows.Forms.FolderBrowserDialog _dlg = new()
        {
            ShowNewFolderButton = true,
            Description = "Select download destination"
        };

        public string SelectedPath => _dlg.SelectedPath;

        public bool? ShowDialog()
        {
            var result = _dlg.ShowDialog();
            return result == System.Windows.Forms.DialogResult.OK ? true : false;
        }
    }
}
