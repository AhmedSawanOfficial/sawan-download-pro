using System.Windows;
using SawanDownloadPro.App.ViewModels;
using SawanDownloadPro.Themes;

namespace SawanDownloadPro.App.Views.Windows
{
    public partial class SettingsWindow : Window
    {
        private readonly SettingsViewModel _vm;

        public SettingsWindow()
        {
            InitializeComponent();
        }

        public SettingsWindow(SettingsViewModel vm) : this()
        {
            _vm = vm;
            DataContext = vm;
            Loaded += async (_, _) => await vm.LoadAsync();
        }

        private async void Save_Click(object sender, RoutedEventArgs e)
        {
            await _vm.SaveAsync();
            // Apply the theme + accent live so the user sees the change immediately.
            ThemeManager.ApplyTheme(_vm.Theme);
            ThemeManager.ApplyCustomAccent(_vm.CustomAccentColor);
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e) => Close();

        /// <summary>
        /// Applies the custom accent color live. Validates via DesignTokens.IsValidHexColor.
        /// </summary>
        private void ApplyAccent_Click(object sender, RoutedEventArgs e)
        {
            var hex = _vm.CustomAccentColor;
            if (!DesignTokens.IsValidHexColor(hex))
            {
                MessageBox.Show("Enter a valid hex color, e.g. #A78BFA.", "Sawan", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            ThemeManager.ApplyCustomAccent(hex);
        }

        /// <summary>
        /// Resets the accent to the Sawan default (SecondaryAccent) and clears the custom field.
        /// </summary>
        private void ResetAccent_Click(object sender, RoutedEventArgs e)
        {
            _vm.CustomAccentColor = null;
            ThemeManager.ApplyCustomAccent(null);
        }
    }
}
