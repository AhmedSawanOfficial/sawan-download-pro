using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Extensions.DependencyInjection;
using SawanDownloadPro.App.Services;
using SawanDownloadPro.App.ViewModels;
using SawanDownloadPro.App.Views.Dialogs;
using SawanDownloadPro.App.Views.Windows;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.App.Views.Windows
{
    public partial class MainWindow : Window
    {
        private readonly MainViewModel _vm;
        private readonly IServiceProvider _services;

        public MainWindow()
        {
            InitializeComponent();
        }

        public MainWindow(MainViewModel vm,
                          DashboardViewModel dashboardVm,
                          SecurityPrivacyService securityService,
                          PrivateDownloadsService privateDownloadsService,
                          IServiceProvider services) : this()
        {
            _vm = vm;
            _services = services;
            DataContext = vm;

            // Wire up the hosted UserControls' DataContexts.
            DashboardViewHost.DataContext = dashboardVm;
            SecurityViewHost.DataContext = securityService;
            PrivateViewHost.DataContext = privateDownloadsService;

            Loaded += OnLoaded;
            Closing += OnClosing;
        }

        private async void OnLoaded(object sender, RoutedEventArgs e)
        {
            await _vm.LoadAsync().ConfigureAwait(true);
            _vm.ApplyFilter();

            // Refresh the dashboard view on a 1-second timer so it shows live data.
            var dashboardVm = DashboardViewHost.DataContext as DashboardViewModel;
            if (dashboardVm != null)
            {
                var timer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
                timer.Tick += async (_, _) =>
                {
                    if (DashboardViewHost.Visibility == Visibility.Visible)
                        await dashboardVm.RefreshAsync().ConfigureAwait(true);
                };
                timer.Start();
            }
        }

        private void OnClosing(object? sender, CancelEventArgs e)
        {
            var settingsStore = _services.GetRequiredService<ISettingsStore>();
            var settings = settingsStore.LoadAsync().GetAwaiter().GetResult();
            if (settings?.CloseToTray == true)
            {
                e.Cancel = true;
                Hide();
                return;
            }

            if (settings?.ConfirmBeforeExit == true)
            {
                var result = MessageBox.Show(
                    (string)Application.Current.FindResource("Confirm_Exit_Text"),
                    (string)Application.Current.FindResource("Confirm_Exit_Title"),
                    MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes) { e.Cancel = true; return; }
            }

            // On clean exit, run the private-session cleanup if configured.
            try
            {
                var privateSvc = _services.GetRequiredService<PrivateDownloadsService>();
                privateSvc.OnApplicationExitAsync().GetAwaiter().GetResult();
            }
            catch { /* best-effort */ }
        }

        private void SidebarItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is SidebarFilter filter)
            {
                _vm.CurrentFilter = filter;
                _vm.ApplyFilter();
                ShowDownloadList();
            }
        }

        /// <summary>
        /// Handles clicks on the new non-filter sidebar items (Dashboard, Scheduler, etc.).
        /// The Tag is a string key identifying which view to show.
        /// </summary>
        private void NavItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string key)
            {
                switch (key)
                {
                    case "dashboard":
                        ShowDashboard();
                        break;
                    case "scheduler":
                        MessageBox.Show("Scheduler window — to be implemented in v1.1. The scheduler is already running in the background; use Start All / Pause All / Stop All to control it.",
                            "Sawan", MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    case "browser":
                        // Open the Settings window on the Browser tab.
                        var sVm = App.Services.GetRequiredService<SettingsViewModel>();
                        _ = sVm.LoadAsync().ContinueWith(_ => { });
                        var sw = new SettingsWindow(sVm);
                        sw.ShowDialog();
                        break;
                    case "private":
                        ShowPrivateDownloads();
                        break;
                    case "security":
                        ShowSecurityPrivacy();
                        break;
                    case "settings":
                        var settingsVm = App.Services.GetRequiredService<SettingsViewModel>();
                        _ = settingsVm.LoadAsync().ContinueWith(_ => { });
                        var settingsWindow = new SettingsWindow(settingsVm);
                        settingsWindow.ShowDialog();
                        break;
                    case "help":
                        MessageBox.Show("Sawan Download Pro v1.0 — First Release.\nCreated by Ahmed Sawan.\n\nFor help, see the user guide at docs/USER_GUIDE_EN.md or docs/USER_GUIDE_AR.md.\nFor troubleshooting, see docs/TROUBLESHOOTING.md.\nFor privacy, see docs/PRIVACY.md.",
                            "Sawan — Help & Support", MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    case "about":
                        var about = new AboutSawanWindow(App.Services.GetRequiredService<IUrlValidator>());
                        about.Owner = this;
                        about.ShowDialog();
                        break;
                }
            }
        }

        private void ShowDownloadList()
        {
            DashboardViewHost.Visibility = Visibility.Collapsed;
            SecurityViewHost.Visibility = Visibility.Collapsed;
            PrivateViewHost.Visibility = Visibility.Collapsed;
            DownloadListHost.Visibility = Visibility.Visible;
        }

        private void ShowDashboard()
        {
            DownloadListHost.Visibility = Visibility.Collapsed;
            SecurityViewHost.Visibility = Visibility.Collapsed;
            PrivateViewHost.Visibility = Visibility.Collapsed;
            DashboardViewHost.Visibility = Visibility.Visible;
            if (DashboardViewHost.DataContext is DashboardViewModel dvm)
                _ = dvm.RefreshAsync();
        }

        private void ShowSecurityPrivacy()
        {
            DownloadListHost.Visibility = Visibility.Collapsed;
            DashboardViewHost.Visibility = Visibility.Collapsed;
            PrivateViewHost.Visibility = Visibility.Collapsed;
            SecurityViewHost.Visibility = Visibility.Visible;
            // The SecurityPrivacyView binds directly to SecurityPrivacyService — refresh its snapshot.
            if (SecurityViewHost.DataContext is SecurityPrivacyService svc)
                _ = svc.GetSnapshotAsync();
        }

        private void ShowPrivateDownloads()
        {
            DownloadListHost.Visibility = Visibility.Collapsed;
            DashboardViewHost.Visibility = Visibility.Collapsed;
            SecurityViewHost.Visibility = Visibility.Collapsed;
            PrivateViewHost.Visibility = Visibility.Visible;
        }

        private void SearchBox_OnKeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            _vm.ApplyFilter();
        }

        /// <summary>
        /// Opens one of the four official Sawan contact links. Strictly allow-listed — we
        /// never accept arbitrary URLs from XAML Tag attributes.
        /// </summary>
        private void OpenSawanLink_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string url)
            {
                bool allowed = url switch
                {
                    "https://wa.me/201000150303" => true,
                    "https://www.youtube.com/@AhmedSawanOfficial" => true,
                    "https://www.facebook.com/AhmedSawanOfficial/" => true,
                    "https://t.me/AhmedMSawan" => true,
                    _ => false
                };
                if (!allowed) return;
                try
                {
                    Process.Start(new ProcessStartInfo { FileName = url, UseShellExecute = true });
                }
                catch { /* best-effort */ }
            }
        }
    }
}
