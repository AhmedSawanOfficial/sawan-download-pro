using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows;
using SawanDownloadPro.App.ViewModels;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.App.Views.Windows
{
    /// <summary>
    /// First-Run Welcome wizard. Shown when AppSettings.FirstRunCompleted is false.
    /// The user's choices populate AppSettings; on "Begin", we persist and continue.
    /// </summary>
    public partial class FirstRunWelcomeWindow : Window
    {
        private readonly SettingsViewModel _vm;
        private bool _beganSuccessfully;

        public FirstRunWelcomeWindow()
        {
            InitializeComponent();
        }

        public FirstRunWelcomeWindow(SettingsViewModel vm) : this()
        {
            _vm = vm;
            DataContext = vm;
        }

        private void Browse_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Select default download folder",
                ShowNewFolderButton = true
            };
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                _vm.DefaultDownloadDirectory = dlg.SelectedPath;
            }
        }

        private async void Begin_Click(object sender, RoutedEventArgs e)
        {
            // Persist the user's choices. The SettingsViewModel already mirrors its bound
            // properties back into BackingSettings on SaveAsync.
            await _vm.SaveAsync().ConfigureAwait(true);
            _vm.BackingSettings!.FirstRunCompleted = true;
            await _vm.SaveAsync().ConfigureAwait(true);
            _beganSuccessfully = true;
            Close();
        }

        private void Skip_Click(object sender, RoutedEventArgs e)
        {
            // Skip: keep defaults, mark first-run complete so we don't show this again.
            _ = _vm.SaveAsync().ContinueWith(_ =>
            {
                _vm.BackingSettings!.FirstRunCompleted = true;
                _ = _vm.SaveAsync();
            });
            _beganSuccessfully = true;
            Close();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            // If the user closed via the X button without clicking Skip or Begin, we still
            // mark first-run complete so they don't see this wizard on every launch. They
            // can re-run it from Settings → Advanced.
            if (!_beganSuccessfully)
            {
                _ = _vm.SaveAsync().ContinueWith(_ =>
                {
                    _vm.BackingSettings!.FirstRunCompleted = true;
                    _ = _vm.SaveAsync();
                });
            }
            base.OnClosing(e);
        }
    }
}
