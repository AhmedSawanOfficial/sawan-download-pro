using System.Windows;
using SawanDownloadPro.App.ViewModels;

namespace SawanDownloadPro.App.Views.Windows
{
    public partial class VideoDownloaderWindow : Window
    {
        public VideoDownloaderWindow()
        {
            InitializeComponent();
        }

        public VideoDownloaderWindow(VideoDownloaderViewModel vm) : this()
        {
            DataContext = vm;
        }
    }
}
