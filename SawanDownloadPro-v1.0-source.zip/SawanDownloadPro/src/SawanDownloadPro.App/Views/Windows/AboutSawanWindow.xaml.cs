using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using SawanDownloadPro.Core.Interfaces;

namespace SawanDownloadPro.App.Views.Windows
{
    /// <summary>
    /// About Sawan window. Shows the brand identity, the creator Ahmed Sawan, and the four
    /// official contact links. All link opens go through a strict https-scheme validation.
    /// </summary>
    public partial class AboutSawanWindow : Window
    {
        private readonly IUrlValidator? _urlValidator;

        public AboutSawanWindow()
        {
            InitializeComponent();
        }

        public AboutSawanWindow(IUrlValidator urlValidator) : this()
        {
            _urlValidator = urlValidator;
        }

        /// <summary>
        /// Opens a URL in the user's default browser ONLY if it is https-scheme and on the
        /// Sawan allow-list of domains. We never use UseShellExecute with arbitrary strings.
        /// </summary>
        private void OpenLink_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string url)
            {
                if (!IsAllowedSawanUrl(url))
                {
                    MessageBox.Show("This URL is not on the Sawan allow-list.", "Sawan", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                try
                {
                    var psi = new ProcessStartInfo
                    {
                        FileName = url,
                        UseShellExecute = true // Required for opening https URLs in the default browser
                    };
                    Process.Start(psi);
                }
                catch { /* best-effort */ }
            }
        }

        /// <summary>
        /// Strict allow-list of official Sawan URLs. We deliberately hard-code the four
        /// destinations rather than accepting any https URL.
        /// </summary>
        private bool IsAllowedSawanUrl(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return false;
            if (_urlValidator != null && !_urlValidator.IsValid(url)) return false;

            return url switch
            {
                "https://wa.me/201000150303" => true,
                "https://www.youtube.com/@AhmedSawanOfficial" => true,
                "https://www.facebook.com/AhmedSawanOfficial/" => true,
                "https://t.me/AhmedMSawan" => true,
                _ => false
            };
        }

        private void CopyText_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string text)
            {
                Clipboard.SetText(text);
                MessageBox.Show("Copied: " + text, "Sawan", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e) => Close();
    }
}
