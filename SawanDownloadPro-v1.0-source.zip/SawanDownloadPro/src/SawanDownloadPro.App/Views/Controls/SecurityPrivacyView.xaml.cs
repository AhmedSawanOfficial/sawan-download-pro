using System.Windows.Controls;

namespace SawanDownloadPro.App.Views.Controls
{
    public partial class SecurityPrivacyView : UserControl
    {
        public SecurityPrivacyView() { InitializeComponent(); }
    }
}
