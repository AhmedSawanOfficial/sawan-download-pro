using System.Windows;
using System.Windows.Controls;

namespace SawanDownloadPro.App.Views.Controls
{
    /// <summary>
    /// View for the Private Downloads mode. The DataContext is PrivateDownloadsService.
    /// </summary>
    public partial class PrivateDownloadsView : UserControl
    {
        public PrivateDownloadsView() { InitializeComponent(); }

        private async void ClearSession_Click(object sender, RoutedEventArgs e)
        {
            var svc = DataContext as Services.PrivateDownloadsService;
            if (svc == null) return;

            // Ask about file retention first (when applicable).
            bool retainFiles = true;
            if (svc.PrivateTasks.Count > 0)
            {
                var result = MessageBox.Show(
                    "Clear the private session?\n\nClick Yes to KEEP downloaded files on disk.\nClick No to ALSO delete the downloaded files from disk.",
                    "Clear Private Session",
                    MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                if (result == MessageBoxResult.Cancel) return;
                retainFiles = result == MessageBoxResult.Yes;
            }

            var cleared = await svc.ClearPrivateSessionAsync(retainFiles).ConfigureAwait(true);
            MessageBox.Show($"Private session cleared. {cleared} task(s) removed.", "Sawan", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private async void TogglePrivateMode_Click(object sender, RoutedEventArgs e)
        {
            var svc = DataContext as Services.PrivateDownloadsService;
            if (svc == null) return;
            await svc.SetEnabledAsync(!svc.IsEnabled).ConfigureAwait(true);
        }
    }
}
