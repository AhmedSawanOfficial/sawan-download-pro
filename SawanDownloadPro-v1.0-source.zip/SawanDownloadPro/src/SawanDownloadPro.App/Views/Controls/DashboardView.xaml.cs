using System.Windows.Controls;

namespace SawanDownloadPro.App.Views.Controls
{
    public partial class DashboardView : UserControl
    {
        public DashboardView()
        {
            InitializeComponent();
        }
    }
}
