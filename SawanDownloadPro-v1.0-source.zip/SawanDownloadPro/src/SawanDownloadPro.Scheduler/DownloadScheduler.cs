using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Events;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.Scheduler
{
    /// <summary>
    /// Manages the active download queue. Honours max-simultaneous limit and per-priority ordering.
    /// </summary>
    public sealed class DownloadScheduler : IScheduler, IDisposable
    {
        private readonly IDownloadEngine _engine;
        private readonly IDownloadTaskStore _store;
        private readonly ISettingsStore _settingsStore;
        private readonly ILogger<DownloadScheduler> _logger;

        private readonly ConcurrentDictionary<string, RunningTask> _running = new();
        private readonly ConcurrentDictionary<string, CancellationTokenSource> _ctsByTask = new();
        private readonly ConcurrentQueue<DownloadTask> _queue = new();
        private readonly object _queueLock = new();

        private Timer? _queuePoller;
        private AppSettings? _settings;
        private DateTime? _scheduledStop;
        private bool _shutdownAfterQueue;
        private bool _stopped;

        public event EventHandler<QueueStateChangedEventArgs>? QueueStateChanged;

        public DownloadScheduler(IDownloadEngine engine,
                                  IDownloadTaskStore store,
                                  ISettingsStore settingsStore,
                                  ILogger<DownloadScheduler> logger)
        {
            _engine = engine;
            _store = store;
            _settingsStore = settingsStore;
            _logger = logger;
        }

        public async Task InitializeAsync()
        {
            _settings = await _settingsStore.LoadAsync().ConfigureAwait(false);

            // Wire engine events so the scheduler can react to completion/failure.
            _engine.Completed += OnTaskCompleted;
            _engine.Failed += OnTaskFailed;
            _engine.StateChanged += OnTaskStateChanged;
            _engine.ProgressChanged += OnTaskProgress;

            // Restore unfinished tasks.
            var all = await _store.GetAllAsync().ConfigureAwait(false);
            foreach (var t in all.Where(t => t.Status == DownloadStatus.Downloading || t.Status == DownloadStatus.Resolving))
            {
                t.Status = DownloadStatus.Paused;
                await _store.UpdateStatusAsync(t.Id, t.Status, t.DownloadedBytes, null).ConfigureAwait(false);
            }

            // Re-enqueue anything paused/waiting so the user can resume.
            foreach (var t in all.Where(t => t.Status == DownloadStatus.Queued))
                _queue.Enqueue(t);

            _queuePoller = new Timer(_ => PollQueue(), null, 1000, 1000);
            _logger.LogInformation("Scheduler initialized with {Count} queued tasks", _queue.Count);
        }

        public void Enqueue(DownloadTask task)
        {
            if (_stopped) return;
            lock (_queueLock) _queue.Enqueue(task);
            task.Status = DownloadStatus.Queued;
            _ = _store.UpdateStatusAsync(task.Id, task.Status, task.DownloadedBytes, null);
            PollQueue();
        }

        public void Pause(DownloadTask task)
        {
            if (_ctsByTask.TryRemove(task.Id, out var cts))
            {
                cts.Cancel();
                cts.Dispose();
            }
            task.Status = DownloadStatus.Paused;
            _ = _store.UpdateStatusAsync(task.Id, task.Status, task.DownloadedBytes, null);
        }

        public void Resume(DownloadTask task)
        {
            if (task.Status == DownloadStatus.Completed) return;
            task.Status = DownloadStatus.Queued;
            _ = _store.UpdateStatusAsync(task.Id, task.Status, task.DownloadedBytes, null);
            lock (_queueLock) _queue.Enqueue(task);
            PollQueue();
        }

        public void Cancel(DownloadTask task)
        {
            if (_ctsByTask.TryRemove(task.Id, out var cts))
            {
                cts.Cancel();
                cts.Dispose();
            }
            task.Status = DownloadStatus.Stopped;
            _ = _store.UpdateStatusAsync(task.Id, task.Status, task.DownloadedBytes, "Cancelled by user");
        }

        public void StartAll()
        {
            _stopped = false;
            _ = Task.Run(async () =>
            {
                var all = await _store.GetAllAsync().ConfigureAwait(false);
                foreach (var t in all.Where(t => t.CanResume))
                {
                    t.Status = DownloadStatus.Queued;
                    await _store.UpdateStatusAsync(t.Id, t.Status, t.DownloadedBytes, null).ConfigureAwait(false);
                    lock (_queueLock) _queue.Enqueue(t);
                }
                PollQueue();
            });
        }

        public void PauseAll()
        {
            foreach (var kv in _ctsByTask.ToList())
            {
                try { kv.Value.Cancel(); } catch { }
            }
            _ = Task.Run(async () =>
            {
                var active = await _store.GetByStatusAsync(DownloadStatus.Downloading).ConfigureAwait(false);
                foreach (var t in active)
                {
                    t.Status = DownloadStatus.Paused;
                    await _store.UpdateStatusAsync(t.Id, t.Status, t.DownloadedBytes, null).ConfigureAwait(false);
                }
            });
        }

        public void StopAll()
        {
            _stopped = true;
            foreach (var kv in _ctsByTask.ToList())
            {
                try { kv.Value.Cancel(); } catch { }
            }
        }

        public void ScheduleQueueStart(DateTime at)
        {
            _ = Task.Run(async () =>
            {
                var delay = at - DateTime.UtcNow;
                if (delay > TimeSpan.Zero) await Task.Delay(delay).ConfigureAwait(false);
                StartAll();
            });
        }

        public void ScheduleQueueStop(DateTime at)
        {
            _scheduledStop = at;
        }

        public async Task OptionallyShutdownAfterQueueCompletesAsync(bool requireConfirmation)
        {
            _shutdownAfterQueue = true;
            _logger.LogInformation("System shutdown scheduled after queue completion (confirmation={Conf})", requireConfirmation);
            await Task.CompletedTask;
        }

        private void PollQueue()
        {
            if (_stopped || _settings == null) return;

            // Honour scheduled stop.
            if (_scheduledStop.HasValue && DateTime.UtcNow >= _scheduledStop.Value)
            {
                StopAll();
                _scheduledStop = null;
                return;
            }

            // Drain queue up to max simultaneous.
            while (_running.Count < _settings.MaxSimultaneousDownloads && _queue.TryDequeue(out var task))
            {
                StartTask(task);
            }

            // Emit aggregate state.
            var active = _running.Count;
            int queued = _queue.Count;
            long totalSpeed = _running.Values.Sum(r => r.LastSpeed);
            QueueStateChanged?.Invoke(this, new QueueStateChangedEventArgs(active, queued, 0, totalSpeed));
        }

        private void StartTask(DownloadTask task)
        {
            var cts = new CancellationTokenSource();
            _ctsByTask[task.Id] = cts;
            var running = new RunningTask { TaskId = task.Id, StartedAt = DateTime.UtcNow };
            _running[task.Id] = running;

            _ = Task.Run(async () =>
            {
                try
                {
                    task.StartedAt = DateTime.UtcNow;
                    await _engine.ExecuteAsync(task, cts.Token).ConfigureAwait(false);
                }
                catch (OperationCanceledException)
                {
                    _logger.LogInformation("Task {Id} cancelled", task.Id);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Task {Id} threw an unhandled exception", task.Id);
                }
                finally
                {
                    _running.TryRemove(task.Id, out _);
                    _ctsByTask.TryRemove(task.Id, out var c);
                    c?.Dispose();
                    PollQueue();
                }
            });
        }

        private void OnTaskCompleted(object? sender, DownloadCompletedEventArgs e)
        {
            _ = Task.Run(async () =>
            {
                var task = await _store.GetByIdAsync(e.TaskId).ConfigureAwait(false);
                if (task != null)
                {
                    task.Status = DownloadStatus.Completed;
                    task.CompletedAt = DateTime.UtcNow;
                    task.DownloadedBytes = e.TotalBytes;
                    await _store.UpdateStatusAsync(task.Id, task.Status, task.DownloadedBytes, null).ConfigureAwait(false);
                }
                if (_shutdownAfterQueue && _running.IsEmpty && _queue.IsEmpty)
                {
                    _logger.LogInformation("Queue complete; initiating system shutdown");
                    InitiateSystemShutdown();
                }
            });
        }

        private void OnTaskFailed(object? sender, DownloadFailedEventArgs e)
        {
            if (!e.WillRetry)
            {
                _ = _store.UpdateStatusAsync(e.TaskId, DownloadStatus.Failed, 0, e.ErrorMessage);
            }
        }

        private void OnTaskStateChanged(object? sender, DownloadStateChangedEventArgs e)
        {
            _ = _store.UpdateStatusAsync(e.TaskId, e.NewStatus, 0, e.ErrorMessage);
        }

        private void OnTaskProgress(object? sender, DownloadProgressEventArgs e)
        {
            if (_running.TryGetValue(e.Update.TaskId, out var r))
            {
                r.LastSpeed = e.Update.CurrentSpeedBytesPerSec;
            }
            _ = _store.UpdateStatusAsync(e.Update.TaskId, DownloadStatus.Downloading, e.Update.DownloadedBytes, null);
        }

        private void InitiateSystemShutdown()
        {
            // Explicit confirmation is required by the spec. The UI shows a Yes/No dialog before
            // this is ever invoked. We do NOT bypass the OS-level shutdown dialog.
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "shutdown.exe",
                    Arguments = "/s /t 60 /c \"Sawan Download Pro: queue complete. Computer will shut down in 60 seconds.\"",
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                System.Diagnostics.Process.Start(psi);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to initiate system shutdown");
            }
        }

        public void Dispose()
        {
            _queuePoller?.Dispose();
            foreach (var kv in _ctsByTask)
            {
                try { kv.Value.Cancel(); kv.Value.Dispose(); } catch { }
            }
            _engine.Completed -= OnTaskCompleted;
            _engine.Failed -= OnTaskFailed;
            _engine.StateChanged -= OnTaskStateChanged;
            _engine.ProgressChanged -= OnTaskProgress;
        }

        private sealed class RunningTask
        {
            public string TaskId { get; set; } = string.Empty;
            public DateTime StartedAt { get; set; }
            public long LastSpeed { get; set; }
        }
    }
}
