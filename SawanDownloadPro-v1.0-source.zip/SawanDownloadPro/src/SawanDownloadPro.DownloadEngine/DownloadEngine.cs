using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Events;
using SawanDownloadPro.Core.Exceptions;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;
using SawanDownloadPro.DownloadEngine.Http;
using SawanDownloadPro.DownloadEngine.Segments;
using SawanDownloadPro.DownloadEngine.Throttling;

namespace SawanDownloadPro.DownloadEngine
{
    /// <summary>
    /// Top-level engine implementation. Routes to single-stream or segmented download based on
    /// server range support and the task's <see cref="DownloadTask.MaxConnections"/> setting.
    /// </summary>
    public sealed class DownloadEngine : IDownloadEngine
    {
        private readonly ILogger<DownloadEngine> _logger;
        private readonly BandwidthThrottle _throttle;
        private readonly int _connectionTimeoutSec;
        private readonly int _readWriteTimeoutSec;
        private readonly int _maxRetryAttempts;
        private readonly int _retryInitialDelayMs;
        private readonly double _retryMultiplier;
        private readonly int _retryMaxDelayMs;

        public event EventHandler<DownloadProgressEventArgs>? ProgressChanged;
        public event EventHandler<DownloadStateChangedEventArgs>? StateChanged;
        public event EventHandler<DownloadCompletedEventArgs>? Completed;
        public event EventHandler<DownloadFailedEventArgs>? Failed;

        public DownloadEngine(ILogger<DownloadEngine> logger,
                              BandwidthThrottle throttle,
                              int connectionTimeoutSec,
                              int readWriteTimeoutSec,
                              int maxRetryAttempts,
                              int retryInitialDelayMs,
                              double retryMultiplier,
                              int retryMaxDelayMs)
        {
            _logger = logger;
            _throttle = throttle;
            _connectionTimeoutSec = connectionTimeoutSec;
            _readWriteTimeoutSec = readWriteTimeoutSec;
            _maxRetryAttempts = maxRetryAttempts;
            _retryInitialDelayMs = retryInitialDelayMs;
            _retryMultiplier = retryMultiplier;
            _retryMaxDelayMs = retryMaxDelayMs;
        }

        public async Task<UrlMetadata> ProbeAsync(string url,
                                                   AuthenticationScheme auth,
                                                   string? username,
                                                   string? password,
                                                   IReadOnlyDictionary<string, string>? customHeaders,
                                                   CancellationToken cancellationToken)
        {
            TlsConfiguration.EnsureApplied();
            var probe = new UrlProbe(_logger, _connectionTimeoutSec);
            return await probe.ProbeAsync(url, auth, username, password, customHeaders, cancellationToken).ConfigureAwait(false);
        }

        public async Task ExecuteAsync(DownloadTask task, CancellationToken cancellationToken)
        {
            if (task == null) throw new ArgumentNullException(nameof(task));
            if (string.IsNullOrWhiteSpace(task.Url)) throw new ArgumentException("Task URL is empty", nameof(task));

            TlsConfiguration.EnsureApplied();

            SetStatus(task, DownloadStatus.Resolving);
            var probe = new UrlProbe(_logger, _connectionTimeoutSec);

            UrlMetadata meta;
            try
            {
                meta = await probe.ProbeAsync(task.Url, task.AuthScheme, task.AuthUsername, task.AuthPassword,
                                              task.CustomHeaders, cancellationToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException) { SetStatus(task, DownloadStatus.Paused); return; }
            catch (Exception ex)
            {
                SetStatus(task, DownloadStatus.Failed, ex.Message);
                return;
            }

            if (!meta.Success)
            {
                SetStatus(task, DownloadStatus.Failed, meta.ErrorMessage ?? "Probe failed");
                Failed?.Invoke(this, new DownloadFailedEventArgs(task.Id, meta.ErrorMessage ?? "Probe failed", meta.HttpStatusCode, false, 0, TimeSpan.Zero));
                return;
            }

            task.FinalUrl = meta.FinalUrl;
            task.AcceptRanges = meta.AcceptRanges;
            task.ETag = meta.ETag;
            task.LastModified = meta.LastModified;
            if (!string.IsNullOrWhiteSpace(meta.FileName)) task.FileName = meta.FileName;
            task.TotalBytes = meta.ContentLength;

            if (task.SpeedLimitBytesPerSec.HasValue)
                _throttle.SetPerTaskLimit(task.Id, task.SpeedLimitBytesPerSec.Value);

            task.PartFilePath = Path.Combine(task.SavePath, task.FileName + ".sawanpart");
            task.MetaFilePath = Path.Combine(task.SavePath, task.FileName + ".sawanmeta");

            // Disk space check (when Content-Length is known).
            if (task.TotalBytes.HasValue)
            {
                var drive = new DriveInfo(Path.GetPathRoot(task.SavePath) ?? "C:\\");
                if (drive.IsReady && drive.AvailableFreeSpace < task.TotalBytes.Value)
                {
                    var ex = new DiskSpaceException(task.TotalBytes.Value, drive.AvailableFreeSpace);
                    SetStatus(task, DownloadStatus.Failed, ex.Message);
                    Failed?.Invoke(this, new DownloadFailedEventArgs(task.Id, ex.Message, null, false, 0, TimeSpan.Zero));
                    return;
                }
            }

            try
            {
                SetStatus(task, DownloadStatus.Downloading);

                if (task.AcceptRanges && task.MaxConnections > 1 && task.TotalBytes.HasValue && task.TotalBytes.Value > 1_000_000)
                {
                    await RunSegmentedAsync(task, cancellationToken).ConfigureAwait(false);
                }
                else
                {
                    await RunSingleStreamAsync(task, cancellationToken).ConfigureAwait(false);
                }
            }
            catch (OperationCanceledException)
            {
                SetStatus(task, DownloadStatus.Paused);
                throw;
            }
            catch (Exception ex)
            {
                SetStatus(task, DownloadStatus.Failed, ex.Message);
                Failed?.Invoke(this, new DownloadFailedEventArgs(task.Id, ex.Message, null, false, 0, TimeSpan.Zero));
            }
        }

        private async Task RunSingleStreamAsync(DownloadTask task, CancellationToken ct)
        {
            var writer = new PartialFileWriter(task.PartFilePath!, task.MetaFilePath!, _logger);
            var policy = new RetryPolicy(_maxRetryAttempts, _retryInitialDelayMs, _retryMultiplier, _retryMaxDelayMs);

            long startPos = 0;
            var existingMeta = await writer.TryReadMetaAsync(ct).ConfigureAwait(false);
            if (existingMeta != null && existingMeta.Segments.Count > 0 && existingMeta.Segments[0].DownloadedBytes > 0)
            {
                startPos = existingMeta.Segments[0].StartByte + existingMeta.Segments[0].DownloadedBytes;
                _logger.LogInformation("Resuming {File} from byte {Start}", task.FileName, startPos);
            }

            int attempt = 0;
            while (true)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    var req = (HttpWebRequest)WebRequest.Create(task.FinalUrl);
                    req.Method = "GET";
                    req.Timeout = _connectionTimeoutSec * 1000;
                    req.ReadWriteTimeout = _readWriteTimeoutSec * 1000;
                    req.AllowAutoRedirect = true;
                    req.UserAgent = "SawanDownloadPro/1.0 (+https://sawan.example)";
                    if (startPos > 0) req.AddRange(startPos);
                    ApplyAuthAndHeaders(req, task);

                    using var resp = (HttpWebResponse)await req.GetResponseAsync().WithCancellation(ct).ConfigureAwait(false);

                    if (resp.StatusCode != HttpStatusCode.OK && resp.StatusCode != HttpStatusCode.PartialContent)
                        throw new DownloadEngineException($"Unexpected HTTP {resp.StatusCode}", (int)resp.StatusCode);

                    using var fs = writer.OpenOrCreate(task.TotalBytes);
                    fs.Seek(startPos, SeekOrigin.Begin);

                    using var respStream = resp.GetResponseStream();
                    var buffer = new byte[65536];
                    long downloadedThisSession = 0;
                    var startedAt = DateTime.UtcNow;
                    int lastReportTick = 0;

                    while (true)
                    {
                        ct.ThrowIfCancellationRequested();
                        var allowed = _throttle.RequestQuota(task.Id, buffer.Length, ct);
                        if (allowed <= 0) continue;
                        if (allowed < buffer.Length) Array.Resize(ref buffer, allowed);

                        int read = await respStream.ReadAsync(buffer, 0, buffer.Length, ct).ConfigureAwait(false);
                        if (read == 0) break;

                        await fs.WriteAsync(buffer, 0, read, ct).ConfigureAwait(false);
                        startPos += read;
                        downloadedThisSession += read;
                        task.DownloadedBytes = startPos;

                        var tick = Environment.TickCount;
                        if (tick - lastReportTick >= 500)
                        {
                            lastReportTick = tick;
                            var elapsed = (DateTime.UtcNow - startedAt).TotalSeconds;
                            if (elapsed > 0.1) task.CurrentSpeed = (long)(downloadedThisSession / elapsed);
                            task.ActiveConnections = 1;
                            ReportProgress(task);
                        }
                    }

                    await fs.FlushAsync(ct).ConfigureAwait(false);

                    // Persist final meta (so we know the file is fully written).
                    var finalMeta = new ResumeMeta
                    {
                        Url = task.Url,
                        FinalUrl = task.FinalUrl,
                        TotalBytes = task.TotalBytes,
                        ETag = task.ETag,
                        LastModified = task.LastModified,
                        AcceptRanges = task.AcceptRanges,
                        Segments = new List<SegmentResume> { new() { StartByte = 0, EndByte = startPos - 1, DownloadedBytes = startPos } }
                    };
                    await writer.WriteMetaAsync(finalMeta, ct).ConfigureAwait(false);

                    var finalPath = Path.Combine(task.SavePath, task.FileName);
                    writer.FinalizeFile(finalPath);

                    task.CompletedAt = DateTime.UtcNow;
                    SetStatus(task, DownloadStatus.Completed);
                    Completed?.Invoke(this, new DownloadCompletedEventArgs(task.Id, finalPath, startPos, task.CompletedAt.Value - (task.StartedAt ?? task.CreatedAt)));
                    return;
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex) when (!(ex is DownloadEngineException))
                {
                    attempt++;
                    var httpCode = (ex as WebException)?.Response is HttpWebResponse h ? (int)h.StatusCode : (int?)null;
                    var delay = policy.GetDelay(attempt, httpCode, ex is WebException w ? (w.Response as HttpWebResponse)?.Headers["Retry-After"] : null);
                    if (!delay.HasValue)
                    {
                        SetStatus(task, DownloadStatus.Failed, ex.Message);
                        Failed?.Invoke(this, new DownloadFailedEventArgs(task.Id, ex.Message, httpCode, false, attempt, TimeSpan.Zero));
                        return;
                    }
                    _logger.LogWarning(ex, "Attempt {N} failed for {File}; retrying in {Delay}ms", attempt, task.FileName, delay.Value.TotalMilliseconds);
                    SetStatus(task, DownloadStatus.WaitingForRetry, ex.Message);
                    Failed?.Invoke(this, new DownloadFailedEventArgs(task.Id, ex.Message, httpCode, true, attempt, delay.Value));
                    await policy.WaitAsync(delay.Value, ct).ConfigureAwait(false);
                    SetStatus(task, DownloadStatus.Downloading);
                }
            }
        }

        private async Task RunSegmentedAsync(DownloadTask task, CancellationToken ct)
        {
            var writer = new PartialFileWriter(task.PartFilePath!, task.MetaFilePath!, _logger);
            var total = task.TotalBytes!.Value;
            int segCount = Math.Min(task.MaxConnections, Math.Max(1, (int)(total / 1_000_000))); // ~1MB per segment minimum

            var segments = new List<SegmentInfo>(segCount);
            long perSeg = total / segCount;
            for (int i = 0; i < segCount; i++)
            {
                long start = i * perSeg;
                long end = (i == segCount - 1) ? total - 1 : (start + perSeg - 1);
                segments.Add(new SegmentInfo
                {
                    DownloadId = task.Id,
                    Position = i,
                    StartByte = start,
                    EndByte = end,
                    Status = SegmentStatus.Pending
                });
            }

            // Restore segment progress if a resume meta exists.
            var existingMeta = await writer.TryReadMetaAsync(ct).ConfigureAwait(false);
            if (existingMeta != null && existingMeta.Segments.Count == segments.Count)
            {
                for (int i = 0; i < segments.Count; i++)
                {
                    segments[i].DownloadedBytes = existingMeta.Segments[i].DownloadedBytes;
                    if (segments[i].DownloadedBytes >= segments[i].Size) segments[i].Status = SegmentStatus.Completed;
                }
            }

            task.Segments = segments;
            task.ActiveConnections = 0;

            using var fs = writer.OpenOrCreate(total);
            var policy = new RetryPolicy(_maxRetryAttempts, _retryInitialDelayMs, _retryMultiplier, _retryMaxDelayMs);
            var segTasks = new Task[segCount];
            var startedAt = DateTime.UtcNow;

            for (int i = 0; i < segCount; i++)
            {
                var seg = segments[i];
                if (seg.Status == SegmentStatus.Completed) continue;
                segTasks[i] = RunSegmentAsync(task, seg, fs, writer, policy, ct);
            }

            // Progress reporter.
            var progressCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            var progressTask = Task.Run(async () =>
            {
                while (!progressCts.Token.IsCancellationRequested)
                {
                    long downloaded = 0;
                    int active = 0;
                    foreach (var s in segments)
                    {
                        downloaded += s.DownloadedBytes;
                        if (s.Status == SegmentStatus.Active) active++;
                    }
                    task.DownloadedBytes = downloaded;
                    task.ActiveConnections = active;
                    var elapsed = (DateTime.UtcNow - startedAt).TotalSeconds;
                    if (elapsed > 0.1) task.AverageSpeed = (long)(downloaded / elapsed);
                    ReportProgress(task);
                    try { await Task.Delay(500, progressCts.Token).ConfigureAwait(false); } catch { break; }
                }
            }, progressCts.Token);

            try
            {
                await Task.WhenAll(segTasks.Where(t => t != null)).ConfigureAwait(false);
            }
            finally
            {
                progressCts.Cancel();
                try { await progressTask.ConfigureAwait(false); } catch { }
            }

            // If any segment failed permanently, the task failed.
            if (segments.Any(s => s.Status == SegmentStatus.Failed))
            {
                SetStatus(task, DownloadStatus.Failed, "One or more segments failed");
                Failed?.Invoke(this, new DownloadFailedEventArgs(task.Id, "Segment failure", null, false, 0, TimeSpan.Zero));
                return;
            }

            // Final meta + atomic finalize.
            await fs.FlushAsync(ct).ConfigureAwait(false);
            var finalMeta = new ResumeMeta
            {
                Url = task.Url,
                FinalUrl = task.FinalUrl,
                TotalBytes = total,
                ETag = task.ETag,
                LastModified = task.LastModified,
                AcceptRanges = true,
                Segments = segments.Select(s => new SegmentResume { StartByte = s.StartByte, EndByte = s.EndByte, DownloadedBytes = s.DownloadedBytes }).ToList()
            };
            await writer.WriteMetaAsync(finalMeta, ct).ConfigureAwait(false);

            var finalPath = Path.Combine(task.SavePath, task.FileName);
            fs.Dispose();
            writer.FinalizeFile(finalPath);

            task.CompletedAt = DateTime.UtcNow;
            SetStatus(task, DownloadStatus.Completed);
            Completed?.Invoke(this, new DownloadCompletedEventArgs(task.Id, finalPath, total, task.CompletedAt.Value - (task.StartedAt ?? task.CreatedAt)));
        }

        private async Task RunSegmentAsync(DownloadTask task, SegmentInfo seg, FileStream fs, PartialFileWriter writer, RetryPolicy policy, CancellationToken ct)
        {
            int attempt = 0;
            while (true)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    seg.Status = SegmentStatus.Active;
                    var req = (HttpWebRequest)WebRequest.Create(task.FinalUrl);
                    req.Method = "GET";
                    req.Timeout = _connectionTimeoutSec * 1000;
                    req.ReadWriteTimeout = _readWriteTimeoutSec * 1000;
                    req.AllowAutoRedirect = true;
                    req.UserAgent = "SawanDownloadPro/1.0 (+https://sawan.example)";
                    req.AddRange(seg.StartByte + seg.DownloadedBytes, seg.EndByte);
                    ApplyAuthAndHeaders(req, task);

                    using var resp = (HttpWebResponse)await req.GetResponseAsync().WithCancellation(ct).ConfigureAwait(false);

                    if (resp.StatusCode != HttpStatusCode.PartialContent && resp.StatusCode != HttpStatusCode.OK)
                        throw new DownloadEngineException($"Segment {seg.Position} got HTTP {resp.StatusCode}", (int)resp.StatusCode);

                    using var respStream = resp.GetResponseStream();
                    var buffer = new byte[65536];
                    var segStartedAt = DateTime.UtcNow;
                    long segSessionBytes = 0;
                    int lastSpeedTick = 0;

                    while (seg.DownloadedBytes < seg.Size)
                    {
                        ct.ThrowIfCancellationRequested();
                        var allowed = _throttle.RequestQuota(task.Id, buffer.Length, ct);
                        if (allowed <= 0) continue;
                        if (allowed < buffer.Length) Array.Resize(ref buffer, allowed);

                        int read = await respStream.ReadAsync(buffer, 0, buffer.Length, ct).ConfigureAwait(false);
                        if (read == 0) break;

                        long offset = seg.StartByte + seg.DownloadedBytes;
                        fs.Seek(offset, SeekOrigin.Begin);
                        await fs.WriteAsync(buffer, 0, read, ct).ConfigureAwait(false);

                        seg.DownloadedBytes += read;
                        segSessionBytes += read;

                        var tick = Environment.TickCount;
                        if (tick - lastSpeedTick >= 500)
                        {
                            lastSpeedTick = tick;
                            var elapsed = (DateTime.UtcNow - segStartedAt).TotalSeconds;
                            if (elapsed > 0.1) seg.CurrentSpeed = (long)(segSessionBytes / elapsed);
                        }
                    }

                    if (seg.DownloadedBytes < seg.Size)
                        throw new DownloadEngineException($"Segment {seg.Position} truncated: {seg.DownloadedBytes}/{seg.Size} bytes");

                    seg.Status = SegmentStatus.Completed;
                    return;
                }
                catch (OperationCanceledException) { seg.Status = SegmentStatus.Pending; throw; }
                catch (Exception ex) when (!(ex is DownloadEngineException))
                {
                    attempt++;
                    var httpCode = (ex as WebException)?.Response is HttpWebResponse h ? (int)h.StatusCode : (int?)null;
                    var delay = policy.GetDelay(attempt, httpCode, ex is WebException w ? (w.Response as HttpWebResponse)?.Headers["Retry-After"] : null);
                    if (!delay.HasValue)
                    {
                        seg.Status = SegmentStatus.Failed;
                        _logger.LogError(ex, "Segment {Pos} failed permanently", seg.Position);
                        return;
                    }
                    _logger.LogWarning(ex, "Segment {Pos} attempt {N} failed; retry in {Ms}ms", seg.Position, attempt, delay.Value.TotalMilliseconds);
                    await policy.WaitAsync(delay.Value, ct).ConfigureAwait(false);
                }
            }
        }

        private void ApplyAuthAndHeaders(HttpWebRequest req, DownloadTask task)
        {
            if (task.AuthScheme != AuthenticationScheme.None && !string.IsNullOrEmpty(task.AuthUsername))
            {
                var cc = new CredentialCache();
                var scheme = task.AuthScheme == AuthenticationScheme.Basic ? "Basic" : "Digest";
                cc.Add(req.RequestUri, scheme, new NetworkCredential(task.AuthUsername, task.AuthPassword ?? string.Empty));
                req.Credentials = cc;
                req.PreAuthenticate = true;
            }
            if (task.CustomHeaders != null)
            {
                foreach (var kv in task.CustomHeaders)
                {
                    if (string.Equals(kv.Key, "Host", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(kv.Key, "Connection", StringComparison.OrdinalIgnoreCase) ||
                        string.Equals(kv.Key, "Content-Length", StringComparison.OrdinalIgnoreCase)) continue;
                    try { req.Headers[kv.Key] = kv.Value; } catch { }
                }
            }
        }

        private void SetStatus(DownloadTask task, DownloadStatus newStatus, string? errorMessage = null)
        {
            var oldStatus = task.Status;
            if (oldStatus == newStatus) return;
            task.Status = newStatus;
            if (newStatus == DownloadStatus.Downloading && !task.StartedAt.HasValue) task.StartedAt = DateTime.UtcNow;
            if (newStatus == DownloadStatus.Failed) task.ErrorMessage = errorMessage;
            StateChanged?.Invoke(this, new DownloadStateChangedEventArgs(task.Id, oldStatus, newStatus, errorMessage));
        }

        private void ReportProgress(DownloadTask task)
        {
            TimeSpan? eta = null;
            if (task.TotalBytes.HasValue && task.TotalBytes.Value > 0 && task.CurrentSpeed > 0)
            {
                var remaining = task.TotalBytes.Value - task.DownloadedBytes;
                eta = TimeSpan.FromSeconds(remaining / (double)task.CurrentSpeed);
            }
            var update = new DownloadTaskUpdate
            {
                TaskId = task.Id,
                DownloadedBytes = task.DownloadedBytes,
                TotalBytes = task.TotalBytes,
                CurrentSpeedBytesPerSec = task.CurrentSpeed,
                AverageSpeedBytesPerSec = task.AverageSpeed,
                ActiveConnections = task.ActiveConnections,
                EstimatedTimeRemaining = eta
            };
            ProgressChanged?.Invoke(this, new DownloadProgressEventArgs(update));
        }

        public void Dispose() => _throttle.Dispose();
    }
}
