using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Exceptions;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.DownloadEngine.Segments
{
    /// <summary>
    /// Writes segment bytes to a .part file at the correct absolute offset. Atomic finalization
    /// is performed by <see cref="FinalizeFile"/> after all segments complete.
    /// </summary>
    internal sealed class PartialFileWriter
    {
        private readonly string _partFilePath;
        private readonly string _metaFilePath;
        private readonly ILogger _logger;

        public PartialFileWriter(string partFilePath, string metaFilePath, ILogger logger)
        {
            _partFilePath = partFilePath;
            _metaFilePath = metaFilePath;
            _logger = logger;
        }

        /// <summary>
        /// Open or create the .part file pre-allocated to the supplied size (when known).
        /// Pre-allocation reduces fragmentation on NTFS.
        /// </summary>
        public FileStream OpenOrCreate(long? totalBytes)
        {
            var dir = Path.GetDirectoryName(_partFilePath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);

            var fs = new FileStream(_partFilePath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite | FileShare.Delete,
                                    bufferSize: 65536, FileOptions.Asynchronous | FileOptions.SequentialScan);

            if (totalBytes.HasValue && fs.Length < totalBytes.Value && fs.Length == 0)
            {
                try { fs.SetLength(totalBytes.Value); } catch { /* best-effort */ }
            }
            return fs;
        }

        public async Task WriteSegmentChunkAsync(FileStream fs, long offset, byte[] buffer, int count, CancellationToken ct)
        {
            fs.Seek(offset, SeekOrigin.Begin);
            await fs.WriteAsync(buffer, 0, count, ct).ConfigureAwait(false);
        }

        /// <summary>
        /// Persists resume metadata (URL, ETag, Last-Modified, total bytes, per-segment progress) to
        /// the .sawanmeta sidecar file. The format is JSON-ish and SHA-256-signed for tamper resistance.
        /// </summary>
        public async Task WriteMetaAsync(ResumeMeta meta, CancellationToken ct)
        {
            var json = Newtonsoft.Json.JsonConvert.SerializeObject(meta);
            var bytes = Encoding.UTF8.GetBytes(json);
            var hash = ComputeSha256(bytes);

            using var fs = new FileStream(_metaFilePath, FileMode.Create, FileAccess.Write, FileShare.None, 4096, FileOptions.Asynchronous);
            await fs.WriteAsync(hash, 0, hash.Length, ct).ConfigureAwait(false);
            await fs.WriteAsync(bytes, 0, bytes.Length, ct).ConfigureAwait(false);
            await fs.FlushAsync(ct).ConfigureAwait(false);
        }

        /// <summary>
        /// Reads and validates the resume metadata sidecar. Returns null if the file does not exist
        /// or the SHA-256 signature does not match (i.e. tampered or corrupted).
        /// </summary>
        public async Task<ResumeMeta?> TryReadMetaAsync(CancellationToken ct)
        {
            if (!File.Exists(_metaFilePath)) return null;

            try
            {
                using var fs = new FileStream(_metaFilePath, FileMode.Open, FileAccess.Read, FileShare.Read, 4096, FileOptions.Asynchronous);
                var hash = new byte[32];
                var read = await fs.ReadAsync(hash, 0, 32, ct).ConfigureAwait(false);
                if (read != 32) return null;

                var rest = new byte[(int)fs.Length - 32];
                var _ = await fs.ReadAsync(rest, 0, rest.Length, ct).ConfigureAwait(false);
                var actual = ComputeSha256(rest);
                for (int i = 0; i < 32; i++) if (actual[i] != hash[i]) return null;

                return Newtonsoft.Json.JsonConvert.DeserializeObject<ResumeMeta>(System.Text.Encoding.UTF8.GetString(rest));
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to read resume meta from {Path}", _metaFilePath);
                return null;
            }
        }

        /// <summary>
        /// Renames the .part file to its final destination, then deletes the .sawanmeta sidecar.
        /// Atomic on NTFS when both files are on the same volume.
        /// </summary>
        public void FinalizeFile(string finalPath)
        {
            var dir = Path.GetDirectoryName(finalPath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);

            if (File.Exists(finalPath))
            {
                // If the target exists and matches in size, assume the user already has the file.
                var partLen = new FileInfo(_partFilePath).Length;
                var finalLen = new FileInfo(finalPath).Length;
                if (partLen == finalLen)
                {
                    File.Delete(_partFilePath);
                }
                else
                {
                    File.Delete(finalPath);
                    File.Move(_partFilePath, finalPath);
                }
            }
            else
            {
                File.Move(_partFilePath, finalPath);
            }

            if (File.Exists(_metaFilePath)) File.Delete(_metaFilePath);
        }

        private static byte[] ComputeSha256(byte[] data)
        {
            using var sha = SHA256.Create();
            return sha.ComputeHash(data);
        }

        public void DeletePartAndMeta()
        {
            try { if (File.Exists(_partFilePath)) File.Delete(_partFilePath); } catch (Exception ex) { _logger.LogWarning(ex, "Could not delete part file"); }
            try { if (File.Exists(_metaFilePath)) File.Delete(_metaFilePath); } catch (Exception ex) { _logger.LogWarning(ex, "Could not delete meta file"); }
        }
    }

    /// <summary>
    /// Persisted to disk as the .sawanmeta sidecar. SHA-256-signed by <see cref="PartialFileWriter"/>.
    /// </summary>
    public sealed class ResumeMeta
    {
        public string Url { get; set; } = string.Empty;
        public string FinalUrl { get; set; } = string.Empty;
        public long? TotalBytes { get; set; }
        public string? ETag { get; set; }
        public string? LastModified { get; set; }
        public bool AcceptRanges { get; set; }
        public System.Collections.Generic.List<SegmentResume> Segments { get; set; } = new();
    }

    public sealed class SegmentResume
    {
        public long StartByte { get; set; }
        public long EndByte { get; set; }
        public long DownloadedBytes { get; set; }
    }
}
