using System;
using System.Net;
using System.Net.Security;
using System.Security.Authentication;

namespace SawanDownloadPro.DownloadEngine.Http
{
    /// <summary>
    /// Centralized TLS configuration. Windows 7 SP1 defaults to TLS 1.0/1.1 which most modern
    /// servers reject. We force TLS 1.2 minimum, which is supported on Win7 SP1 after the
    /// KB4019276 update.
    /// </summary>
    internal static class TlsConfiguration
    {
        private static int _applied;

        /// <summary>
        /// Idempotent. Safe to call from every engine entry point.
        /// </summary>
        public static void EnsureApplied()
        {
            if (System.Threading.Interlocked.Exchange(ref _applied, 1) == 1) return;

            try
            {
                // TLS 1.2 is the minimum we will negotiate. TLS 1.3 is not supported on Win7.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11;
            }
            catch
            {
                // Older .NET Frameworks may not have the Tls12 enum value; fall back to whatever the OS offers.
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11;
            }

            ServicePointManager.CheckCertificateRevocationList = false; // Win7 often lacks fresh CRLs; we trade strictness for compatibility
            ServicePointManager.ServerCertificateValidationCallback = (sender, cert, chain, sslPolicyErrors) =>
            {
                // We DO validate; we just allow revocation-offline failures to proceed on Win7.
                // Any other policy error is a hard failure (return false).
                if (sslPolicyErrors == SslPolicyErrors.None) return true;
                if ((sslPolicyErrors & SslPolicyErrors.RemoteCertificateChainErrors) != 0)
                {
                    // Chain status will include revocation-offline on Win7. Allow only that specific case.
                    if (chain != null)
                    {
                        foreach (var status in chain.ChainStatus)
                        {
                            if (status.Status != System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.OfflineRevocation &&
                                status.Status != System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.RevocationStatusUnknown)
                            {
                                return false;
                            }
                        }
                        return true;
                    }
                }
                return false;
            };

            // Disable default Nagle for snappier small-range requests.
            ServicePointManager.UseNagleAlgorithm = false;
            ServicePointManager.Expect100Continue = false;

            // Reasonable default; per-task ServicePoint is configured in the engine.
            ServicePointManager.DefaultConnectionLimit = 64;
        }
    }
}
