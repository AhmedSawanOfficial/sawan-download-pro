using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Exceptions;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.DownloadEngine.Http
{
    /// <summary>
    /// Probes a URL with a HEAD request (falls back to GET with Range: bytes=0-0) to extract
    /// <see cref="UrlMetadata"/> without consuming the response body.
    /// </summary>
    internal sealed class UrlProbe
    {
        private readonly ILogger _logger;
        private readonly int _timeoutSec;

        public UrlProbe(ILogger logger, int timeoutSec)
        {
            _logger = logger;
            _timeoutSec = timeoutSec;
        }

        public async Task<UrlMetadata> ProbeAsync(string url,
                                                   AuthenticationScheme auth,
                                                   string? username,
                                                   string? password,
                                                   IReadOnlyDictionary<string, string>? customHeaders,
                                                   CancellationToken ct)
        {
            TlsConfiguration.EnsureApplied();

            var result = new UrlMetadata { FinalUrl = url };

            try
            {
                // Try HEAD first; many CDNs reject HEAD on dynamic endpoints.
                var meta = await TryProbeAsync("HEAD", url, auth, username, password, customHeaders, ct).ConfigureAwait(false);
                if (meta.Success || meta.HttpStatusCode == 405 || meta.HttpStatusCode == 403)
                {
                    // Some servers return 405 to HEAD; fall back to ranged GET.
                    if (!meta.Success)
                    {
                        _logger.LogDebug("HEAD failed with {Status}; falling back to ranged GET on {Url}", meta.HttpStatusCode, url);
                        meta = await TryProbeAsync("GET", url, auth, username, password, customHeaders, ct, range: "bytes=0-0").ConfigureAwait(false);
                    }
                    return meta;
                }
                return meta;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Probe failed for {Url}", url);
                result.ErrorMessage = ex.Message;
                return result;
            }
        }

        private async Task<UrlMetadata> TryProbeAsync(string method,
                                                       string url,
                                                       AuthenticationScheme auth,
                                                       string? username,
                                                       string? password,
                                                       IReadOnlyDictionary<string, string>? customHeaders,
                                                       CancellationToken ct,
                                                       string? range = null)
        {
            var result = new UrlMetadata { FinalUrl = url };

            var req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = method;
            req.Timeout = _timeoutSec * 1000;
            req.ReadWriteTimeout = _timeoutSec * 1000;
            req.AllowAutoRedirect = true;
            req.MaximumAutomaticRedirections = 10;
            req.UserAgent = "SawanDownloadPro/1.0 (+https://sawan.example)";
            req.KeepAlive = true;

            if (range != null) req.AddRange(0, 0);

            ApplyAuth(req, auth, username, password);
            ApplyCustomHeaders(req, customHeaders);

            try
            {
                using var resp = (HttpWebResponse)await req.GetResponseAsync().WithCancellation(ct).ConfigureAwait(false);
                result.Success = true;
                result.HttpStatusCode = (int)resp.StatusCode;
                result.FinalUrl = resp.ResponseUri.ToString();
                result.ContentLength = resp.ContentLength >= 0 ? resp.ContentLength : (long?)null;
                result.AcceptRanges = string.Equals(resp.Headers["Accept-Ranges"], "bytes", StringComparison.OrdinalIgnoreCase);
                result.ETag = resp.Headers["ETag"];
                result.LastModified = resp.Headers["Last-Modified"];
                result.ContentType = resp.ContentType;

                if (string.IsNullOrEmpty(result.FileName))
                {
                    result.FileName = FileNameExtractor.ExtractFromResponse(resp, url);
                }
                return result;
            }
            catch (WebException wex) when (wex.Response is HttpWebResponse errResp)
            {
                result.HttpStatusCode = (int)errResp.StatusCode;
                result.Success = false;
                result.ErrorMessage = $"HTTP {errResp.StatusCode}: {errResp.StatusDescription}";
                return result;
            }
            catch (WebException wex)
            {
                result.Success = false;
                result.ErrorMessage = wex.Status.ToString();
                return result;
            }
        }

        private static void ApplyAuth(HttpWebRequest req, AuthenticationScheme auth, string? u, string? p)
        {
            if (auth == AuthenticationScheme.None || string.IsNullOrEmpty(u)) return;
            var credentialCache = new CredentialCache();
            var uri = req.RequestUri;
            if (auth == AuthenticationScheme.Basic)
                credentialCache.Add(uri, "Basic", new NetworkCredential(u, p ?? string.Empty));
            else if (auth == AuthenticationScheme.Digest)
                credentialCache.Add(uri, "Digest", new NetworkCredential(u, p ?? string.Empty));
            req.Credentials = credentialCache;
            req.PreAuthenticate = true;
        }

        private static void ApplyCustomHeaders(HttpWebRequest req, IReadOnlyDictionary<string, string>? headers)
        {
            if (headers == null) return;
            foreach (var kv in headers)
            {
                // Restricted headers cannot be set via the indexer; ignore attempts to set them.
                if (string.Equals(kv.Key, "Host", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(kv.Key, "Connection", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(kv.Key, "Content-Length", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                try { req.Headers[kv.Key] = kv.Value; } catch { /* restricted header; ignore */ }
            }
        }
    }

    internal static class TaskExtensions
    {
        public static async Task<T> WithCancellation<T>(this Task<T> task, CancellationToken ct)
        {
            var tcs = new TaskCompletionSource<bool>();
            using (ct.Register(s => ((TaskCompletionSource<bool>)s!).TrySetCanceled(), tcs))
            {
                var completed = await Task.WhenAny(task, tcs.Task).ConfigureAwait(false);
                if (completed == tcs.Task)
                {
                    // Cancellation was requested. We still need to observe the original task
                    // to avoid unobserved-exception warnings.
                    _ = task.ContinueWith(t => { var _ = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted);
                    ct.ThrowIfCancellationRequested();
                }
                return await task.ConfigureAwait(false);
            }
        }
    }

    internal static class FileNameExtractor
    {
        public static string ExtractFromResponse(HttpWebResponse resp, string originalUrl)
        {
            // 1. Content-Disposition
            var cd = resp.Headers["Content-Disposition"];
            if (!string.IsNullOrEmpty(cd))
            {
                var fn = ParseContentDisposition(cd);
                if (!string.IsNullOrWhiteSpace(fn)) return Sanitize(fn);
            }

            // 2. URL path
            try
            {
                var uri = resp.ResponseUri;
                var seg = uri.Segments.Length > 0 ? uri.Segments[uri.Segments.Length - 1] : string.Empty;
                seg = Uri.UnescapeDataString(seg).Trim('/');
                if (!string.IsNullOrWhiteSpace(seg) && seg.IndexOfAny(System.IO.Path.GetInvalidFileNameChars()) < 0)
                    return Sanitize(seg);
            }
            catch { /* fall through */ }

            // 3. Fallback
            return "sawan_download_" + Guid.NewGuid().ToString("N").Substring(0, 8);
        }

        private static string? ParseContentDisposition(string cd)
        {
            // Very small parser for filename*=UTF-8''… and filename="…"
            var parts = cd.Split(';');
            foreach (var p in parts)
            {
                var t = p.Trim();
                if (t.StartsWith("filename*=", StringComparison.OrdinalIgnoreCase))
                {
                    var v = t.Substring("filename*=".Length);
                    var apostrophe = v.IndexOf('\'');
                    if (apostrophe >= 0 && v.IndexOf('\'', apostrophe + 1) is int a2 && a2 > apostrophe)
                    {
                        v = v.Substring(a2 + 1);
                    }
                    return Uri.UnescapeDataString(v.Trim('"'));
                }
                if (t.StartsWith("filename=", StringComparison.OrdinalIgnoreCase))
                {
                    return t.Substring("filename=".Length).Trim('"');
                }
            }
            return null;
        }

        private static string Sanitize(string s)
        {
            foreach (var c in System.IO.Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
            return s;
        }
    }
}
