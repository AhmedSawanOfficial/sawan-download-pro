using System;
using System.Threading;
using System.Threading.Tasks;

namespace SawanDownloadPro.DownloadEngine.Http
{
    /// <summary>
    /// Retry policy with exponential backoff and jitter. Honours Retry-After when present.
    /// </summary>
    internal sealed class RetryPolicy
    {
        private readonly int _maxAttempts;
        private readonly int _initialDelayMs;
        private readonly double _multiplier;
        private readonly int _maxDelayMs;
        private readonly Random _jitter = new();

        public RetryPolicy(int maxAttempts, int initialDelayMs, double multiplier, int maxDelayMs)
        {
            _maxAttempts = Math.Max(1, maxAttempts);
            _initialDelayMs = Math.Max(100, initialDelayMs);
            _multiplier = Math.Max(1.0, multiplier);
            _maxDelayMs = Math.Max(_initialDelayMs, maxDelayMs);
        }

        /// <summary>
        /// Returns the delay before the next attempt, or null if no further attempts should be made.
        /// </summary>
        public TimeSpan? GetDelay(int attempt, int? httpStatusCode, string? retryAfterHeader)
        {
            if (attempt >= _maxAttempts) return null;

            // Honour server Retry-After (delta-seconds or HTTP-date).
            if (!string.IsNullOrEmpty(retryAfterHeader))
            {
                if (int.TryParse(retryAfterHeader, out var secs))
                    return TimeSpan.FromSeconds(Math.Min(secs, _maxDelayMs / 1000));
                if (DateTimeOffset.TryParse(retryAfterHeader, out var dt))
                {
                    var delta = dt - DateTimeOffset.UtcNow;
                    if (delta > TimeSpan.Zero) return TimeSpan.FromMilliseconds(Math.Min(delta.TotalMilliseconds, _maxDelayMs));
                }
            }

            // 429 (Too Many Requests) and 5xx are retryable. 4xx generally is not.
            if (httpStatusCode.HasValue)
            {
                if (httpStatusCode == 429 || httpStatusCode >= 500) { /* retryable */ }
                else if (httpStatusCode >= 400 && httpStatusCode < 500) return null;
            }

            var baseDelay = _initialDelayMs * Math.Pow(_multiplier, attempt);
            var jitter = _jitter.Next(0, (int)(baseDelay * 0.25) + 1);
            var delay = (long)Math.Min(_maxDelayMs, baseDelay + jitter);
            return TimeSpan.FromMilliseconds(delay);
        }

        public async Task WaitAsync(TimeSpan delay, CancellationToken ct)
        {
            try { await Task.Delay(delay, ct).ConfigureAwait(false); }
            catch (OperationCanceledException) { throw; }
        }
    }
}
