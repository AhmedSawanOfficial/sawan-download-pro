using System;
using System.Threading;

namespace SawanDownloadPro.DownloadEngine.Throttling
{
    /// <summary>
    /// Token-bucket bandwidth throttle. Supports both per-task and a global limit.
    /// Thread-safe; cheap to call from the per-segment read loop.
    /// </summary>
    public sealed class BandwidthThrottle : Core.Interfaces.IBandwidthThrottle
    {
        private long _globalLimitBytesPerSec;     // 0 = unlimited
        private long _globalConsumedThisSecond;
        private long _lastGlobalSecondTick;

        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, TaskBucket> _taskBuckets = new();

        public BandwidthThrottle(long globalLimitBytesPerSec = 0)
        {
            _globalLimitBytesPerSec = globalLimitBytesPerSec;
            _lastGlobalSecondTick = (long)Environment.TickCount;
        }

        public void SetGlobalLimit(long bytesPerSec)
        {
            Interlocked.Exchange(ref _globalLimitBytesPerSec, bytesPerSec);
        }

        public void SetPerTaskLimit(string taskId, long bytesPerSec)
        {
            var bucket = _taskBuckets.GetOrAdd(taskId, _ => new TaskBucket());
            bucket.LimitBytesPerSec = bytesPerSec;
        }

        public long GetConsumedBytes(string taskId) =>
            _taskBuckets.TryGetValue(taskId, out var b) ? b.ConsumedTotal : 0;

        public void Reset()
        {
            _taskBuckets.Clear();
            Interlocked.Exchange(ref _globalConsumedThisSecond, 0);
            _lastGlobalSecondTick = (long)Environment.TickCount;
        }

        /// <summary>
        /// Block until <paramref name="bytesRequested"/> may be "spent" by the caller for the given task.
        /// Returns the actual number of bytes the caller is allowed to send/receive (always ≤ requested).
        /// </summary>
        public int RequestQuota(string taskId, int bytesRequested, CancellationToken ct)
        {
            int granted = bytesRequested;

            // Per-task limit
            if (_taskBuckets.TryGetValue(taskId, out var bucket) && bucket.LimitBytesPerSec > 0)
            {
                granted = Math.Min(granted, bucket.TryAcquire(bytesRequested, ct));
            }

            // Global limit
            var globalLimit = Interlocked.Read(ref _globalLimitBytesPerSec);
            if (globalLimit > 0)
            {
                granted = Math.Min(granted, TryAcquireGlobal(granted, ct));
            }

            if (_taskBuckets.TryGetValue(taskId, out var b2))
            {
                Interlocked.Add(ref b2.ConsumedTotal, granted);
            }
            return granted;
        }

        private int TryAcquireGlobal(int bytesRequested, CancellationToken ct)
        {
            while (true)
            {
                ct.ThrowIfCancellationRequested();
                var now = (long)Environment.TickCount;
                var lastTick = Interlocked.Read(ref _lastGlobalSecondTick);

                if (now - lastTick >= 1000)
                {
                    // Roll to a new 1-second window.
                    Interlocked.CompareExchange(ref _lastGlobalSecondTick, now, lastTick);
                    Interlocked.Exchange(ref _globalConsumedThisSecond, 0);
                }

                var limit = Interlocked.Read(ref _globalLimitBytesPerSec);
                var consumed = Interlocked.Read(ref _globalConsumedThisSecond);
                if (consumed < limit)
                {
                    var allowed = (int)Math.Min(bytesRequested, limit - consumed);
                    if (allowed <= 0)
                    {
                        // Window exhausted; wait briefly.
                        ct.WaitHandle.WaitOne(20);
                        continue;
                    }
                    var newConsumed = Interlocked.Add(ref _globalConsumedThisSecond, allowed);
                    if (newConsumed <= limit) return allowed;
                    // Raced with another thread; back off.
                    Interlocked.Add(ref _globalConsumedThisSecond, -allowed);
                    ct.WaitHandle.WaitOne(20);
                    continue;
                }
                ct.WaitHandle.WaitOne(20);
            }
        }

        public void Dispose() => _taskBuckets.Clear();

        private sealed class TaskBucket
        {
            public long LimitBytesPerSec;
            public long ConsumedThisSecond;
            public long LastSecondTick = (long)Environment.TickCount;
            public long ConsumedTotal;

            public int TryAcquire(int bytesRequested, CancellationToken ct)
            {
                while (true)
                {
                    ct.ThrowIfCancellationRequested();
                    var now = (long)Environment.TickCount;
                    if (now - Interlocked.Read(ref LastSecondTick) >= 1000)
                    {
                        Interlocked.Exchange(ref LastSecondTick, now);
                        Interlocked.Exchange(ref ConsumedThisSecond, 0);
                    }
                    var limit = Interlocked.Read(ref LimitBytesPerSec);
                    var consumed = Interlocked.Read(ref ConsumedThisSecond);
                    if (consumed < limit)
                    {
                        var allowed = (int)Math.Min(bytesRequested, limit - consumed);
                        if (allowed <= 0) { ct.WaitHandle.WaitOne(20); continue; }
                        var nc = Interlocked.Add(ref ConsumedThisSecond, allowed);
                        if (nc <= limit) return allowed;
                        Interlocked.Add(ref ConsumedThisSecond, -allowed);
                        ct.WaitHandle.WaitOne(20);
                        continue;
                    }
                    ct.WaitHandle.WaitOne(20);
                }
            }
        }
    }
}
