using System;

namespace SawanDownloadPro.Core.Exceptions
{
    public class DownloadEngineException : Exception
    {
        public int? HttpStatusCode { get; }
        public DownloadEngineException(string message, int? httpStatusCode = null, Exception? inner = null)
            : base(message, inner) => HttpStatusCode = httpStatusCode;
    }

    public class ResumeValidationException : DownloadEngineException
    {
        public ResumeValidationException(string message) : base(message) { }
    }

    public class DiskSpaceException : DownloadEngineException
    {
        public long RequiredBytes { get; }
        public long AvailableBytes { get; }
        public DiskSpaceException(long required, long available)
            : base($"Insufficient disk space. Required: {required:N0} bytes. Available: {available:N0} bytes.")
        {
            RequiredBytes = required;
            AvailableBytes = available;
        }
    }

    public class RangeNotSupportedException : DownloadEngineException
    {
        public RangeNotSupportedException() : base("Server does not support byte-range requests; cannot use segmented download.") { }
    }

    public class UnsafePathException : Exception
    {
        public UnsafePathException(string message) : base(message) { }
    }

    public class InvalidUrlException : Exception
    {
        public InvalidUrlException(string message) : base(message) { }
    }

    public class StorageException : Exception
    {
        public StorageException(string message, Exception? inner = null) : base(message, inner) { }
    }

    public class SchedulerException : Exception
    {
        public SchedulerException(string message) : base(message) { }
    }
}
