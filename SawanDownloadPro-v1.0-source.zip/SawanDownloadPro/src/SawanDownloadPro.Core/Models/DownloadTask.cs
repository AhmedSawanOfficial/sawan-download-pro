using System;
using System.Collections.Generic;
using SawanDownloadPro.Core.Enums;

namespace SawanDownloadPro.Core.Models
{
    /// <summary>
    /// A single download task. Mirrors the <c>downloads</c> SQLite table.
    /// </summary>
    public sealed class DownloadTask
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("D");

        /// <summary>Original URL the user entered or the browser sent.</summary>
        public string Url { get; set; } = string.Empty;

        /// <summary>Final URL after redirects (may equal <see cref="Url"/>).</summary>
        public string FinalUrl { get; set; } = string.Empty;

        /// <summary>Sanitized filename (no path).</summary>
        public string FileName { get; set; } = string.Empty;

        /// <summary>Absolute destination directory.</summary>
        public string SavePath { get; set; } = string.Empty;

        public DownloadCategory Category { get; set; } = DownloadCategory.Other;

        public DownloadStatus Status { get; set; } = DownloadStatus.Queued;

        /// <summary>Total size in bytes, or null when the server did not provide Content-Length.</summary>
        public long? TotalBytes { get; set; }

        /// <summary>Cumulative downloaded bytes across all segments.</summary>
        public long DownloadedBytes { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? StartedAt { get; set; }
        public DateTime? CompletedAt { get; set; }

        public string? ErrorMessage { get; set; }

        /// <summary>ETag from the initial response, used to validate resume.</summary>
        public string? ETag { get; set; }

        /// <summary>Last-Modified header value, used to validate resume.</summary>
        public string? LastModified { get; set; }

        /// <summary>True when the server advertised Accept-Ranges: bytes.</summary>
        public bool AcceptRanges { get; set; }

        /// <summary>Number of segments currently active.</summary>
        public int ActiveConnections { get; set; }

        /// <summary>Configured max connections (1 = single-stream).</summary>
        public int MaxConnections { get; set; } = 1;

        public DownloadPriority Priority { get; set; } = DownloadPriority.Normal;

        public AuthenticationScheme AuthScheme { get; set; } = AuthenticationScheme.None;
        public string? AuthUsername { get; set; }

        /// <summary>Plaintext only in memory; DPAPI-encrypted at the storage boundary.</summary>
        public string? AuthPassword { get; set; }

        /// <summary>Custom request headers (key/value). Limited to a safe allow-list by the engine.</summary>
        public Dictionary<string, string> CustomHeaders { get; set; } = new();

        public DownloadSource Source { get; set; } = DownloadSource.Manual;

        /// <summary>
        /// True when this task belongs to a Private Downloads session. Private tasks are stored
        /// in a separate list at runtime; their persistence is governed by
        /// <see cref="AppSettings.AutoDeletePrivateSessionMetadataOnExit"/> and
        /// <see cref="AppSettings.RetainPrivateSessionDownloadedFiles"/>.
        /// </summary>
        public bool IsPrivate { get; set; } = false;

        /// <summary>Per-download bandwidth limit in bytes/sec, or null for unlimited.</summary>
        public long? SpeedLimitBytesPerSec { get; set; }

        /// <summary>Current speed in bytes/sec (live value, not persisted).</summary>
        public long CurrentSpeed { get; set; }

        /// <summary>Average speed in bytes/sec across the lifetime of the task.</summary>
        public long AverageSpeed { get; set; }

        /// <summary>Live segments list — not persisted directly; rehydrated from <see cref="SegmentInfo"/> rows.</summary>
        public List<SegmentInfo> Segments { get; set; } = new();

        /// <summary>
        /// Absolute path to the .part file currently being written.
        /// </summary>
        public string? PartFilePath { get; set; }

        /// <summary>
        /// Absolute path to the .sawanmeta sidecar file used for resume validation.
        /// </summary>
        public string? MetaFilePath { get; set; }

        /// <summary>
        /// Convenience: returns true when this task is in a state that can be resumed.
        /// </summary>
        public bool CanResume =>
            Status == DownloadStatus.Paused ||
            Status == DownloadStatus.Stopped ||
            Status == DownloadStatus.Failed ||
            Status == DownloadStatus.WaitingForRetry;

        /// <summary>
        /// Convenience: returns true when this task is in a state that can be started/paused.
        /// </summary>
        public bool IsRunning =>
            Status == DownloadStatus.Downloading ||
            Status == DownloadStatus.Resolving ||
            Status == DownloadStatus.WaitingForRetry;
    }
}
