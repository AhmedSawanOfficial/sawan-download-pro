using SawanDownloadPro.Core.Enums;

namespace SawanDownloadPro.Core.Models
{
    /// <summary>
    /// A byte-range segment of a <see cref="DownloadTask"/>. Mirrors the <c>segments</c> SQLite table.
    /// </summary>
    public sealed class SegmentInfo
    {
        public string Id { get; set; } = System.Guid.NewGuid().ToString("D");
        public string DownloadId { get; set; } = string.Empty;

        /// <summary>Inclusive start byte.</summary>
        public long StartByte { get; set; }

        /// <summary>Inclusive end byte.</summary>
        public long EndByte { get; set; }

        public long DownloadedBytes { get; set; }

        /// <summary>0-based position within the parent task's segment list.</summary>
        public int Position { get; set; }

        public SegmentStatus Status { get; set; } = SegmentStatus.Pending;

        /// <summary>Current speed for this segment in bytes/sec (live value).</summary>
        public long CurrentSpeed { get; set; }

        public long Size => EndByte - StartByte + 1;

        public bool IsComplete => DownloadedBytes >= Size;
    }
}
