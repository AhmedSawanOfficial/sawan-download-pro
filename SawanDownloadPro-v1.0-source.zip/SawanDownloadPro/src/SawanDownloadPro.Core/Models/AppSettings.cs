using System;
using System.Collections.Generic;
using SawanDownloadPro.Core.Enums;

namespace SawanDownloadPro.Core.Models
{
    /// <summary>
    /// In-memory application settings. Persisted via <c>ISettingsStore</c>.
    /// </summary>
    public sealed class AppSettings
    {
        // --- General ---
        public bool StartWithWindows { get; set; } = false;
        public bool MinimizeToTray { get; set; } = true;
        public bool StartMinimized { get; set; } = false;
        public bool CloseToTray { get; set; } = true;
        public bool ConfirmBeforeExit { get; set; } = true;
        public bool ConfirmBeforeDeleteFile { get; set; } = true;

        // --- Downloads ---
        public string DefaultDownloadDirectory { get; set; } = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + "\\Downloads\\Sawan";
        public string TempDirectory { get; set; } = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\SawanDownloadPro\\temp";
        public int MaxSimultaneousDownloads { get; set; } = 3;
        public int MaxConnectionsPerDownload { get; set; } = 8;
        public int MaxRetryAttempts { get; set; } = 5;
        public int RetryInitialDelayMs { get; set; } = 1000;
        public double RetryBackoffMultiplier { get; set; } = 2.0;
        public int RetryMaxDelayMs { get; set; } = 60000;
        public bool AutoCategorizeByExtension { get; set; } = true;
        public bool AvoidDuplicateUrls { get; set; } = true;

        // --- Network ---
        public long GlobalSpeedLimitBytesPerSec { get; set; } = 0; // 0 = unlimited
        public int ConnectionTimeoutSec { get; set; } = 30;
        public int ReadWriteTimeoutSec { get; set; } = 120;
        public bool UseProxy { get; set; } = false;
        public string ProxyHost { get; set; } = string.Empty;
        public int ProxyPort { get; set; } = 8080;
        public bool ProxyBypassLocal { get; set; } = true;
        public string ProxyBypassList { get; set; } = string.Empty;
        public bool ForceTls12 { get; set; } = true;

        // --- Clipboard ---
        public bool MonitorClipboard { get; set; } = true;
        public bool ClipboardAutoAddDirectDownloads { get; set; } = false;

        // --- Browser integration ---
        public bool EnableChromeIntegration { get; set; } = true;
        public bool EnableEdgeIntegration { get; set; } = true;
        public bool EnableFirefoxIntegration { get; set; } = true;
        public bool EnableOperaIntegration { get; set; } = true;
        public bool EnableBraveIntegration { get; set; } = true;
        public bool EnableVivaldiIntegration { get; set; } = true;

        // --- Appearance ---
        /// <summary>Default v1.0 theme is Dark Eggplant. The user may switch in Settings.</summary>
        public AppTheme Theme { get; set; } = AppTheme.DarkEggplant;
        public AppLanguage Language { get; set; } = AppLanguage.Arabic;
        public int FontSize { get; set; } = 14; // pt

        /// <summary>
        /// Optional custom accent color as a hex string (e.g. "#6F42A6"). Empty/null means
        /// "use the theme's default accent." Used to override the secondary accent across the UI.
        /// </summary>
        public string? CustomAccentColor { get; set; }

        // --- First-run / onboarding ---
        /// <summary>True after the user has completed the First-Run Welcome wizard at least once.</summary>
        public bool FirstRunCompleted { get; set; } = false;

        // --- Privacy / Private Downloads ---
        /// <summary>Enable the Private Downloads mode (separate session list, separate history).</summary>
        public bool EnablePrivateDownloadsMode { get; set; } = false;

        /// <summary>When Private Downloads mode is on, also try to integrate with browser private modes (Chrome Incognito, Edge InPrivate, Firefox Private Browsing). Requires the user to grant the extension private-mode permission in each browser — we never enable it silently.</summary>
        public bool EnableBrowserPrivateModeIntegration { get; set; } = false;

        /// <summary>When true, private-session metadata (URLs, history rows) is automatically deleted when the application closes.</summary>
        public bool AutoDeletePrivateSessionMetadataOnExit { get; set; } = true;

        /// <summary>When true, downloaded files from a private session are RETAINED on disk after the session is cleared. When false, the user is asked each time.</summary>
        public bool RetainPrivateSessionDownloadedFiles { get; set; } = true;

        /// <summary>When true, private-mode URLs are never written to the standard download history table even if the user later switches off Private Downloads mode.</summary>
        public bool NeverMixPrivateUrlsIntoStandardHistory { get; set; } = true;

        /// <summary>Days to retain completed-download history rows before automatic pruning. 0 = never prune.</summary>
        public int HistoryRetentionDays { get; set; } = 0;

        /// <summary>Opt-in telemetry toggle. Defaults to false. v1.0 ships with no telemetry implementation; this flag is reserved for future opt-in crash reporting.</summary>
        public bool EnableTelemetry { get; set; } = false;

        // --- Notifications ---
        public bool NotifyOnComplete { get; set; } = true;
        public bool NotifyOnFailure { get; set; } = true;
        public bool NotifyOnQueueComplete { get; set; } = true;
        public bool PlaySoundOnComplete { get; set; } = false;
        public bool PlaySoundOnFailure { get; set; } = false;

        // --- Advanced ---
        public string LogDirectory { get; set; } = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "\\SawanDownloadPro\\logs";
        public bool VerboseLogging { get; set; } = false;

        // --- Media (optional) ---
        public string FFmpegPath { get; set; } = string.Empty;
        public string YtDlpPath { get; set; } = string.Empty;
        public bool EnableVideoDownloader { get; set; } = true;
        public string VideoDefaultFormat { get; set; } = "mp4";
        public string AudioDefaultFormat { get; set; } = "mp3";

        // --- Security ---
        public bool WarnOnDangerousExtensions { get; set; } = true;
        public bool ScanWithAntivirus { get; set; } = false;
        public string AntivirusPath { get; set; } = string.Empty;

        /// <summary>
        /// Category → subfolder mapping. Empty string means use DefaultDownloadDirectory.
        /// </summary>
        public Dictionary<DownloadCategory, string> CategorySubfolders { get; set; } = new()
        {
            { DownloadCategory.Compressed, "Compressed" },
            { DownloadCategory.Videos, "Videos" },
            { DownloadCategory.Music, "Music" },
            { DownloadCategory.Documents, "Documents" },
            { DownloadCategory.Programs, "Programs" },
            { DownloadCategory.Other, "" }
        };

        /// <summary>Extension-to-category mapping for auto-categorization.</summary>
        public Dictionary<string, DownloadCategory> ExtensionCategories { get; set; } = new()
        {
            { "zip", DownloadCategory.Compressed }, { "rar", DownloadCategory.Compressed },
            { "7z", DownloadCategory.Compressed }, { "tar", DownloadCategory.Compressed },
            { "gz", DownloadCategory.Compressed },

            { "mp4", DownloadCategory.Videos }, { "mkv", DownloadCategory.Videos },
            { "avi", DownloadCategory.Videos }, { "mov", DownloadCategory.Videos },
            { "webm", DownloadCategory.Videos }, { "flv", DownloadCategory.Videos },
            { "wmv", DownloadCategory.Videos }, { "m4v", DownloadCategory.Videos },

            { "mp3", DownloadCategory.Music }, { "flac", DownloadCategory.Music },
            { "wav", DownloadCategory.Music }, { "aac", DownloadCategory.Music },
            { "ogg", DownloadCategory.Music }, { "m4a", DownloadCategory.Music },
            { "wma", DownloadCategory.Music },

            { "pdf", DownloadCategory.Documents }, { "doc", DownloadCategory.Documents },
            { "docx", DownloadCategory.Documents }, { "xls", DownloadCategory.Documents },
            { "xlsx", DownloadCategory.Documents }, { "ppt", DownloadCategory.Documents },
            { "pptx", DownloadCategory.Documents }, { "txt", DownloadCategory.Documents },
            { "rtf", DownloadCategory.Documents }, { "csv", DownloadCategory.Documents },
            { "epub", DownloadCategory.Documents },

            { "exe", DownloadCategory.Programs }, { "msi", DownloadCategory.Programs },
            { "dmg", DownloadCategory.Programs }, { "iso", DownloadCategory.Programs },
            { "img", DownloadCategory.Programs }
        };
    }
}
