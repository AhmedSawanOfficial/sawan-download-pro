using System;

namespace SawanDownloadPro.Core.Models
{
    /// <summary>
    /// Snapshot of a download task's progress, sent to subscribers via
    /// <see cref="Events.DownloadProgressEventArgs"/>.
    /// </summary>
    public sealed class DownloadTaskUpdate
    {
        public string TaskId { get; set; } = string.Empty;
        public long DownloadedBytes { get; set; }
        public long? TotalBytes { get; set; }
        public long CurrentSpeedBytesPerSec { get; set; }
        public long AverageSpeedBytesPerSec { get; set; }
        public int ActiveConnections { get; set; }
        public TimeSpan? EstimatedTimeRemaining { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }

    /// <summary>
    /// Result of a URL metadata fetch (HEAD or initial GET).
    /// </summary>
    public sealed class UrlMetadata
    {
        public string FinalUrl { get; set; } = string.Empty;
        public string? FileName { get; set; }
        public long? ContentLength { get; set; }
        public bool AcceptRanges { get; set; }
        public string? ETag { get; set; }
        public string? LastModified { get; set; }
        public string? ContentType { get; set; }
        public bool Success { get; set; }
        public string? ErrorMessage { get; set; }
        public int HttpStatusCode { get; set; }
    }
}
