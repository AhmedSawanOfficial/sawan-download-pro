namespace SawanDownloadPro.Core.Enums
{
    /// <summary>
    /// Lifecycle state of a download task. Stored as a string in SQLite.
    /// </summary>
    public enum DownloadStatus
    {
        /// <summary>Task created but not yet started (e.g. added to queue).</summary>
        Queued = 0,

        /// <summary>Currently downloading.</summary>
        Downloading = 1,

        /// <summary>Paused by user or by the scheduler.</summary>
        Paused = 2,

        /// <summary>Completed successfully; file finalized.</summary>
        Completed = 3,

        /// <summary>Failed with an error; see error_message.</summary>
        Failed = 4,

        /// <summary>Stopped by user; partial file may exist on disk.</summary>
        Stopped = 5,

        /// <summary>Waiting to be retried after a transient failure.</summary>
        WaitingForRetry = 6,

        /// <summary>Metadata being fetched from the server.</summary>
        Resolving = 7
    }

    /// <summary>
    /// File-category enum. Drives the sidebar filter and default save folder.
    /// </summary>
    public enum DownloadCategory
    {
        Compressed = 0,
        Videos = 1,
        Music = 2,
        Documents = 3,
        Programs = 4,
        Other = 5
    }

    /// <summary>
    /// Queue priority. Higher number = higher priority.
    /// </summary>
    public enum DownloadPriority
    {
        Low = 0,
        Normal = 1,
        High = 2,
        Critical = 3
    }

    /// <summary>
    /// HTTP authentication scheme. FTP credentials are handled separately.
    /// </summary>
    public enum AuthenticationScheme
    {
        None = 0,
        Basic = 1,
        Digest = 2
    }

    /// <summary>
    /// How a task was introduced into the application.
    /// </summary>
    public enum DownloadSource
    {
        Manual = 0,
        Clipboard = 1,
        Browser = 2,
        VideoDownloader = 3,
        Import = 4
    }

    /// <summary>
    /// Per-segment lifecycle.
    /// </summary>
    public enum SegmentStatus
    {
        Pending = 0,
        Active = 1,
        Completed = 2,
        Failed = 3
    }

    /// <summary>
    /// User-selectable UI theme. <see cref="DarkEggplant"/> is the v1.0 default.
    /// </summary>
    public enum AppTheme
    {
        /// <summary>Default v1.0 theme — deep aubergine/eggplant identity.</summary>
        DarkEggplant = 0,

        Light = 1,

        /// <summary>Follows the OS light/dark preference (where detectable on Win10+).</summary>
        System = 2
    }

    /// <summary>
    /// UI language.
    /// </summary>
    public enum AppLanguage
    {
        Arabic = 0,
        English = 1
    }
}
