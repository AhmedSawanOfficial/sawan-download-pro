using System;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.Core.Events
{
    public sealed class DownloadProgressEventArgs : EventArgs
    {
        public DownloadTaskUpdate Update { get; }
        public DownloadProgressEventArgs(DownloadTaskUpdate update) => Update = update;
    }

    public sealed class DownloadStateChangedEventArgs : EventArgs
    {
        public string TaskId { get; }
        public DownloadStatus OldStatus { get; }
        public DownloadStatus NewStatus { get; }
        public string? ErrorMessage { get; }

        public DownloadStateChangedEventArgs(string taskId, DownloadStatus oldStatus, DownloadStatus newStatus, string? errorMessage = null)
        {
            TaskId = taskId;
            OldStatus = oldStatus;
            NewStatus = newStatus;
            ErrorMessage = errorMessage;
        }
    }

    public sealed class DownloadCompletedEventArgs : EventArgs
    {
        public string TaskId { get; }
        public string FinalFilePath { get; }
        public long TotalBytes { get; }
        public TimeSpan Duration { get; }

        public DownloadCompletedEventArgs(string taskId, string finalFilePath, long totalBytes, TimeSpan duration)
        {
            TaskId = taskId;
            FinalFilePath = finalFilePath;
            TotalBytes = totalBytes;
            Duration = duration;
        }
    }

    public sealed class DownloadFailedEventArgs : EventArgs
    {
        public string TaskId { get; }
        public string ErrorMessage { get; }
        public int? HttpStatusCode { get; }
        public bool WillRetry { get; }
        public int RetryAttempt { get; }
        public TimeSpan NextRetryIn { get; }

        public DownloadFailedEventArgs(string taskId, string errorMessage, int? httpStatusCode, bool willRetry, int retryAttempt, TimeSpan nextRetryIn)
        {
            TaskId = taskId;
            ErrorMessage = errorMessage;
            HttpStatusCode = httpStatusCode;
            WillRetry = willRetry;
            RetryAttempt = retryAttempt;
            NextRetryIn = nextRetryIn;
        }
    }

    public sealed class QueueStateChangedEventArgs : EventArgs
    {
        public int ActiveCount { get; }
        public int QueuedCount { get; }
        public int PausedCount { get; }
        public long AggregateSpeedBytesPerSec { get; }

        public QueueStateChangedEventArgs(int active, int queued, int paused, long aggregateSpeed)
        {
            ActiveCount = active;
            QueuedCount = queued;
            PausedCount = paused;
            AggregateSpeedBytesPerSec = aggregateSpeed;
        }
    }
}
