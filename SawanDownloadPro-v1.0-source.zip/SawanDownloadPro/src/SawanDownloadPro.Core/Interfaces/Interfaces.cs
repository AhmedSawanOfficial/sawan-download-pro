using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Events;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.Core.Interfaces
{
    /// <summary>
    /// Abstraction over the actual byte-pulling engine. Implementations:
    /// <list type="bullet">
    ///   <item><see cref="SawanDownloadPro.DownloadEngine.HttpDownloadEngine"/>: single-stream HTTP/HTTPS.</item>
    ///   <item><see cref="SawanDownloadPro.DownloadEngine.SegmentedDownloadEngine"/>: parallel-segment engine when server supports ranges.</item>
    /// </list>
    /// </summary>
    public interface IDownloadEngine : IDisposable
    {
        /// <summary>Fired on every progress tick (default: 2 Hz).</summary>
        event EventHandler<DownloadProgressEventArgs>? ProgressChanged;

        /// <summary>Fired when the task transitions between statuses.</summary>
        event EventHandler<DownloadStateChangedEventArgs>? StateChanged;

        /// <summary>Fired on completion (file finalized on disk).</summary>
        event EventHandler<DownloadCompletedEventArgs>? Completed;

        /// <summary>Fired on failure (with retry information).</summary>
        event EventHandler<DownloadFailedEventArgs>? Failed;

        /// <summary>
        /// Begin downloading the supplied task. Returns a task that completes when the download finishes
        /// (either successfully or with an error). Use the <paramref name="cancellationToken"/> to pause/cancel.
        /// </summary>
        Task ExecuteAsync(DownloadTask task, CancellationToken cancellationToken);

        /// <summary>
        /// Pre-fetch metadata for a URL without starting the download.
        /// </summary>
        Task<UrlMetadata> ProbeAsync(string url, AuthenticationScheme auth, string? username, string? password, IReadOnlyDictionary<string, string>? customHeaders, CancellationToken cancellationToken);
    }

    /// <summary>
    /// Persistence boundary for <see cref="DownloadTask"/>.
    /// </summary>
    public interface IDownloadTaskStore
    {
        Task<DownloadTask?> GetByIdAsync(string id);
        Task<IReadOnlyList<DownloadTask>> GetAllAsync();
        Task<IReadOnlyList<DownloadTask>> GetByStatusAsync(DownloadStatus status);
        Task UpsertAsync(DownloadTask task);
        Task DeleteAsync(string id);
        Task UpdateStatusAsync(string id, DownloadStatus status, long downloadedBytes, string? errorMessage);
        Task UpdateSegmentsAsync(string downloadId, IEnumerable<SegmentInfo> segments);
        Task<IReadOnlyList<SegmentInfo>> GetSegmentsAsync(string downloadId);
    }

    /// <summary>
    /// Key/value settings store backed by SQLite.
    /// </summary>
    public interface ISettingsStore
    {
        Task<AppSettings> LoadAsync();
        Task SaveAsync(AppSettings settings);
        Task ResetAsync();
    }

    /// <summary>
    /// Download history (completed-and-kept or completed-and-deleted-but-recorded).
    /// </summary>
    public interface IHistoryStore
    {
        Task AddAsync(HistoryEntry entry);
        Task<IReadOnlyList<HistoryEntry>> GetRecentAsync(int limit = 100);
        Task DeleteAsync(string id);
        Task ClearAsync();
    }

    public sealed class HistoryEntry
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("D");
        public string? DownloadId { get; set; }
        public string Url { get; set; } = string.Empty;
        public string FileName { get; set; } = string.Empty;
        public DownloadCategory? Category { get; set; }
        public DateTime CompletedAt { get; set; } = DateTime.UtcNow;
        public long? TotalBytes { get; set; }
        public bool Deleted { get; set; }
    }

    public interface IPathSanitizer
    {
        string SanitizeFileName(string input);
        string SanitizeAndCombinePath(string directory, string fileName);
        bool IsPathSafe(string absolutePath, string rootDirectory);
        bool IsDangerousExtension(string fileName);
    }

    public interface IUrlValidator
    {
        bool IsValid(string url);
        bool IsSchemeAllowed(string url);
        Uri? NormalizeOrNull(string url);
    }

    public interface ISafeProcessLauncher
    {
        int Run(string fileName, IEnumerable<string> arguments, bool waitForExit = false, int timeoutMs = 30000);
        bool TryOpenInDefaultApplication(string filePath);
        bool TryOpenContainingFolder(string filePath);
    }

    public interface IScheduler
    {
        event EventHandler<QueueStateChangedEventArgs>? QueueStateChanged;
        void Enqueue(DownloadTask task);
        void Pause(DownloadTask task);
        void Resume(DownloadTask task);
        void Cancel(DownloadTask task);
        void StartAll();
        void PauseAll();
        void StopAll();
        void ScheduleQueueStart(DateTime at);
        void ScheduleQueueStop(DateTime at);
        Task OptionallyShutdownAfterQueueCompletesAsync(bool requireConfirmation);
    }

    public interface ISecretProtector
    {
        byte[] Protect(string plaintext);
        string Unprotect(byte[] encrypted);
    }

    public interface IBandwidthThrottle : IDisposable
    {
        void SetGlobalLimit(long bytesPerSec);
        void SetPerTaskLimit(string taskId, long bytesPerSec);
        long GetConsumedBytes(string taskId);
        void Reset();
    }
}
