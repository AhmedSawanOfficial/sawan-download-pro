using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Microsoft.Extensions.Logging;

namespace SawanDownloadPro.BrowserIntegration.NativeMessaging
{
    /// <summary>
    /// Forwards validated <see cref="DownloadMessage"/> instances to the main
    /// Sawan Download Pro application over a Windows named pipe.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The main app creates a server end of the named pipe
    /// <c>\\.\pipe\sawan_download_pro</c> on startup. This class is the
    /// client side: it connects, sends the JSON-serialized message, reads
    /// the app's response, and returns it to the caller.
    /// </para>
    /// <para>
    /// The pipe is message-mode: each <see cref="SendAsync"/> call sends
    /// exactly one JSON object and reads exactly one response object. The
    /// app side is expected to reply with <c>{"ok":true}</c> on success or
    /// <c>{"ok":false,"error":"..."}</c> on failure.
    /// </para>
    /// <para>
    /// Every connection is short-lived: open → write → read → close. This
    /// keeps the protocol stateless and avoids pinning a worker in the main
    /// app for the lifetime of the host process.
    /// </para>
    /// </remarks>
    public sealed class NamedPipeBridge : IDisposable
    {
        /// <summary>The well-known pipe name. Must match the main app.</summary>
        public const string PipeName = "sawan_download_pro";

        /// <summary>Full pipe path as the Win32 API expects it.</summary>
        public static readonly string PipePath = @"\\" + "." + @"\pipe\" + PipeName;

        private readonly ILogger _logger;
        private readonly int _connectTimeoutMs;
        private readonly int _readTimeoutMs;
        private readonly int _writeTimeoutMs;
        private readonly int _maxResponseBytes;
        private bool _disposed;

        /// <summary>
        /// Create a bridge with default timeouts (5 s connect, 5 s read, 5 s write,
        /// 64 KiB max response).
        /// </summary>
        public NamedPipeBridge(ILogger logger)
            : this(logger,
                   connectTimeoutMs: 5000,
                   readTimeoutMs: 5000,
                   writeTimeoutMs: 5000,
                   maxResponseBytes: 64 * 1024)
        {
        }

        public NamedPipeBridge(
            ILogger logger,
            int connectTimeoutMs,
            int readTimeoutMs,
            int writeTimeoutMs,
            int maxResponseBytes)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            if (connectTimeoutMs <= 0) throw new ArgumentOutOfRangeException(nameof(connectTimeoutMs));
            if (readTimeoutMs <= 0)    throw new ArgumentOutOfRangeException(nameof(readTimeoutMs));
            if (writeTimeoutMs <= 0)   throw new ArgumentOutOfRangeException(nameof(writeTimeoutMs));
            if (maxResponseBytes <= 0) throw new ArgumentOutOfRangeException(nameof(maxResponseBytes));

            _connectTimeoutMs = connectTimeoutMs;
            _readTimeoutMs = readTimeoutMs;
            _writeTimeoutMs = writeTimeoutMs;
            _maxResponseBytes = maxResponseBytes;
        }

        /// <summary>
        /// Send a validated message to the main Sawan application.
        /// </summary>
        /// <param name="message">A message that has already passed
        /// <see cref="MessageSchema.TryValidate"/>. The bridge does not
        /// re-validate.</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>A tuple of (success, error). On success, error is null.
        /// On failure, error is a human-readable description.</returns>
        public async Task<(bool Ok, string? Error)> SendAsync(
            DownloadMessage message,
            CancellationToken cancellationToken = default)
        {
            if (message is null) throw new ArgumentNullException(nameof(message));
            ThrowIfDisposed();

            string json = SerializeMessage(message);
            byte[] payload = Encoding.UTF8.GetBytes(json);

            // We intentionally do NOT catch OperationCanceledException — the
            // caller may use the token to abort.
            using var pipe = new NamedPipeClientStream(
                serverName: ".",
                pipeName: PipeName,
                direction: PipeDirection.InOut,
                options: PipeOptions.Asynchronous);

            _logger.LogDebug("Connecting to pipe {Pipe} (timeout {Ms} ms)", PipePath, _connectTimeoutMs);
            try
            {
                // ConnectAsync does not honor a timeout; we wrap it in a task race.
                await ConnectWithTimeoutAsync(pipe, _connectTimeoutMs, cancellationToken)
                    .ConfigureAwait(false);
            }
            catch (TimeoutException)
            {
                return (false, "Could not connect to Sawan Download Pro (timeout). Is the app running?");
            }
            catch (IOException ioEx)
            {
                return (false, "Sawan app is not running or the pipe is unavailable: " + ioEx.Message);
            }
            catch (UnauthorizedAccessException uaEx)
            {
                return (false, "Access denied to Sawan pipe (different user?): " + uaEx.Message);
            }

            try
            {
                // Switch to message mode so the app's ReadFile completes once
                // the entire JSON is received, rather than buffering arbitrarily.
                if (pipe.IsConnected)
                {
                    pipe.ReadMode = PipeTransmissionMode.Message;
                }

                // Write the request.
                await pipe.WriteAsync(payload, 0, payload.Length, cancellationToken)
                    .ConfigureAwait(false);
                await pipe.FlushAsync(cancellationToken).ConfigureAwait(false);

                // Read the response. With message-mode pipes, ReadAsync returns
                // a full message in one call when IsMessageComplete is true.
                var buffer = new byte[Math.Min(8192, _maxResponseBytes)];
                using var responseStream = new MemoryStream();
                int totalRead = 0;
                bool complete = false;
                while (!complete)
                {
                    int read = await pipe.ReadAsync(buffer, 0, buffer.Length, cancellationToken)
                        .ConfigureAwait(false);
                    if (read == 0) break; // pipe closed
                    responseStream.Write(buffer, 0, read);
                    totalRead += read;
                    if (totalRead > _maxResponseBytes)
                    {
                        return (false, "Sawan app response exceeded the size limit.");
                    }
                    // For message-mode pipes, CheckResult.Completed indicates a full message arrived.
                    complete = pipe.IsMessageComplete;
                }

                if (responseStream.Length == 0)
                {
                    return (false, "Sawan app closed the pipe without responding.");
                }

                string responseJson = Encoding.UTF8.GetString(responseStream.ToArray());
                return ParseResponse(responseJson);
            }
            catch (IOException ioEx)
            {
                return (false, "Pipe I/O error while talking to Sawan: " + ioEx.Message);
            }
            catch (OperationCanceledException)
            {
                throw; // let the caller decide
            }
            catch (Exception ex)
            {
                return (false, "Unexpected error communicating with Sawan: " + ex.Message);
            }
        }

        /// <summary>
        /// Race ConnectAsync against a timeout. ConnectAsync on the
        /// NamedPipeClientStream does not accept a timeout parameter, so we
        /// implement one with Task.WhenAny.
        /// </summary>
        private async Task ConnectWithTimeoutAsync(
            NamedPipeClientStream pipe,
            int timeoutMs,
            CancellationToken cancellationToken)
        {
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(timeoutMs);

            try
            {
                await pipe.ConnectAsync(cts.Token).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                // The linked CTS fired (timeout), not the caller's token.
                throw new TimeoutException();
            }
        }

        /// <summary>
        /// Parse the JSON response from the main app. Expected shape:
        /// <c>{"ok":true}</c> or <c>{"ok":false,"error":"..."}</c>.
        /// </summary>
        private static (bool Ok, string? Error) ParseResponse(string json)
        {
            // Reuse JavaScriptSerializer for symmetry with MessageSchema.
            var ser = new JavaScriptSerializer();
            object? root;
            try
            {
                root = ser.DeserializeObject(json);
            }
            catch
            {
                return (false, "Sawan app returned a malformed response.");
            }

            if (root is not IDictionary<string, object> dict)
            {
                return (false, "Sawan app returned a non-object response.");
            }

            if (!dict.TryGetValue("ok", out var okRaw) || okRaw is not bool ok)
            {
                return (false, "Sawan app response is missing the 'ok' field.");
            }

            if (ok) return (true, null);

            string? err = null;
            if (dict.TryGetValue("error", out var errRaw) && errRaw is string errStr)
            {
                err = errStr;
            }
            return (false, err ?? "Sawan app reported an unspecified error.");
        }

        /// <summary>
        /// Serialize a <see cref="DownloadMessage"/> to a compact JSON string
        /// using <see cref="DataContractJsonSerializer"/>. The wire format
        /// matches what the Sawan app's pipe server expects.
        /// </summary>
        private static string SerializeMessage(DownloadMessage message)
        {
            var ser = new DataContractJsonSerializer(typeof(DownloadMessage));
            using var ms = new MemoryStream();
            ser.WriteObject(ms, message);
            return Encoding.UTF8.GetString(ms.ToArray());
        }

        private void ThrowIfDisposed()
        {
            if (_disposed) throw new ObjectDisposedException(nameof(NamedPipeBridge));
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            // Nothing to release beyond what `using` on the pipe already handles;
            // the method exists for future symmetry with the main app's server.
        }
    }
}
