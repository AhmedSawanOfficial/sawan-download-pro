using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace SawanDownloadPro.BrowserIntegration.NativeMessaging
{
    /// <summary>
    /// Standalone .NET Framework 4.8 console entry point that speaks the
    /// Chrome/Edge/Firefox native messaging protocol on stdin/stdout,
    /// validates incoming messages via <see cref="MessageSchema"/>, and
    /// forwards valid download URLs to the main Sawan Download Pro
    /// application via <see cref="NamedPipeBridge"/>.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>Wire protocol</b> (Chrome "Native Messaging" standard):
    /// </para>
    /// <code>
    /// request:  [4-byte little-endian uint32 length][UTF-8 JSON payload of `length` bytes]
    /// response: [4-byte little-endian uint32 length][UTF-8 JSON payload of `length` bytes]
    /// </code>
    /// <para>
    /// The browser keeps the host process alive for the lifetime of the
    /// extension; we read messages in a loop until stdin closes.
    /// </para>
    /// <para>
    /// <b>Why a C# host alongside the Python one?</b> .NET Framework 4.8 is
    /// preinstalled on Windows 7 SP1+, so the C# host requires no runtime
    /// install. The Python host is provided as a reference for users who
    /// prefer Python or who already have Python installed.
    /// </para>
    /// <para>
    /// <b>Security.</b> The host trusts nothing. Every incoming message is
    /// validated by <see cref="MessageSchema"/> before any pipe I/O happens.
    /// The host never logs cookies, headers, or passwords — the native
    /// messaging protocol carries only the URL string. See the
    /// <c>browser-extensions/native-host/README.md</c> for the full threat
    /// model.
    /// </para>
    /// </remarks>
    public static class NativeMessagingHost
    {
        /// <summary>Hard cap on a single incoming message (1 MiB, matches Chrome).</summary>
        private const int MaxMessageBytes = MessageSchema.MaxMessageBytes;

        /// <summary>
        /// Console entry point. Reads framed messages from stdin until EOF,
        /// validating and forwarding each one.
        /// </summary>
        /// <returns>0 on clean shutdown, 1 on fatal error.</returns>
        public static int Main(string[] args)
        {
            // Optional --selftest flag: writes a fixed response and exits.
            // Useful for the installer to verify the host binary launches.
            if (args != null && args.Length > 0 &&
                string.Equals(args[0], "--selftest", StringComparison.OrdinalIgnoreCase))
            {
                return RunSelfTest();
            }

            var logger = CreateLogger();

            // Force stdin/stdout to binary. Console.OpenStandardInput/Output
            // already return raw streams, but we must NOT touch Console.In
            // or Console.Out anywhere — that would re-wrap them in text-mode
            // readers with newline translation.
            using var stdin = Console.OpenStandardInput();
            using var stdout = Console.OpenStandardOutput();
            using var bridge = new NamedPipeBridge(logger);

            logger.LogInformation("Native host starting (pid={Pid})", Process.GetCurrentProcess().Id);

            int exitCode;
            try
            {
                while (true)
                {
                    string? json;
                    try
                    {
                        json = ReadMessage(stdin);
                    }
                    catch (IOException ioEx)
                    {
                        // Pipe broken — typically the browser closed stdin
                        // during extension unload. Exit cleanly.
                        logger.LogInformation("stdin closed: {Message}", ioEx.Message);
                        break;
                    }

                    if (json is null)
                    {
                        // Clean EOF.
                        logger.LogInformation("stdin EOF, exiting");
                        break;
                    }

                    var response = HandleOneMessage(json, bridge, logger);
                    try
                    {
                        WriteMessage(stdout, response);
                    }
                    catch (IOException ioEx)
                    {
                        logger.LogWarning("stdout write failed: {Message}", ioEx.Message);
                        break;
                    }
                }
                exitCode = 0;
            }
            catch (OperationCanceledException)
            {
                // Should not happen — no cancellation tokens in this path.
                exitCode = 0;
            }
            catch (Exception ex)
            {
                // Last-resort handler. We never leak stack traces to the
                // browser; log locally and emit a single error frame.
                logger.LogError(ex, "Unhandled exception in main loop");
                try
                {
                    WriteMessage(stdout, "{\"ok\":false,\"error\":\"Internal host error\"}");
                }
                catch
                {
                    // Nothing else we can do.
                }
                exitCode = 1;
            }

            // Flush the log file before exit so the on-disk log is complete.
            if (logger is IDisposable disposableLogger)
            {
                try { disposableLogger.Dispose(); } catch { /* ignore */ }
            }

            return exitCode;
        }

        /// <summary>
        /// Validate one message and forward it to the main app.
        /// Returns the JSON response string to write back to the browser.
        /// </summary>
        private static string HandleOneMessage(string json, NamedPipeBridge bridge, ILogger logger)
        {
            if (!MessageSchema.TryValidate(json, out var message, out var error))
            {
                logger.LogWarning("Rejected message: {Error}", error);
                return ErrorResponse(error ?? "Validation failed");
            }

            // Log a redacted summary. We log the URL (it is the user-facing
            // string the user explicitly chose to download) but NEVER cookies,
            // auth headers, or passwords — none of which are part of the
            // native messaging payload anyway.
            logger.LogInformation("Accepted download: source={Source} url={Url}",
                                  message!.Source, message.Url);

            try
            {
                var (ok, fwdError) = bridge.SendAsync(message).GetAwaiter().GetResult();
                if (ok)
                {
                    logger.LogInformation("Forwarded to app successfully");
                    return OkResponse();
                }
                logger.LogWarning("Forwarding failed: {Error}", fwdError);
                return ErrorResponse(fwdError ?? "Unknown forwarding error");
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Unexpected error forwarding to app");
                return ErrorResponse("Internal forwarding error: " + ex.Message);
            }
        }

        // --- Native messaging framing --------------------------------------

        /// <summary>
        /// Read one length-prefixed message from the stream.
        /// Returns null on clean EOF; throws IOException on a truncated frame.
        /// </summary>
        private static string? ReadMessage(Stream stdin)
        {
            var header = new byte[4];
            if (!ReadExact(stdin, header, 0, 4))
            {
                // ReadExact returns false only on a clean EOF before any byte
                // was read; truncated frames throw IOException instead.
                return null;
            }

            // Little-endian uint32 length.
            uint length = (uint)(header[0]
                                | (header[1] << 8)
                                | (header[2] << 16)
                                | (header[3] << 24));

            if (length == 0) return string.Empty;
            if (length > MaxMessageBytes)
            {
                throw new IOException(
                    $"Incoming message too large: {length} bytes (max {MaxMessageBytes})");
            }

            var payload = new byte[length];
            if (!ReadExact(stdin, payload, 0, (int)length))
            {
                // ReadExact returned false, meaning EOF before any payload
                // byte was read — but we already had a header, so this is a
                // truncated frame, not a clean EOF.
                throw new IOException("Truncated message body");
            }
            return Encoding.UTF8.GetString(payload);
        }

        /// <summary>
        /// Read exactly <paramref name="count"/> bytes. Returns false if EOF
        /// was hit before any byte was read; throws IOException if EOF was
        /// hit mid-frame.
        /// </summary>
        private static bool ReadExact(Stream s, byte[] buffer, int offset, int count)
        {
            int total = 0;
            while (total < count)
            {
                int read = s.Read(buffer, offset + total, count - total);
                if (read == 0)
                {
                    if (total == 0) return false;
                    throw new IOException(
                        $"Unexpected EOF after {total} of {count} bytes");
                }
                total += read;
            }
            return true;
        }

        /// <summary>
        /// Write a length-prefixed message to the stream.
        /// </summary>
        private static void WriteMessage(Stream stdout, string json)
        {
            byte[] body = Encoding.UTF8.GetBytes(json);
            if (body.Length > MaxMessageBytes)
            {
                // Defensive: should never happen, but never write an oversized frame.
                body = Encoding.UTF8.GetBytes(ErrorResponse("Response too large"));
            }

            var header = new byte[4];
            uint len = (uint)body.Length;
            header[0] = (byte)(len & 0xFF);
            header[1] = (byte)((len >> 8) & 0xFF);
            header[2] = (byte)((len >> 16) & 0xFF);
            header[3] = (byte)((len >> 24) & 0xFF);

            stdout.Write(header, 0, 4);
            stdout.Write(body, 0, body.Length);
            stdout.Flush();
        }

        // --- Response builders ---------------------------------------------

        private static string OkResponse() => "{\"ok\":true}";

        private static string ErrorResponse(string message)
        {
            // Escape the message for safe JSON embedding.
            var sb = new StringBuilder("{\"ok\":false,\"error\":\"");
            foreach (char c in message ?? string.Empty)
            {
                switch (c)
                {
                    case '\\': sb.Append("\\\\"); break;
                    case '"':  sb.Append("\\\""); break;
                    case '\b': sb.Append("\\b"); break;
                    case '\f': sb.Append("\\f"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (c < 0x20) sb.AppendFormat("\\u{0:x4}", (int)c);
                        else sb.Append(c);
                        break;
                }
            }
            sb.Append("\"}");
            return sb.ToString();
        }

        // --- Logger setup --------------------------------------------------

        /// <summary>
        /// Build a logger that writes to %LOCALAPPDATA%\SawanDownloadPro\logs\native-host.log.
        /// Falls back to NullLogger if the file cannot be opened.
        /// </summary>
        private static ILogger CreateLogger()
        {
            try
            {
                var baseDir = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                if (string.IsNullOrEmpty(baseDir))
                    return NullLogger.Instance;

                var logDir = Path.Combine(baseDir, "SawanDownloadPro", "logs");
                Directory.CreateDirectory(logDir);
                var logPath = Path.Combine(logDir, "native-host.log");

                // Simple file logger: open in append mode, share-read, UTF-8.
                // We deliberately avoid bringing in Microsoft.Extensions.Logging
                // providers — keep the dependency surface small.
                var writer = new StreamWriter(
                    new FileStream(logPath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite),
                    new UTF8Encoding(encoderShouldEmitUTF8Identifier: false))
                {
                    AutoFlush = true
                };

                return new SimpleFileLogger(writer);
            }
            catch
            {
                // Logging is best-effort. If we cannot write to the log file,
                // we still want the host to function.
                return NullLogger.Instance;
            }
        }

        private static int RunSelfTest()
        {
            // Emit a single framed {"ok":true,"selftest":true} response and exit.
            // This is invoked by the installer to verify the binary launches.
            using var stdout = Console.OpenStandardOutput();
            WriteMessage(stdout, "{\"ok\":true,\"selftest\":true}");
            return 0;
        }

        /// <summary>
        /// Minimal file logger that implements <see cref="ILogger"/>. We avoid
        /// pulling in Microsoft.Extensions.Logging.Console etc. to keep the
        /// native host's dependency surface tiny.
        /// </summary>
        private sealed class SimpleFileLogger : ILogger, IDisposable
        {
            private readonly TextWriter _writer;
            private readonly object _gate = new();

            public SimpleFileLogger(TextWriter writer) => _writer = writer;

            public IDisposable BeginScope<TState>(TState state) where TState : notnull
                => NullScope.Instance;

            public bool IsEnabled(LogLevel logLevel) => logLevel >= LogLevel.Information;

            public void Log<TState>(LogLevel logLevel, EventId eventId, TState state,
                                    Exception? exception, Func<TState, Exception?, string> formatter)
            {
                if (!IsEnabled(logLevel)) return;

                var message = formatter(state, exception);
                var line = $"{DateTime.UtcNow:yyyy-MM-ddTHH:mm:ss.fffZ} [{logLevel}] {message}";
                lock (_gate)
                {
                    try
                    {
                        _writer.WriteLine(line);
                        if (exception != null)
                        {
                            _writer.WriteLine(exception.ToString());
                        }
                    }
                    catch
                    {
                        // Swallow; logging is best-effort.
                    }
                }
            }

            public void Dispose()
            {
                try { _writer.Dispose(); } catch { /* ignore */ }
            }
        }

        private sealed class NullScope : IDisposable
        {
            public static readonly NullScope Instance = new();
            public void Dispose() { }
        }
    }
}
