using System;
using System.Collections.Generic;
using System.Globalization;
using System.Web.Script.Serialization;

namespace SawanDownloadPro.BrowserIntegration.NativeMessaging
{
    /// <summary>
    /// Strict, dependency-free validator for the browser → host message schema.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The wire schema accepted from any Sawan browser extension is exactly:
    /// </para>
    /// <code>
    /// {
    ///   "type":   "download",                       // required, literal
    ///   "url":    "https://example.com/file.zip",   // required, ≤8192 chars
    ///   "source": "context_menu",                   // required, allow-list
    ///   "tabUrl": "https://example.com/page"        // optional, ≤8192 chars
    /// }
    /// </code>
    /// <para>
    /// Anything else — extra fields, wrong types, missing fields, disallowed
    /// schemes, embedded credentials, oversize URLs — is rejected with a
    /// descriptive <paramref name="error"/> string. The validator never
    /// throws on untrusted input.
    /// </para>
    /// <para>
    /// <b>Security note:</b> this is the only place the C# host trusts input
    /// from the browser. Every downstream component (named-pipe bridge, main
    /// app) can safely assume a <see cref="DownloadMessage"/> has already
    /// passed every check below.
    /// </para>
    /// </remarks>
    public static class MessageSchema
    {
        /// <summary>Hard cap on URL length. Matches the extension and Python host.</summary>
        public const int MaxUrlLength = 8192;

        /// <summary>Hard cap on the entire incoming JSON message (1 MiB, matches Chrome).</summary>
        public const int MaxMessageBytes = 1 * 1024 * 1024;

        /// <summary>Schemes the host will accept. Anything else is rejected.</summary>
        public static readonly HashSet<string> AllowedSchemes = new(StringComparer.OrdinalIgnoreCase)
        {
            "http", "https", "ftp"
        };

        /// <summary>Allowed values for the <c>source</c> field. Unknown values are clamped to <c>"unknown"</c>.</summary>
        public static readonly HashSet<string> AllowedSources = new(StringComparer.Ordinal)
        {
            "context_menu", "toolbar_click", "popup",
            "suggestion_accepted", "unknown"
        };

        private const string ExpectedType = "download";

        // Reusing one serializer instance is safe (it is documented thread-safe
        // for deserialization once configured).
        private static readonly JavaScriptSerializer Serializer =
            new() { MaxJsonLength = MaxMessageBytes };

        /// <summary>
        /// Validate a JSON payload against the Sawan native messaging schema.
        /// </summary>
        /// <param name="json">Raw UTF-8 JSON string received from the browser.</param>
        /// <param name="message">On success, a populated <see cref="DownloadMessage"/>. On failure, null.</param>
        /// <param name="error">On failure, a human-readable description. On success, null.</param>
        /// <returns>True if the message is acceptable; false otherwise.</returns>
        public static bool TryValidate(string json, out DownloadMessage? message, out string? error)
        {
            message = null;
            error = null;

            if (json is null)
            {
                error = "Message is null.";
                return false;
            }
            if (json.Length == 0)
            {
                error = "Message is empty.";
                return false;
            }
            if (json.Length > MaxMessageBytes)
            {
                error = $"Message exceeds {MaxMessageBytes} bytes.";
                return false;
            }

            // --- Deserialize to a generic dictionary so we can validate field
            //     presence and types before trusting any value. ---
            object? root;
            try
            {
                root = Serializer.DeserializeObject(json);
            }
            catch (ArgumentException ex)
            {
                // JavaScriptSerializer throws ArgumentException for malformed JSON.
                error = "JSON parse error: " + ex.Message;
                return false;
            }
            catch (InvalidOperationException ex)
            {
                error = "JSON parse error: " + ex.Message;
                return false;
            }

            if (root is not IDictionary<string, object> dict)
            {
                error = "Top-level JSON must be an object.";
                return false;
            }

            // --- type ---
            if (!dict.TryGetValue("type", out var typeRaw) || typeRaw is not string typeStr)
            {
                error = "Field 'type' is missing or not a string.";
                return false;
            }
            if (!string.Equals(typeStr, ExpectedType, StringComparison.Ordinal))
            {
                error = $"Field 'type' must be '{ExpectedType}'.";
                return false;
            }

            // --- url ---
            if (!dict.TryGetValue("url", out var urlRaw) || urlRaw is not string urlStr)
            {
                error = "Field 'url' is missing or not a string.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(urlStr))
            {
                error = "Field 'url' must not be empty.";
                return false;
            }
            if (urlStr.Length > MaxUrlLength)
            {
                error = $"Field 'url' exceeds {MaxUrlLength} characters.";
                return false;
            }
            if (!TryValidateUrl(urlStr, out var urlError))
            {
                error = urlError;
                return false;
            }

            // --- source ---
            string sourceStr = "unknown";
            if (dict.TryGetValue("source", out var sourceRaw))
            {
                if (sourceRaw is not string srcStr)
                {
                    error = "Field 'source' must be a string.";
                    return false;
                }
                // Clamp unknown sources to "unknown" so a newer extension's
                // source value doesn't break the host. We still validate the
                // type strictly above.
                sourceStr = AllowedSources.Contains(srcStr) ? srcStr : "unknown";
            }

            // --- tabUrl (optional) ---
            string? tabUrlStr = null;
            if (dict.TryGetValue("tabUrl", out var tabUrlRaw) && tabUrlRaw is not null)
            {
                if (tabUrlRaw is not string tuStr)
                {
                    error = "Field 'tabUrl' must be a string when present.";
                    return false;
                }
                if (string.IsNullOrWhiteSpace(tuStr))
                {
                    error = "Field 'tabUrl' must not be empty when present.";
                    return false;
                }
                if (tuStr.Length > MaxUrlLength)
                {
                    error = $"Field 'tabUrl' exceeds {MaxUrlLength} characters.";
                    return false;
                }
                if (!TryValidateUrl(tuStr, out var tuError))
                {
                    error = tuError;
                    return false;
                }
                tabUrlStr = tuStr;
            }

            // --- Reject any extra top-level keys beyond the known set ---
            // This is a defense-in-depth measure: it prevents a confused-deputy
            // scenario where an attacker crafts a payload with keys the main
            // app might misinterpret. The known set is type, url, source, tabUrl.
            foreach (var key in dict.Keys)
            {
                if (key != "type" && key != "url" && key != "source" && key != "tabUrl")
                {
                    error = $"Unknown field '{key}' is not permitted.";
                    return false;
                }
            }

            // --- Assemble the validated message. Timestamp is set here, never
            //     trusted from the wire. ---
            message = new DownloadMessage
            {
                Type = ExpectedType,
                Url = urlStr,
                Source = sourceStr,
                TabUrl = tabUrlStr,
                Timestamp = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture)
            };
            return true;
        }

        /// <summary>
        /// Validate a single URL string: must be absolute, scheme must be in
        /// <see cref="AllowedSchemes"/>, must have a host, must not embed
        /// credentials.
        /// </summary>
        private static bool TryValidateUrl(string url, out string? error)
        {
            error = null;
            if (url.Length > MaxUrlLength)
            {
                error = $"URL exceeds {MaxUrlLength} characters.";
                return false;
            }

            if (!Uri.TryCreate(url, UriKind.Absolute, out var uri))
            {
                error = "URL is not absolute or could not be parsed.";
                return false;
            }

            if (!AllowedSchemes.Contains(uri.Scheme))
            {
                error = $"URL scheme '{uri.Scheme}' is not allowed (only http, https, ftp).";
                return false;
            }

            if (string.IsNullOrWhiteSpace(uri.Host))
            {
                error = "URL is missing a host.";
                return false;
            }

            // Reject embedded credentials. UserInfo is non-empty for URLs of
            // the form http://user:pass@host/. We treat the presence of any
            // userinfo as a hard failure — Sawan will re-prompt for auth.
            if (!string.IsNullOrEmpty(uri.UserInfo))
            {
                error = "URLs containing embedded credentials are not accepted.";
                return false;
            }

            return true;
        }
    }
}
