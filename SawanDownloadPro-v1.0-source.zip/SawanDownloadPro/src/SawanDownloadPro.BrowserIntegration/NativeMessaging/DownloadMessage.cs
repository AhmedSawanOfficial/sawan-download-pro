using System;
using System.Runtime.Serialization;

namespace SawanDownloadPro.BrowserIntegration.NativeMessaging
{
    /// <summary>
    /// Strongly-typed, validated representation of a message received from a
    /// browser extension via the native messaging protocol.
    /// </summary>
    /// <remarks>
    /// Instances are only ever produced by <see cref="MessageSchema.TryValidate"/>,
    /// which guarantees that:
    /// <list type="bullet">
    ///   <item><see cref="Url"/> is a non-empty string of at most 8192 chars,
    ///         with an http/https/ftp scheme and no embedded credentials.</item>
    ///   <item><see cref="Source"/> is one of a small allow-list of source
    ///         strings, or <c>"unknown"</c>.</item>
    ///   <item><see cref="TabUrl"/> (when present) passes the same checks as
    ///         <see cref="Url"/>.</item>
    ///   <item><see cref="Timestamp"/> is a UTC ISO-8601 string set by the
    ///         host at validation time (never trusted from the wire).</item>
    /// </list>
    /// </remarks>
    [DataContract]
    public sealed class DownloadMessage
    {
        /// <summary>Always the literal string "download".</summary>
        [DataMember(Name = "type", IsRequired = true)]
        public string Type { get; set; } = "download";

        /// <summary>The URL to download. Validated against the scheme allow-list.</summary>
        [DataMember(Name = "url", IsRequired = true)]
        public string Url { get; set; } = string.Empty;

        /// <summary>
        /// Origin of the request — one of <c>context_menu</c>,
        /// <c>toolbar_click</c>, <c>popup</c>, <c>suggestion_accepted</c>,
        /// or <c>unknown</c>.
        /// </summary>
        [DataMember(Name = "source", IsRequired = true)]
        public string Source { get; set; } = "unknown";

        /// <summary>
        /// The URL of the browser tab the user was on when they triggered the
        /// download. Optional; may be null. Used only for provenance/logging.
        /// </summary>
        [DataMember(Name = "tabUrl", IsRequired = false, EmitDefaultValue = false)]
        public string? TabUrl { get; set; }

        /// <summary>
        /// UTC ISO-8601 timestamp set by the host. Never trusted from the
        /// browser; always overwritten during validation.
        /// </summary>
        [DataMember(Name = "timestamp", IsRequired = true)]
        public string Timestamp { get; set; } = string.Empty;
    }
}
