using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.Extensions.Logging;
using Microsoft.Win32;

namespace SawanDownloadPro.BrowserIntegration.NativeMessaging
{
    /// <summary>
    /// Registers the Sawan Download Pro native messaging host for Chrome,
    /// Edge, Firefox, Opera, Brave, and Vivaldi on the current Windows
    /// user profile.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <b>What "install" means here</b>
    /// </para>
    /// <list type="number">
    ///   <item>Write (or overwrite) the JSON manifest at
    ///         <c>%LOCALAPPDATA%\SawanDownloadPro\native-messaging\com.sawan.downloadpro.json</c>.
    ///         This single file is shared by every supported Chromium-based
    ///         browser and by Firefox — it contains both
    ///         <c>allowed_origins</c> (for Chromium browsers) and
    ///         <c>allowed_extensions</c> (for Firefox).</item>
    ///   <item>For Chrome: create / set the registry value
    ///         <c>HKCU\Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro\(Default)</c>
    ///         to the absolute path of the JSON manifest.</item>
    ///   <item>For Edge: same pattern, under
    ///         <c>HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.sawan.downloadpro\(Default)</c>.</item>
    ///   <item>For Opera: same pattern, but Opera <b>shares Chrome's
    ///         registry path</b> (<c>HKCU\Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro</c>).
    ///         This is intentional Chromium behaviour: Opera does not ship
    ///         its own <c>NativeMessagingHosts</c> discovery key.</item>
    ///   <item>For Brave: same pattern, under
    ///         <c>HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\com.sawan.downloadpro\(Default)</c>.</item>
    ///   <item>For Vivaldi: same pattern, under
    ///         <c>HKCU\Software\Vivaldi\NativeMessagingHosts\com.sawan.downloadpro\(Default)</c>.</item>
    ///   <item>For Firefox: copy the JSON manifest to
    ///         <c>%APPDATA%\Mozilla\NativeMessagingHosts\com.sawan.downloadpro.json</c>.
    ///         Firefox does not use the registry for native host discovery.</item>
    /// </list>
    /// <para>
    /// All operations are per-user (under <c>HKCU</c> and per-user folders),
    /// so no administrator elevation is required.
    /// </para>
    /// <para>
    /// <b>Shared manifest.</b> Whenever any Chromium install method is
    /// called, the manifest is rewritten with <i>every</i> Chromium
    /// extension ID that is currently set on this instance — so a single
    /// manifest file works for all five Chromium-based browsers
    /// simultaneously. Firefox shares the same file (it ignores
    /// <c>allowed_origins</c> and reads only <c>allowed_extensions</c>).
    /// </para>
    /// <para>
    /// <b>Thread safety.</b> The class is not thread-safe; the caller (typically
    /// the settings UI) is expected to invoke it from a single thread.
    /// </para>
    /// </remarks>
    public sealed class ExtensionInstaller
    {
        // --- Registry paths --------------------------------------------------

        private const string ChromeRegistryPath = @"Software\Google\Chrome\NativeMessagingHosts\" + HostName;
        private const string EdgeRegistryPath   = @"Software\Microsoft\Edge\NativeMessagingHosts\" + HostName;
        private const string OperaRegistryPath  = @"Software\Google\Chrome\NativeMessagingHosts\" + HostName; // Opera shares Chrome's path.
        private const string BraveRegistryPath  = @"Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\" + HostName;
        private const string VivaldiRegistryPath = @"Software\Vivaldi\NativeMessagingHosts\" + HostName;

        /// <summary>The native messaging host name. MUST match the JSON manifest's <c>name</c> field.</summary>
        public const string HostName = "com.sawan.downloadpro";

        // --- Properties ------------------------------------------------------

        private readonly ILogger _logger;

        /// <summary>
        /// Absolute path to the executable (.exe or .bat) that the browser
        /// should launch. Defaults to the current process's main module path,
        /// which is correct when this assembly is the host itself.
        /// </summary>
        public string HostExecutablePath { get; set; }

        /// <summary>
        /// Chrome extension ID (32 lowercase a-p chars). Required for
        /// <see cref="InstallForChrome"/>. Leave null to skip Chrome
        /// installation.
        /// </summary>
        public string? ChromeExtensionId { get; set; }

        /// <summary>
        /// Edge extension ID. Required for <see cref="InstallForEdge"/>.
        /// Leave null to skip Edge installation. If Chrome and Edge share
        /// the same extension ID, set both to the same value.
        /// </summary>
        public string? EdgeExtensionId { get; set; }

        /// <summary>
        /// Opera extension ID (32 lowercase a-p chars). Required for
        /// <see cref="InstallForOpera"/>. Leave null to skip Opera
        /// installation. Opera is Chromium-based and uses the same MV3
        /// extension model as Chrome.
        /// </summary>
        public string? OperaExtensionId { get; set; }

        /// <summary>
        /// Brave extension ID (32 lowercase a-p chars). Required for
        /// <see cref="InstallForBrave"/>. Leave null to skip Brave
        /// installation. Brave is Chromium-based and uses the same MV3
        /// extension model as Chrome.
        /// </summary>
        public string? BraveExtensionId { get; set; }

        /// <summary>
        /// Vivaldi extension ID (32 lowercase a-p chars). Required for
        /// <see cref="InstallForVivaldi"/>. Leave null to skip Vivaldi
        /// installation. Vivaldi is Chromium-based and uses the same MV3
        /// extension model as Chrome.
        /// </summary>
        public string? VivaldiExtensionId { get; set; }

        /// <summary>
        /// Firefox add-on ID. Defaults to the value shipped in
        /// <c>browser-extensions/firefox/manifest.json</c>.
        /// </summary>
        public string FirefoxExtensionId { get; set; } = "sawan@sawan.example";

        /// <summary>Human-readable description embedded in the manifest.</summary>
        public string ManifestDescription { get; set; } = "Sawan Download Pro native messaging host";

        public ExtensionInstaller(ILogger logger)
            : this(logger, hostExecutablePath: GetCurrentProcessMainModulePath())
        {
        }

        public ExtensionInstaller(ILogger logger, string hostExecutablePath)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            if (string.IsNullOrWhiteSpace(hostExecutablePath))
                throw new ArgumentException("Host executable path must not be empty.", nameof(hostExecutablePath));
            HostExecutablePath = hostExecutablePath;
        }

        // --- Public API ------------------------------------------------------

        /// <summary>
        /// Install the native host for Google Chrome: write the manifest, then
        /// register it in <c>HKCU\Software\Google\Chrome\NativeMessagingHosts</c>.
        /// </summary>
        /// <exception cref="InvalidOperationException">
        /// Thrown if <see cref="ChromeExtensionId"/> is null or empty.
        /// </exception>
        public void InstallForChrome()
        {
            if (string.IsNullOrWhiteSpace(ChromeExtensionId))
                throw new InvalidOperationException(
                    "ChromeExtensionId must be set before calling InstallForChrome().");

            ValidateExtensionId(ChromeExtensionId!.Trim());
            InstallForChromiumBrowser("Chrome", ChromeRegistryPath);
        }

        /// <summary>
        /// Install the native host for Microsoft Edge: write the manifest,
        /// then register it in <c>HKCU\Software\Microsoft\Edge\NativeMessagingHosts</c>.
        /// </summary>
        public void InstallForEdge()
        {
            if (string.IsNullOrWhiteSpace(EdgeExtensionId))
                throw new InvalidOperationException(
                    "EdgeExtensionId must be set before calling InstallForEdge().");

            ValidateExtensionId(EdgeExtensionId!.Trim());
            InstallForChromiumBrowser("Edge", EdgeRegistryPath);
        }

        /// <summary>
        /// Install the native host for Opera: write the manifest, then
        /// register it in <c>HKCU\Software\Google\Chrome\NativeMessagingHosts</c>.
        /// Opera is Chromium-based and shares Chrome's native-messaging
        /// registry path — it does not ship its own discovery key.
        /// </summary>
        /// <exception cref="InvalidOperationException">
        /// Thrown if <see cref="OperaExtensionId"/> is null or empty.
        /// </exception>
        public void InstallForOpera()
        {
            if (string.IsNullOrWhiteSpace(OperaExtensionId))
                throw new InvalidOperationException(
                    "OperaExtensionId must be set before calling InstallForOpera().");

            ValidateExtensionId(OperaExtensionId!.Trim());
            InstallForChromiumBrowser("Opera", OperaRegistryPath);
        }

        /// <summary>
        /// Install the native host for Brave: write the manifest, then
        /// register it in
        /// <c>HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts</c>.
        /// Brave is Chromium-based and uses the same MV3 extension model as
        /// Chrome, but it does <b>not</b> share Chrome's registry path.
        /// </summary>
        /// <exception cref="InvalidOperationException">
        /// Thrown if <see cref="BraveExtensionId"/> is null or empty.
        /// </exception>
        public void InstallForBrave()
        {
            if (string.IsNullOrWhiteSpace(BraveExtensionId))
                throw new InvalidOperationException(
                    "BraveExtensionId must be set before calling InstallForBrave().");

            ValidateExtensionId(BraveExtensionId!.Trim());
            InstallForChromiumBrowser("Brave", BraveRegistryPath);
        }

        /// <summary>
        /// Install the native host for Vivaldi: write the manifest, then
        /// register it in
        /// <c>HKCU\Software\Vivaldi\NativeMessagingHosts</c>. Vivaldi is
        /// Chromium-based and uses the same MV3 extension model as Chrome,
        /// but it does <b>not</b> share Chrome's registry path.
        /// </summary>
        /// <exception cref="InvalidOperationException">
        /// Thrown if <see cref="VivaldiExtensionId"/> is null or empty.
        /// </exception>
        public void InstallForVivaldi()
        {
            if (string.IsNullOrWhiteSpace(VivaldiExtensionId))
                throw new InvalidOperationException(
                    "VivaldiExtensionId must be set before calling InstallForVivaldi().");

            ValidateExtensionId(VivaldiExtensionId!.Trim());
            InstallForChromiumBrowser("Vivaldi", VivaldiRegistryPath);
        }

        /// <summary>
        /// Install the native host for Firefox: copy the shared manifest to
        /// <c>%APPDATA%\Mozilla\NativeMessagingHosts\</c>. No registry edits
        /// are required for Firefox.
        /// </summary>
        public void InstallForFirefox()
        {
            if (string.IsNullOrWhiteSpace(FirefoxExtensionId))
                throw new InvalidOperationException(
                    "FirefoxExtensionId must be set before calling InstallForFirefox().");

            _logger.LogInformation("Installing native host for Firefox (add-on id={Id})", FirefoxExtensionId);

            // Build a manifest that contains both allowed_origins (so the
            // same JSON file works if it gets symlinked to Chrome's path)
            // and allowed_extensions (for Firefox). Firefox ignores
            // allowed_origins.
            var origins = CollectChromiumOrigins();

            var manifestJson = BuildManifestJson(
                allowedOrigins: origins.ToArray(),
                allowedExtensions: new[] { FirefoxExtensionId });

            // Firefox does NOT use the registry. It scans a well-known folder.
            var firefoxDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Mozilla", "NativeMessagingHosts");
            Directory.CreateDirectory(firefoxDir);

            var firefoxPath = Path.Combine(firefoxDir, HostName + ".json");
            File.WriteAllText(firefoxPath, manifestJson, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));

            _logger.LogInformation("Firefox install complete. Manifest: {Path}", firefoxPath);
        }

        /// <summary>
        /// Remove the native host registration for all supported browsers
        /// (Chrome, Edge, Opera, Brave, Vivaldi, and Firefox). Safe to call
        /// even if some browsers were never installed.
        /// </summary>
        public void UninstallAll()
        {
            _logger.LogInformation("Uninstalling native host from all browsers");

            // Note: ChromeRegistryPath and OperaRegistryPath are the same
            // string (Opera shares Chrome's path). UnregisterFromRegistry
            // is idempotent, so the second call is a no-op.
            UnregisterFromRegistry(ChromeRegistryPath);
            UnregisterFromRegistry(EdgeRegistryPath);
            UnregisterFromRegistry(OperaRegistryPath);
            UnregisterFromRegistry(BraveRegistryPath);
            UnregisterFromRegistry(VivaldiRegistryPath);

            var firefoxPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Mozilla", "NativeMessagingHosts", HostName + ".json");
            TryDeleteFile(firefoxPath);

            var sharedManifest = GetSharedManifestPath();
            TryDeleteFile(sharedManifest);

            // Also try to remove the parent native-messaging folder if empty.
            TryCleanupParentDirectory(sharedManifest);

            _logger.LogInformation("Uninstall complete");
        }

        // --- Helpers ---------------------------------------------------------

        /// <summary>
        /// Shared implementation for all Chromium-based browser installs.
        /// Writes the shared manifest (which includes every configured
        /// Chromium extension ID in <c>allowed_origins</c>) and registers
        /// it under the browser-specific registry path.
        /// </summary>
        /// <param name="browserName">Human-readable browser name (for logging).</param>
        /// <param name="registryPath">Per-browser registry path under <c>HKCU</c>.</param>
        private void InstallForChromiumBrowser(string browserName, string registryPath)
        {
            _logger.LogInformation("Installing native host for {Browser}", browserName);

            // Collect every configured Chromium origin so a single shared
            // manifest file works for all five Chromium-based browsers at
            // once. The caller has already validated the requested browser's
            // ID, so its origin is guaranteed to be in the list.
            var origins = CollectChromiumOrigins();
            if (origins.Count == 0)
            {
                throw new InvalidOperationException(
                    "No Chromium extension IDs are configured. Set at least one of " +
                    "ChromeExtensionId / EdgeExtensionId / OperaExtensionId / " +
                    "BraveExtensionId / VivaldiExtensionId before calling " +
                    "InstallFor" + browserName + "().");
            }

            var manifestJson = BuildManifestJson(
                allowedOrigins: origins.ToArray(),
                allowedExtensions: new[] { FirefoxExtensionId });

            var manifestPath = WriteSharedManifest(manifestJson);
            RegisterInRegistry(registryPath, manifestPath);

            _logger.LogInformation("{Browser} install complete. Manifest: {Path}", browserName, manifestPath);
        }

        /// <summary>
        /// Build the list of <c>chrome-extension://...</c> origin strings
        /// for every Chromium-based browser that has its extension ID set.
        /// Used to populate the shared manifest's <c>allowed_origins</c>
        /// array so a single manifest works for all installed Chromium
        /// browsers simultaneously.
        /// </summary>
        private List<string> CollectChromiumOrigins()
        {
            var origins = new List<string>(capacity: 5);

            if (!string.IsNullOrWhiteSpace(ChromeExtensionId))
                origins.Add("chrome-extension://" + ChromeExtensionId!.Trim() + "/");
            if (!string.IsNullOrWhiteSpace(EdgeExtensionId))
                origins.Add("chrome-extension://" + EdgeExtensionId!.Trim() + "/");
            if (!string.IsNullOrWhiteSpace(OperaExtensionId))
                origins.Add("chrome-extension://" + OperaExtensionId!.Trim() + "/");
            if (!string.IsNullOrWhiteSpace(BraveExtensionId))
                origins.Add("chrome-extension://" + BraveExtensionId!.Trim() + "/");
            if (!string.IsNullOrWhiteSpace(VivaldiExtensionId))
                origins.Add("chrome-extension://" + VivaldiExtensionId!.Trim() + "/");

            return origins;
        }

        /// <summary>
        /// Build the JSON manifest body. The same file works for all
        /// supported browsers because Chromium browsers consult
        /// <c>allowed_origins</c> and Firefox consults
        /// <c>allowed_extensions</c>.
        /// </summary>
        private string BuildManifestJson(string[]? allowedOrigins, string[]? allowedExtensions)
        {
            var sb = new StringBuilder();
            sb.Append('{');
            sb.Append("\"name\":\"").Append(HostName).Append("\",");
            sb.Append("\"description\":\"").Append(EscapeJsonString(ManifestDescription)).Append("\",");
            sb.Append("\"path\":\"").Append(EscapeJsonString(HostExecutablePath)).Append("\",");
            sb.Append("\"type\":\"stdio\"");

            if (allowedOrigins != null && allowedOrigins.Length > 0)
            {
                sb.Append(",\"allowed_origins\":[");
                for (int i = 0; i < allowedOrigins.Length; i++)
                {
                    if (i > 0) sb.Append(',');
                    sb.Append('"').Append(EscapeJsonString(allowedOrigins[i])).Append('"');
                }
                sb.Append(']');
            }

            if (allowedExtensions != null && allowedExtensions.Length > 0)
            {
                sb.Append(",\"allowed_extensions\":[");
                for (int i = 0; i < allowedExtensions.Length; i++)
                {
                    if (i > 0) sb.Append(',');
                    sb.Append('"').Append(EscapeJsonString(allowedExtensions[i])).Append('"');
                }
                sb.Append(']');
            }

            sb.Append('}');
            return sb.ToString();
        }

        /// <summary>
        /// Write the manifest to <c>%LOCALAPPDATA%\SawanDownloadPro\native-messaging\com.sawan.downloadpro.json</c>
        /// and return the absolute path. The directory is created if missing.
        /// </summary>
        private string WriteSharedManifest(string json)
        {
            var path = GetSharedManifestPath();
            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            File.WriteAllText(path, json, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
            return path;
        }

        private string GetSharedManifestPath()
        {
            var dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "SawanDownloadPro", "native-messaging");
            return Path.Combine(dir, HostName + ".json");
        }

        private void RegisterInRegistry(string keyPath, string manifestPath)
        {
            // HKCU does not require admin rights.
            using var key = Registry.CurrentUser.CreateSubKey(keyPath, writable: true);
            if (key is null)
                throw new InvalidOperationException("Could not create or open registry key: " + keyPath);
            key.SetValue(null, manifestPath, RegistryValueKind.String);
        }

        private void UnregisterFromRegistry(string keyPath)
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(keyPath, writable: true);
                if (key is null) return; // nothing to remove
                Registry.CurrentUser.DeleteSubKey(keyPath, throwOnMissingSubKey: false);
            }
            catch (Exception ex)
            {
                // Best-effort; never throw from UninstallAll.
                _logger.LogWarning(ex, "Could not remove registry key {Path}", keyPath);
            }
        }

        private static void ValidateExtensionId(string id)
        {
            // Chromium-based browser extension IDs are 32 lowercase
            // characters from the alphabet a-p (generated from the SHA-256
            // of the public key). We accept any 32-char lowercase a-p
            // string. We deliberately do not throw on a malformed ID — we
            // just warn — because the user may have a non-standard
            // distribution.
            if (id.Length != 32)
                throw new InvalidOperationException(
                    $"Extension ID '{id}' is not 32 characters long. Chromium IDs are 32 lowercase a-p chars.");

            foreach (var c in id)
            {
                if (c < 'a' || c > 'p')
                    throw new InvalidOperationException(
                        $"Extension ID '{id}' contains invalid character '{c}'. Only a-p are allowed.");
            }
        }

        private void TryDeleteFile(string path)
        {
            try
            {
                if (File.Exists(path)) File.Delete(path);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Could not delete file {Path}", path);
            }
        }

        private void TryCleanupParentDirectory(string path)
        {
            try
            {
                var dir = Path.GetDirectoryName(path);
                if (string.IsNullOrEmpty(dir)) return;
                if (!Directory.Exists(dir)) return;
                if (Directory.GetFiles(dir).Length == 0 &&
                    Directory.GetDirectories(dir).Length == 0)
                {
                    Directory.Delete(dir);
                }
            }
            catch
            {
                // Non-fatal.
            }
        }

        private static string EscapeJsonString(string s)
        {
            var sb = new StringBuilder(s.Length + 2);
            foreach (var c in s)
            {
                switch (c)
                {
                    case '\\': sb.Append("\\\\"); break;
                    case '"':  sb.Append("\\\""); break;
                    case '\b': sb.Append("\\b"); break;
                    case '\f': sb.Append("\\f"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (c < 0x20) sb.AppendFormat("\\u{0:x4}", (int)c);
                        else sb.Append(c);
                        break;
                }
            }
            return sb.ToString();
        }

        private static string GetCurrentProcessMainModulePath()
        {
            // On .NET Framework 4.8, AppDomain.CurrentDomain.BaseDirectory
            // ends in a trailing backslash. We combine with the assembly's
            // code base so the path always points at the host executable.
            try
            {
                var module = System.Diagnostics.Process.GetCurrentProcess().MainModule;
                if (module != null && !string.IsNullOrEmpty(module.FileName))
                    return module.FileName;
            }
            catch
            {
                // Fall through.
            }
            return typeof(ExtensionInstaller).Assembly.Location;
        }
    }
}
