using System;
using System.Collections.Generic;
using System.Windows;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.Themes
{
    /// <summary>
    /// Applies the user-selected theme to the running WPF application by swapping the
    /// theme ResourceDictionary in <see cref="Application.Resources"/>. Also handles
    /// applying the custom accent color at runtime.
    /// </summary>
    /// <remarks>
    /// The XAML theme dictionaries live in the App project under Themes/. We load them
    /// by pack URI so that the Themes project itself does not need a WPF reference at
    /// build time. This class is invoked from the App project.
    /// </remarks>
    public static class ThemeManager
    {
        private const string DarkEggplantPackUri =
            "pack://application:,,,/SawanDownloadPro.App;component/Themes/DarkEggplantTheme.xaml";
        private const string LightPackUri =
            "pack://application:,,,/SawanDownloadPro.App;component/Themes/LightTheme.xaml";

        /// <summary>
        /// Dictionary keys that should be repointed when a custom accent color is applied.
        /// These keys are used throughout the XAML as {DynamicResource} so updating them at
        /// runtime propagates immediately.
        /// </summary>
        private static readonly string[] AccentKeys =
        {
            "AccentBrush",
            "SecondaryAccentBrush",
            "SidebarItemSelectedBrush",
            "ProgressBarForegroundBrush",
            "ButtonBackgroundBrush"
        };

        /// <summary>
        /// Applies the supplied theme to the application. Safe to call repeatedly.
        /// </summary>
        public static void ApplyTheme(AppTheme theme)
        {
            var app = Application.Current;
            if (app == null) return;

            var targetUri = theme switch
            {
                AppTheme.DarkEggplant => DarkEggplantPackUri,
                AppTheme.Light        => LightPackUri,
                AppTheme.System       => IsSystemDarkTheme() ? DarkEggplantPackUri : LightPackUri,
                _                     => DarkEggplantPackUri
            };

            var newDict = new ResourceDictionary { Source = new Uri(targetUri, UriKind.Absolute) };

            // Replace the second merged dictionary (index 1) — the theme dictionary.
            // Index 0 is Colors.xaml; index 1 is the active theme; index 2 is localization; index 3 is CommonStyles.
            // We find the existing theme dict by Source and replace it in place to preserve order.
            ResourceDictionary? existing = null;
            foreach (var d in app.Resources.MergedDictionaries)
            {
                if (d.Source != null && (d.Source.OriginalString.Contains("DarkEggplantTheme") ||
                                          d.Source.OriginalString.Contains("LightTheme")))
                {
                    existing = d;
                    break;
                }
            }

            if (existing != null)
            {
                existing.Source = newDict.Source;
            }
            else
            {
                app.Resources.MergedDictionaries.Insert(1, newDict);
            }
        }

        /// <summary>
        /// Applies the supplied custom accent color. Pass null to clear and revert to the
        /// theme's default accent.
        /// </summary>
        public static void ApplyCustomAccent(string? hexColor)
        {
            var app = Application.Current;
            if (app == null) return;

            if (string.IsNullOrWhiteSpace(hexColor))
            {
                // Remove overrides — fall back to the theme's accent.
                foreach (var key in AccentKeys) app.Resources.Remove(key);
                return;
            }

            if (!DesignTokens.IsValidHexColor(hexColor)) return;

            var color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(hexColor);
            var brush = new System.Windows.Media.SolidColorBrush(color);
            brush.Freeze();
            foreach (var key in AccentKeys) app.Resources[key] = brush;
        }

        /// <summary>
        /// Returns true when the OS is in dark mode. On Windows 7/8 this always returns false
        /// (no system dark-mode concept). On Windows 10+ it reads
        /// <c>HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize\AppsUseLightTheme</c>.
        /// </summary>
        public static bool IsSystemDarkTheme()
        {
            try
            {
                using var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
                if (key?.GetValue("AppsUseLightTheme") is int v) return v == 0;
            }
            catch { /* Win7/8 — no personalization key; treat as light. */ }
            return false;
        }
    }
}
