namespace SawanDownloadPro.Themes
{
    /// <summary>
    /// The official Sawan v1.0 design tokens. These are the source-of-truth for the brand
    /// identity. The XAML resource dictionaries in the App project mirror these values.
    /// Adjust here first, then propagate to Colors.xaml / DarkEggplantTheme.xaml / LightTheme.xaml.
    /// </summary>
    /// <remarks>
    /// Per the v1.0 specification:
    /// - Dark Eggplant is the default theme on a fresh install.
    /// - Blue must NOT be the dominant brand color.
    /// - Tokens may be adjusted only to improve accessibility/contrast while preserving
    ///   the dark aubergine identity.
    /// </remarks>
    public static class DesignTokens
    {
        // --- Dark Eggplant palette (default theme) ---
        public const string PrimaryBackground   = "#21102F";
        public const string SecondaryBackground = "#2B173B";
        public const string CardBackground      = "#382047";

        public const string PrimaryAccent   = "#6F42A6";
        public const string SecondaryAccent = "#A78BFA";
        public const string LightAccent     = "#D8B4FE";

        public const string TextPrimaryOnDark   = "#F8F4FC";
        public const string TextSecondaryOnDark = "#D5C0E8";
        public const string BorderOnDark        = "#654778";

        // --- Semantic colors (consistent across themes) ---
        public const string Success = "#2E9D72";
        public const string Warning = "#D69E36";
        public const string Error   = "#D95368";

        // --- Light theme palette (used when user switches to Light) ---
        public const string LightWindowBackground   = "#FAF7FC";
        public const string LightSecondaryBackground = "#F1EAF7";
        public const string LightCardBackground      = "#FFFFFF";
        public const string LightTextPrimary   = "#21102F";
        public const string LightTextSecondary = "#5A4A6B";
        public const string LightBorder        = "#D8C8E5";

        /// <summary>
        /// The default custom-accent color (used when the user opens the accent picker
        /// but does not yet choose one). It is identical to <see cref="SecondaryAccent"/>
        /// so that "Reset to Sawan defaults" is visually equivalent to choosing the brand color.
        /// </summary>
        public const string DefaultCustomAccent = SecondaryAccent;

        /// <summary>
        /// Returns true if the supplied hex color is a valid 7-character #RRGGBB string.
        /// Used by the SettingsViewModel to validate the custom accent field before applying it.
        /// </summary>
        public static bool IsValidHexColor(string? s)
        {
            if (string.IsNullOrWhiteSpace(s)) return false;
            if (s.Length != 7) return false;
            if (s[0] != '#') return false;
            for (int i = 1; i < 7; i++)
            {
                if (!IsHexDigit(s[i])) return false;
            }
            return true;
        }

        private static bool IsHexDigit(char c)
            => (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }
}
