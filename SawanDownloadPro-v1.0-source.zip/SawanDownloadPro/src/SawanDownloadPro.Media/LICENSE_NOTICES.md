# License Notices — Sawan Download Pro Media Module

This document explains the licensing of the third-party binaries that the
Sawan Download Pro media module invokes, why Sawan Download Pro does not
bundle them, and what the user must do to use them lawfully.

---

## TL;DR

| Binary        | License            | Bundled with Sawan? | Source                                                                              |
|---------------|--------------------|---------------------|-------------------------------------------------------------------------------------|
| FFmpeg        | LGPL 2.1+ (or GPL) | **No**              | <https://ffmpeg.org/legal.html>                                                     |
| yt-dlp        | The Unlicense      | **No**              | <https://github.com/yt-dlp/yt-dlp/blob/master/LICENSE>)                             |

You — the user — must obtain these binaries yourself, accept their license
terms, and configure their paths in **Settings → Media**. Sawan Download
Pro invokes them as external processes with safe argument construction; it
does not link against them, redistribute them, or modify them.

---

## 1. FFmpeg

### 1.1 License

FFmpeg is licensed under the **GNU Lesser General Public License (LGPL)
version 2.1 or later**, with the following caveat: any FFmpeg build that
includes GPL-licensed libraries (such as `libx264`, `libx265`, `libfdk-aac`,
`libmp3lame` in some configurations, or `xvidcore`) becomes a combined work
licensed under the **GNU General Public License (GPL) version 2 or later**.

The license under which a particular binary is distributed is determined
entirely by the build configuration chosen by whoever compiled that binary.
Sawan Download Pro makes no representation about which license applies to
any user-supplied FFmpeg binary.

The full text of the LGPL 2.1 is at <https://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt>.
The full text of the GPL 2.0 is at <https://www.gnu.org/licenses/old-licenses/gpl-2.0.txt>.

### 1.2 Patent notice

Some video and audio codecs that FFmpeg implements — most notably
**H.264 (AVC)**, **H.265 (HEVC)**, **AAC**, and **MP3** — may be subject to
patent royalties in some jurisdictions. Sawan Download Pro does not
distribute codec implementations and does not provide legal advice. The
user is responsible for any patent licensing obligations that arise from
their use of FFmpeg.

### 1.3 Why we do not bundle FFmpeg

1. **License incompatibility.** Bundling an LGPL-licensed FFmpeg binary
   with Sawan Download Pro would require us to permit end-user relinking
   and reverse engineering for debugging modifications, and to ship the
   corresponding source for the FFmpeg build. Bundling a GPL-licensed
   build would impose GPL on the entire product. Neither is acceptable
   for a closed-source product.
2. **Build-matrix complexity.** FFmpeg has dozens of common build
   configurations. Each one is licensed differently. We cannot pick one
   that is appropriate for every user's jurisdiction and use case.
3. **Volatile binaries.** FFmpeg is updated frequently. Bundling a
   specific version would freeze users on a version that grows stale;
   letting the user supply their own lets them update at will.
4. **Footprint.** A full FFmpeg build is ~80–100 MB. Users who do not
   want media conversion should not have to download it.

### 1.4 User obligations when configuring FFmpeg

When you set `FFmpegPath` in **Settings → Media**, you are confirming that:

- You have lawfully obtained an FFmpeg binary, and you accept the license
  (LGPL 2.1+ or GPL, as applicable to your build) under which it was
  distributed to you.
- You have satisfied any patent licensing obligations for the codecs you
  intend to use, in your jurisdiction.
- You understand that Sawan Download Pro invokes this binary as an
  external process and does not modify, redistribute, or link against it.

Sawan Download Pro invokes FFmpeg with `UseShellExecute=false`,
`CreateNoWindow=true`, and manually-quoted arguments. No shell
interpretation occurs. The binary is launched with the same user
privileges as the Sawan Download Pro process itself.

---

## 2. yt-dlp

### 2.1 License

yt-dlp is released into the public domain under the terms of
**The Unlicense**. The full text is at
<https://github.com/yt-dlp/yt-dlp/blob/master/LICENSE>.

### 2.2 Why we do not bundle yt-dlp

1. **Volatile.** YouTube and other supported sites change their player
   APIs frequently. yt-dlp issues patch releases often; bundling a
   specific version would freeze users on a version that breaks within
   weeks.
2. **Authorization clarity.** Some users do not want media-download
   features at all. Forcing yt-dlp on every install blurs the line
   between "download manager" and "media downloader". Making it opt-in
   via Settings keeps the default install focused on its core purpose.
3. **User-responsibility framing.** Downloading media from third-party
   platforms carries ToS and copyright considerations. Requiring the
   user to obtain yt-dlp themselves makes their agency explicit: they
   chose to install it, they chose to point Sawan Download Pro at it,
   and they are responsible for using it lawfully.

### 2.3 User obligations when configuring yt-dlp

When you set `YtDlpPath` in **Settings → Media**, you are confirming that:

- You accept the Unlicense terms under which yt-dlp is distributed.
- You will use yt-dlp only to download content you are authorized to
  download (your own content, public-domain content, content licensed
  for reuse, etc.), and only in compliance with the source platform's
  Terms of Service and with applicable copyright law in your
  jurisdiction.
- You understand that yt-dlp may break at any time if a supported site
  changes its API, and that updating yt-dlp (`yt-dlp -U` or reinstall)
  is the standard remedy.

### 2.4 What Sawan Download Pro will NOT do with yt-dlp

- It will NOT pass cookies or session tokens harvested from your
  browser.
- It will NOT pass `--cookies-from-browser`.
- It will NOT pass any authentication credentials.
- It will NOT attempt to bypass DRM, age gates that require login, or
  members-only restrictions.
- It will NOT auto-update yt-dlp; that is your responsibility.

If yt-dlp refuses a video (e.g. because it is DRM-protected, members-only,
or removed), Sawan Download Pro surfaces the refusal verbatim. It does
NOT retry with workarounds.

---

## 3. Sawan Download Pro's own license

The Sawan Download Pro source code (including this media module) is
distributed under the **Apache License, Version 2.0**. See the project's
top-level `LICENSE` file.

The Apache 2.0 license is compatible with both the LGPL and the Unlicense.
This means the user may combine Sawan Download Pro with a user-supplied
FFmpeg binary and a user-supplied yt-dlp binary without license conflict,
provided the terms of all three licenses are honoured.

---

## 4. Audit trail

Every invocation of FFmpeg and yt-dlp is logged (without cookies,
credentials, or auth headers) to
`%LOCALAPPDATA%\SawanDownloadPro\logs\media.log`. The log records:

- The binary path that was invoked.
- The arguments (with sensitive paths redacted in future revisions; the
  current implementation logs them verbatim — do not point the log
  directory at a cloud-synced folder if this is a concern).
- The exit code.
- The first line of any error output.

You can audit which binary was used for which download at any time by
reviewing this log file.

---

## 5. Contact

Questions about this document or about the media module's licensing
posture can be sent to the Sawan engineering team via the project's
issue tracker. We do not provide legal advice; for licensing questions
specific to your jurisdiction, consult a qualified attorney.
