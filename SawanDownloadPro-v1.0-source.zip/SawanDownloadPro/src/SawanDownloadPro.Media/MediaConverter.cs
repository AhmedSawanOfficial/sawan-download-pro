using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Models;
using SawanDownloadPro.Media.Extractors;
using SawanDownloadPro.Media.FFmpeg;
using SawanDownloadPro.Security.Process;

namespace SawanDownloadPro.Media
{
    /// <summary>
    /// Top-level facade that the WPF UI (the App project) talks to for media
    /// operations. Composes a <see cref="VideoExtractorRegistry"/> (probe +
    /// download from a media URL) and an <see cref="FFmpegRunner"/> (post-
    /// processing conversion). Insulates the UI from the concrete extractor
    /// set and from FFmpeg configuration concerns.
    /// </summary>
    /// <remarks>
    /// The App project should construct exactly one <see cref="MediaConverter"/>
    /// at startup. The UI's "Video Downloader" window calls
    /// <see cref="ProbeAsync"/>, displays the returned formats, and on user
    /// confirmation calls <see cref="DownloadAsync"/>; if the user then
    /// requests a format conversion (e.g. MP4 → MP3),
    /// <see cref="ConvertAsync"/> is invoked on the resulting file.
    /// </remarks>
    public sealed class MediaConverter
    {
        private readonly VideoExtractorRegistry _registry;
        private readonly FFmpegRunner _ffmpeg;
        private readonly ILogger _logger;

        public MediaConverter(
            VideoExtractorRegistry registry,
            FFmpegRunner ffmpeg,
            ILogger<MediaConverter> logger)
        {
            _registry = registry ?? throw new ArgumentNullException(nameof(registry));
            _ffmpeg = ffmpeg ?? throw new ArgumentNullException(nameof(ffmpeg));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// The underlying extractor registry (for diagnostics / settings UI).
        /// </summary>
        public VideoExtractorRegistry Registry => _registry;

        /// <summary>
        /// The underlying FFmpeg runner (for version display / config check).
        /// </summary>
        public FFmpegRunner FFmpeg => _ffmpeg;

        /// <summary>
        /// Probes a media URL and returns metadata + available formats without
        /// downloading. Never throws — failures are returned as
        /// <see cref="VideoInfo.HasError"/>.
        /// </summary>
        public async Task<VideoInfo> ProbeAsync(string url, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(url))
                return new VideoInfo
                {
                    ErrorMessage = "URL is required.",
                    ExtractorName = _registry.Fallback.DisplayName
                };

            var extractor = _registry.FindExtractor(url);
            try
            {
                return await extractor.ProbeAsync(url, ct);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Probe failed for {Url}", url);
                return new VideoInfo
                {
                    SourceUrl = url,
                    ExtractorName = extractor.DisplayName,
                    ErrorMessage =
                        "Probe failed unexpectedly: " + ex.Message +
                        " — this is most likely caused by a missing or out-of-date " +
                        "yt-dlp binary. Update yt-dlp and retry."
                };
            }
        }

        /// <summary>
        /// Downloads the chosen format to <paramref name="savePath"/>. The
        /// directory must already exist; the file may be overwritten.
        /// </summary>
        public async Task<DownloadResult> DownloadAsync(
            string url,
            VideoFormat selectedFormat,
            string savePath,
            IProgress<int>? progress,
            CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(url))
                return DownloadResult.Fail("URL is required.");
            if (string.IsNullOrWhiteSpace(savePath))
                return DownloadResult.Fail("Save path is required.");
            if (selectedFormat == null)
                return DownloadResult.Fail("No format selected.");

            var extractor = _registry.FindExtractor(url);
            try
            {
                return await extractor.DownloadAsync(url, selectedFormat, savePath, progress, ct);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Download failed for {Url}", url);
                return DownloadResult.Fail("Download failed unexpectedly: " + ex.Message);
            }
        }

        /// <summary>
        /// Converts an already-downloaded media file using FFmpeg. Returns a
        /// clear configuration error if FFmpeg is not configured.
        /// </summary>
        public Task<ConversionResult> ConvertAsync(
            string inputPath,
            string outputPath,
            ConversionOptions options,
            IProgress<int>? progress,
            CancellationToken ct)
            => _ffmpeg.ConvertAsync(inputPath, outputPath, options, progress, ct);

        // -------------------------------------------------------------------
        // Convenience factory for the App project's composition root.
        // -------------------------------------------------------------------

        /// <summary>
        /// Builds a fully-wired <see cref="MediaConverter"/> with the default
        /// extractor set. The caller must supply the user's
        /// <see cref="AppSettings"/> (already loaded from storage), a logger
        /// factory, and a <see cref="SafeProcessLauncher"/> instance.
        /// </summary>
        public static MediaConverter CreateDefault(
            AppSettings settings,
            ILoggerFactory loggerFactory,
            SafeProcessLauncher safeProcessLauncher)
        {
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            if (loggerFactory == null) throw new ArgumentNullException(nameof(loggerFactory));
            if (safeProcessLauncher == null) throw new ArgumentNullException(nameof(safeProcessLauncher));

            var registry = VideoExtractorRegistry.CreateDefault(settings, loggerFactory, safeProcessLauncher);
            var ffmpeg = new FFmpegRunner(settings, loggerFactory.CreateLogger<FFmpegRunner>());
            return new MediaConverter(registry, ffmpeg, loggerFactory.CreateLogger<MediaConverter>());
        }
    }
}
