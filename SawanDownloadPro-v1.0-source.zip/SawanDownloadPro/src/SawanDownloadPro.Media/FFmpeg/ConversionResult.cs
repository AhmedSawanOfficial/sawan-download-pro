using System;

namespace SawanDownloadPro.Media.FFmpeg
{
    /// <summary>
    /// Result of an FFmpeg conversion. Always returned (never thrown).
    /// </summary>
    public sealed class ConversionResult
    {
        /// <summary><c>true</c> if the conversion finished and the output file exists.</summary>
        public bool Success { get; set; }

        /// <summary>Absolute path to the produced file.</summary>
        public string? OutputPath { get; set; }

        /// <summary>Human-readable error message. Empty on success.</summary>
        public string ErrorMessage { get; set; } = string.Empty;

        /// <summary>Wall-clock duration of the conversion.</summary>
        public TimeSpan Duration { get; set; }

        public static ConversionResult Ok(string path, TimeSpan duration) =>
            new() { Success = true, OutputPath = path, Duration = duration };

        public static ConversionResult Fail(string error, string? partialPath = null) =>
            new() { Success = false, ErrorMessage = error ?? string.Empty, OutputPath = partialPath };
    }
}
