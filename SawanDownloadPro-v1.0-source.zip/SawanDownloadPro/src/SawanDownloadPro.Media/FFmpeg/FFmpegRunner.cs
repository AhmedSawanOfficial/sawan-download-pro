using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.Media.FFmpeg
{
    /// <summary>
    /// Wraps an external <c>ffmpeg.exe</c> binary the USER supplies. Sawan
    /// Download Pro NEVER bundles FFmpeg.
    /// </summary>
    /// <remarks>
    /// <para><b>FFmpeg licensing.</b> FFmpeg is licensed under the GNU Lesser
    /// General Public License (LGPL) version 2.1 or later. Some build
    /// configurations (those that include GPL-licensed libraries such as
    /// libx264, libx265, or libfdk-aac) are licensed under the GNU General
    /// Public License (GPL) version 2 or later. The user is responsible for
    /// ensuring that the FFmpeg binary they configure complies with FFmpeg's
    /// license terms and with the licenses of all codecs it includes.
    /// <b>Sawan Download Pro does not bundle FFmpeg.</b></para>
    /// <para><b>Patent notice.</b> Some codecs (notably H.264/H.265 video and
    /// AAC audio) may be subject to patent royalties in some jurisdictions.
    /// Sawan Download Pro invokes the user-supplied binary and does not
    /// distribute codec implementations. The user is responsible for any
    /// patent licensing obligations that arise from their use of FFmpeg.</para>
    /// <para><b>Safety.</b> All user-controlled fields (paths, bitrates,
    /// resolutions) are passed through the same manual argument-quoting
    /// algorithm used by <c>SafeProcessLauncher</c>. FFmpeg is invoked with
    /// <c>UseShellExecute=false</c> and <c>CreateNoWindow=true</c>. No shell
    /// interpretation occurs.</para>
    /// </remarks>
    public sealed class FFmpegRunner
    {
        private const string NotConfiguredMessage =
            "FFmpeg path not configured. Open Settings → Media to configure.";

        private readonly AppSettings _settings;
        private readonly ILogger _logger;

        // FFmpeg progress lines look like:
        //   frame=  123 fps= 60 q=24.0 size=     256kB time=00:00:05.12 bitrate= 409.6kbits/s speed=2.5x
        // We extract the time= field and (if known) divide by the input duration.
        private static readonly Regex ProgressRegex = new Regex(
            @"time=(\d{2}):(\d{2}):(\d{2}(?:\.\d+)?)",
            RegexOptions.Compiled);

        // Duration probe line (appears once near the start):
        //   Duration: 00:03:45.20, start: 0.000000, bitrate: 128 kb/s
        private static readonly Regex DurationRegex = new Regex(
            @"Duration:\s+(\d{2}):(\d{2}):(\d{2}(?:\.\d+)?)",
            RegexOptions.Compiled);

        public FFmpegRunner(AppSettings settings, ILogger<FFmpegRunner> logger)
        {
            _settings = settings ?? throw new ArgumentNullException(nameof(settings));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Returns <c>true</c> if a usable ffmpeg.exe has been configured.
        /// </summary>
        public bool IsConfigured => ResolveFFmpegPath() != null;

        /// <summary>
        /// Verifies the configured binary exists and prints its version.
        /// Returns the version string on success, or <c>null</c> (and logs)
        /// if FFmpeg is missing or unusable.
        /// </summary>
        public async Task<string?> GetVersionAsync(CancellationToken ct = default)
        {
            var path = ResolveFFmpegPath();
            if (path == null) return null;
            try
            {
                var (exit, stdout, _) = await RunCaptureAsync(path, new[] { "-version" }, TimeSpan.FromSeconds(10), ct);
                if (exit != 0) return null;
                var firstLine = stdout.Split('\n');
                return firstLine.Length > 0 ? firstLine[0].Trim() : "ffmpeg";
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "FFmpeg version probe failed");
                return null;
            }
        }

        /// <summary>
        /// Converts <paramref name="inputPath"/> to <paramref name="outputPath"/>
        /// using the supplied <paramref name="options"/>. Progress is reported
        /// as 0–100 percent based on FFmpeg's <c>time=</c> output relative to
        /// the input's probed duration.
        /// </summary>
        public async Task<ConversionResult> ConvertAsync(
            string inputPath,
            string outputPath,
            ConversionOptions options,
            IProgress<int>? progress,
            CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(inputPath))
                return ConversionResult.Fail("Input path is required.");
            if (string.IsNullOrWhiteSpace(outputPath))
                return ConversionResult.Fail("Output path is required.");
            if (!File.Exists(inputPath))
                return ConversionResult.Fail($"Input file does not exist: {inputPath}");
            if (options == null) options = new ConversionOptions();

            var ffmpeg = ResolveFFmpegPath();
            if (ffmpeg == null)
                return ConversionResult.Fail(NotConfiguredMessage);

            var dir = Path.GetDirectoryName(outputPath);
            if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir))
                return ConversionResult.Fail($"Output directory does not exist: {dir}");

            // Probe duration first so we can compute progress percentages.
            var totalDuration = await ProbeDurationAsync(ffmpeg, inputPath, ct);
            if (totalDuration <= TimeSpan.Zero && options.TrimEnd.HasValue)
                totalDuration = options.TrimEnd.Value
                    - (options.TrimStart ?? TimeSpan.Zero);

            var args = BuildArgs(inputPath, outputPath, options);
            var startedAt = Stopwatch.StartNew();

            try
            {
                int exit = await RunWithProgressAsync(
                    ffmpeg, args, totalDuration, progress, ct);
                var elapsed = startedAt.Elapsed;
                if (exit != 0)
                {
                    var partial = File.Exists(outputPath) ? outputPath : null;
                    return ConversionResult.Fail(
                        $"FFmpeg exited with code {exit}. The input may use an unsupported codec, " +
                        "or the configured FFmpeg build may lack the required encoder. Check that " +
                        "your FFmpeg binary includes the codec for the chosen output format.",
                        partial);
                }
                if (!File.Exists(outputPath))
                    return ConversionResult.Fail(
                        "FFmpeg exited successfully but no output file was produced.");
                return ConversionResult.Ok(outputPath, elapsed);
            }
            catch (OperationCanceledException)
            {
                TryDelete(outputPath);
                return ConversionResult.Fail("Conversion cancelled by user.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "FFmpeg conversion failed for {Input}", inputPath);
                return ConversionResult.Fail("FFmpeg conversion failed: " + ex.Message);
            }
        }

        // -------------------------------------------------------------------
        // Argument construction
        // -------------------------------------------------------------------

        private static List<string> BuildArgs(string input, string output, ConversionOptions o)
        {
            var args = new List<string>();
            args.Add("-y");      // overwrite without prompting
            args.Add("-hide_banner");

            // Trim start: seek the input before reading (fast).
            if (o.TrimStart.HasValue)
            {
                args.Add("-ss");
                args.Add(FormatTime(o.TrimStart.Value));
            }

            if (!string.IsNullOrWhiteSpace(o.ExtraInputArgs))
                args.Add(o.ExtraInputArgs);

            args.Add("-i");
            args.Add(input);

            // Trim end: stop reading after this duration (relative to -ss).
            if (o.TrimStart.HasValue && o.TrimEnd.HasValue && o.TrimEnd.Value > o.TrimStart.Value)
            {
                args.Add("-to");
                args.Add(FormatTime(o.TrimEnd.Value - o.TrimStart.Value));
            }

            // Output format and codec selection.
            switch (o.OutputFormat)
            {
                case OutputFormat.Mp3:
                    args.Add("-vn");                   // drop any video stream
                    args.Add("-c:a"); args.Add("libmp3lame");
                    if (o.AudioBitrateKbps.HasValue)
                    { args.Add("-b:a"); args.Add(o.AudioBitrateKbps.Value + "k"); }
                    break;
                case OutputFormat.Aac:
                    args.Add("-vn");
                    args.Add("-c:a"); args.Add("aac");
                    if (o.AudioBitrateKbps.HasValue)
                    { args.Add("-b:a"); args.Add(o.AudioBitrateKbps.Value + "k"); }
                    break;
                case OutputFormat.Wav:
                    args.Add("-vn");
                    args.Add("-c:a"); args.Add("pcm_s16le");
                    break;
                case OutputFormat.Flac:
                    args.Add("-vn");
                    args.Add("-c:a"); args.Add("flac");
                    break;
                case OutputFormat.Ogg:
                    args.Add("-vn");
                    args.Add("-c:a"); args.Add("libvorbis");
                    if (o.AudioBitrateKbps.HasValue)
                    { args.Add("-b:a"); args.Add(o.AudioBitrateKbps.Value + "k"); }
                    break;
                case OutputFormat.Mp4:
                    args.Add("-c:v"); args.Add("libx264");
                    args.Add("-c:a"); args.Add("aac");
                    if (!string.IsNullOrWhiteSpace(o.VideoResolution))
                    { args.Add("-s"); args.Add(o.VideoResolution); }
                    break;
                case OutputFormat.Webm:
                    args.Add("-c:v"); args.Add("libvpx-vp9");
                    args.Add("-c:a"); args.Add("libopus");
                    if (!string.IsNullOrWhiteSpace(o.VideoResolution))
                    { args.Add("-s"); args.Add(o.VideoResolution); }
                    break;
            }

            if (!string.IsNullOrWhiteSpace(o.ExtraOutputArgs))
                args.Add(o.ExtraOutputArgs);

            args.Add(output);
            return args;
        }

        private static string FormatTime(TimeSpan t) =>
            $"{(int)t.TotalHours:D2}:{t.Minutes:D2}:{t.Seconds:D2}.{t.Milliseconds / 10:D2}";

        // -------------------------------------------------------------------
        // Process execution (mirrors SafeProcessLauncher's safety pattern)
        // -------------------------------------------------------------------

        private string? ResolveFFmpegPath()
        {
            var path = _settings.FFmpegPath;
            if (string.IsNullOrWhiteSpace(path)) return null;
            if (File.Exists(path)) return Path.GetFullPath(path);
            if (Directory.Exists(path))
            {
                var exe = Path.Combine(path, "ffmpeg.exe");
                if (File.Exists(exe)) return Path.GetFullPath(exe);
            }
            _logger.LogWarning("Configured FFmpeg path does not exist: {Path}", path);
            return null;
        }

        /// <summary>
        /// Mirrors <see cref="Security.Process.SafeProcessLauncher"/>'s private
        /// <c>QuoteArgument</c>. Kept in sync so both code paths offer the same
        /// injection resistance.
        /// </summary>
        private static string QuoteArgument(string arg)
        {
            if (arg.Length == 0) return "\"\"";
            if (arg.IndexOfAny(new[] { ' ', '\t', '"', '\\' }) < 0) return arg;
            var sb = new StringBuilder(arg.Length + 2);
            sb.Append('"');
            for (int i = 0; i < arg.Length; i++)
            {
                int backslashes = 0;
                while (i < arg.Length && arg[i] == '\\') { backslashes++; i++; }
                if (i == arg.Length)
                    sb.Append('\\', backslashes * 2);
                else if (arg[i] == '"')
                    sb.Append('\\', backslashes * 2 + 1).Append('"');
                else
                    sb.Append('\\', backslashes).Append(arg[i]);
            }
            sb.Append('"');
            return sb.ToString();
        }

        private static string BuildArgString(IReadOnlyList<string> args)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < args.Count; i++)
            {
                if (sb.Length > 0) sb.Append(' ');
                sb.Append(QuoteArgument(args[i]));
            }
            return sb.ToString();
        }

        private async Task<(int exit, string stdout, string stderr)> RunCaptureAsync(
            string fileName, IReadOnlyList<string> args, TimeSpan timeout, CancellationToken ct)
        {
            var psi = new ProcessStartInfo
            {
                FileName = fileName,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8
            };
            psi.Arguments = BuildArgString(args);

            using var proc = new Process { StartInfo = psi };
            var stdout = new StringBuilder();
            var stderr = new StringBuilder();
            proc.OutputDataReceived += (_, e) => { if (e.Data != null) stdout.AppendLine(e.Data); };
            proc.ErrorDataReceived += (_, e) => { if (e.Data != null) stderr.AppendLine(e.Data); };

            if (!proc.Start()) throw new InvalidOperationException("Failed to start: " + fileName);
            proc.BeginOutputReadLine();
            proc.BeginErrorReadLine();

            using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            cts.CancelAfter(timeout);
            try
            {
                while (!proc.HasExited)
                {
                    if (cts.IsCancellationRequested) { TryKill(proc); break; }
                    try { await Task.Delay(150, cts.Token); }
                    catch (TaskCanceledException) { TryKill(proc); break; }
                }
            }
            catch (OperationCanceledException) { TryKill(proc); throw; }

            if (!proc.HasExited) TryKill(proc);
            try { proc.WaitForExit(2000); } catch { /* best-effort */ }
            if (ct.IsCancellationRequested) ct.ThrowIfCancellationRequested();
            return (proc.ExitCode, stdout.ToString(), stderr.ToString());
        }

        private async Task<int> RunWithProgressAsync(
            string fileName, IReadOnlyList<string> args,
            TimeSpan totalDuration, IProgress<int>? progress, CancellationToken ct)
        {
            var psi = new ProcessStartInfo
            {
                FileName = fileName,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8
            };
            psi.Arguments = BuildArgString(args);

            // FFmpeg writes its progress to stderr. We parse the time= field
            // and convert to a 0–100 percentage based on the probed duration.
            // If duration is unknown we report 0 until completion, then 100.
            double totalSeconds = totalDuration > TimeSpan.Zero ? totalDuration.TotalSeconds : 0;

            using var proc = new Process { StartInfo = psi };
            proc.ErrorDataReceived += (_, e) =>
            {
                if (e.Data == null) return;
                var m = ProgressRegex.Match(e.Data);
                if (m.Success && m.Groups.Count >= 4
                    && int.TryParse(m.Groups[1].Value, out var hh)
                    && int.TryParse(m.Groups[2].Value, out var mm)
                    && double.TryParse(m.Groups[3].Value,
                        System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out var ss))
                {
                    var elapsed = hh * 3600 + mm * 60 + ss;
                    if (totalSeconds > 0)
                    {
                        int pct = (int)((elapsed / totalSeconds * 100.0 < 0) ? 0 : ((elapsed / totalSeconds * 100.0 > 99) ? 99 : elapsed / totalSeconds * 100.0));
                        try { progress?.Report(pct); } catch { /* ignore */ }
                    }
                }
            };

            if (!proc.Start()) throw new InvalidOperationException("Failed to start: " + fileName);
            proc.BeginOutputReadLine();
            proc.BeginErrorReadLine();

            while (!proc.HasExited)
            {
                if (ct.IsCancellationRequested)
                {
                    TryKill(proc);
                    ct.ThrowIfCancellationRequested();
                }
                try { await Task.Delay(250, ct); }
                catch (OperationCanceledException)
                {
                    TryKill(proc);
                    throw;
                }
            }

            if (proc.ExitCode == 0)
            {
                try { progress?.Report(100); } catch { /* ignore */ }
            }
            return proc.ExitCode;
        }

        private async Task<TimeSpan> ProbeDurationAsync(
            string ffmpeg, string input, CancellationToken ct)
        {
            try
            {
                // FFmpeg prints "Duration: HH:MM:SS.ss" on stderr. We pass -i
                // without an output, so FFmpeg will exit non-zero (no output
                // specified) but still emit the input metadata we want.
                var (_, stdout, stderr) = await RunCaptureAsync(
                    ffmpeg, new[] { "-i", input }, TimeSpan.FromSeconds(15), ct);
                var combined = stdout + "\n" + stderr;
                var m = DurationRegex.Match(combined);
                if (m.Success && m.Groups.Count >= 4
                    && int.TryParse(m.Groups[1].Value, out var hh)
                    && int.TryParse(m.Groups[2].Value, out var mm)
                    && double.TryParse(m.Groups[3].Value,
                        System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out var ss))
                {
                    return TimeSpan.FromSeconds(hh * 3600 + mm * 60 + ss);
                }
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "FFmpeg duration probe failed for {Input}", input);
            }
            return TimeSpan.Zero;
        }

        private static void TryKill(Process proc)
        {
            try { if (!proc.HasExited) proc.Kill(); } catch { /* best-effort */ }
        }

        private static void TryDelete(string path)
        {
            try { if (File.Exists(path)) File.Delete(path); } catch { /* best-effort */ }
        }
    }
}
