using System;

namespace SawanDownloadPro.Media.FFmpeg
{
    /// <summary>
    /// Options for an FFmpeg conversion. All fields are optional; null/zero
    /// values are passed through to FFmpeg as "let it decide" defaults.
    /// </summary>
    public sealed class ConversionOptions
    {
        /// <summary>Target container/codec family. Default <c>mp3</c>.</summary>
        public OutputFormat OutputFormat { get; set; } = OutputFormat.Mp3;

        /// <summary>
        /// Audio bitrate in kbps. If <c>null</c>, FFmpeg uses its codec default.
        /// </summary>
        public int? AudioBitrateKbps { get; set; }

        /// <summary>
        /// Target video resolution as <c>WIDTHxHEIGHT</c> (e.g. <c>1280x720</c>),
        /// or <c>null</c> to keep source resolution. Ignored for audio-only
        /// output formats.
        /// </summary>
        public string? VideoResolution { get; set; }

        /// <summary>
        /// Optional trim start. If set, the output begins at this offset.
        /// </summary>
        public TimeSpan? TrimStart { get; set; }

        /// <summary>
        /// Optional trim end. If set, the output ends at this offset. Both
        /// <see cref="TrimStart"/> and <see cref="TrimEnd"/> must be set for
        /// a trim range to be applied.
        /// </summary>
        public TimeSpan? TrimEnd { get; set; }

        /// <summary>
        /// Optional additional FFmpeg arguments, appended verbatim BEFORE the
        /// <c>-i</c> input. Use sparingly; unsafe values are NOT sanitized by
        /// <see cref="FFmpegRunner"/> and the caller is responsible for their
        /// safety.
        /// </summary>
        public string? ExtraInputArgs { get; set; }

        /// <summary>
        /// Optional additional FFmpeg arguments, appended verbatim AFTER the
        /// output path. Use sparingly.
        /// </summary>
        public string? ExtraOutputArgs { get; set; }
    }

    /// <summary>
    /// Target output format. The string value is the file extension and the
    /// FFmpeg <c>-f</c> muxer name.
    /// </summary>
    public enum OutputFormat
    {
        Mp3 = 0,
        Aac = 1,
        Mp4 = 2,
        Webm = 3,
        Wav = 4,
        Flac = 5,
        Ogg = 6
    }

    internal static class OutputFormatExtensions
    {
        public static string Extension(this OutputFormat f) => f switch
        {
            OutputFormat.Mp3 => "mp3",
            OutputFormat.Aac => "m4a",
            OutputFormat.Mp4 => "mp4",
            OutputFormat.Webm => "webm",
            OutputFormat.Wav => "wav",
            OutputFormat.Flac => "flac",
            OutputFormat.Ogg => "ogg",
            _ => "mp3"
        };

        public static bool IsAudioOnly(this OutputFormat f) =>
            f == OutputFormat.Mp3 || f == OutputFormat.Aac ||
            f == OutputFormat.Wav || f == OutputFormat.Flac ||
            f == OutputFormat.Ogg;
    }
}
