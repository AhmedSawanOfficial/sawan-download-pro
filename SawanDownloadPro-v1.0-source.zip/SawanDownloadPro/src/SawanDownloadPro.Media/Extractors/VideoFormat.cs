namespace SawanDownloadPro.Media.Extractors
{
    /// <summary>
    /// A single downloadable format for a media URL. Modeled after the
    /// <c>format</c> object yt-dlp emits, but generic enough for any source.
    /// </summary>
    public sealed class VideoFormat
    {
        /// <summary>
        /// Source-specific format identifier (e.g. yt-dlp's <c>format_id</c>).
        /// Passed back to the extractor when downloading.
        /// </summary>
        public string FormatId { get; set; } = string.Empty;

        /// <summary>Container/codec extension: <c>mp4</c>, <c>webm</c>, <c>m4a</c>, <c>mp3</c>, etc.</summary>
        public string Extension { get; set; } = "mp4";

        /// <summary>Human-readable resolution label, e.g. <c>1080p60</c>.</summary>
        public string Resolution { get; set; } = string.Empty;

        /// <summary>Video height in pixels, or 0 if audio-only.</summary>
        public int Height { get; set; }

        /// <summary>Video width in pixels, or 0 if audio-only.</summary>
        public int Width { get; set; }

        /// <summary>Frames per second, or 0 if unknown / audio-only.</summary>
        public int Fps { get; set; }

        /// <summary>
        /// Estimated file size in bytes, or <c>null</c> if the source does not
        /// report it. The UI shows "unknown" when this is null.
        /// </summary>
        public long? FileSizeBytes { get; set; }

        /// <summary><c>true</c> if this format contains an audio stream.</summary>
        public bool HasAudio { get; set; }

        /// <summary><c>true</c> if this format contains a video stream.</summary>
        public bool HasVideo { get; set; }

        /// <summary>
        /// Audio bitrate in kbps, or <c>null</c> for video-only / unknown.
        /// </summary>
        public int? BitrateKbps { get; set; }

        /// <summary>Short label suitable for a UI dropdown.</summary>
        public string DisplayLabel
        {
            get
            {
                if (HasVideo && HasAudio)
                    return string.IsNullOrEmpty(Resolution)
                        ? $"{Extension.ToUpperInvariant()} (av)"
                        : $"{Resolution} ({Extension})";
                if (HasVideo)
                    return string.IsNullOrEmpty(Resolution)
                        ? $"{Extension.ToUpperInvariant()} (video)"
                        : $"{Resolution} ({Extension}, no audio)";
                return BitrateKbps.HasValue
                    ? $"{Extension.ToUpperInvariant()} {BitrateKbps.Value} kbps"
                    : $"{Extension.ToUpperInvariant()} (audio)";
            }
        }
    }
}
