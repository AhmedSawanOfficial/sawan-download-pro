using System;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Models;
using SawanDownloadPro.Security.Process;

namespace SawanDownloadPro.Media.Extractors
{
    /// <summary>
    /// Holds the registered extractors and resolves a URL to the first
    /// <see cref="IVideoExtractor"/> whose <see cref="IVideoExtractor.CanHandle"/>
    /// returns <c>true</c>. If none matches, returns the
    /// <see cref="UnsupportedSourceExtractor"/> fallback so the UI can always
    /// present a clear diagnostic.
    /// </summary>
    public sealed class VideoExtractorRegistry
    {
        private readonly UnsupportedSourceExtractor _fallback;
        private readonly List<IVideoExtractor> _extractors;

        /// <summary>
        /// Creates a registry pre-populated with the default extractor set.
        /// The fallback is always <see cref="UnsupportedSourceExtractor"/> and
        /// is consulted only if no other extractor claims the URL.
        /// </summary>
        public static VideoExtractorRegistry CreateDefault(
            AppSettings appSettings,
            ILoggerFactory loggerFactory,
            SafeProcessLauncher safeProcessLauncher)
        {
            if (appSettings == null) throw new ArgumentNullException(nameof(appSettings));
            if (loggerFactory == null) throw new ArgumentNullException(nameof(loggerFactory));
            if (safeProcessLauncher == null) throw new ArgumentNullException(nameof(safeProcessLauncher));

            var yt = new YouTubeExtractor(
                appSettings,
                safeProcessLauncher,
                loggerFactory.CreateLogger<YouTubeExtractor>());

            var fb = new FacebookExtractor(loggerFactory.CreateLogger<FacebookExtractor>());
            var tt = new TikTokExtractor(loggerFactory.CreateLogger<TikTokExtractor>());
            var unsupported = new UnsupportedSourceExtractor(
                loggerFactory.CreateLogger<UnsupportedSourceExtractor>());

            return new VideoExtractorRegistry(yt, fb, tt, unsupported);
        }

        public VideoExtractorRegistry(params IVideoExtractor[] extractors)
        {
            if (extractors == null || extractors.Length == 0)
                throw new ArgumentException("At least one extractor is required.", nameof(extractors));

            var last = extractors[extractors.Length - 1];
            _fallback = last as UnsupportedSourceExtractor
                ?? throw new ArgumentException(
                    "The last extractor must be an UnsupportedSourceExtractor fallback.",
                    nameof(extractors));

            _extractors = new List<IVideoExtractor>(extractors);
        }

        /// <summary>
        /// All registered extractors in resolution order (fallback is last).
        /// </summary>
        public IReadOnlyList<IVideoExtractor> All => _extractors;

        /// <summary>
        /// The fallback extractor used when no other extractor claims a URL.
        /// </summary>
        public UnsupportedSourceExtractor Fallback => _fallback;

        /// <summary>
        /// Returns the first extractor whose <see cref="IVideoExtractor.CanHandle"/>
        /// matches <paramref name="url"/>. If none matches, returns the
        /// <see cref="UnsupportedSourceExtractor"/> fallback.
        /// </summary>
        public IVideoExtractor FindExtractor(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return _fallback;
            for (int i = 0; i < _extractors.Count - 1; i++)
            {
                try
                {
                    if (_extractors[i].CanHandle(url)) return _extractors[i];
                }
                catch (Exception)
                {
                    // Be defensive: a misbehaving extractor must not crash the registry.
                    continue;
                }
            }
            return _fallback;
        }
    }
}
