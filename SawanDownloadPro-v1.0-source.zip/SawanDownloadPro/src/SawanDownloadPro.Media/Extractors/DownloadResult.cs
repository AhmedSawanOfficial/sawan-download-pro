namespace SawanDownloadPro.Media.Extractors
{
    /// <summary>
    /// Result of a download operation. Always returned (never thrown) so the
    /// caller can present a clean diagnostic to the user.
    /// </summary>
    public sealed class DownloadResult
    {
        /// <summary><c>true</c> if the file was fully downloaded and finalized.</summary>
        public bool Success { get; set; }

        /// <summary>
        /// Absolute path to the finalized file. May be a partial file if
        /// <see cref="Success"/> is <c>false</c> and the operation was
        /// cancelled mid-stream.
        /// </summary>
        public string? FinalFilePath { get; set; }

        /// <summary>
        /// Human-readable error message. Empty when <see cref="Success"/> is
        /// <c>true</c>.
        /// </summary>
        public string ErrorMessage { get; set; } = string.Empty;

        public static DownloadResult Ok(string path) => new() { Success = true, FinalFilePath = path };

        public static DownloadResult Fail(string error, string? partialPath = null) =>
            new() { Success = false, ErrorMessage = error ?? string.Empty, FinalFilePath = partialPath };
    }
}
