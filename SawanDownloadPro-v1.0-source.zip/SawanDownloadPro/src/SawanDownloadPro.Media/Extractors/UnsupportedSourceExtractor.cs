using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace SawanDownloadPro.Media.Extractors
{
    /// <summary>
    /// Fallback extractor that handles any URL the other extractors do not
    /// explicitly support. Always returns a clear "unsupported source" error
    /// with concrete suggestions; never silently fails.
    /// </summary>
    public sealed class UnsupportedSourceExtractor : IVideoExtractor
    {
        private readonly ILogger _logger;

        public UnsupportedSourceExtractor(ILogger<UnsupportedSourceExtractor> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <inheritdoc/>
        public string DisplayName => "Unsupported source";

        /// <inheritdoc/>
        public string[] SupportedHosts => Array.Empty<string>();

        /// <inheritdoc/>
        public string Limitations =>
            "This source is not supported by Sawan Download Pro's media downloader. " +
            "Use the regular download dialog for direct file URLs (http/https/ftp).";

        /// <inheritdoc/>
        public bool CanHandle(string url) => true; // catch-all

        /// <inheritdoc/>
        public Task<VideoInfo> ProbeAsync(string url, CancellationToken ct)
        {
            _logger.LogInformation("UnsupportedSourceExtractor probe for {Url}", url);
            var info = new VideoInfo
            {
                SourceUrl = url ?? string.Empty,
                ExtractorName = DisplayName,
                ErrorMessage =
                    "This source is not supported by the media downloader.\n\n" +
                    "What you can do instead:\n" +
                    "  • If the URL points directly to a media file (e.g. ends in .mp4, " +
                    ".mp3, .zip), close this dialog and use Add Download instead — " +
                    "Sawan Download Pro will download it as a regular file.\n" +
                    "  • For YouTube videos, paste the YouTube URL here. Make sure " +
                    "yt-dlp is configured in Settings → Media.\n" +
                    "  • For Facebook and TikTok, this application does not perform " +
                    "downloads because those platforms restrict automated access. " +
                    "Use the platform's official save feature instead.\n" +
                    "  • For other streaming sites, check the project roadmap — " +
                    "additional extractors may be added in future versions."
            };
            return Task.FromResult(info);
        }

        /// <inheritdoc/>
        public Task<DownloadResult> DownloadAsync(
            string url, VideoFormat selectedFormat, string savePath,
            IProgress<int>? progress, CancellationToken ct)
        {
            var result = DownloadResult.Fail(
                "Unsupported source. Sawan Download Pro's media downloader only " +
                "supports YouTube via a user-supplied yt-dlp binary. For direct " +
                "file URLs (http/https/ftp), close this dialog and use Add Download.");
            return Task.FromResult(result);
        }
    }
}
