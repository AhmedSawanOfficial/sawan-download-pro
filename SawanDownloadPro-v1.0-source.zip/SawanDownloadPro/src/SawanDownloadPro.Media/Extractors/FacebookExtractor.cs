using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Models;

namespace SawanDownloadPro.Media.Extractors
{
    /// <summary>
    /// Facebook extractor — INTENTIONAL STUB.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Facebook's terms of service and technical measures place significant
    /// restrictions on automated media access. Most Facebook video content is
    /// either private, shared with a limited audience, gated behind login, or
    /// embedded in private groups. Sawan Download Pro will NOT:
    /// </para>
    /// <list type="bullet">
    ///   <item>Bypass Facebook login.</item>
    ///   <item>Extract media from private groups the user is not a member of.</item>
    ///   <item>Strip DRM from Facebook Watch paid content.</item>
    ///   <item>Use cookies or session tokens harvested from the user's browser
    ///         to impersonate the user against Facebook.</item>
    /// </list>
    /// <para>
    /// <see cref="CanHandle"/> returns <c>true</c> for facebook.com URLs so the
    /// UI can present a clear, source-specific explanation rather than the
    /// generic "unsupported source" message. The probe returns a
    /// <see cref="VideoInfo"/> whose <see cref="VideoInfo.ErrorMessage"/>
    /// explains the situation.
    /// </para>
    /// </remarks>
    public sealed class FacebookExtractor : IVideoExtractor
    {
        private static readonly string[] Hosts =
        {
            "facebook.com", "www.facebook.com", "m.facebook.com",
            "fb.com", "fb.watch"
        };

        private readonly ILogger _logger;

        public FacebookExtractor(ILogger<FacebookExtractor> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <inheritdoc/>
        public string DisplayName => "Facebook";

        /// <inheritdoc/>
        public string[] SupportedHosts => Hosts;

        /// <inheritdoc/>
        public string Limitations =>
            "Stub implementation. Does NOT bypass Facebook login, private-group " +
            "restrictions, or DRM. Only public videos that the user is authorized " +
            "to download are conceptually supported; in practice this stub returns " +
            "a clear explanation and does not perform any download. Use Facebook's " +
            "official 'Save video' feature for content you have permission to keep.";

        /// <inheritdoc/>
        public bool CanHandle(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return false;
            if (!Uri.TryCreate(url.Trim(), UriKind.Absolute, out var uri)) return false;
            if (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps) return false;
            foreach (var h in Hosts)
                if (uri.Host.EndsWith(h, StringComparison.OrdinalIgnoreCase))
                    return true;
            return false;
        }

        /// <inheritdoc/>
        public Task<VideoInfo> ProbeAsync(string url, CancellationToken ct)
        {
            _logger.LogInformation("FacebookExtractor stub probe for {Url}", url);
            var info = new VideoInfo
            {
                SourceUrl = url,
                ExtractorName = DisplayName,
                ErrorMessage =
                    "Facebook restricts media downloads. Sawan Download Pro only supports " +
                    "public videos you are explicitly authorized to download, and this " +
                    "stub extractor does not perform the download. " +
                    "It does NOT bypass login, private-group restrictions, or DRM. " +
                    "To save a Facebook video you have permission to keep, use Facebook's " +
                    "official 'Save video' feature, or contact the video's author for " +
                    "an authorized copy."
            };
            return Task.FromResult(info);
        }

        /// <inheritdoc/>
        public Task<DownloadResult> DownloadAsync(
            string url, VideoFormat selectedFormat, string savePath,
            IProgress<int>? progress, CancellationToken ct)
        {
            var result = DownloadResult.Fail(
                "Facebook downloads are not supported by this stub extractor. " +
                "The application does not bypass Facebook login, private-group " +
                "restrictions, or DRM. Use Facebook's official 'Save video' feature " +
                "for content you have permission to keep.");
            return Task.FromResult(result);
        }
    }
}
