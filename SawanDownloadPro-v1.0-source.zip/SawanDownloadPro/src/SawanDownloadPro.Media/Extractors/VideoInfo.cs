using System;
using System.Collections.Generic;

namespace SawanDownloadPro.Media.Extractors
{
    /// <summary>
    /// Metadata about a media URL, as reported by an <see cref="IVideoExtractor"/>.
    /// </summary>
    public sealed class VideoInfo
    {
        /// <summary>Video title as published by the source (may be empty).</summary>
        public string Title { get; set; } = string.Empty;

        /// <summary>Direct URL to a thumbnail image, if the source exposes one.</summary>
        public string? ThumbnailUrl { get; set; }

        /// <summary>Total duration. <c>null</c> if unknown (e.g. live streams).</summary>
        public TimeSpan? Duration { get; set; }

        /// <summary>Author/uploader/channel name, if exposed.</summary>
        public string? Author { get; set; }

        /// <summary>Upload date in UTC, if exposed.</summary>
        public DateTime? UploadDate { get; set; }

        /// <summary>
        /// Formats available for download. May be empty if the extractor cannot
        /// enumerate formats (e.g. stub extractors).
        /// </summary>
        public List<VideoFormat> AvailableFormats { get; set; } = new();

        /// <summary>
        /// The source URL that was probed.
        /// </summary>
        public string SourceUrl { get; set; } = string.Empty;

        /// <summary>
        /// Display name of the extractor that produced this info.
        /// </summary>
        public string ExtractorName { get; set; } = string.Empty;

        /// <summary>
        /// If non-null, probing failed and this is the human-readable reason.
        /// When set, <see cref="AvailableFormats"/> is guaranteed empty.
        /// </summary>
        public string? ErrorMessage { get; set; }

        /// <summary>Returns <c>true</c> if probing failed.</summary>
        public bool HasError => !string.IsNullOrEmpty(ErrorMessage);
    }
}
