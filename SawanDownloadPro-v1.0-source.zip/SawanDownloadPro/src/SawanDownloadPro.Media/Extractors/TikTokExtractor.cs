using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace SawanDownloadPro.Media.Extractors
{
    /// <summary>
    /// TikTok extractor — INTENTIONAL STUB that only supports the user's OWN
    /// content.
    /// </summary>
    /// <remarks>
    /// <para>
    /// TikTok's terms of service generally prohibit automated downloads of
    /// third-party content, and TikTok videos typically carry a visible
    /// watermark identifying the original creator. Sawan Download Pro will:
    /// </para>
    /// <list type="bullet">
    ///   <item>NOT strip watermarks from third-party content.</item>
    ///   <item>NOT bypass TikTok's login or anti-scraping measures.</item>
    ///   <item>NOT download content the user does not own or have explicit
    ///         permission to download.</item>
    /// </list>
    /// <para>
    /// Watermark-free downloads are only attempted when the authorized official
    /// source (e.g. TikTok's creator download endpoint, where the user is the
    /// creator) provides one. This stub returns a clear explanation rather
    /// than performing any download, because verifying creator ownership is
    /// outside the scope of an offline extractor.
    /// </para>
    /// </remarks>
    public sealed class TikTokExtractor : IVideoExtractor
    {
        private static readonly string[] Hosts =
        {
            "tiktok.com", "www.tiktok.com", "vm.tiktok.com",
            "vt.tiktok.com"
        };

        private readonly ILogger _logger;

        public TikTokExtractor(ILogger<TikTokExtractor> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <inheritdoc/>
        public string DisplayName => "TikTok";

        /// <inheritdoc/>
        public string[] SupportedHosts => Hosts;

        /// <inheritdoc/>
        public string Limitations =>
            "Stub implementation. Supports the user's OWN content only. " +
            "Watermark-free downloads are only attempted when the authorized official " +
            "source provides one. Does NOT strip watermarks from third-party content, " +
            "does NOT bypass login or anti-scraping. To download your own TikToks " +
            "without a watermark, use TikTok's official app download feature while " +
            "signed in as the creator.";

        /// <inheritdoc/>
        public bool CanHandle(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return false;
            if (!Uri.TryCreate(url.Trim(), UriKind.Absolute, out var uri)) return false;
            if (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps) return false;
            foreach (var h in Hosts)
                if (uri.Host.EndsWith(h, StringComparison.OrdinalIgnoreCase))
                    return true;
            return false;
        }

        /// <inheritdoc/>
        public Task<VideoInfo> ProbeAsync(string url, CancellationToken ct)
        {
            _logger.LogInformation("TikTokExtractor stub probe for {Url}", url);
            var info = new VideoInfo
            {
                SourceUrl = url,
                ExtractorName = DisplayName,
                ErrorMessage =
                    "TikTok downloads are restricted. Sawan Download Pro supports only " +
                    "the user's OWN content, and only attempts watermark-free downloads " +
                    "when the authorized official source provides one. This stub does " +
                    "NOT strip watermarks from third-party content, does NOT bypass " +
                    "login or anti-scraping, and does NOT verify creator ownership. " +
                    "To download your own TikToks without a watermark, use TikTok's " +
                    "official in-app download feature while signed in as the creator."
            };
            return Task.FromResult(info);
        }

        /// <inheritdoc/>
        public Task<DownloadResult> DownloadAsync(
            string url, VideoFormat selectedFormat, string savePath,
            IProgress<int>? progress, CancellationToken ct)
        {
            var result = DownloadResult.Fail(
                "TikTok downloads are not supported by this stub extractor. " +
                "The application only supports the user's OWN content and does NOT " +
                "strip watermarks from third-party content. Use TikTok's official " +
                "in-app download feature for content you own.");
            return Task.FromResult(result);
        }
    }
}
