using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;
using SawanDownloadPro.Security.Process;

namespace SawanDownloadPro.Media.Extractors
{
    /// <summary>
    /// YouTube extractor that invokes an external <c>yt-dlp.exe</c> binary the
    /// USER supplies. Sawan Download Pro NEVER bundles yt-dlp.
    /// </summary>
    /// <remarks>
    /// <para><b>Authorization and legal.</b> This extractor is provided solely
    /// to download content that the user is authorized to download and that
    /// the source platform's terms of service permit. The user is responsible
    /// for compliance with YouTube's Terms of Service and with applicable
    /// copyright law in their jurisdiction.</para>
    /// <para><b>DRM.</b> DRM-protected content (e.g. YouTube Premium music
    /// videos, paid movies, paid live streams) cannot and will not be
    /// downloaded. yt-dlp itself refuses such content; this extractor reports
    /// the refusal verbatim.</para>
    /// <para><b>Volatility.</b> YouTube changes its player API frequently. The
    /// extractor may break at any time; when it does, the user should update
    /// yt-dlp (<c>yt-dlp -U</c> or reinstall) and try again.</para>
    /// </remarks>
    public sealed class YouTubeExtractor : IVideoExtractor
    {
        private const string NotConfiguredMessage =
            "FFmpeg/yt-dlp path not configured. Open Settings → Media to configure.";

        private static readonly string[] Hosts =
        {
            "youtube.com", "www.youtube.com", "m.youtube.com",
            "youtu.be", "music.youtube.com"
        };

        private readonly AppSettings _settings;
        private readonly SafeProcessLauncher _launcher;
        private readonly ILogger _logger;

        public YouTubeExtractor(AppSettings settings, SafeProcessLauncher launcher, ILogger<YouTubeExtractor> logger)
        {
            _settings = settings ?? throw new ArgumentNullException(nameof(settings));
            _launcher = launcher ?? throw new ArgumentNullException(nameof(launcher));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <inheritdoc/>
        public string DisplayName => "YouTube";

        /// <inheritdoc/>
        public string[] SupportedHosts => Hosts;

        /// <inheritdoc/>
        public string Limitations =>
            "Downloads only content you are authorized to download and that YouTube's ToS " +
            "permits. DRM-protected content (Premium music videos, paid movies, paid live " +
            "streams) is NOT supported. The extractor may break at any time if YouTube " +
            "changes its API; update yt-dlp and retry. Sawan Download Pro does not bundle " +
            "yt-dlp — you must obtain and configure it yourself.";

        /// <inheritdoc/>
        public bool CanHandle(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return false;
            return Uri.TryCreate(url.Trim(), UriKind.Absolute, out var uri)
                   && (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps)
                   && HostMatch(uri.Host);
        }

        private static bool HostMatch(string host)
        {
            foreach (var h in Hosts)
                if (string.Equals(h, host, StringComparison.OrdinalIgnoreCase))
                    return true;
            return false;
        }

        /// <inheritdoc/>
        public async Task<VideoInfo> ProbeAsync(string url, CancellationToken ct)
        {
            var ytdlp = ResolveYtDlpPath();
            if (ytdlp == null)
                return ErrorInfo(url, NotConfiguredMessage);

            // Verify the binary is runnable via SafeProcessLauncher (which also
            // exercises the safe argument-quoting path). A failed probe here
            // gives the user a much clearer error than a cryptic -J failure.
            var runnable = VerifyYtDlpBinary(ytdlp);
            if (runnable == null)
                return ErrorInfo(url, NotConfiguredMessage);
            if (runnable == false)
                return ErrorInfo(url,
                    "The configured yt-dlp binary could not be launched. The file exists " +
                    "but does not run with --version. It may be the wrong architecture " +
                    "(e.g. a 64-bit yt-dlp on 32-bit Windows), corrupted, or blocked by " +
                    "antivirus. Re-download yt-dlp from https://github.com/yt-dlp/yt-dlp/releases " +
                    "and replace the file at: " + ytdlp);

            // Probe with -J (dump single JSON) — wait synchronously, capture stdout.
            // We pass --no-playlist so a single video returns a single JSON object
            // rather than an array. We do NOT pass --cookies or any credential; the
            // user is responsible for the binary's authentication state, if any.
            var args = new[]
            {
                "--no-playlist",
                "--no-warnings",
                "--no-call-home",
                "--no-check-certificate", // do not abort on cert issues; user's responsibility
                "-J",
                url
            };

            string json;
            try
            {
                json = await RunCaptureAsync(ytdlp, args, TimeSpan.FromMinutes(2), ct);
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "yt-dlp probe failed for {Url}", url);
                return ErrorInfo(url,
                    "yt-dlp could not probe this URL. The video may be private, age-restricted " +
                    "(requires login that this extractor will not perform), removed, or the URL " +
                    "may be invalid. Update yt-dlp and try again. Underlying error: "
                    + ex.Message);
            }

            return ParseProbeJson(json, url);
        }

        /// <inheritdoc/>
        public async Task<DownloadResult> DownloadAsync(
            string url, VideoFormat selectedFormat, string savePath,
            IProgress<int>? progress, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(savePath))
                return DownloadResult.Fail("Save path is required.");

            var ytdlp = ResolveYtDlpPath();
            if (ytdlp == null)
                return DownloadResult.Fail(NotConfiguredMessage);

            if (selectedFormat == null || string.IsNullOrEmpty(selectedFormat.FormatId))
                return DownloadResult.Fail("No format selected. Probe the URL first.");

            var dir = Path.GetDirectoryName(savePath);
            if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir))
                return DownloadResult.Fail($"Output directory does not exist: {dir}");

            // yt-dlp output template: write directly to savePath. We use -o with the
            // full path and a placeholder extension so yt-dlp merges into the chosen
            // extension. We pass --no-part so the final file lands at savePath exactly.
            // merge-output-format defaults to mkv for separate audio+video; if user
            // picked an mp4 format we ask for mp4 merge.
            var ext = !string.IsNullOrEmpty(selectedFormat.Extension)
                ? selectedFormat.Extension
                : Path.GetExtension(savePath).TrimStart('.');

            var template = Path.ChangeExtension(savePath, null) + ".%(ext)s";
            var ffmpegPath = ResolveFFmpegPath();
            var argList = new List<string>
            {
                "--no-playlist",
                "--no-warnings",
                "--no-call-home",
                "--no-part",
                "--newline",                       // flush per-line progress to stdout
                "--progress",                      // human-readable progress lines
                "-f", selectedFormat.FormatId,
                "-o", template,
                "--merge-output-format", ext
            };
            if (!string.IsNullOrEmpty(ffmpegPath))
            {
                argList.Add("--ffmpeg-location");
                argList.Add(ffmpegPath);
            }
            argList.Add(url);

            try
            {
                int exit = await RunStreamProgressAsync(
                    ytdlp, argList, savePath, ext, progress, ct);
                if (exit != 0)
                {
                    var partial = File.Exists(savePath) ? savePath : null;
                    return DownloadResult.Fail(
                        $"yt-dlp exited with code {exit}. The video may be DRM-protected, " +
                        "private, age-restricted, or removed. Update yt-dlp and retry.",
                        partial);
                }

                // yt-dlp may have produced savePath with the real extension. Resolve.
                var finalPath = ResolveFinalPath(savePath, ext);
                if (finalPath == null || !File.Exists(finalPath))
                    return DownloadResult.Fail(
                        "yt-dlp exited successfully but no output file was found at " + savePath);

                return DownloadResult.Ok(finalPath);
            }
            catch (OperationCanceledException)
            {
                var partial = File.Exists(savePath) ? savePath : null;
                return DownloadResult.Fail("Download cancelled by user.", partial);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "yt-dlp download failed for {Url}", url);
                var partial = File.Exists(savePath) ? savePath : null;
                return DownloadResult.Fail("yt-dlp download failed: " + ex.Message, partial);
            }
        }

        // -------------------------------------------------------------------
        // Helpers
        // -------------------------------------------------------------------

        private string? ResolveYtDlpPath()
        {
            var path = _settings.YtDlpPath;
            if (string.IsNullOrWhiteSpace(path)) return null;
            if (!File.Exists(path))
            {
                _logger.LogWarning("Configured yt-dlp path does not exist: {Path}", path);
                return null;
            }
            return Path.GetFullPath(path);
        }

        private string? ResolveFFmpegPath()
        {
            var path = _settings.FFmpegPath;
            if (string.IsNullOrWhiteSpace(path)) return null;
            // FFmpegPath may point to ffmpeg.exe directly or to a folder containing it.
            if (File.Exists(path)) return Path.GetFullPath(path);
            if (Directory.Exists(path))
            {
                var exe = Path.Combine(path, "ffmpeg.exe");
                if (File.Exists(exe)) return Path.GetFullPath(exe);
            }
            return null;
        }

        private VideoInfo ErrorInfo(string url, string error) => new()
        {
            SourceUrl = url,
            ExtractorName = DisplayName,
            ErrorMessage = error
        };

        /// <summary>
        /// Verifies that the configured yt-dlp binary can be launched and exits
        /// cleanly when asked for its version. Uses
        /// <see cref="SafeProcessLauncher"/> directly so that the binary is
        /// invoked through the same safe argument-quoting and no-shell path
        /// as every other process launch in the app. Returns <c>null</c> if
        /// the binary is missing or <c>false</c> if it exits non-zero.
        /// </summary>
        private bool? VerifyYtDlpBinary(string path)
        {
            try
            {
                int exit = _launcher.Run(path, new[] { "--version" }, waitForExit: true, timeoutMs: 8000);
                return exit == 0;
            }
            catch (FileNotFoundException) { return null; }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "yt-dlp version probe failed for {Path}", path);
                return false;
            }
        }

        /// <summary>
        /// Mirrors <see cref="SafeProcessLauncher"/>'s private
        /// <c>QuoteArgument</c> for the cases where we need to capture stdout
        /// or stream progress (the public <see cref="ISafeProcessLauncher"/>
        /// interface does not expose stdout). The algorithm is identical so
        /// both code paths offer the same injection resistance.
        /// </summary>
        private static string QuoteArgument(string arg)
        {
            if (arg.Length == 0) return "\"\"";
            if (arg.IndexOfAny(new[] { ' ', '\t', '"', '\\' }) < 0) return arg;
            var sb = new StringBuilder(arg.Length + 2);
            sb.Append('"');
            for (int i = 0; i < arg.Length; i++)
            {
                int backslashes = 0;
                while (i < arg.Length && arg[i] == '\\') { backslashes++; i++; }
                if (i == arg.Length)
                    sb.Append('\\', backslashes * 2);
                else if (arg[i] == '"')
                    sb.Append('\\', backslashes * 2 + 1).Append('"');
                else
                    sb.Append('\\', backslashes).Append(arg[i]);
            }
            sb.Append('"');
            return sb.ToString();
        }

        /// <summary>
        /// Runs the binary synchronously, captures stdout (used for
        /// <c>yt-dlp -J</c>). Uses the same safety pattern as
        /// <see cref="SafeProcessLauncher"/>: <c>UseShellExecute=false</c>,
        /// <c>CreateNoWindow=true</c>, manually-quoted arguments.
        /// </summary>
        private async Task<string> RunCaptureAsync(
            string fileName, IReadOnlyList<string> args, TimeSpan timeout, CancellationToken ct)
        {
            var psi = new ProcessStartInfo
            {
                FileName = fileName,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8
            };
            var sb = new StringBuilder();
            for (int i = 0; i < args.Count; i++)
            {
                if (sb.Length > 0) sb.Append(' ');
                sb.Append(QuoteArgument(args[i]));
            }
            psi.Arguments = sb.ToString();

            using var proc = new Process { StartInfo = psi };
            var stdout = new StringBuilder();
            var stderr = new StringBuilder();
            proc.OutputDataReceived += (_, e) => { if (e.Data != null) stdout.AppendLine(e.Data); };
            proc.ErrorDataReceived += (_, e) => { if (e.Data != null) stderr.AppendLine(e.Data); };

            if (!proc.Start()) throw new InvalidOperationException("Failed to start: " + fileName);
            proc.BeginOutputReadLine();
            proc.BeginErrorReadLine();

            // Await either process exit, cancellation, or timeout.
            using (var cts = CancellationTokenSource.CreateLinkedTokenSource(ct))
            {
                cts.CancelAfter(timeout);
                try
                {
                    while (!proc.HasExited)
                    {
                        if (cts.IsCancellationRequested)
                        {
                            TryKill(proc);
                            break;
                        }
                        try { await Task.Delay(200, cts.Token); }
                        catch (TaskCanceledException) { TryKill(proc); break; }
                    }
                }
                catch (OperationCanceledException) { TryKill(proc); throw; }
            }

            if (!proc.HasExited) TryKill(proc);
            try { proc.WaitForExit(2000); } catch { /* best-effort */ }

            if (ct.IsCancellationRequested) ct.ThrowIfCancellationRequested();
            if (proc.ExitCode != 0)
            {
                throw new InvalidOperationException(
                    $"yt-dlp exited with code {proc.ExitCode}. stderr: {stderr}");
            }
            return stdout.ToString();
        }

        /// <summary>
        /// Runs the binary with streaming progress reporting. Parses yt-dlp's
        /// <c>[download] xx.x% of ...</c> lines into 0–100 percent.
        /// </summary>
        private async Task<int> RunStreamProgressAsync(
            string fileName, IReadOnlyList<string> args, string savePath,
            string expectedExt, IProgress<int>? progress, CancellationToken ct)
        {
            var psi = new ProcessStartInfo
            {
                FileName = fileName,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8
            };
            var sb = new StringBuilder();
            for (int i = 0; i < args.Count; i++)
            {
                if (sb.Length > 0) sb.Append(' ');
                sb.Append(QuoteArgument(args[i]));
            }
            psi.Arguments = sb.ToString();

            // [download]  23.4% of 12.34MiB at 1.23MiB/s ETA 00:05
            var progressRegex = new Regex(
                @"\[download\]\s+([0-9]+(?:\.[0-9]+)?)%",
                RegexOptions.Compiled);

            using var proc = new Process { StartInfo = psi };
            proc.OutputDataReceived += (_, e) =>
            {
                if (e.Data == null) return;
                var m = progressRegex.Match(e.Data);
                if (m.Success && double.TryParse(m.Groups[1].Value, out var pct))
                {
                    int pctInt = (int)((Math.Round(pct) < 0) ? 0 : ((Math.Round(pct) > 100) ? 100 : Math.Round(pct)));
                    try { progress?.Report(pctInt); } catch { /* ignore */ }
                }
            };
            // yt-dlp writes most diagnostics to stderr; swallow to keep the
            // console clean — the exit code is the source of truth.

            if (!proc.Start()) throw new InvalidOperationException("Failed to start: " + fileName);
            proc.BeginOutputReadLine();
            proc.BeginErrorReadLine();

            while (!proc.HasExited)
            {
                if (ct.IsCancellationRequested)
                {
                    TryKill(proc);
                    ct.ThrowIfCancellationRequested();
                }
                try { await Task.Delay(250, ct); }
                catch (OperationCanceledException)
                {
                    TryKill(proc);
                    throw;
                }
            }
            return proc.ExitCode;
        }

        private static void TryKill(Process proc)
        {
            try { if (!proc.HasExited) proc.Kill(); } catch { /* best-effort */ }
        }

        private static string? ResolveFinalPath(string savePath, string ext)
        {
            // yt-dlp writes to <basename>.<ext>. If the caller's savePath already
            // has the right extension, the file lands there; otherwise we resolve
            // the produced file.
            if (File.Exists(savePath)) return savePath;
            var noExt = Path.ChangeExtension(savePath, null);
            var candidate = noExt + "." + ext;
            if (File.Exists(candidate)) return candidate;
            // Last resort: any file matching <basename>.* in the same directory.
            var dir = Path.GetDirectoryName(savePath);
            var baseName = Path.GetFileNameWithoutExtension(savePath);
            if (!string.IsNullOrEmpty(dir) && !string.IsNullOrEmpty(baseName))
            {
                var matches = Directory.GetFiles(dir, baseName + ".*");
                if (matches.Length > 0) return matches[0];
            }
            return null;
        }

        // -------------------------------------------------------------------
        // JSON parsing — yt-dlp -J emits a single JSON object per video.
        // -------------------------------------------------------------------

        private VideoInfo ParseProbeJson(string json, string url)
        {
            if (string.IsNullOrWhiteSpace(json))
                return ErrorInfo(url, "yt-dlp returned empty output. Update yt-dlp and retry.");

            var ser = new JavaScriptSerializer { MaxJsonLength = 1 << 24 };
            Dictionary<string, object>? root;
            try
            {
                root = ser.Deserialize<Dictionary<string, object>>(json);
            }
            catch (Exception ex)
            {
                return ErrorInfo(url, "Could not parse yt-dlp output. The video may be private, removed, or DRM-protected. Error: " + ex.Message);
            }

            if (root == null)
                return ErrorInfo(url, "yt-dlp returned no parseable data. The video may be private or removed.");

            var info = new VideoInfo
            {
                SourceUrl = url,
                ExtractorName = DisplayName,
                Title = AsString(root, "title"),
                ThumbnailUrl = AsString(root, "thumbnail"),
                Author = AsString(root, "uploader") ?? AsString(root, "channel"),
            };

            if (long.TryParse(AsString(root, "duration"), out var durSec) && durSec > 0)
                info.Duration = TimeSpan.FromSeconds(durSec);

            var uploadStr = AsString(root, "upload_date"); // YYYYMMDD
            if (!string.IsNullOrEmpty(uploadStr) && uploadStr.Length == 8
                && DateTime.TryParseExact(uploadStr, "yyyyMMdd",
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.AssumeUniversal,
                    out var upload))
                info.UploadDate = upload;

            // Formats: yt-dlp emits either "formats" (array) or a single "format_id".
            if (root.TryGetValue("formats", out var fmtObj) && fmtObj is IEnumerable<object> fmtList)
            {
                foreach (var item in fmtList)
                {
                    if (item is not Dictionary<string, object> f) continue;
                    info.AvailableFormats.Add(ParseFormat(f));
                }
            }
            else if (!string.IsNullOrEmpty(AsString(root, "format_id")))
            {
                info.AvailableFormats.Add(ParseFormat(root));
            }

            // Heuristic: if no formats were emitted, the video is almost certainly
            // DRM-protected, members-only, or live.
            if (info.AvailableFormats.Count == 0)
            {
                info.ErrorMessage =
                    "yt-dlp returned no downloadable formats. The video may be " +
                    "DRM-protected, members-only, an active live stream, or removed. " +
                    "This extractor will not bypass DRM or login requirements.";
            }

            return info;
        }

        private static VideoFormat ParseFormat(Dictionary<string, object> f)
        {
            var fmt = new VideoFormat
            {
                FormatId = AsString(f, "format_id") ?? string.Empty,
                Extension = AsString(f, "ext") ?? "mp4",
                Resolution = AsString(f, "format_note") ?? AsString(f, "resolution") ?? string.Empty,
            };
            if (int.TryParse(AsString(f, "width"), out var w)) fmt.Width = w;
            if (int.TryParse(AsString(f, "height"), out var h)) fmt.Height = h;
            if (int.TryParse(AsString(f, "fps"), out var fps)) fmt.Fps = fps;
            if (long.TryParse(AsString(f, "filesize"), out var fs) && fs > 0) fmt.FileSizeBytes = fs;
            else if (long.TryParse(AsString(f, "filesize_approx"), out var fsa) && fsa > 0) fmt.FileSizeBytes = fsa;

            // vcodec=none => audio-only; acodec=none => video-only.
            var vcodec = AsString(f, "vcodec");
            var acodec = AsString(f, "acodec");
            fmt.HasVideo = !string.IsNullOrEmpty(vcodec) && vcodec != "none";
            fmt.HasAudio = !string.IsNullOrEmpty(acodec) && acodec != "none";

            if (int.TryParse(AsString(f, "abr"), out var abr)) fmt.BitrateKbps = abr;
            else if (int.TryParse(AsString(f, "tbr"), out var tbr)) fmt.BitrateKbps = tbr;

            // Compose a friendly resolution label if yt-dlp didn't give us one.
            if (string.IsNullOrEmpty(fmt.Resolution) && fmt.HasVideo && fmt.Height > 0)
                fmt.Resolution = fmt.Fps > 0 ? $"{fmt.Height}p{fmt.Fps}" : $"{fmt.Height}p";

            return fmt;
        }

        private static string? AsString(Dictionary<string, object> d, string key)
        {
            if (d.TryGetValue(key, out var v) && v != null) return v.ToString();
            return null;
        }
    }
}
