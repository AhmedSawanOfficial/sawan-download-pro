using System;
using System.Threading;
using System.Threading.Tasks;

namespace SawanDownloadPro.Media.Extractors
{
    /// <summary>
    /// Abstraction for a site-specific media extractor. Implementations MUST be
    /// fail-safe: a URL that cannot be handled must return a clear error rather
    /// than silently misbehaving, and every implementation MUST document what it
    /// cannot do via <see cref="Limitations"/>.
    /// </summary>
    /// <remarks>
    /// Implementations MUST NOT bundle third-party binaries (e.g. yt-dlp, FFmpeg).
    /// They MAY invoke such binaries if the user has explicitly configured their
    /// location in <c>AppSettings</c>, and MUST report a clear configuration
    /// error if the binary is missing.
    /// </remarks>
    public interface IVideoExtractor
    {
        /// <summary>
        /// Display name shown in the UI (e.g. "YouTube").
        /// </summary>
        string DisplayName { get; }

        /// <summary>
        /// Hosts this extractor is willing to attempt (e.g. "youtube.com",
        /// "youtu.be"). Used only for diagnostics; <see cref="CanHandle"/>
        /// is the authoritative check.
        /// </summary>
        string[] SupportedHosts { get; }

        /// <summary>
        /// Plain-text description of what this extractor CANNOT do — for example,
        /// "Does not download DRM-protected content" or "Cannot bypass login
        /// walls". This string is shown to the user verbatim.
        /// </summary>
        string Limitations { get; }

        /// <summary>
        /// Returns <c>true</c> if this extractor is willing to attempt the URL.
        /// This is a cheap host check; the actual extraction may still fail.
        /// </summary>
        bool CanHandle(string url);

        /// <summary>
        /// Probes the URL and returns metadata (title, thumbnail, duration,
        /// available formats) WITHOUT downloading the media. Implementations
        /// SHOULD fail fast and return a <see cref="VideoInfo"/> whose
        /// <see cref="VideoInfo.ErrorMessage"/> is set on failure rather than
        /// throwing, so the UI can present a clean diagnostic.
        /// </summary>
        Task<VideoInfo> ProbeAsync(string url, CancellationToken ct);

        /// <summary>
        /// Downloads the selected format to <paramref name="savePath"/>. The
        /// caller is responsible for ensuring the directory exists and that
        /// <paramref name="savePath"/> has been sanitized.
        /// </summary>
        /// <param name="url">Source URL.</param>
        /// <param name="selectedFormat">Format chosen by the user.</param>
        /// <param name="savePath">Absolute file path to write to.</param>
        /// <param name="progress">Optional progress reporter (0–100 percent).</param>
        /// <param name="ct">Cancellation token (pause/cancel).</param>
        Task<DownloadResult> DownloadAsync(
            string url,
            VideoFormat selectedFormat,
            string savePath,
            IProgress<int>? progress,
            CancellationToken ct);
    }
}
