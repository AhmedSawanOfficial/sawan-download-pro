using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Interfaces;

namespace SawanDownloadPro.Security.Process
{
    /// <summary>
    /// Safe process launcher that never uses UseShellExecute with untrusted input, escapes
    /// arguments via quoted ProcessStartInfo.ArgumentList, and blocks dangerous patterns.
    /// </summary>
    public sealed class SafeProcessLauncher : ISafeProcessLauncher
    {
        private readonly ILogger _logger;

        public SafeProcessLauncher(ILogger logger) => _logger = logger;

        public int Run(string fileName, IEnumerable<string> arguments, bool waitForExit = false, int timeoutMs = 30000)
        {
            if (string.IsNullOrWhiteSpace(fileName))
                throw new ArgumentException("fileName is required", nameof(fileName));
            if (!File.Exists(fileName))
                throw new FileNotFoundException($"External executable not found: {fileName}");

            var psi = new ProcessStartInfo
            {
                FileName = fileName,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            foreach (var a in arguments ?? Enumerable.Empty<string>())
            {
                // .NET Framework 4.8 does not expose ProcessStartInfo.ArgumentList (added in .NET 5).
                // We must manually quote. The safe form for Windows is: double-quote, double internal quotes.
                psi.Arguments += (psi.Arguments.Length > 0 ? " " : "") + QuoteArgument(a);
            }

            _logger.LogInformation("Launching process: {File} {Args}", fileName, psi.Arguments);

            using var proc = new System.Diagnostics.Process { StartInfo = psi };
            if (!proc.Start()) throw new InvalidOperationException("Failed to start process: " + fileName);

            if (!waitForExit) return proc.Id;

            if (!proc.WaitForExit(timeoutMs))
            {
                try { proc.Kill(); } catch { /* best-effort */ }
                throw new TimeoutException($"Process {fileName} did not exit within {timeoutMs}ms");
            }
            return proc.ExitCode;
        }

        private static string QuoteArgument(string arg)
        {
            if (arg.Length == 0) return "\"\"";
            if (arg.IndexOfAny(new[] { ' ', '\t', '"', '\\' }) < 0) return arg;
            var sb = new StringBuilder(arg.Length + 2);
            sb.Append('"');
            for (int i = 0; i < arg.Length; i++)
            {
                char c = arg[i];
                int backslashes = 0;
                while (i < arg.Length && arg[i] == '\\') { backslashes++; i++; }
                if (i == arg.Length)
                {
                    sb.Append('\\', backslashes * 2);
                }
                else if (arg[i] == '"')
                {
                    sb.Append('\\', backslashes * 2 + 1).Append('"');
                }
                else
                {
                    sb.Append('\\', backslashes).Append(arg[i]);
                }
            }
            sb.Append('"');
            return sb.ToString();
        }

        public bool TryOpenInDefaultApplication(string filePath)
        {
            if (!File.Exists(filePath)) return false;
            try
            {
                System.Diagnostics.Process.Start(new ProcessStartInfo(filePath) { UseShellExecute = true });
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Could not open {Path} in default application", filePath);
                return false;
            }
        }

        public bool TryOpenContainingFolder(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    System.Diagnostics.Process.Start("explorer.exe", "/select,\"" + filePath + "\"");
                    return true;
                }
                if (Directory.Exists(filePath))
                {
                    System.Diagnostics.Process.Start("explorer.exe", "\"" + filePath + "\"");
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Could not open folder for {Path}", filePath);
                return false;
            }
        }
    }

    /// <summary>
    /// DPAPI-based secret protector. Per-user, per-machine encryption. No key material is
    /// ever persisted by the application itself.
    /// </summary>
    public sealed class DpapiSecretProtector : ISecretProtector
    {
        public byte[] Protect(string plaintext)
        {
            if (string.IsNullOrEmpty(plaintext)) return Array.Empty<byte>();
            var bytes = Encoding.UTF8.GetBytes(plaintext);
            return ProtectedData.Protect(bytes, null, DataProtectionScope.CurrentUser);
        }

        public string Unprotect(byte[] encrypted)
        {
            if (encrypted == null || encrypted.Length == 0) return string.Empty;
            var bytes = ProtectedData.Unprotect(encrypted, null, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(bytes);
        }
    }
}
