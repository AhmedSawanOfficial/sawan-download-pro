using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using SawanDownloadPro.Core.Exceptions;
using SawanDownloadPro.Core.Interfaces;

namespace SawanDownloadPro.Security.Validation
{
    /// <summary>
    /// Path sanitizer that prevents path traversal, normalizes Windows paths, and flags
    /// dangerous file extensions.
    /// </summary>
    public sealed class PathSanitizer : IPathSanitizer
    {
        // Extensions that may execute code on Windows. We do not refuse them, but the UI warns.
        private static readonly string[] DangerousExtensions =
        {
            ".exe", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jse", ".wsf",
            ".wsh", ".msc", ".msi", ".scr", ".com", ".pif", ".jar", ".lnk",
            ".reg", ".inf", ".hta", ".cpl", ".vb", ".vbe"
        };

        private static readonly char[] InvalidFileNameChars = Path.GetInvalidFileNameChars();
        private static readonly Regex RelativeTraversal = new(@"(\.\.[\\/])|(\.[\\/])", RegexOptions.Compiled);

        private readonly ILogger _logger;

        public PathSanitizer(ILogger logger) => _logger = logger;

        public string SanitizeFileName(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                throw new UnsafePathException("Filename is empty.");

            // Strip control chars.
            var sb = new StringBuilder(input.Length);
            foreach (var c in input)
            {
                if (char.IsControl(c)) continue;
                sb.Append(c);
            }
            var s = sb.ToString();

            // Remove any path-separator sequences (filename only).
            s = s.Replace('/', '_').Replace('\\', '_');

            // Replace invalid filename chars.
            foreach (var c in InvalidFileNameChars) s = s.Replace(c, '_');

            // Collapse multiple underscores.
            s = Regex.Replace(s, "_{2,}", "_").Trim(' ', '.');

            // Reserved Windows names.
            var reserved = new[] { "CON", "PRN", "AUX", "NUL",
                "COM1","COM2","COM3","COM4","COM5","COM6","COM7","COM8","COM9",
                "LPT1","LPT2","LPT3","LPT4","LPT5","LPT6","LPT7","LPT8","LPT9" };
            var stem = Path.GetFileNameWithoutExtension(s).ToUpperInvariant();
            if (reserved.Contains(stem)) s = "sawan_" + s;

            if (string.IsNullOrWhiteSpace(s)) s = "sawan_download";
            if (s.Length > 200) s = s.Substring(0, 200);

            return s;
        }

        public string SanitizeAndCombinePath(string directory, string fileName)
        {
            if (string.IsNullOrWhiteSpace(directory))
                throw new UnsafePathException("Destination directory is empty.");
            if (string.IsNullOrWhiteSpace(fileName))
                throw new UnsafePathException("Filename is empty.");

            var safe = SanitizeFileName(fileName);

            // Reject anything that survived as a traversal pattern.
            if (RelativeTraversal.IsMatch(safe) || RelativeTraversal.IsMatch(directory))
                throw new UnsafePathException("Path traversal detected.");

            // Normalize directory.
            var full = Path.GetFullPath(Path.Combine(directory, safe));

            // Verify the result is still inside the requested directory.
            var normalizedDir = Path.GetFullPath(directory.TrimEnd('\\') + "\\");
            if (!full.StartsWith(normalizedDir, StringComparison.OrdinalIgnoreCase))
                throw new UnsafePathException("Combined path escapes destination directory.");

            return full;
        }

        public bool IsPathSafe(string absolutePath, string rootDirectory)
        {
            if (string.IsNullOrWhiteSpace(absolutePath) || string.IsNullOrWhiteSpace(rootDirectory)) return false;
            try
            {
                var full = Path.GetFullPath(absolutePath);
                var root = Path.GetFullPath(rootDirectory.TrimEnd('\\') + "\\");
                return full.StartsWith(root, StringComparison.OrdinalIgnoreCase);
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Path safety check failed for {Path}", absolutePath);
                return false;
            }
        }

        public bool IsDangerousExtension(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName)) return false;
            var ext = Path.GetExtension(fileName).ToLowerInvariant();
            return DangerousExtensions.Contains(ext);
        }
    }

    /// <summary>
    /// URL validator with scheme allow-list and length limits.
    /// </summary>
    public sealed class UrlValidator : IUrlValidator
    {
        private static readonly string[] AllowedSchemes = { "http", "https", "ftp" };
        private const int MaxUrlLength = 8192;

        public bool IsValid(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return false;
            if (url.Length > MaxUrlLength) return false;
            if (Uri.TryCreate(url, UriKind.Absolute, out var uri))
            {
                return IsSchemeAllowed(url) && !string.IsNullOrWhiteSpace(uri.Host);
            }
            return false;
        }

        public bool IsSchemeAllowed(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return false;
            var colon = url.IndexOf(':');
            if (colon <= 0) return false;
            var scheme = url.Substring(0, colon).ToLowerInvariant();
            return AllowedSchemes.Contains(scheme);
        }

        public Uri? NormalizeOrNull(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return null;
            var trimmed = url.Trim();
            if (!trimmed.Contains("://"))
            {
                // Best-effort: assume http if the user pasted a bare domain.
                if (Uri.TryCreate("https://" + trimmed, UriKind.Absolute, out var prepended)) return prepended;
            }
            return Uri.TryCreate(trimmed, UriKind.Absolute, out var uri) ? uri : null;
        }
    }
}
