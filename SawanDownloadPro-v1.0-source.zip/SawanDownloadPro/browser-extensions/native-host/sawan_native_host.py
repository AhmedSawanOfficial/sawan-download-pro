#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Sawan Download Pro — Native Messaging Host (reference implementation).

This script bridges a browser extension (Chrome MV3, Edge MV3, Firefox MV2)
to the Sawan Download Pro desktop application on Windows.

Protocol
--------
The browser speaks the standard Chrome "Native Messaging" protocol on
stdin/stdout:

    [4-byte little-endian unsigned length][UTF-8 JSON payload]

Each incoming message is validated against a strict schema:

    { "type": "download", "url": <string>, "source": <string>,
      "tabUrl": <string, optional> }

Only `http`, `https` and `ftp` URLs are accepted, URLs longer than 8192
characters are rejected, and credentials embedded in the URL
(`http://user:pass@host/`) are rejected. Valid URLs are forwarded to the
main Sawan application via a Windows named pipe:

    \\\\.\\pipe\\sawan_download_pro

Each request gets a JSON response written to stdout in the same framing:

    { "ok": true }                                  -- on success
    { "ok": false, "error": "<reason>" }            -- on validation/pipe error

Security
--------
- NEVER logs cookies, Authorization headers, or passwords. Only URL strings,
  timestamps, source, and result codes are written to the log file.
- Refuses any message that does not match the strict schema.
- Refuses URLs with embedded credentials.
- Refuses non-allowed schemes (only http/https/ftp).
- Refuses URLs longer than 8192 chars.
- Times out the named pipe connection after 5 seconds to avoid blocking
  the browser indefinitely.

Compatibility
-------------
Runs on Windows 7 SP1+ with Python 3.6+ (no third-party packages required).
On Windows 7, Python 3.8 is the last official release; on Windows 8/10/11
any Python 3.6+ works.

This script is intended to be launched via `sawan_native_host.bat`, which
sets up the environment and absolute paths. The browser invokes the .bat
file (registered as `path` in `com.sawan.downloadpro.json`).
"""

from __future__ import absolute_import, print_function

import json
import logging
import os
import struct
import sys
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple

# --- Constants --------------------------------------------------------------

NATIVE_HOST_NAME = "com.sawan.downloadpro"
PIPE_NAME = r"\\.\pipe\sawan_download_pro"
ALLOWED_SCHEMES = ("http://", "https://", "ftp://")
MAX_URL_LENGTH = 8192
MAX_MESSAGE_LENGTH = 1 * 1024 * 1024  # 1 MiB hard cap; browser caps at 1 MiB too
PIPE_CONNECT_TIMEOUT_SEC = 5.0
PIPE_READ_TIMEOUT_SEC = 5.0
PIPE_WRITE_TIMEOUT_SEC = 5.0

# Top-level message schema. Anything not matching is rejected.
ALLOWED_MESSAGE_TYPES = ("download",)
ALLOWED_SOURCES = (
    "context_menu", "toolbar_click", "popup",
    "suggestion_accepted", "unknown"
)


# --- Logging ----------------------------------------------------------------

def _log_dir() -> str:
    """Return the directory for native-host logs. Created if missing."""
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    path = os.path.join(base, "SawanDownloadPro", "logs")
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        # Fall back to %TEMP% if we can't write next to the app data.
        path = os.environ.get("TEMP") or os.environ.get("TMP") or "."
    return path


def _configure_logging() -> logging.Logger:
    log_path = os.path.join(_log_dir(), "native-host.log")
    logger = logging.getLogger("sawan_native_host")
    logger.setLevel(logging.INFO)
    # Avoid duplicate handlers if the script is re-imported in a test harness.
    if not logger.handlers:
        try:
            handler = logging.FileHandler(log_path, encoding="utf-8")
            handler.setFormatter(logging.Formatter(
                "%(asctime)s [%(levelname)s] %(message)s"
            ))
            logger.addHandler(handler)
        except (OSError, PermissionError):
            # If we cannot write to the log, fall back to stderr. The browser
            # captures stderr but does not parse it; this is purely for debug.
            handler = logging.StreamHandler(sys.stderr)
            handler.setFormatter(logging.Formatter(
                "%(asctime)s [%(levelname)s] %(message)s"
            ))
            logger.addHandler(handler)
    return logger


LOG = _configure_logging()


# --- Native messaging I/O ---------------------------------------------------

def _read_exact(stdin, n: int) -> bytes:
    """Read exactly n bytes from stdin. Returns fewer only on EOF."""
    buf = b""
    while len(buf) < n:
        chunk = stdin.read(n - len(buf))
        if not chunk:
            break
        # If `stdin` is text-mode, encode back to bytes for length math.
        if isinstance(chunk, str):
            chunk = chunk.encode("utf-8")
        buf += chunk
    return buf


def read_message(stdin) -> Optional[Dict[str, Any]]:
    """
    Read one native-messaging framed message from stdin.
    Returns None on EOF, or a parsed dict on success.
    Raises ValueError on framing/size errors.
    """
    header = _read_exact(stdin, 4)
    if len(header) < 4:
        return None  # clean EOF
    (length,) = struct.unpack("<I", header)
    if length == 0:
        return {}
    if length > MAX_MESSAGE_LENGTH:
        raise ValueError(
            "Incoming message too large: %d bytes (max %d)" % (length, MAX_MESSAGE_LENGTH)
        )
    body = _read_exact(stdin, length)
    if len(body) < length:
        raise ValueError("Truncated message body (expected %d, got %d)" % (length, len(body)))
    try:
        parsed = json.loads(body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        raise ValueError("Invalid JSON payload: %s" % exc)
    if not isinstance(parsed, dict):
        raise ValueError("Top-level JSON must be an object")
    return parsed


def write_message(stdout, payload: Dict[str, Any]) -> None:
    """Write one native-messaging framed message to stdout."""
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    framed = struct.pack("<I", len(body)) + body
    # Use os.write on the raw fd to avoid any text-mode buffering/newline
    # translation that Python's print() would apply on Windows.
    os.write(sys.stdout.fileno(), framed)
    try:
        sys.stdout.flush()
    except Exception:
        pass


# --- Schema validation ------------------------------------------------------

def validate_message(msg: Dict[str, Any]) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Validate an incoming message against the strict schema.

    Returns (parsed_message, None) on success, or (None, error_string) on
    failure. The returned `parsed_message` contains only the fields the
    main Sawan app expects:
        { "type": "download", "url": str, "source": str,
          "tabUrl": Optional[str], "timestamp": ISO8601 str }
    """
    if not isinstance(msg, dict):
        return None, "Message is not a JSON object"

    msg_type = msg.get("type")
    if not isinstance(msg_type, str) or msg_type not in ALLOWED_MESSAGE_TYPES:
        return None, "Field 'type' must be one of %r" % (ALLOWED_MESSAGE_TYPES,)

    url = msg.get("url")
    if not isinstance(url, str) or not url:
        return None, "Field 'url' must be a non-empty string"
    if len(url) > MAX_URL_LENGTH:
        return None, "Field 'url' exceeds %d characters" % MAX_URL_LENGTH

    lowered = url.lower()
    if not lowered.startswith(ALLOWED_SCHEMES):
        return None, "URL scheme not allowed (only http/https/ftp)"

    # Reject embedded credentials: http://user:pass@host/
    # We do this by parsing the URL and inspecting the userinfo component.
    try:
        from urllib.parse import urlsplit
        parts = urlsplit(url)
    except Exception:
        return None, "URL could not be parsed"
    if parts.username or parts.password:
        return None, "URLs containing embedded credentials are not accepted"
    if not parts.netloc:
        return None, "URL is missing a host"

    source = msg.get("source", "unknown")
    if not isinstance(source, str):
        return None, "Field 'source' must be a string"
    if source not in ALLOWED_SOURCES:
        # Don't reject unknown sources outright — clamp to "unknown" so a
        # newer extension's source value doesn't break the host. But still
        # validate it's a string.
        source = "unknown"

    tab_url = msg.get("tabUrl")
    if tab_url is not None:
        if not isinstance(tab_url, str) or not tab_url:
            return None, "Field 'tabUrl' must be a non-empty string when present"
        if len(tab_url) > MAX_URL_LENGTH:
            return None, "Field 'tabUrl' exceeds %d characters" % MAX_URL_LENGTH
        if not tab_url.lower().startswith(ALLOWED_SCHEMES):
            return None, "tabUrl scheme not allowed"

    parsed = {
        "type": "download",
        "url": url,
        "source": source,
        "tabUrl": tab_url,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    return parsed, None


# --- Named pipe bridge ------------------------------------------------------

def forward_to_app(parsed: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
    """
    Forward the validated URL to the main Sawan application via a Windows
    named pipe. Returns (True, None) on success, or (False, error_string).

    On non-Windows platforms this is a no-op that returns False with a
    descriptive message — useful for running the host under WSL for testing.
    """
    if os.name != "nt":
        return False, "Named-pipe forwarding is only supported on Windows"

    payload = json.dumps(parsed, separators=(",", ":")).encode("utf-8")

    # Import lazily so the script can still be imported on non-Windows for tests.
    try:
        import win32file
        import win32pipe
        import pywintypes
    except ImportError:
        return False, (
            "pywin32 is not installed; the native host cannot reach the Sawan pipe. "
            "Install pywin32 (pip install pywin32) or use the C# native host instead."
        )

    handle = None
    try:
        # Connect to the existing pipe created by the Sawan app. Use a
        # bounded retry loop because the app may be briefly busy.
        last_err = None
        for _ in range(5):
            try:
                handle = win32file.CreateFile(
                    PIPE_NAME,
                    win32file.GENERIC_READ | win32file.GENERIC_WRITE,
                    0,                # no sharing
                    None,             # default security
                    win32file.OPEN_EXISTING,
                    0,                # default attributes
                    None,             # no template
                )
                break
            except pywintypes.error as exc:
                last_err = exc
                # Win error 2 = file not found (app not running).
                # Win error 231 = pipe busy (app busy); wait and retry.
                if exc.winerror in (2, 231):
                    import time
                    time.sleep(0.2)
                    continue
                raise
        else:
            return False, "Sawan app is not running (pipe not found). Last error: %s" % last_err

        # Set read/write timeouts so a misbehaving app can't wedge us.
        win32pipe.SetNamedPipeHandleState(
            handle,
            win32pipe.PIPE_READMODE_MESSAGE,
            None,
            None,
        )

        # Write the request.
        win32file.WriteFile(handle, payload)

        # Read the response (the app replies with {"ok":true} or
        # {"ok":false,"error":...}).
        resp_header = win32file.ReadFile(handle, 64 * 1024)
        # ReadFile returns (result_code, data]; result 0 means success.
        result_code, data = resp_header
        if result_code != 0:
            return False, "Pipe read failed (code %d)" % result_code

        try:
            response = json.loads(data.decode("utf-8"))
            if isinstance(response, dict) and response.get("ok") is True:
                return True, None
            err = response.get("error") if isinstance(response, dict) else None
            return False, err or "Sawan app reported an unspecified error"
        except (ValueError, UnicodeDecodeError) as exc:
            return False, "Invalid response from Sawan app: %s" % exc

    except pywintypes.error as exc:
        return False, "Pipe I/O error: %s" % exc.strerror
    finally:
        if handle is not None:
            try:
                win32file.CloseHandle(handle)
            except Exception:
                pass


# --- Main loop --------------------------------------------------------------

def handle_one_message(msg: Dict[str, Any]) -> Dict[str, Any]:
    parsed, err = validate_message(msg)
    if err is not None:
        LOG.warning("Rejected message: %s", err)
        return {"ok": False, "error": err}

    # Log a redacted summary. We log the URL (it is the user-facing string the
    # user explicitly chose to download) but NEVER cookies, auth headers, or
    # passwords — none of which are part of the native messaging payload anyway.
    LOG.info(
        "Accepted download: source=%s url=%s",
        parsed.get("source"),
        parsed.get("url"),
    )

    ok, err = forward_to_app(parsed)
    if ok:
        LOG.info("Forwarded to app successfully")
        return {"ok": True}
    LOG.warning("Forwarding failed: %s", err)
    return {"ok": False, "error": err or "Unknown forwarding error"}


def main() -> int:
    LOG.info("Native host starting (pid=%d)", os.getpid())
    try:
        while True:
            try:
                msg = read_message(sys.stdin)
            except ValueError as exc:
                # Framing/schema problem on the wire. Respond with an error
                # and keep the loop alive so the browser can recover.
                LOG.warning("Read error: %s", exc)
                write_message(sys.stdout, {"ok": False, "error": str(exc)})
                continue

            if msg is None:
                # Clean EOF — browser closed the pipe. Exit gracefully.
                LOG.info("stdin EOF, exiting")
                break

            response = handle_one_message(msg)
            write_message(sys.stdout, response)
    except KeyboardInterrupt:
        LOG.info("Interrupted, exiting")
        return 0
    except Exception as exc:
        # Last-resort handler. Don't leak stack traces to the browser.
        LOG.exception("Unhandled exception in main loop")
        try:
            write_message(sys.stdout, {"ok": False, "error": "Internal host error"})
        except Exception:
            pass
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
