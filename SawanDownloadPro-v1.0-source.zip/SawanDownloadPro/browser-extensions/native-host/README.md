# Sawan Download Pro — Native Messaging Host

This directory contains the browser-side bridge that lets the Sawan Download
Pro **extensions** (Chrome MV3, Edge MV3, Firefox MV2) hand URLs to the Sawan
**desktop application**.

```
            ┌──────────────────────┐    stdin/stdout     ┌─────────────────────┐
 Browser ─► │  sawan_native_host   │ ──────────────────► │  Sawan Download Pro │
 extension  │  (.py via .bat)      │     JSON frames     │  (main app, WPF)    │
            └──────────────────────┘                     └─────────────────────┘
                       │                                          ▲
                       └──── writes URL ──► named pipe ──────────┘
                            \\.\pipe\sawan_download_pro
```

The host has two interchangeable implementations:

1. **`sawan_native_host.py`** — a pure-Python reference (Python 3.6+,
   no third-party packages needed on Windows 7 if pywin32 is bundled).
2. **C# `SawanDownloadPro.BrowserIntegration.NativeMessagingHost`** — a
   .NET Framework 4.8 console-app entry point in
   `src/SawanDownloadPro.BrowserIntegration/`. The Sawan installer picks
   one at install time based on whether Python is detected.

Both implementations speak the same wire protocol, so the extensions cannot
tell them apart.

---

## 1. Files in this directory

| File | Purpose |
|---|---|
| `sawan_native_host.py`      | Reference implementation. Reads framed messages from stdin, validates, forwards via named pipe, writes framed responses to stdout. |
| `sawan_native_host.bat`     | Windows launcher. Resolves the Python interpreter path and runs the script with binary stdin/stdout. This is the `path` referenced by the JSON manifest. |
| `com.sawan.downloadpro.json` | Native messaging manifest. **You must customise two fields** before installing — see section 3. |
| `README.md`                 | This file. |

---

## 2. Where the browser looks for the manifest

Each browser scans a different location for the native-messaging manifest JSON.
**All locations use the same JSON file** — copy it (or symlink it) into each.

### Chrome (Windows)

```
HKCU\Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro
        (default) = "C:\Users\<you>\AppData\Local\SawanDownloadPro\native-messaging\com.sawan.downloadpro.json"
```

### Edge (Windows)

```
HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.sawan.downloadpro
        (default) = "C:\Users\<you>\AppData\Local\SawanDownloadPro\native-messaging\com.sawan.downloadpro.json"
```

### Firefox (Windows)

Firefox ignores the registry and scans a well-known folder:

```
%APPDATA%\Mozilla\NativeMessagingHosts\com.sawan.downloadpro.json
```

(The file must be the actual JSON, not a registry pointer.)

The C# `ExtensionInstaller` class (`src/SawanDownloadPro.BrowserIntegration/`)
automates all three: it copies the JSON into `%LOCALAPPDATA%\SawanDownloadPro\native-messaging\`,
then writes the registry values (for Chrome and Edge) or the file (for Firefox).

---

## 3. Customising `com.sawan.downloadpro.json`

Open the file. Two fields need attention:

### `path` (mandatory)

Absolute path to the .bat launcher. The default template ships with:

```jsonc
"path": "C:\\Users\\YOUR_USERNAME\\AppData\\Local\\SawanDownloadPro\\native-host\\sawan_native_host.bat"
```

Replace `YOUR_USERNAME` with the actual Windows username, **or** better,
let the Sawan installer rewrite it via `ExtensionInstaller` so the path
points to the real install location. The path must be absolute; relative
paths are rejected by Chrome/Edge.

### `allowed_origins` and `allowed_extensions`

Both fields can coexist in the same file:

```jsonc
"allowed_origins":   [ "chrome-extension://<EXTENSION_ID>/" ],  // Chrome + Edge
"allowed_extensions": [ "sawan@sawan.example" ]                  // Firefox only
```

#### Obtaining the Chrome / Edge extension ID

The ID is a 32-character lowercase hash (a–p) that Chrome derives from the
extension's public key. There are three ways to discover it:

1. **Load the unpacked extension**, then visit `chrome://extensions`
   (or `edge://extensions`). The ID is shown under the extension name.
2. **Compute it from the public key** (before publishing): if you have a
   `.pem` key, run
   `python -c "import hashlib,sys; print(''.join(chr(97+int(c,16)%16) for c in hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest()[:32]))" key.pem`
3. **For a published extension**, the ID appears in the Web Store /
   Microsoft Store URL.

Replace `<EXTENSION_ID>` with the actual ID. You can list multiple origins
if you ship separate debug/release extensions.

> Firefox's `allowed_extensions` always uses the add-on ID `sawan@sawan.example`
> declared in `firefox/manifest.json`. No customisation needed unless you
> change that ID.

---

## 4. Manual install (per-user, no admin rights required)

The Sawan installer automates this; the manual procedure is for development.

```bat
REM 1. Customise com.sawan.downloadpro.json (path + allowed_origins).
REM 2. Create the native-messaging folder if it does not exist:
mkdir "%LOCALAPPDATA%\SawanDownloadPro\native-messaging"

REM 3. Copy the manifest there:
copy /Y com.sawan.downloadpro.json "%LOCALAPPDATA%\SawanDownloadPro\native-messaging\"

REM 4. Register with Chrome:
reg add "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro" /ve /d "%LOCALAPPDATA%\SawanDownloadPro\native-messaging\com.sawan.downloadpro.json" /f

REM 5. Register with Edge:
reg add "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.sawan.downloadpro" /ve /d "%LOCALAPPDATA%\SawanDownloadPro\native-messaging\com.sawan.downloadpro.json" /f

REM 6. Register with Firefox:
mkdir "%APPDATA%\Mozilla\NativeMessagingHosts"
copy /Y com.sawan.downloadpro.json "%APPDATA%\Mozilla\NativeMessagingHosts\com.sawan.downloadpro.json"

REM 7. Restart the browser. Reload the unpacked extension.
```

To verify the host responds, run it directly (no browser needed):

```bat
REM The host reads 4-byte length + JSON from stdin. This PowerShell one-liner
REM sends a single test message:
powershell -Command "$b=[Text.Encoding]::UTF8.GetBytes('{\"\"type\"\":\"\"download\"\",\"\"url\"\":\"\"https://example.com/test.zip\"\",\"\"source\"\":\"\"manual_test\"\"}'); $len=([BitConverter]::GetBytes([UInt32]$b.Length)); [Console]::OpenStandardInput().Write($len,0,4); [Console]::OpenStandardInput().Write($b,0,$b.Length)" | sawan_native_host.bat
```

(If the Sawan app is not running, the host will respond with
`{"ok":false,"error":"Sawan app is not running (pipe not found)."}`.)

---

## 5. Log file

The host writes a structured log to:

```
%LOCALAPPDATA%\SawanDownloadPro\logs\native-host.log
```

Each line records:

- The PID on startup.
- Each accepted download: `source` and `url`.
- Each rejection: the validation error.
- Each pipe-forwarding outcome.

**The log NEVER contains cookies, `Authorization` headers, or passwords.**
The native messaging protocol does not carry them, and the host explicitly
parses only `url`, `source`, `tabUrl`, and `type`. URLs containing embedded
credentials (`http://user:pass@host/`) are rejected before logging — the URL
itself is not written in that case.

If the log directory is not writable, the host falls back to writing to
`%TEMP%` and then to stderr (which the browser captures but does not parse).

---

## 6. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Browser console: `Native host has not been registered` | Manifest JSON not in the right location, or `path` is wrong | Re-check section 2. Use `reg query` to confirm the registry value. |
| Browser console: `Native host exited` | Python interpreter missing, or the .bat printed to stdout | Verify `sawan_native_host.bat` runs without printing anything before invoking Python. |
| Host responds `Sawan app is not running` | Sawan Download Pro main app is closed | Launch Sawan; the app creates the named pipe on startup. |
| Host responds `pywin32 is not installed` | The reference Python implementation needs pywin32 for pipe I/O | `pip install pywin32`, or use the C# host instead (recommended for production). |
| Host responds `URLs containing embedded credentials are not accepted` | You sent `http://user:pass@host/...` | Re-enter the URL without credentials; Sawan will prompt for HTTP auth itself. |
| Host responds `URL scheme not allowed` | You sent `file://`, `javascript:`, `data:`, etc. | Sawan only accepts `http`, `https`, `ftp`. |

---

## 7. Security considerations

- **Strict schema.** Only `{type:"download", url, source, tabUrl?}` is
  accepted. Any other shape is rejected.
- **Scheme allow-list.** Only `http`/`https`/`ftp`.
- **No embedded credentials.** URLs with `user:pass@` are rejected.
- **Length caps.** URL ≤ 8192 chars; total message ≤ 1 MiB.
- **No logging of secrets.** Only URL strings, source, and outcomes are
  written to the log. Cookies, headers, and form data are not part of the
  native messaging protocol and are never seen by the host.
- **Origin allow-list.** Only extension IDs listed in `allowed_origins`
  (Chrome/Edge) or `allowed_extensions` (Firefox) can invoke the host. A
  malicious extension with a different ID cannot connect.
- **Per-user install.** The manifest lives under `HKCU` (or
  `%APPDATA%`), so installation does not require admin rights. A
  per-machine install under `HKLM` is possible but not recommended;
  `ExtensionInstaller` uses `HKCU` by default.
- **Pipe permissions.** The named pipe `\\.\pipe\sawan_download_pro` is
  created by the Sawan app with a security descriptor that grants access
  only to the current user's SID. Other users on the machine cannot
  connect.

---

## 8. Windows 7 limitation

This host runs on Windows 7 SP1 with **Python 3.8.x** (the last official
Python release for Windows 7). Python ≥ 3.9 dropped Windows 7 support.

The C# host (`SawanDownloadPro.BrowserIntegration`) is the recommended
option for Windows 7 users because .NET Framework 4.8 is fully supported
on Windows 7 SP1 and requires no Python install.

The browser extensions themselves are the limiting factor — see each
extension's README for which browser versions still run on Windows 7.
