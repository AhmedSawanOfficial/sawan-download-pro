@echo off
REM ===========================================================================
REM  Sawan Download Pro — Native Messaging Host launcher
REM  ---------------------------------------------------------------------------
REM  Invoked by Chrome/Edge/Firefox via the path declared in
REM  com.sawan.downloadpro.json. Resolves the absolute path to the Python
REM  interpreter and the host script, then runs the script with stdin/stdout
REM  in binary mode (mandatory for the native messaging protocol).
REM
REM  This .bat is intentionally tiny: it must NOT echo anything to stdout
REM  (any stray output corrupts the native messaging frame). All diagnostics
REM  go to stderr, which the browser captures but does not parse.
REM
REM  The Sawan installer rewrites this file at install time to point at the
REM  bundled Python interpreter. For manual install, edit the two paths below.
REM ===========================================================================

setlocal

REM --- Edit these two paths for manual install --------------------------------
REM   PYTHON_EXE  : absolute path to python.exe (3.6+; 3.8 for Windows 7)
REM   HOST_SCRIPT : absolute path to sawan_native_host.py
set "PYTHON_EXE=%LOCALAPPDATA%\SawanDownloadPro\runtime\python\python.exe"
set "HOST_SCRIPT=%LOCALAPPDATA%\SawanDownloadPro\native-host\sawan_native_host.py"
REM ---------------------------------------------------------------------------

REM  Allow the user to override via environment variables (handy for dev).
if defined SAWAN_PYTHON_EXE  set "PYTHON_EXE=%SAWAN_PYTHON_EXE%"
if defined SAWAN_HOST_SCRIPT set "HOST_SCRIPT=%SAWAN_HOST_SCRIPT%"

REM  If the bundled interpreter is missing, fall back to system PATH lookup.
if not exist "%PYTHON_EXE%" (
  where python >nul 2>nul
  if %errorlevel%==0 (
    set "PYTHON_EXE=python"
  ) else (
    REM  No Python available. Write a structured error to stderr and exit.
    echo [Sawan] Python interpreter not found. Install Python 3.6+ or rerun the Sawan installer. 1>&2
    exit /b 1
  )
)

if not exist "%HOST_SCRIPT%" (
  echo [Sawan] Native host script not found: %HOST_SCRIPT% 1>&2
  exit /b 2
)

REM  Run the host. -u forces unbuffered stdout so framed messages flush
REM  immediately; -B blocks the creation of .pyc files in the user's tree.
"%PYTHON_EXE%" -u -B "%HOST_SCRIPT%"

REM  Pass through the script's exit code.
exit /b %errorlevel%
