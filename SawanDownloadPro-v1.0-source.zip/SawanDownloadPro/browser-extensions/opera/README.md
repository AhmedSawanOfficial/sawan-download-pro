# Sawan Download Pro — Opera Extension (Manifest V3)

Send downloads from Opera to the Sawan Download Pro native Windows
download manager via the standard Native Messaging Host protocol.

| Field | Value |
|---|---|
| Manifest version | 3 |
| Minimum Opera    | 74 (Chromium 88) |
| Native host name | `com.sawan.downloadpro` |
| Permissions      | `contextMenus`, `activeTab`, `nativeMessaging`, `downloads`, `clipboardWrite`, `notifications`, `storage` |
| Host permissions | `<all_urls>` |

> **Note:** This extension is identical to the Chrome MV3 extension.
> Opera has been Chromium-based since Opera 15 (2013) and supports the
> same Manifest V3 service-worker model with the same `chrome.*` APIs.
> The only practical differences are:
>
> 1. Opera scans `HKCU\Software\Google\Chrome\NativeMessagingHosts\`
>    for native-messaging manifests — Opera **shares Chrome's registry
>    path**, so registering the host for Chrome also registers it for
>    Opera. (This is intentional Chromium behaviour: Opera does not
>    ship its own `NativeMessagingHosts` discovery key.)
> 2. Opera's developer-mode "Load unpacked" UI is reached from the
>    Opera add-ons manager rather than `chrome://extensions`.

---

## 1. Install steps (developer / unpacked)

1. **Install the native host first.** See
   `browser-extensions/native-host/README.md`. The same native host
   binary serves Chrome, Edge, Firefox, Opera, Brave, and Vivaldi —
   the per-browser difference is purely the registry location and the
   `allowed_origins` list.
2. Open Opera → enter `opera://extensions` in the address bar.
3. Enable **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select this `opera/` folder.
5. Note the **extension ID** Opera assigns (a 32-character hash like
   `abcdefghijklmnopqrstuvwxyz123456`). You must put it in the native
   host manifest — see the native-host README.

### Replacing the placeholder in the native host manifest

Open `native-host/com.sawan.downloadpro.json` and add your Opera
extension ID to the `allowed_origins` array, e.g.
`chrome-extension://abcdefghijklmnopqrstuvwxyz123456/`. (Opera uses
the `chrome-extension://` scheme — it is the same scheme Chrome
uses, because Opera is Chromium-based.)

Re-register the manifest (the Sawan installer does this automatically
when `EnableOperaIntegration` is ticked; for manual install see the
native-host README).

> **Registry path.** Opera reads native-messaging manifests from
> `HKCU\Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro`
> — the **same** key Chrome uses. The Sawan installer's
> `InstallForOpera()` method writes there. If Chrome is also
> installed and you have already run `InstallForChrome()`, Opera will
> pick up the same manifest; you only need to make sure your Opera
> extension ID is also listed in `allowed_origins`.

---

## 2. How it works

The behaviour is identical to the Chrome extension. See
`../chrome/README.md` section 2 for the full table.

| User action | What the extension does |
|---|---|
| Right-click a link → "Download with Sawan Download Pro" | Sends `{type:"download", url:<linkUrl>, source:"context_menu"}` to the native host. |
| Click the toolbar icon | Opens the popup pre-filled with the active tab URL. Click **Send to Sawan** to submit. |
| Click a link to a downloadable file | Sets a cyan **S** badge on the toolbar icon. The URL is **not** sent automatically. |

The extension **never** submits URLs to the native host without an
explicit user gesture.

---

## 3. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| "Could not reach Sawan Download Pro" on every send | Native host not installed or not registered | Re-run the Sawan installer with **Enable Opera integration** ticked, or follow `native-host/README.md`. Opera looks under `HKCU\Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro`. |
| Native host works from the popup but not the context menu | Opera extension ID missing from `allowed_origins` in `com.sawan.downloadpro.json` | Re-check the ID in `opera://extensions` and add it to `allowed_origins`. Re-run the installer or re-register the manifest. |
| Opera refuses to load the extension | Opera version too old (< 74) | Update Opera. Opera 73 and earlier do not support all MV3 service-worker features this extension uses. |
| No badge on downloadable links | Content script blocked by site CSP | Inspect the page console. |
| Toolbar icon missing after install | Opera hides unpacked extensions by default | Click the cube icon in Opera's toolbar → pin "Sawan Download Pro". |

Inspect the service worker via `opera://extensions` → "Inspect views:
service worker". Native host logs are written to
`%LOCALAPPDATA%\SawanDownloadPro\logs\native-host.log`.

---

## 4. Security considerations

Identical to the Chrome extension. See `../chrome/README.md` section 4.

In summary:

- No automatic URL submission — every send is user-initiated.
- Only `http`/`https`/`ftp` schemes accepted.
- URLs with embedded credentials are rejected.
- URL length capped at 8192 chars.
- The native host validates again; nothing is trusted from the browser.
- No cookies or `Authorization` headers are forwarded — only the URL string.
- The native-host manifest's `allowed_origins` list is the only
  mechanism that lets an extension talk to the host; only the Sawan
  extension's ID is on that list.

---

## 5. Windows 7 limitation

Opera ≥ 87 dropped Windows 7 / 8.1 support. The last Opera version
that installs on Windows 7 SP1 is in the 86 range. This extension
still works on those older Opera versions because it only uses MV3
features available since Opera 74 (Chromium 88); however, **users on
Windows 7 must pin Opera to v86 or earlier** to keep the extension
running.

The Sawan native host itself continues to run on Windows 7 SP1 — only
the browser is the limiting factor.

> **Verification status:** Designed for, not yet verified. Opera
> compatibility is asserted by the Chromium lineage of Opera 74+ and
> the standard native-messaging protocol; it has not been tested on
> physical hardware by the Sawan team.

---

## 6. A note on SVG icons

Opera prefers PNG for manifest icons (especially for the Opera Add-ons
Store submission pipeline, which rasterizes them). SVG works in
developer-mode unpacked loads but is not officially supported for the
`action.default_icon` field across all Chromium versions. The SVGs in
`icons/` are the source-of-truth artwork.

Before publishing to the Opera Add-ons Store, convert each SVG to PNG
at its nominal size (e.g.
`rsvg-convert -w 48 -h 48 icons/icon48.svg -o icons/icon48.png`) and
replace the `icons/icon*.svg` references in `manifest.json` with the
`.png` equivalents.
