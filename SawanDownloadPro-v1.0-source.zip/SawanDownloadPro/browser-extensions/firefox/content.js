/*
 * Sawan Download Pro — Firefox content script.
 *
 * Behavioural contract identical to the Chrome version: it watches for clicks
 * on <a> elements pointing to downloadable files, then sends a "suggest"
 * message to the background script. It NEVER auto-submits URLs.
 *
 * The only Firefox-specific touch is the API namespace shim: in Firefox the
 * extension globals `browser` is preferred over `chrome` (both exist, but
 * `browser` returns promises). We use whichever is present.
 */

(function () {
  'use strict';

  const api = (typeof browser !== 'undefined') ? browser : chrome;

  const DOWNLOADABLE_EXTENSIONS = new Set([
    'zip', 'exe', 'msi', 'mp4', 'mkv', 'mp3', 'pdf',
    'doc', 'docx', 'xls', 'xlsx', 'iso', 'rar', '7z',
    'tar', 'gz', 'bz2', 'xz', 'webm', 'mov', 'avi',
    'flv', 'wav', 'flac', 'apk', 'deb', 'rpm', 'dmg'
  ]);

  const PAGE_SCHEME_OK = /^https?:|^ftp:/i;

  if (window.__sawanBound) return;
  window.__sawanBound = true;

  document.addEventListener('click', onClickCapture, true);

  function onClickCapture(ev) {
    if (ev.defaultPrevented || ev.button !== 0) return;
    if (!ev.target || !(ev.target instanceof Element)) return;

    const a = ev.target.closest('a[href]');
    if (!a) return;

    const href = a.getAttribute('href');
    if (!href) return;

    const absoluteUrl = safeResolveUrl(href);
    if (!absoluteUrl) return;
    if (!PAGE_SCHEME_OK.test(absoluteUrl)) return;
    if (!looksLikeDownload(absoluteUrl, a)) return;

    try {
      api.runtime.sendMessage({
        type: 'suggest',
        url: absoluteUrl,
        pageUrl: location.href
      }, () => {
        // Swallow "receiving end does not exist" errors during install/upgrade.
        if (api.runtime.lastError) {
          // Ignore.
        }
      });
    } catch (_) {
      // Cross-origin frame; ignore.
    }
  }

  function safeResolveUrl(href) {
    const trimmed = href.trim();
    if (!trimmed) return null;
    if (/^javascript:/i.test(trimmed)) return null;
    if (/^data:/i.test(trimmed)) return null;
    try {
      return new URL(trimmed, document.baseURI).href;
    } catch (_) {
      return null;
    }
  }

  function looksLikeDownload(url, a) {
    if (a.hasAttribute('download') && a.getAttribute('download') !== '') {
      return true;
    }
    try {
      const u = new URL(url);
      const path = u.pathname.toLowerCase();
      const dot = path.lastIndexOf('.');
      if (dot < 0) return false;
      const ext = path.slice(dot + 1);
      return DOWNLOADABLE_EXTENSIONS.has(ext);
    } catch (_) {
      return false;
    }
  }
})();
