# Sawan Download Pro — Firefox Extension (Manifest V2)

Send downloads from Mozilla Firefox to the Sawan Download Pro native Windows
download manager via the standard Native Messaging Host protocol.

| Field | Value |
|---|---|
| Manifest version | 2 |
| Firefox version  | ≥ 115 (ESR or current) |
| Add-on ID        | `sawan@sawan.example` |
| Native host name | `com.sawan.downloadpro` |
| Permissions      | `contextMenus`, `activeTab`, `nativeMessaging`, `downloads`, `clipboardWrite`, `notifications`, `storage`, `<all_urls>` |

> Firefox ESR 115 supports both Manifest V2 and V3. This add-on ships as MV2
> for maximum compatibility with the ESR channel that the Sawan installer
> targets on legacy systems. An MV3 build is a future task.

---

## 1. Install steps (temporary add-on)

1. **Install the native host first.** See
   `browser-extensions/native-host/README.md`. Firefox does **not** use the
   Windows registry; it scans
   `%APPDATA%\Mozilla\NativeMessagingHosts\com.sawan.downloadpro.json` for the
   host manifest, and the manifest's `allowed_extensions` must include
   `sawan@sawan.example`.
2. Open Firefox → `about:debugging#/runtime/this-firefox`.
3. Click **Load Temporary Add-on…** and select any file in this `firefox/`
   folder (e.g. `manifest.json`).
4. The toolbar icon should appear. Click it to open the popup and verify
   the active tab URL is pre-filled.

### Permanent installation

Temporary add-ons are removed when Firefox closes. To install permanently
without going through AMO (Mozilla Add-ons):

1. Package the contents of this folder as a ZIP with `manifest.json` at the
   root, then rename to `sawan_download_pro-1.0.0.xpi`.
2. Sign the XPI on <https://addons.mozilla.org/developers/> (mandatory for
   release-channel Firefox; ESR can be configured to accept unsigned add-ons
   via `about:config` → `xpinstall.signatures.required = false`).
3. Distribute the signed XPI via your Sawan installer or AMO.

---

## 2. How it works

| User action | What the extension does |
|---|---|
| Right-click a link → "Download with Sawan Download Pro" | Sends `{type:"download", url:<linkUrl>, source:"context_menu"}` to the native host. |
| Click the toolbar icon | Opens the popup pre-filled with the active tab URL. Click **Send to Sawan** to submit. |
| Click a link to a downloadable file | Sets a cyan **S** badge on the toolbar icon. The URL is **not** sent automatically. |

The extension **never** submits URLs to the native host without an explicit
user gesture. There is no background page-URL capture, no clipboard polling,
no automatic submission.

---

## 3. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| "Could not reach Sawan Download Pro" on every send | Native host JSON missing from `%APPDATA%\Mozilla\NativeMessagingHosts\` | Copy `native-host/com.sawan.downloadpro.json` there and ensure `allowed_extensions` includes `sawan@sawan.example`. |
| `browser.runtime.sendNativeMessage` rejects with "Native host has not been registered" | Manifest JSON not present, or path inside the manifest is wrong | Open the JSON and check the `path` points to the absolute location of `sawan_native_host.bat`. |
| "No such native application" | Add-on ID mismatch | The add-on ID in `manifest.json` (`sawan@sawan.example`) must match an entry in the host manifest's `allowed_extensions`. |
| No badge on downloadable links | Content script blocked by site CSP | Inspect the page console via `about:debugging` → Inspect. |
| Firefox refuses to install the XPI | Unsigned in release channel | Sign on AMO, or use ESR / Developer Edition with signature check disabled. |

Inspect the background event page via `about:debugging` → **Inspect**. Native
host stderr is logged to `%LOCALAPPDATA%\SawanDownloadPro\logs\native-host.log`.

---

## 4. Security considerations

- **No automatic URL submission.** Every download requires an explicit user
  click (context menu, toolbar, or popup button).
- **Scheme allow-list.** Only `http`, `https` and `ftp` URLs are forwarded.
- **No credentials in URLs.** URLs of the form `http://user:pass@host/...`
  are rejected; the user enters credentials in Sawan itself, where they are
  DPAPI-encrypted at rest.
- **URL length cap.** URLs longer than 8192 characters are rejected.
- **Native host validates again.** The native host independently validates
  the JSON schema and scheme before forwarding to the main app.
- **No cookies or `Authorization` headers are forwarded** — only the URL
  string. Firefox's `nativeMessaging` API does not expose cookie jars or
  request headers to the host.
- The add-on ID `sawan@sawan.example` is whitelisted inside the host
  manifest; no other Firefox add-on can talk to the Sawan host.

---

## 5. Windows 7 limitation

Firefox ESR 115 is the last ESR line that runs on Windows 7 SP1 / 8.1. The
next ESR (≥ 128) drops Windows 7 / 8.1 support entirely. Users on Windows 7
must:

1. Stay on Firefox ESR 115.x, **or**
2. Use a Chromium-based browser still pinned to v109 (see the Chrome/Edge
   READMEs), **or**
3. Drop browser integration entirely and use Sawan's main UI to paste URLs.

The Sawan native host itself continues to run on Windows 7 SP1; only the
browser is the limiting factor.

---

## 6. Firefox vs Chrome/Edge differences (for maintainers)

| Concern | Chrome/Edge MV3 | Firefox MV2 (this folder) |
|---|---|---|
| Background | Service worker (`background.js`) | Event page (`background.js`, `persistent:false`) |
| Action | `action` | `browser_action` |
| Native host discovery | Windows registry | `%APPDATA%\Mozilla\NativeMessagingHosts\` |
| Native host allow-list | `allowed_origins: ["chrome-extension://<ID>/"]` | `allowed_extensions: ["sawan@sawan.example"]` |
| Add-on identifier | Random per-install ID (must be looked up) | Stable ID `sawan@sawan.example` set in manifest |
| `sendNativeMessage` | Callback-based | Promise-based (callback also works) |
| Notification icon | SVG accepted (with caveats) | SVG accepted |

When porting changes between the two folders, the background script is the
file that diverges most: the Firefox version uses an `api` shim
(`browser.*` preferred, `chrome.*` fallback) and adapts to the promise-based
`sendNativeMessage` API.
