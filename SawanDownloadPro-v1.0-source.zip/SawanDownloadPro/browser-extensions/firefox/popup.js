/*
 * Sawan Download Pro — Firefox popup script.
 *
 * Same behavioural contract as the Chrome popup, with the `browser.*` API
 * namespace shim. The popup pre-fills the active tab URL (convenience only —
 * the user still must click "Send to Sawan" to submit).
 */

(function () {
  'use strict';

  const api = (typeof browser !== 'undefined') ? browser : chrome;

  const ALLOWED_SCHEMES = new Set(['http:', 'https:', 'ftp:']);
  const MAX_URL_LENGTH = 8192;

  const urlInput = document.getElementById('url');
  const sendBtn  = document.getElementById('send');
  const pasteBtn = document.getElementById('paste');
  const statusEl = document.getElementById('status');

  // --- Pre-fill with active tab URL ----------------------------------------
  try {
    api.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
      const t = tabs && tabs[0];
      if (t && t.url) {
        try {
          if (ALLOWED_SCHEMES.has(new URL(t.url).protocol)) {
            urlInput.value = t.url;
            urlInput.focus();
            urlInput.select();
            return;
          }
        } catch (_) { /* fall through */ }
      }
      urlInput.focus();
    }).catch(() => urlInput.focus());
  } catch (_) {
    urlInput.focus();
  }

  // --- Send -----------------------------------------------------------------
  sendBtn.addEventListener('click', () => {
    const raw = (urlInput.value || '').trim();
    setStatus('', '');
    if (!raw) { setStatus('Please enter a URL.', 'error'); return; }
    if (raw.length > MAX_URL_LENGTH) { setStatus('URL is too long.', 'error'); return; }

    let parsed;
    try { parsed = new URL(raw); }
    catch (e) { setStatus('That does not look like a valid URL.', 'error'); return; }

    if (!ALLOWED_SCHEMES.has(parsed.protocol)) {
      setStatus('Only http, https and ftp URLs are accepted.', 'error');
      return;
    }
    if (parsed.username || parsed.password) {
      setStatus('URLs with embedded credentials are not accepted.', 'error');
      return;
    }

    sendBtn.disabled = true;
    api.runtime.sendMessage(
      { type: 'download', url: raw, source: 'popup' },
      (resp) => {
        sendBtn.disabled = false;
        if (api.runtime.lastError) {
          setStatus('Internal error: ' + api.runtime.lastError.message, 'error');
          return;
        }
        if (resp && resp.ok) {
          setStatus('Sent to Sawan Download Pro.', 'ok');
        } else {
          const err = (resp && resp.error) || 'Unknown error';
          setStatus(err, 'error');
        }
      }
    );
  });

  // --- Paste ----------------------------------------------------------------
  pasteBtn.addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        urlInput.value = text.trim();
        urlInput.focus();
        urlInput.select();
      }
    } catch (e) {
      setStatus('Clipboard read denied by browser.', 'error');
    }
  });

  // --- Enter key ------------------------------------------------------------
  urlInput.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter') {
      ev.preventDefault();
      sendBtn.click();
    }
  });

  function setStatus(message, kind) {
    statusEl.textContent = message || '';
    statusEl.classList.remove('ok', 'error');
    if (kind === 'ok')    statusEl.classList.add('ok');
    if (kind === 'error') statusEl.classList.add('error');
  }
})();
