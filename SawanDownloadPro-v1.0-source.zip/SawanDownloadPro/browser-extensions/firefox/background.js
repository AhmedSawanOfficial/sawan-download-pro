/*
 * Sawan Download Pro — Firefox MV2 background event page.
 *
 * Same behavioural contract as the Chrome MV3 service worker:
 *   1. On install: create a context-menu item.
 *   2. On context-menu click: send {type:"download", url, source:"context_menu"} to the native host.
 *   3. On browser-action click (when popup is closed): capture the active tab URL.
 *   4. Validate scheme (http/https/ftp) before sending.
 *   5. Surface native-host responses/errors via notifications.
 *
 * SECURITY: This extension NEVER auto-submits URLs to the native host. Every
 * message requires an explicit user gesture.
 *
 * Firefox-specific notes:
 *   - Firefox supports the `browser.*` API namespace with promises natively.
 *   - We use `browser.*` where it exists and fall back to `chrome.*` callbacks
 *     so the file also works in any Chromium-based re-port of the extension.
 *   - Firefox does NOT use the Windows registry for native messaging host
 *     registration; it scans %APPDATA%\Mozilla\NativeMessagingHosts\ instead.
 *     See ../native-host/README.md.
 */

'use strict';

// --- API namespace shim -----------------------------------------------------
//
// `browser.*` returns promises; `chrome.*` uses callbacks. We prefer
// `browser.*` and only fall back when running under a Chromium shell.
const api = (typeof browser !== 'undefined') ? browser : chrome;

const NATIVE_HOST_NAME = 'com.sawan.downloadpro';
const ALLOWED_SCHEMES = new Set(['http:', 'https:', 'ftp:']);
const MAX_URL_LENGTH = 8192;
const MENU_ITEM_ID = 'sawan-download-link';
const NOTIFICATION_ID = 'sawan-native-response';

// --- Context menu -----------------------------------------------------------

api.runtime.onInstalled.addListener(() => {
  try {
    api.contextMenus.create({
      id: MENU_ITEM_ID,
      title: 'Download with Sawan Download Pro',
      contexts: ['link', 'image', 'video', 'audio', 'selection']
    });
  } catch (err) {
    // Duplicate-create throws; safe to ignore.
    console.warn('[Sawan] contextMenus.create failed:', err);
  }
});

api.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== MENU_ITEM_ID) return;
  const candidate =
    info.linkUrl ||
    info.srcUrl ||
    (info.selectionText ? info.selectionText.trim() : null) ||
    (tab && tab.url);
  if (!candidate) {
    notifyError('No URL could be determined for this target.');
    return;
  }
  sendDownload(candidate, 'context_menu', tab && tab.url);
});

// --- Browser-action click (popup-closed fallback) ---------------------------
//
// When a default_popup is set, Firefox opens it instead of firing the click
// event. We still register the handler for the case where the popup is
// suppressed (e.g. when the user has set the action to no-popup).
try {
  api.browserAction.onClicked.addListener((tab) => {
    if (!tab || !tab.url) {
      notifyError('The active tab has no URL that can be sent to Sawan.');
      return;
    }
    sendDownload(tab.url, 'toolbar_click', tab.url);
  });
} catch (_) {
  // Older Firefox may not expose browserAction.onClicked when a popup is set.
}

// --- Messages from content script & popup -----------------------------------

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') {
    sendResponse({ ok: false, error: 'Invalid message shape' });
    return false;
  }

  if (msg.type === 'suggest') {
    handleSuggestion(msg, sender);
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'download') {
    const url = typeof msg.url === 'string' ? msg.url : '';
    const source = typeof msg.source === 'string' ? msg.source : 'popup';
    const tabUrl = typeof msg.tabUrl === 'string' ? msg.tabUrl : '';
    sendDownload(url, source, tabUrl)
      .then((result) => sendResponse(result))
      .catch((err) => sendResponse({ ok: false, error: String(err && err.message || err) }));
    return true; // keep the message channel open for async response
  }

  sendResponse({ ok: false, error: 'Unknown message type' });
  return false;
});

// --- Helpers ----------------------------------------------------------------

/**
 * Returns the URL's protocol string (e.g. "https:") or null if it cannot be parsed.
 */
function safeScheme(url) {
  if (!url) return null;
  try {
    return new URL(url).protocol;
  } catch (_) {
    return null;
  }
}

// --- Core: send a download request to the native host -----------------------

async function sendDownload(rawUrl, source, tabUrl) {
  const trimmed = String(rawUrl || '').trim();
  if (!trimmed) {
    return { ok: false, error: 'Empty URL' };
  }
  if (trimmed.length > MAX_URL_LENGTH) {
    return { ok: false, error: 'URL is too long' };
  }

  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch (e) {
    return { ok: false, error: 'Invalid URL: ' + (e && e.message) };
  }
  if (!ALLOWED_SCHEMES.has(parsed.protocol)) {
    return { ok: false, error: 'Scheme not allowed: ' + parsed.protocol };
  }
  if (parsed.username || parsed.password) {
    return { ok: false, error: 'URLs containing embedded credentials are not accepted' };
  }

  const payload = {
    type: 'download',
    url: trimmed,
    source: String(source || 'unknown')
  };
  const tabScheme = safeScheme(tabUrl);
  if (tabScheme && ALLOWED_SCHEMES.has(tabScheme)) {
    payload.tabUrl = tabUrl;
  }

  try {
    // Firefox's browser.runtime.sendNativeMessage returns a promise.
    // Chrome's returns undefined and uses a callback. We handle both.
    const response = await new Promise((resolve, reject) => {
      try {
        const maybe = api.runtime.sendNativeMessage(NATIVE_HOST_NAME, payload, (resp) => {
          const lastErr = api.runtime.lastError;
          if (lastErr) reject(lastErr);
          else resolve(resp);
        });
        if (maybe && typeof maybe.then === 'function') {
          maybe.then(resolve, reject);
        }
      } catch (e) {
        reject(e);
      }
    });

    if (response && response.ok) {
      notifySuccess('Sent to Sawan Download Pro.');
      return { ok: true };
    }
    const errMsg = (response && response.error) || 'Native host returned no error details';
    notifyError(errMsg);
    return { ok: false, error: errMsg };
  } catch (err) {
    const msg = String(err && err.message || err);
    notifyError('Could not reach Sawan Download Pro. Is the native host installed? (' + msg + ')');
    return { ok: false, error: msg };
  }
}

// --- Suggestion handling (content.js) ---------------------------------------

function handleSuggestion(msg, sender) {
  try {
    const tabId = sender.tab && sender.tab.id;
    api.browserAction.setBadgeText({ tabId, text: 'S' });
    api.browserAction.setBadgeBackgroundColor({ tabId, color: '#00B8D4' });
    if (typeof tabId === 'number') {
      setTimeout(() => {
        try { api.browserAction.setBadgeText({ tabId, text: '' }); } catch (_) {}
      }, 4000);
    }
  } catch (_) {
    // Non-fatal.
  }
}

// --- Notifications -----------------------------------------------------------

function notifySuccess(message) {
  notify(message, 'Sawan Download Pro');
}

function notifyError(message) {
  notify(message, 'Sawan Download Pro — error');
}

function notify(message, title) {
  try {
    api.notifications.create(NOTIFICATION_ID, {
      type: 'basic',
      iconUrl: 'icons/icon48.svg',
      title: title || 'Sawan Download Pro',
      message: String(message || '')
    });
  } catch (e) {
    console.error('[Sawan]', message, e);
  }
}
