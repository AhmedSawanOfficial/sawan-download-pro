# Sawan Download Pro — Chrome Extension (Manifest V3)

Send downloads from Google Chrome to the Sawan Download Pro native Windows
download manager via the standard Native Messaging Host protocol.

| Field | Value |
|---|---|
| Manifest version | 3 |
| Minimum Chrome   | 88 |
| Native host name | `com.sawan.downloadpro` |
| Permissions      | `contextMenus`, `activeTab`, `nativeMessaging`, `downloads`, `clipboardWrite`, `notifications`, `storage` |
| Host permissions | `<all_urls>` |

---

## 1. Install steps (developer / unpacked)

1. **Install the native host first.** See
   `browser-extensions/native-host/README.md`. Without the native host the
   extension will load but every "Send to Sawan" click will fail with
   *"Could not reach Sawan Download Pro"*.
2. Open Chrome → `chrome://extensions`.
3. Enable **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select this `chrome/` folder.
5. Note the **extension ID** Chrome assigns (a 32-character hash like
   `abcdefghijklmnopqrstuvwxyz123456`). You must put it in the native host
   manifest — see the native-host README.

### Replacing the placeholder in the native host manifest

Open `native-host/com.sawan.downloadpro.json` and replace
`chrome-extension://<EXTENSION_ID>/` with your actual ID, e.g.
`chrome-extension://abcdefghijklmnopqrstuvwxyz123456/`.

Re-register the manifest (the Sawan installer does this automatically; for
manual install see the native-host README).

---

## 2. How it works

| User action | What the extension does |
|---|---|
| Right-click a link → "Download with Sawan Download Pro" | Sends `{type:"download", url:<linkUrl>, source:"context_menu"}` to the native host. |
| Click the toolbar icon | Opens a popup pre-filled with the active tab URL. Click **Send to Sawan** to submit. |
| Click a link whose URL ends in a known file extension (`.zip`, `.exe`, ...) | Sets a cyan **S** badge on the toolbar icon. The URL is **not** sent — you must click the icon to actually submit. |
| Select text that looks like a URL, right-click | Sends the selected text as a URL (validated). |

The extension **never** submits URLs to the native host without an explicit
user gesture. There is no background page-URL capture, no clipboard polling,
no automatic submission.

---

## 3. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| "Could not reach Sawan Download Pro" on every send | Native host not installed or not registered | Re-run the Sawan installer, or follow `native-host/README.md` for manual registration. |
| Native host works from the popup but not the context menu | Extension ID mismatch in `com.sawan.downloadpro.json` | Re-check the ID in `chrome://extensions` and update `allowed_origins`. |
| No badge appears on downloadable links | Content script blocked by site CSP / the page uses shadow DOM | Open DevTools → Console on the page; the content script logs there when `lastError` fires. |
| Clicking the toolbar icon does nothing | Popup is the default action; clicking it just opens the popup | Open the popup, then click **Send to Sawan**. |
| "URLs with embedded credentials are not accepted" | You sent `http://user:pass@host/...` | Re-enter the URL without credentials; Sawan will prompt for HTTP auth itself. |

Inspect the service worker via `chrome://extensions` → "Inspect views:
service worker". Native host stderr is logged to
`%LOCALAPPDATA%\SawanDownloadPro\logs\native-host.log`.

---

## 4. Security considerations

- **No automatic URL submission.** Every download requires an explicit user
  click (context menu, toolbar, or popup button).
- **Scheme allow-list.** Only `http`, `https` and `ftp` URLs are forwarded.
  `javascript:`, `data:`, `file:`, `blob:` and other schemes are rejected
  client-side and again at the native host.
- **No credentials in URLs.** URLs of the form
  `http://user:pass@host/...` are rejected; the user is expected to enter
  credentials in Sawan itself, where they are DPAPI-encrypted at rest.
- **URL length cap.** URLs longer than 8192 characters are rejected
  (defense-in-depth; matches the C# `MessageSchema` limit).
- **Native host validates again.** Even if a malicious page somehow
  bypassed the content script's heuristic, the native host independently
  validates the JSON schema and scheme before forwarding to the main app.
- **No cookies or auth headers are ever sent.** The extension only forwards
  the URL string. Cookies, `Authorization` headers, and form data are not
  accessible to the extension and not part of the message payload.

---

## 5. Windows 7 limitation

Chrome ≥ 110 dropped Windows 7 / 8.1 support. The last Chrome version that
installs on Windows 7 SP1 is in the 109 range. This extension still works on
those older Chrome versions because it only uses MV3 features available since
Chrome 88; however, **users on Windows 7 must pin Chrome to v109 or earlier**
to keep receiving extension updates.

The Sawan native host itself runs on Windows 7 SP1 (see the C#
`SawanDownloadPro.BrowserIntegration` project), but you must use a
Windows 7-compatible browser to talk to it.

---

## 6. A note on SVG icons

Chrome and Edge prefer PNG for manifest icons (especially for the Web Store /
Microsoft Store submission pipeline, which rasterizes them). SVG works in
developer-mode unpacked loads but is not officially supported for the
`action.default_icon` field across all Chromium versions. The SVGs in
`icons/` are the source-of-truth artwork.

Before publishing to the Chrome Web Store, convert each SVG to PNG at its
nominal size (e.g. `rsvg-convert -w 48 -h 48 icons/icon48.svg -o icons/icon48.png`)
and replace the `icons/icon*.svg` references in `manifest.json` with the
`.png` equivalents.
