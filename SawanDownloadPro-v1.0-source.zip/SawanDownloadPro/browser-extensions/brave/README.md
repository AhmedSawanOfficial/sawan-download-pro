# Sawan Download Pro — Brave Extension (Manifest V3)

Send downloads from Brave to the Sawan Download Pro native Windows
download manager via the standard Native Messaging Host protocol.

| Field | Value |
|---|---|
| Manifest version | 3 |
| Minimum Brave    | 1.20 (Chromium 88) |
| Native host name | `com.sawan.downloadpro` |
| Permissions      | `contextMenus`, `activeTab`, `nativeMessaging`, `downloads`, `clipboardWrite`, `notifications`, `storage` |
| Host permissions | `<all_urls>` |

> **Note:** This extension is identical to the Chrome MV3 extension.
> Brave is a Chromium fork and supports the same Manifest V3
> service-worker model with the same `chrome.*` APIs. The only
> practical differences are:
>
> 1. Brave scans its own registry path,
>    `HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\`,
>    for native-messaging manifests (it does **not** share Chrome's
>    path).
> 2. Brave's developer-mode "Load unpacked" UI lives at
>    `brave://extensions`.

---

## 1. Install steps (developer / unpacked)

1. **Install the native host first.** See
   `browser-extensions/native-host/README.md`. The same native host
   binary serves Chrome, Edge, Firefox, Opera, Brave, and Vivaldi —
   the per-browser difference is purely the registry location and the
   `allowed_origins` list.
2. Open Brave → enter `brave://extensions` in the address bar.
3. Enable **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select this `brave/` folder.
5. Note the **extension ID** Brave assigns (a 32-character hash like
   `abcdefghijklmnopqrstuvwxyz123456`). You must put it in the native
   host manifest — see the native-host README.

### Replacing the placeholder in the native host manifest

Open `native-host/com.sawan.downloadpro.json` and add your Brave
extension ID to the `allowed_origins` array, e.g.
`chrome-extension://abcdefghijklmnopqrstuvwxyz123456/`. (Brave uses
the `chrome-extension://` scheme — it is the same scheme Chrome
uses, because Brave is Chromium-based.)

Re-register the manifest (the Sawan installer does this automatically
when `EnableBraveIntegration` is ticked; for manual install see the
native-host README).

> **Registry path.** Brave reads native-messaging manifests from
> `HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\com.sawan.downloadpro`.
> The Sawan installer's `InstallForBrave()` method writes there.

---

## 2. How it works

The behaviour is identical to the Chrome extension. See
`../chrome/README.md` section 2 for the full table.

| User action | What the extension does |
|---|---|
| Right-click a link → "Download with Sawan Download Pro" | Sends `{type:"download", url:<linkUrl>, source:"context_menu"}` to the native host. |
| Click the toolbar icon | Opens the popup pre-filled with the active tab URL. Click **Send to Sawan** to submit. |
| Click a link to a downloadable file | Sets a cyan **S** badge on the toolbar icon. The URL is **not** sent automatically. |

The extension **never** submits URLs to the native host without an
explicit user gesture.

> **Brave Shields note.** Brave Shields can block third-party
> content scripts on some sites. The Sawan content script is a
> first-party extension script and is **not** blocked by Shields;
> but if you do not see the toolbar badge on a downloadable link,
> try temporarily disabling Shields for that site to confirm
> whether Shields is the cause.

---

## 3. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| "Could not reach Sawan Download Pro" on every send | Native host not installed or not registered | Re-run the Sawan installer with **Enable Brave integration** ticked, or follow `native-host/README.md`. Brave looks under `HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\com.sawan.downloadpro`. |
| Native host works from the popup but not the context menu | Brave extension ID missing from `allowed_origins` in `com.sawan.downloadpro.json` | Re-check the ID in `brave://extensions` and add it to `allowed_origins`. Re-run the installer or re-register the manifest. |
| Brave refuses to load the extension | Brave version too old (< 1.20) | Update Brave. Earlier versions do not support all MV3 service-worker features this extension uses. |
| No badge on downloadable links | Content script blocked by site CSP or Brave Shields | Inspect the page console; try disabling Shields for the site. |
| Toolbar icon missing after install | Brave hides unpacked extensions by default | Click the puzzle-piece icon in Brave's toolbar → pin "Sawan Download Pro". |

Inspect the service worker via `brave://extensions` → "Inspect views:
service worker". Native host logs are written to
`%LOCALAPPDATA%\SawanDownloadPro\logs\native-host.log`.

---

## 4. Security considerations

Identical to the Chrome extension. See `../chrome/README.md` section 4.

In summary:

- No automatic URL submission — every send is user-initiated.
- Only `http`/`https`/`ftp` schemes accepted.
- URLs with embedded credentials are rejected.
- URL length capped at 8192 chars.
- The native host validates again; nothing is trusted from the browser.
- No cookies or `Authorization` headers are forwarded — only the URL string.
- The native-host manifest's `allowed_origins` list is the only
  mechanism that lets an extension talk to the host; only the Sawan
  extension's ID is on that list.

---

## 5. Windows 7 limitation

Brave ≥ 1.46 dropped Windows 7 / 8.1 support. The last Brave version
that installs on Windows 7 SP1 is in the 1.45 range. This extension
still works on those older Brave versions because it only uses MV3
features available since Brave 1.20 (Chromium 88); however, **users
on Windows 7 must pin Brave to v1.45 or earlier** to keep the
extension running.

The Sawan native host itself continues to run on Windows 7 SP1 — only
the browser is the limiting factor.

> **Verification status:** Designed for, not yet verified. Brave
> compatibility is asserted by the Chromium lineage of Brave 1.20+
> and the standard native-messaging protocol; it has not been tested
> on physical hardware by the Sawan team.

---

## 6. A note on SVG icons

Brave prefers PNG for manifest icons (especially for the Brave
Extensions Store submission pipeline, which rasterizes them). SVG
works in developer-mode unpacked loads but is not officially
supported for the `action.default_icon` field across all Chromium
versions. The SVGs in `icons/` are the source-of-truth artwork.

Before publishing to the Brave Extensions Store, convert each SVG to
PNG at its nominal size (e.g.
`rsvg-convert -w 48 -h 48 icons/icon48.svg -o icons/icon48.png`) and
replace the `icons/icon*.svg` references in `manifest.json` with the
`.png` equivalents.
