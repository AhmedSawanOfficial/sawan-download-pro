/*
 * Sawan Download Pro — popup script.
 *
 * Reads the typed URL, validates the scheme client-side, and forwards it to
 * the background service worker as {type:"download", url, source:"popup"}.
 * Shows a status line with success/error feedback.
 */

(function () {
  'use strict';

  const ALLOWED_SCHEMES = new Set(['http:', 'https:', 'ftp:']);
  const MAX_URL_LENGTH = 8192;

  const urlInput   = document.getElementById('url');
  const sendBtn    = document.getElementById('send');
  const pasteBtn   = document.getElementById('paste');
  const statusEl   = document.getElementById('status');

  // --- Pre-fill with the active tab's URL (convenience only — user still must click Send) ---
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const t = tabs && tabs[0];
      if (t && t.url && ALLOWED_SCHEMES.has(new URL(t.url).protocol)) {
        urlInput.value = t.url;
        urlInput.focus();
        urlInput.select();
      } else {
        urlInput.focus();
      }
    });
  } catch (_) {
    urlInput.focus();
  }

  // --- Send button ----------------------------------------------------------
  sendBtn.addEventListener('click', () => {
    const raw = (urlInput.value || '').trim();
    setStatus('', '');
    if (!raw) {
      setStatus('Please enter a URL.', 'error');
      return;
    }
    if (raw.length > MAX_URL_LENGTH) {
      setStatus('URL is too long.', 'error');
      return;
    }

    let parsed;
    try {
      parsed = new URL(raw);
    } catch (e) {
      setStatus('That does not look like a valid URL.', 'error');
      return;
    }
    if (!ALLOWED_SCHEMES.has(parsed.protocol)) {
      setStatus('Only http, https and ftp URLs are accepted.', 'error');
      return;
    }
    if (parsed.username || parsed.password) {
      setStatus('URLs with embedded credentials are not accepted.', 'error');
      return;
    }

    sendBtn.disabled = true;
    chrome.runtime.sendMessage(
      { type: 'download', url: raw, source: 'popup' },
      (resp) => {
        sendBtn.disabled = false;
        if (chrome.runtime.lastError) {
          setStatus('Internal error: ' + chrome.runtime.lastError.message, 'error');
          return;
        }
        if (resp && resp.ok) {
          setStatus('Sent to Sawan Download Pro.', 'ok');
        } else {
          const err = (resp && resp.error) || 'Unknown error';
          setStatus(err, 'error');
        }
      }
    );
  });

  // --- Paste button ---------------------------------------------------------
  pasteBtn.addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        urlInput.value = text.trim();
        urlInput.focus();
        urlInput.select();
      }
    } catch (e) {
      setStatus('Clipboard read denied by browser.', 'error');
    }
  });

  // --- Enter key in input triggers send ------------------------------------
  urlInput.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter') {
      ev.preventDefault();
      sendBtn.click();
    }
  });

  function setStatus(message, kind) {
    statusEl.textContent = message || '';
    statusEl.classList.remove('ok', 'error');
    if (kind === 'ok')    statusEl.classList.add('ok');
    if (kind === 'error') statusEl.classList.add('error');
  }
})();
