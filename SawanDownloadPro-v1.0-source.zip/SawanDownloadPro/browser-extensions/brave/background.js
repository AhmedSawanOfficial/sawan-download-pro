/*
 * Sawan Download Pro — Chrome/Edge MV3 background service worker.
 *
 * Responsibilities:
 *   1. On install: create a context-menu item "Download with Sawan Download Pro".
 *   2. On context-menu click: send {type:"download", url, source:"context_menu"} to the native host.
 *   3. On extension button click (no popup interaction): capture the active tab URL.
 *   4. Validate the URL scheme is http/https/ftp before sending.
 *   5. Surface native-host responses/errors via Chrome notifications.
 *
 * SECURITY: This extension NEVER auto-submits URLs to the native host. Every message
 * requires an explicit user gesture (context-menu click, button click, or popup submit).
 * No page URLs are sent without an explicit user action.
 *
 * Native messaging endpoint name: "com.sawan.downloadpro"
 */

'use strict';

// --- Constants ---------------------------------------------------------------

/** Native messaging host name registered in the OS. MUST match the registry/manifest. */
const NATIVE_HOST_NAME = 'com.sawan.downloadpro';

/** Schemes we will forward to Sawan Download Pro. Anything else is rejected. */
const ALLOWED_SCHEMES = new Set(['http:', 'https:', 'ftp:']);

/** Maximum URL length we will accept (matches the C# MessageSchema limit). */
const MAX_URL_LENGTH = 8192;

/** Context-menu item id. */
const MENU_ITEM_ID = 'sawan-download-link';

/** Notification id prefix used for surfacing native host responses. */
const NOTIFICATION_ID = 'sawan-native-response';

// --- Install: register context menu -----------------------------------------

/**
 * Chrome MV3 service workers can be torn down and respawned. We must use
 * a guard so we don't try to create duplicate menu items on every wake-up.
 */
let menuCreated = false;

chrome.runtime.onInstalled.addListener(() => {
  if (menuCreated) return;
  try {
    chrome.contextMenus.create({
      id: MENU_ITEM_ID,
      title: 'Download with Sawan Download Pro',
      contexts: ['link', 'image', 'video', 'audio', 'selection']
    });
    menuCreated = true;
  } catch (err) {
    // Creating twice throws; safe to ignore if the item already exists.
    console.warn('[Sawan] contextMenus.create failed:', err);
  }
});

// Also rebuild the menu when the worker wakes up (Chrome can persist menu items,
// but a defensive guard is cheap).
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== MENU_ITEM_ID) return;

  // Prefer the explicit link URL (when right-clicking an <a>), then fall back
  // to src for media, then to the selection text (in case the user selected a URL),
  // finally to the page URL itself.
  const candidate = info.linkUrl || info.srcUrl || (info.selectionText ? info.selectionText.trim() : null) || (tab && tab.url);

  if (!candidate) {
    notifyError('No URL could be determined for this target.');
    return;
  }

  sendDownload(candidate, 'context_menu', tab && tab.url);
});

// --- Extension button click: capture active tab URL --------------------------
//
// When the popup is open it intercepts the click. But if the user has set
// the action to "no popup", or the popup is closed programmatically, this
// handler is the fallback. We keep both paths: the popup is the primary UI
// (because it lets the user edit the URL), but we also support click-to-send.

chrome.action.onClicked.addListener((tab) => {
  if (!tab || !tab.url) {
    notifyError('The active tab has no URL that can be sent to Sawan.');
    return;
  }
  sendDownload(tab.url, 'toolbar_click', tab.url);
});

// --- Messages from content script & popup -----------------------------------

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') {
    sendResponse({ ok: false, error: 'Invalid message shape' });
    return false;
  }

  if (msg.type === 'suggest') {
    // content.js detected a downloadable link. We DO NOT auto-send; we surface
    // a non-blocking badge so the user knows the link is recognised.
    handleSuggestion(msg, sender);
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'download') {
    const url = typeof msg.url === 'string' ? msg.url : '';
    const source = typeof msg.source === 'string' ? msg.source : 'popup';
    const tabUrl = typeof msg.tabUrl === 'string' ? msg.tabUrl : '';
    sendDownload(url, source, tabUrl)
      .then((result) => sendResponse(result))
      .catch((err) => sendResponse({ ok: false, error: String(err && err.message || err) }));
    return true; // async response
  }

  sendResponse({ ok: false, error: 'Unknown message type' });
  return false;
});

// --- Helpers ----------------------------------------------------------------

/**
 * Returns the URL's protocol string (e.g. "https:") or null if it cannot be parsed.
 * @param {string} [url]
 * @returns {string|null}
 */
function safeScheme(url) {
  if (!url) return null;
  try {
    return new URL(url).protocol;
  } catch (_) {
    return null;
  }
}

// --- Core: send a download request to the native host ------------------------

/**
 * Validates and forwards a URL to the Sawan Download Pro native messaging host.
 *
 * @param {string} rawUrl  - The URL to send.
 * @param {string} source  - One of: "context_menu", "toolbar_click", "popup", "suggestion_accepted".
 * @param {string} [tabUrl] - The URL of the page the user was on (for provenance; never sent unless valid).
 * @returns {Promise<{ok:boolean, error?:string}>}
 */
async function sendDownload(rawUrl, source, tabUrl) {
  const trimmed = String(rawUrl || '').trim();
  if (!trimmed) {
    return { ok: false, error: 'Empty URL' };
  }
  if (trimmed.length > MAX_URL_LENGTH) {
    return { ok: false, error: 'URL is too long' };
  }

  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch (e) {
    return { ok: false, error: 'Invalid URL: ' + (e && e.message) };
  }

  if (!ALLOWED_SCHEMES.has(parsed.protocol)) {
    return { ok: false, error: 'Scheme not allowed: ' + parsed.protocol };
  }

  // Reject userinfo (http://user:pass@host) for safety; Sawan can re-prompt for auth.
  if (parsed.username || parsed.password) {
    return { ok: false, error: 'URLs containing embedded credentials are not accepted' };
  }

  const payload = {
    type: 'download',
    url: trimmed,
    source: String(source || 'unknown')
  };
  // Attach the originating page URL as provenance, but only if it is itself
  // a scheme we would accept. Never forward arbitrary tab URLs.
  const tabScheme = safeScheme(tabUrl);
  if (tabScheme && ALLOWED_SCHEMES.has(tabScheme)) {
    payload.tabUrl = tabUrl;
  }

  try {
    const response = await chrome.runtime.sendNativeMessage(NATIVE_HOST_NAME, payload);
    if (response && response.ok) {
      notifySuccess('Sent to Sawan Download Pro.');
      return { ok: true };
    }
    const errMsg = (response && response.error) || 'Native host returned no error details';
    notifyError(errMsg);
    return { ok: false, error: errMsg };
  } catch (err) {
    const msg = String(err && err.message || err);
    // The most common failure: native host not installed / not registered.
    notifyError('Could not reach Sawan Download Pro. Is the native host installed? (' + msg + ')');
    return { ok: false, error: msg };
  }
}

// --- Suggestion handling (content.js) ---------------------------------------

function handleSuggestion(msg, sender) {
  // We deliberately do NOT send to the native host here. We only set a badge
  // so the user knows Sawan recognised the link; they can click the toolbar
  // icon to actually send it (or use the context menu).
  try {
    chrome.action.setBadgeText({
      tabId: sender.tab && sender.tab.id,
      text: 'S'
    });
    chrome.action.setBadgeBackgroundColor({
      tabId: sender.tab && sender.tab.id,
      color: '#00B8D4'
    });
    // Auto-clear after a few seconds so it doesn't linger.
    const tabId = sender.tab && sender.tab.id;
    if (typeof tabId === 'number') {
      setTimeout(() => {
        try { chrome.action.setBadgeText({ tabId, text: '' }); } catch (_) {}
      }, 4000);
    }
  } catch (_) {
    // Badge failures are non-fatal.
  }
}

// --- Notifications -----------------------------------------------------------

function notifySuccess(message) {
  notify(message, 'Sawan Download Pro');
}

function notifyError(message) {
  notify(message, 'Sawan Download Pro — error');
}

function notify(message, title) {
  try {
    chrome.notifications.create(NOTIFICATION_ID, {
      type: 'basic',
      iconUrl: 'icons/icon48.svg',
      title: title || 'Sawan Download Pro',
      message: String(message || ''),
      priority: 1
    });
  } catch (e) {
    // Notifications may be denied. Fall back to console so the user can still
    // see the message via the inspector.
    console.error('[Sawan]', message, e);
  }
}
