/*
 * Sawan Download Pro — content script.
 *
 * Watches the page for clicks on <a> elements whose href looks like a downloadable
 * file (by extension). When the user clicks such a link:
 *   - We DO NOT preventDefault, DO NOT redirect, DO NOT auto-download.
 *   - We send a "suggest" message to the background, which sets a badge on the
 *     toolbar icon so the user knows Sawan recognised the link.
 *   - The user then explicitly clicks the toolbar icon (or uses the context menu)
 *     to actually send the URL to Sawan Download Pro.
 *
 * SECURITY: This script NEVER submits URLs to the native host. It only suggests.
 */

(function () {
  'use strict';

  // Extensions we consider "downloadable" for the heuristic. Lowercased, no dot.
  const DOWNLOADABLE_EXTENSIONS = new Set([
    'zip', 'exe', 'msi', 'mp4', 'mkv', 'mp3', 'pdf',
    'doc', 'docx', 'xls', 'xlsx', 'iso', 'rar', '7z',
    'tar', 'gz', 'bz2', 'xz', 'webm', 'mov', 'avi',
    'flv', 'wav', 'flac', 'apk', 'deb', 'rpm', 'dmg'
  ]);

  // Only http/https/ftp page URLs get instrumented. We never run on
  // chrome://, file://, etc.
  const PAGE_SCHEME_OK = /^https?:|^ftp:/i;

  // Avoid re-binding on SPA navigations / iframes injection cycles.
  if (window.__sawanBound) return;
  window.__sawanBound = true;

  // Capture phase so we see the click before any stopPropagation runs.
  document.addEventListener('click', onClickCapture, true);

  /**
   * @param {MouseEvent} ev
   */
  function onClickCapture(ev) {
    if (ev.defaultPrevented || ev.button !== 0) return;
    if (!ev.target || !(ev.target instanceof Element)) return;

    const a = ev.target.closest('a[href]');
    if (!a) return;

    const href = a.getAttribute('href');
    if (!href) return;

    const absoluteUrl = safeResolveUrl(href);
    if (!absoluteUrl) return;
    if (!PAGE_SCHEME_OK.test(absoluteUrl)) return;
    if (!looksLikeDownload(absoluteUrl, a)) return;

    // Send a non-blocking suggestion. The user must explicitly click the
    // toolbar icon or the context menu to actually send the URL.
    try {
      chrome.runtime.sendMessage({
        type: 'suggest',
        url: absoluteUrl,
        // Provenance only; not sent to native host unless user accepts.
        pageUrl: location.href
      }, () => {
        // Swallow "receiving end does not exist" errors during install/upgrade.
        if (chrome.runtime.lastError) {
          // Ignore — background may be sleeping or extension just installed.
        }
      });
    } catch (_) {
      // Cross-origin frames can throw; ignore.
    }
  }

  /**
   * Resolves a possibly-relative href to an absolute URL using the page's
   * own base URL. Returns null if the href is empty or javascript:.
   *
   * @param {string} href
   * @returns {string|null}
   */
  function safeResolveUrl(href) {
    const trimmed = href.trim();
    if (!trimmed) return null;
    // Reject javascript: and data: outright.
    if (/^javascript:/i.test(trimmed)) return null;
    if (/^data:/i.test(trimmed)) return null;
    try {
      return new URL(trimmed, document.baseURI).href;
    } catch (_) {
      return null;
    }
  }

  /**
   * Heuristic: does this URL look like a downloadable file?
   * We require either:
   *   - A path ending in ".ext" where ext is in our allow-list, OR
   *   - The <a> has a "download" attribute AND a non-empty href.
   *
   * @param {string} url
   * @param {HTMLAnchorElement} a
   * @returns {boolean}
   */
  function looksLikeDownload(url, a) {
    if (a.hasAttribute('download') && a.getAttribute('download') !== '') {
      return true;
    }
    try {
      const u = new URL(url);
      const path = u.pathname.toLowerCase();
      const dot = path.lastIndexOf('.');
      if (dot < 0) return false;
      const ext = path.slice(dot + 1);
      // Strip any trailing query that the URL parser already removed.
      return DOWNLOADABLE_EXTENSIONS.has(ext);
    } catch (_) {
      return false;
    }
  }
})();
