# Sawan Download Pro — Microsoft Edge Extension (Manifest V3)

Send downloads from Microsoft Edge to the Sawan Download Pro native Windows
download manager via the standard Native Messaging Host protocol.

| Field | Value |
|---|---|
| Manifest version | 3 |
| Minimum Edge     | 88 (Chromium-based) |
| Native host name | `com.sawan.downloadpro` |
| Permissions      | `contextMenus`, `activeTab`, `nativeMessaging`, `downloads`, `clipboardWrite`, `notifications`, `storage` |
| Host permissions | `<all_urls>` |

> **Note:** This extension is identical to the Chrome MV3 extension because
> Edge has been Chromium-based since 2020 and supports MV3 with the same APIs.
> The only practical difference is the Windows registry path used to register
> the native messaging host (see the native-host README).

---

## 1. Install steps (developer / unpacked)

1. **Install the native host first.** See
   `browser-extensions/native-host/README.md`. The same native host binary
   serves Chrome, Edge and Firefox — the per-browser difference is purely
   the registry location and the `allowed_origins` list.
2. Open Edge → `edge://extensions`.
3. Enable **Developer mode** (left-side panel toggle).
4. Click **Load unpacked** and select this `edge/` folder.
5. Note the **extension ID** Edge assigns. Put it in
   `native-host/com.sawan.downloadpro.json` under `allowed_origins`, then
   re-register the host manifest.

---

## 2. How it works

The behaviour is identical to the Chrome extension. See
`../chrome/README.md` section 2 for the full table.

| User action | What the extension does |
|---|---|
| Right-click a link → "Download with Sawan Download Pro" | Sends `{type:"download", url:<linkUrl>, source:"context_menu"}` to the native host. |
| Click the toolbar icon | Opens the popup pre-filled with the active tab URL. Click **Send to Sawan** to submit. |
| Click a link to a downloadable file | Sets a cyan **S** badge on the toolbar icon. The URL is **not** sent automatically. |

The extension **never** submits URLs to the native host without an explicit
user gesture.

---

## 3. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| "Could not reach Sawan Download Pro" on every send | Native host not installed or not registered | Re-run the Sawan installer, or follow `native-host/README.md`. Edge looks under `HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.sawan.downloadpro`. |
| Native host works from the popup but not the context menu | Extension ID mismatch in `com.sawan.downloadpro.json` | Re-check the ID in `edge://extensions` and update `allowed_origins`. |
| Edge refuses to load the extension | Edge version too old (< 88) | Update Edge. Pre-Chromium Edge (≤ 44) does **not** support this extension. |
| No badge on downloadable links | Content script blocked by site CSP | Inspect the page console. |

Inspect the service worker via `edge://extensions` → "Inspect views:
service worker". Native host logs are written to
`%LOCALAPPDATA%\SawanDownloadPro\logs\native-host.log`.

---

## 4. Security considerations

Identical to the Chrome extension. See `../chrome/README.md` section 4.

In summary:

- No automatic URL submission — every send is user-initiated.
- Only `http`/`https`/`ftp` schemes accepted.
- URLs with embedded credentials are rejected.
- URL length capped at 8192 chars.
- The native host validates again; nothing is trusted from the browser.
- No cookies or `Authorization` headers are forwarded — only the URL string.

---

## 5. Windows 7 limitation

Microsoft Edge ≥ 110 dropped Windows 7 / 8.1 support. The last Edge version
that runs on Windows 7 SP1 is in the 109 range. This extension still works
on those older Edge versions because it only uses MV3 features available
since Edge 88; however, **users on Windows 7 must pin Edge to v109 or
earlier** to keep receiving extension updates.

The native host itself continues to run on Windows 7 SP1 — only the browser
is the limiting factor.

---

## 6. Microsoft Store distribution (future)

To publish to the Microsoft Store as an Edge Add-on:

1. Zip this folder's contents (the `manifest.json` must be at the zip root).
2. Submit via <https://partner.microsoft.com/dashboard/microsoftedge>.
3. After publication, Edge assigns a **stable** extension ID; update the
   `allowed_origins` in `native-host/com.sawan.downloadpro.json` accordingly
   and ship a new Sawan installer.
