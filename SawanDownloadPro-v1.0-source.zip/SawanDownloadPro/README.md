# Sawan Download Pro

> **Fast. Smart. In Control.**

| | |
|---|---|
| **Version**   | 1.0 — First Release |
| **Created by** | Ahmed Sawan |
| **Brand**     | Sawan |
| **Tagline**   | Fast. Smart. In Control. |
| **Release date** | October 2026 |
| **License**   | Apache License, Version 2.0 |

Sawan Download Pro is a native Windows desktop download manager built
in C# and WPF, targeting Windows 7 SP1, Windows 10, and Windows 11. It
supports HTTP/HTTPS downloads with segmented acceleration,
pause/resume, queue scheduling, six-browser integration (Chrome, Edge,
Firefox, Opera, Brave, Vivaldi), an optional media downloader for
authorized sources, a real-time dashboard, a Private Downloads mode
for sensitive downloads, and a Security & Privacy center that
collects every privacy-sensitive control in one place.

The primary interface language is **Arabic** with full right-to-left
support; **English** is fully supported as a secondary language. The
v1.0 release introduces the **Dark Eggplant** visual identity
(`#21102F` primary background, `#6F42A6` primary accent, `#A78BFA`
secondary accent) as the new default theme, replacing the Stage-2
MVP's blue/cyan palette.

---

## Status

> **Source code complete; binary compilation and Windows-based testing
> pending.**

This repository contains the full source code for the Sawan Download
Pro v1.0 first release. The source was authored on Linux for
engineering reasons but targets .NET Framework 4.8 and WPF, so it
must be compiled on Windows. No Windows host was available during the
source-authoring phase, so:

- The solution has **not yet been compiled**.
- The test suite has **not yet been run**.
- The installer has **not yet been built**.
- Browser integration has **not yet been verified** on any platform.
- The new v1.0 features (Dashboard, Private Downloads, Security &
  Privacy, First-run wizard, Opera/Brave/Vivaldi extensions) have
  **not yet been tested** on physical Windows hardware.

Every doc that makes a testable claim labels it explicitly as
"Designed for, not yet verified" or "Not Yet Run". See
[`docs/TEST_REPORT.md`](docs/TEST_REPORT.md) for the full honest
accounting, and [`docs/RELEASE_NOTES_v1.0.md`](docs/RELEASE_NOTES_v1.0.md)
for the v1.0 release notes.

---

## Key features

- **Dark Eggplant visual identity.** New default theme with a deep
  aubergine background, saturated purple primary accent, and soft
  lavender secondary accent. Light and System themes also available;
  custom accent colour picker; theme import/export.
- **Real-time dashboard.** Live totals (active, queued, completed,
  failed), aggregate download speed with sparkline, free disk space
  on the default download drive, recent notifications, quick actions.
- **Six-browser integration.** Chrome MV3, Edge MV3, Firefox MV2,
  Opera MV3, Brave MV3, and Vivaldi MV3 extensions with a single
  native-messaging host bridge. Right-click any link → "Download with
  Sawan Download Pro".
- **Private Downloads mode.** Separate session for sensitive
  downloads; isolated from the regular queue and history; Clear
  Private Session action; optional auto-clear-on-exit; optional
  secure-delete of private partial files.
- **Security & Privacy center.** Single panel for DPAPI status,
  telemetry status (always off), log management, antivirus
  integration, native-messaging host status, Private Downloads
  status, update check status, and a one-click security self-check.
- **First-run welcome wizard.** Seven-step guided setup: welcome,
  language, theme, default download folder, browser integration
  (all six browsers), Private Downloads consent, finish.
- **About Sawan page.** Creator credit (Ahmed Sawan) and the four
  official contact channels: WhatsApp, YouTube, Facebook, Telegram.
- **Segmented HTTP/HTTPS downloads.** Parallel-segment engine when
  the server supports `Accept-Ranges: bytes`; single-connection
  fallback otherwise.
- **Pause, resume, retry.** Per-segment pause with `.sawanmeta`
  sidecar for resume metadata. Exponential backoff with `Retry-After`
  honouring.
- **Bandwidth throttling.** Global and per-task limits via a token
  bucket.
- **Queue scheduling.** Start the queue at a scheduled time; stop the
  queue at a scheduled time; optionally shut down the computer when
  the queue completes.
- **Categories and smart views.** Auto-categorize by extension;
  custom extension mappings; custom subfolders; smart views
  (Dashboard, All, Today, Active, Failed, History, Private).
- **Clipboard monitoring.** Optional auto-detect of URLs in the
  clipboard with toast confirmation.
- **Media downloader.** Optional YouTube extractor via a
  user-supplied `yt-dlp.exe`. Facebook and TikTok are intentional
  stubs that document what the app will and will not do.
- **FFmpeg integration.** Optional post-download conversion (MP4 →
  MP3, trim, transcode) via a user-supplied `ffmpeg.exe`. Sawan
  never bundles FFmpeg.
- **SQLite persistence.** Atomic transactions for resume state,
  history, and settings. No external database server.
- **Security first.** Path traversal prevention, URL allow-listing,
  DPAPI-encrypted credentials, no telemetry, no bundled offers,
  Ed25519-signed updates (opt-in only).
- **Bilingual UI.** Arabic (default, RTL) and English (LTR). Toggle
  from Settings → Appearance.
- **Per-machine MSI installer.** Built with WiX v3.14 in both x86
  and x64 variants. Per-machine install with optional per-user
  overrides.
- **No telemetry, ever.** No analytics, no crash reports phoning
  home, no auto-update without explicit user opt-in.

---

## Tech stack

| Layer                | Choice                                                      |
|----------------------|-------------------------------------------------------------|
| UI framework         | WPF (PresentationFramework)                                 |
| .NET target          | .NET Framework 4.8 (LTS) — last Framework supported on Win7 SP1 |
| Language             | C# 9.0 (`LangVersion 9.0`, `Nullable enable`)              |
| HTTP client          | `HttpWebRequest` (segmented engine) + `HttpClient` (metadata) |
| Persistence          | SQLite via `System.Data.SQLite` (x86 + x64)                |
| Logging              | `Microsoft.Extensions.Logging` + custom file sink          |
| DI                   | `Microsoft.Extensions.DependencyInjection`                 |
| MVVM                 | `CommunityToolkit.Mvvm` (source-generator-based)          |
| Theming              | `SawanDownloadPro.Themes` (new in v1.0)                    |
| Browser integration  | Native Messaging Host (Chrome/Edge/Firefox/Opera/Brave/Vivaldi) |
| Media conversion     | Optional FFmpeg (user-supplied, never bundled)             |
| Media extraction     | Optional yt-dlp (user-supplied, never bundled)             |
| Installer            | WiX Toolset v3.14                                          |
| Tests                | xUnit 2.5.3 + Moq 4.20.70                                  |

### Why .NET Framework 4.8 and not .NET 8?

.NET 6+ has dropped Windows 7 support. .NET Framework 4.8 is the only
modern runtime that still installs and runs on Windows 7 SP1. We
accept older language features in exchange for the Windows 7 support
that this product requires.

### Why WPF and not Electron / Tauri / WebView2?

All of these have either dropped or never properly supported Windows
7:

- Electron ≥ 23 dropped Win7/8 support.
- WebView2 Runtime ≥ 110 dropped Win7 support.
- Tauri requires WebView2, inheriting the same limitation.

A native WPF + .NET Framework 4.8 application is the only way to
honour the Windows 7 SP1 requirement without shipping a separate,
degraded product.

---

## Quick start

1. **Build the application.** See
   [`docs/BUILD_INSTRUCTIONS.md`](docs/BUILD_INSTRUCTIONS.md) for
   complete step-by-step instructions. The short version:

   ```cmd
   nuget restore SawanDownloadPro.sln
   msbuild SawanDownloadPro.sln /p:Configuration=Release /p:Platform=x64
   ```

2. **Run the app.** Launch
   `src\SawanDownloadPro.App\bin\Release\SawanDownloadPro.App.exe`.
   On first launch, the v1.0 welcome wizard walks you through language,
   theme (default: Dark Eggplant), default download folder, browser
   integration (all six browsers), and Private Downloads consent.

3. **Build the installer (optional).** From the `installer/` folder:

   ```cmd
   BuildInstaller.bat
   ```

   Produces `installer\bin\x86\SawanDownloadProSetup.msi` and
   `installer\bin\x64\SawanDownloadProSetup_x64.msi`. See
   [`installer/README.md`](installer/README.md) for code-signing
   instructions.

4. **Configure browser integration (optional).** Open Settings →
   Browser Integration, tick your browser(s), and follow the prompts
   to load the unpacked extension. v1.0 supports Chrome, Edge,
   Firefox, Opera, Brave, and Vivaldi. See
   [`docs/BUILD_INSTRUCTIONS.md`](docs/BUILD_INSTRUCTIONS.md) Section 4
   for details.

5. **Configure media downloader (optional).** Obtain `yt-dlp.exe`
   from <https://github.com/yt-dlp/yt-dlp/releases> and `ffmpeg.exe`
   from <https://ffmpeg.org/download.html>. Point Settings → Media
   at them. Sawan never bundles either binary; see
   [`src/SawanDownloadPro.Media/LICENSE_NOTICES.md`](src/SawanDownloadPro.Media/LICENSE_NOTICES.md)
   for the licensing rationale.

---

## Solution structure

```
SawanDownloadPro.sln
│
├── src/
│   ├── SawanDownloadPro.Core/                  — domain models, interfaces, enums, events
│   ├── SawanDownloadPro.DownloadEngine/        — HTTP/HTTPS segmented downloader
│   ├── SawanDownloadPro.Storage/               — SQLite persistence
│   ├── SawanDownloadPro.Security/              — path/URL validation, safe process launch, DPAPI
│   ├── SawanDownloadPro.Scheduler/             — queue, priorities, scheduling
│   ├── SawanDownloadPro.Media/                 — video extractor + FFmpeg wrapper
│   ├── SawanDownloadPro.BrowserIntegration/    — native messaging host (6 browsers)
│   ├── SawanDownloadPro.Themes/                — theme management (new in v1.0)
│   └── SawanDownloadPro.App/                   — WPF UI, app composition root
│
├── browser-extensions/
│   ├── chrome/                                 — Manifest V3 extension
│   ├── edge/                                   — Manifest V3 extension (same base)
│   ├── firefox/                                — Manifest V2 extension
│   ├── opera/                                  — Manifest V3 extension (new in v1.0)
│   ├── brave/                                  — Manifest V3 extension (new in v1.0)
│   ├── vivaldi/                                — Manifest V3 extension (new in v1.0)
│   └── native-host/                            — Native messaging host manifest + installer
│
├── tests/
│   └── SawanDownloadPro.Tests/                 — xUnit test project
│
├── installer/                                  — WiX v3.14 source (.wxs)
│
└── docs/                                       — all documentation
```

### Dependency direction (strict, enforced by project references)

```
            App
             │
   ┌─────────┼─────────┬───────────┬──────────┬──────────┐
   │         │         │           │          │          │
Scheduler  Media   BrowserInt.   Storage   Security   Themes
   │         │         │           │          │          │
   └─────────┴─────────┴───────────┴──────────┴──────────┘
                       │
                DownloadEngine
                       │
                    Core
```

- `Core` depends on nothing.
- `DownloadEngine` depends only on `Core`.
- `Storage`, `Security`, `Scheduler`, `Media`, `BrowserIntegration`,
  `Themes` depend on `Core`.
- `Media` additionally depends on `Security` (for `SafeProcessLauncher`).
- `App` depends on everything; nothing depends on `App`.
- `Tests` depends on everything for testability.

No project may take a dependency that violates this direction.

---

## Documentation index

| Document                                                              | What's in it                                                                          |
|-----------------------------------------------------------------------|---------------------------------------------------------------------------------------|
| [`docs/RELEASE_NOTES_v1.0.md`](docs/RELEASE_NOTES_v1.0.md)            | v1.0 first-release notes: highlights, feature list, known limitations, breaking changes, acknowledgments. |
| [`docs/ABOUT_AHMED_SAWAN.md`](docs/ABOUT_AHMED_SAWAN.md)              | About the creator; the four official contact channels (WhatsApp, YouTube, Facebook, Telegram). |
| [`docs/PRIVACY.md`](docs/PRIVACY.md)                                  | Comprehensive v1.0 privacy statement: data collection (none), local data, Private Downloads, credentials, logs, browser integration, updates, antivirus, children's privacy, user rights. |
| [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)                        | Engineering design document: tech stack, modules, schema, security posture, roadmap. |
| [`docs/BUILD_INSTRUCTIONS.md`](docs/BUILD_INSTRUCTIONS.md)            | Exact commands to build the app, run tests, build the installer, and load browser extensions. |
| [`docs/USER_GUIDE_EN.md`](docs/USER_GUIDE_EN.md)                      | Comprehensive English user guide for v1.0.                                          |
| [`docs/USER_GUIDE_AR.md`](docs/USER_GUIDE_AR.md)                      | Comprehensive Arabic (MSA, RTL) user guide for v1.0.                                |
| [`docs/TROUBLESHOOTING.md`](docs/TROUBLESHOOTING.md)                  | Common issues and fixes, grouped by category (including v1.0 sections on theme, Private Downloads, Opera/Brave/Vivaldi, first-run wizard). |
| [`docs/SECURITY.md`](docs/SECURITY.md)                                | Threat model, path/URL/credential protection, Private Downloads security, six-browser native messaging, first-run consent, no-telemetry commitment, vulnerability reporting. |
| [`docs/LICENSE_INVENTORY.md`](docs/LICENSE_INVENTORY.md)              | Table of all third-party dependencies with their licenses.                          |
| [`docs/TEST_REPORT.md`](docs/TEST_REPORT.md)                          | All test cases with status (v1.0 features: "Implemented but not fully tested").     |
| [`docs/ROADMAP.md`](docs/ROADMAP.md)                                  | v1.0 (current) → v1.1 (scheduler UI, batch ops, plugin SDK foundation) → v1.2 (HLS/DASH, BitTorrent, cloud sync, integrated player) → Future. |
| [`docs/COMPATIBILITY_MATRIX.md`](docs/COMPATIBILITY_MATRIX.md)        | OS × architecture × runtime × browser support matrix (now includes Opera, Brave, Vivaldi). |
| [`installer/README.md`](installer/README.md)                          | WiX installer build instructions, code signing, Win7 SP1 SHA-2 update note.            |
| [`src/SawanDownloadPro.Media/LICENSE_NOTICES.md`](src/SawanDownloadPro.Media/LICENSE_NOTICES.md) | FFmpeg (LGPL/GPL) and yt-dlp (Unlicense) licensing notices.             |

---

## Honest status

- **Source code complete.** The v1.0 source tree is reviewed and
  ready for compilation on Windows.
- **Binary compilation and Windows-based testing pending.** The
  development environment is Linux; the project targets .NET Framework
  4.8 + WPF and must be compiled and tested on a Windows host.
- **Not yet tested on physical Windows 7 / 10 / 11 hardware.** Every
  test case in [`docs/TEST_REPORT.md`](docs/TEST_REPORT.md) is marked
  "Implemented but not fully tested" or "Not implemented" because no
  Windows host was available during the source-authoring phase.
- **Modern browsers dropped Windows 7.** Chrome ≥ 110, Edge ≥ 110,
  Opera ≥ 87, Brave ≥ 1.46, and Vivaldi ≥ 5.6 dropped Windows 7
  support. Users on Windows 7 must use legacy ESR builds or the last
  Win7-compatible browser release.
- **FFmpeg and yt-dlp are not bundled.** Users who want media
  conversion or YouTube extraction must download `ffmpeg.exe` and
  `yt-dlp.exe` themselves from the official sources.
- **YouTube, Facebook, and TikTok support depends on authorized
  sources.** Sawan will not bypass DRM, login walls, or members-only
  restrictions. Facebook and TikTok are intentional stubs.
- **Private Downloads mode is not a forensic anonymity tool.** It
  isolates Sawan's own state; it does not clear browser history, NTFS
  journal, DNS cache, or Recycle Bin. See
  [`docs/PRIVACY.md`](docs/PRIVACY.md) Section 3.2.

---

## License

Sawan Download Pro is licensed under the **Apache License, Version
2.0**. See [`LICENSE`](LICENSE) for the full text.

The Apache 2.0 license is permissive: you may use, modify, and
redistribute Sawan Download Pro (including commercially) provided you
preserve the copyright notice and the LICENSE file. The Apache 2.0
license is compatible with every third-party license we depend on
(MIT, BSD-3, Apache 2.0, MS-RL, public domain, LGPL, GPL, Unlicense,
PSF).

The end-user binary installer is governed by the EULA in
[`installer/License.rtf`](installer/License.rtf). Where the EULA
conflicts with the Apache 2.0 license, the Apache 2.0 license
prevails for the source code and for any portion of the binary that
is unambiguously derived from Apache-2.0-licensed source.

---

## Contributing

We welcome contributions. Before opening a pull request:

1. Read [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) to understand
   the module boundaries.
2. Read [`docs/SECURITY.md`](docs/SECURITY.md) Section 13 (the
   security review checklist) — every change to security-sensitive
   code must pass it.
3. Run `msbuild /p:TreatWarningsAsErrors=true` locally to catch
   warnings before they reach CI.
4. Add or update tests in `tests/SawanDownloadPro.Tests/` for any
   logic change. Pure-logic tests run on Windows; integration tests
   that require external binaries (FFmpeg, yt-dlp) should be tagged
   `[Trait("Category", "RequiresExternalBinaries")]`.
5. Update [`docs/LICENSE_INVENTORY.md`](docs/LICENSE_INVENTORY.md)
   if you add a new dependency.

### Code style

- C# 9.0 syntax (`is not` patterns, target-typed `new()`, `using var`).
- `Nullable enable` in every project.
- File-scoped namespaces are NOT used (LangVersion 9.0 does not
  support them; they were added in C# 10).
- Async methods suffixed with `Async`.
- `internal` types for anything that's not part of the project's
  public API.
- XML doc comments on every public and protected member.

---

## Acknowledgements

Sawan Download Pro stands on the shoulders of:

- **Ahmed Sawan** — creator of the Sawan brand, lead designer and
  product owner of Sawan Download Pro.
- The .NET Framework team at Microsoft.
- The SQLite team (<https://www.sqlite.org>).
- The WiX Toolset team (<https://wixtoolset.org>).
- The FFmpeg team (<https://ffmpeg.org>).
- The yt-dlp team (<https://github.com/yt-dlp/yt-dlp>).
- The CommunityToolkit team (<https://github.com/CommunityToolkit>).
- James Newton-King for Newtonsoft.Json.

See [`docs/LICENSE_INVENTORY.md`](docs/LICENSE_INVENTORY.md) for the
full attribution table.

---

## Connect with Sawan

The following are the **only** official Sawan contact channels. Any
other account, page, or handle claiming to represent Ahmed Sawan or
the Sawan brand is not authentic.

| Channel   | Link                                                  |
|-----------|-------------------------------------------------------|
| WhatsApp  | <https://wa.me/201000150303>                          |
| YouTube   | <https://www.youtube.com/@AhmedSawanOfficial>         |
| Facebook  | <https://www.facebook.com/AhmedSawanOfficial/>        |
| Telegram  | <https://t.me/AhmedMSawan>                            |

- **Bug reports and feature requests:** file an issue at the project's
  public tracker.
- **Security reports:** see [`docs/SECURITY.md`](docs/SECURITY.md)
  Section 12 for the responsible-disclosure process. Do not file a
  public issue for security vulnerabilities.
- **Privacy inquiries:** see [`docs/PRIVACY.md`](docs/PRIVACY.md)
  Section 12. WhatsApp is preferred for time-sensitive privacy
  inquiries.
- **General discussion:** use the project's discussion board, or
  reach out via the official channels above.

We do not operate a bug bounty. We do not provide a SLA on responses.
We do commit to acknowledging every issue within 30 days.

---

**Tagline:** Fast. Smart. In Control.

**Status:** Source code complete; binary compilation and Windows-based
testing pending. This is the first official release of the Sawan
product line.
