using System;
using System.Reflection;
using SawanDownloadPro.DownloadEngine;
using Xunit;

namespace SawanDownloadPro.Tests.DownloadEngine
{
    /// <summary>
    /// Unit tests for the internal <c>RetryPolicy</c> class
    /// (<see cref="SawanDownloadPro.DownloadEngine.Http.RetryPolicy"/>).
    /// </summary>
    /// <remarks>
    /// <para>
    /// <see cref="SawanDownloadPro.DownloadEngine.Http.RetryPolicy"/> is
    /// <c>internal sealed</c> and the production project does not expose it via
    /// <c>InternalsVisibleTo</c>. We exercise the policy through reflection to
    /// avoid having to modify the production source.
    /// </para>
    /// <para>
    /// The reflection helpers below (<see cref="CreatePolicy"/> and
    /// <see cref="InvokeGetDelay"/>) wrap the runtime invocation so each test
    /// reads naturally. If a future refactor exposes the type, the helpers
    /// can be replaced with direct calls and the tests will still pass.
    /// </para>
    /// </remarks>
    public class RetryPolicyTests
    {
        // ---------------------------------------------------------------------
        // Reflection helpers
        // ---------------------------------------------------------------------

        private const string RetryPolicyFullName =
            "SawanDownloadPro.DownloadEngine.Http.RetryPolicy";

        /// <summary>
        /// Creates an instance of the internal RetryPolicy via reflection.
        /// </summary>
        private static object CreatePolicy(int maxAttempts, int initialDelayMs,
                                           double multiplier, int maxDelayMs)
        {
            var asm = typeof(SawanDownloadPro.DownloadEngine.DownloadEngine).Assembly;
            var t = asm.GetType(RetryPolicyFullName, throwOnError: true);
            return Activator.CreateInstance(t, maxAttempts, initialDelayMs,
                                            multiplier, maxDelayMs)!;
        }

        /// <summary>
        /// Invokes GetDelay(int attempt, int? httpStatusCode, string? retryAfterHeader)
        /// on the given policy instance.
        /// </summary>
        private static TimeSpan? InvokeGetDelay(object policy, int attempt,
                                                int? httpStatusCode,
                                                string? retryAfterHeader)
        {
            var t = policy.GetType();
            var m = t.GetMethod("GetDelay", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)!;
            var result = m.Invoke(policy, new object?[] { attempt, httpStatusCode, retryAfterHeader });
            return (TimeSpan?)result;
        }

        // ---------------------------------------------------------------------
        // Tests
        // ---------------------------------------------------------------------

        [Fact]
        public void GetDelay_ReturnsNull_WhenAttemptExceedsMax()
        {
            // maxAttempts=3 means attempts 0,1,2 may retry; attempt 3 is the
            // boundary (>= maxAttempts) and returns null. attempt 5 is well
            // past the limit.
            var policy = CreatePolicy(maxAttempts: 3, initialDelayMs: 1000,
                                      multiplier: 2.0, maxDelayMs: 60000);

            Assert.Null(InvokeGetDelay(policy, attempt: 3, httpStatusCode: 503, retryAfterHeader: null));
            Assert.Null(InvokeGetDelay(policy, attempt: 5, httpStatusCode: 429, retryAfterHeader: null));
        }

        [Fact]
        public void GetDelay_HonoursRetryAfterHeader_DeltaSeconds()
        {
            // "Retry-After: 10" means wait 10 seconds. The policy must honour
            // the server's hint, capped at maxDelayMs.
            var policy = CreatePolicy(maxAttempts: 5, initialDelayMs: 1000,
                                      multiplier: 2.0, maxDelayMs: 60000);

            var delay = InvokeGetDelay(policy, attempt: 0, httpStatusCode: 429,
                                       retryAfterHeader: "10");

            Assert.NotNull(delay);
            Assert.Equal(TimeSpan.FromSeconds(10), delay!.Value);
        }

        [Fact]
        public void GetDelay_HonoursRetryAfterHeader_DeltaSecondsCapsAtMaxDelay()
        {
            // Server asks for 120s but maxDelayMs is 60s — the policy must
            // cap at 60s.
            var policy = CreatePolicy(maxAttempts: 5, initialDelayMs: 1000,
                                      multiplier: 2.0, maxDelayMs: 60000);

            var delay = InvokeGetDelay(policy, attempt: 0, httpStatusCode: 429,
                                       retryAfterHeader: "120");

            Assert.NotNull(delay);
            Assert.Equal(TimeSpan.FromSeconds(60), delay!.Value);
        }

        [Fact]
        public void GetDelay_HonoursRetryAfterHeader_HttpDate()
        {
            // Retry-After as an RFC 1123 HTTP date roughly 30s in the future.
            // The policy converts it to a delta from UtcNow.
            var policy = CreatePolicy(maxAttempts: 5, initialDelayMs: 1000,
                                      multiplier: 2.0, maxDelayMs: 60000);

            var future = DateTimeOffset.UtcNow.AddSeconds(30);
            var retryAfter = future.ToString("R"); // RFC 1123 format

            var delay = InvokeGetDelay(policy, attempt: 0, httpStatusCode: 503,
                                       retryAfterHeader: retryAfter);

            Assert.NotNull(delay);
            // Allow some slack for test execution time. The delta should be
            // close to 30s and capped at the 60s maxDelayMs.
            Assert.InRange(delay!.Value.TotalSeconds, 25, 35);
        }

        [Theory]
        [InlineData(400)] // Bad Request
        [InlineData(401)] // Unauthorized
        [InlineData(403)] // Forbidden
        [InlineData(404)] // Not Found
        [InlineData(410)] // Gone
        public void GetDelay_ReturnsNull_ForClient4xx(int statusCode)
        {
            var policy = CreatePolicy(maxAttempts: 5, initialDelayMs: 1000,
                                      multiplier: 2.0, maxDelayMs: 60000);

            var delay = InvokeGetDelay(policy, attempt: 0,
                                       httpStatusCode: statusCode,
                                       retryAfterHeader: null);

            // 4xx (except 429) are not retryable — the policy returns null
            // so the engine can mark the task as permanently failed.
            Assert.Null(delay);
        }

        [Theory]
        [InlineData(500)] // Internal Server Error
        [InlineData(502)] // Bad Gateway
        [InlineData(503)] // Service Unavailable
        [InlineData(504)] // Gateway Timeout
        public void GetDelay_ReturnsDelay_ForServer5xx(int statusCode)
        {
            var policy = CreatePolicy(maxAttempts: 5, initialDelayMs: 1000,
                                      multiplier: 2.0, maxDelayMs: 60000);

            var delay = InvokeGetDelay(policy, attempt: 0,
                                       httpStatusCode: statusCode,
                                       retryAfterHeader: null);

            Assert.NotNull(delay);
            Assert.True(delay!.Value > TimeSpan.Zero,
                $"Expected a positive retry delay for HTTP {statusCode}.");
        }

        [Fact]
        public void GetDelay_ReturnsDelay_For429()
        {
            // 429 (Too Many Requests) is retryable even though it's a 4xx.
            var policy = CreatePolicy(maxAttempts: 5, initialDelayMs: 1000,
                                      multiplier: 2.0, maxDelayMs: 60000);

            var delay = InvokeGetDelay(policy, attempt: 0,
                                       httpStatusCode: 429,
                                       retryAfterHeader: null);

            Assert.NotNull(delay);
            Assert.True(delay!.Value > TimeSpan.Zero);
        }

        [Fact]
        public void GetDelay_ReturnsDelay_ForNetworkErrors()
        {
            // When httpStatusCode is null (e.g., a DNS or connection failure),
            // the policy retries because no 4xx code was returned.
            var policy = CreatePolicy(maxAttempts: 5, initialDelayMs: 1000,
                                      multiplier: 2.0, maxDelayMs: 60000);

            var delay = InvokeGetDelay(policy, attempt: 0,
                                       httpStatusCode: null,
                                       retryAfterHeader: null);

            Assert.NotNull(delay);
            Assert.True(delay!.Value > TimeSpan.Zero);
        }

        [Fact]
        public void GetDelay_ExponentialBackoff_IncreasesWithAttempts()
        {
            // With multiplier=2.0 and initialDelay=1000ms, the base delay
            // doubles on each attempt. Even with the +25% jitter, the ranges
            // are strictly non-overlapping:
            //   attempt 0: [1000, 1250]
            //   attempt 1: [2000, 2500]
            //   attempt 2: [4000, 5000]
            // So delay0 < delay1 < delay2 must hold for any random jitter.
            var policy = CreatePolicy(maxAttempts: 5, initialDelayMs: 1000,
                                      multiplier: 2.0, maxDelayMs: 60000);

            var d0 = InvokeGetDelay(policy, 0, null, null)!;
            var d1 = InvokeGetDelay(policy, 1, null, null)!;
            var d2 = InvokeGetDelay(policy, 2, null, null)!;

            Assert.True(d0 < d1, $"Expected delay(0) < delay(1); got {d0} vs {d1}.");
            Assert.True(d1 < d2, $"Expected delay(1) < delay(2); got {d1} vs {d2}.");

            // Sanity-check the absolute ranges.
            Assert.InRange(d0.Value.TotalMilliseconds, 1000, 1250);
            Assert.InRange(d1.Value.TotalMilliseconds, 2000, 2500);
            Assert.InRange(d2.Value.TotalMilliseconds, 4000, 5000);
        }

        [Fact]
        public void GetDelay_RespectsMaxDelayCap()
        {
            // With a high attempt count and a low maxDelayMs, the backoff
            // must be capped. Use a very small maxDelay to make the cap
            // obvious.
            var policy = CreatePolicy(maxAttempts: 10, initialDelayMs: 1000,
                                      multiplier: 4.0, maxDelayMs: 5000);

            // The base delay at attempt 3 would be 1000 * 4^3 = 64000ms,
            // but the cap is 5000ms.
            var delay = InvokeGetDelay(policy, attempt: 3, httpStatusCode: null,
                                       retryAfterHeader: null);

            Assert.NotNull(delay);
            // Cap plus up to 25% jitter on the uncapped base — but the cap
            // is applied to base+jitter, so the actual delay is at most
            // maxDelayMs.
            Assert.True(delay!.Value.TotalMilliseconds <= 5000,
                $"Delay {delay} exceeded maxDelayMs cap.");
        }
    }
}
