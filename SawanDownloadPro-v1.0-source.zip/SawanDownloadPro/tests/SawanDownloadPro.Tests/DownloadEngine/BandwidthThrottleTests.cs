using System;
using System.Reflection;
using System.Threading;
using SawanDownloadPro.DownloadEngine;
using Xunit;

namespace SawanDownloadPro.Tests.DownloadEngine
{
    /// <summary>
    /// Unit tests for the internal <c>BandwidthThrottle</c> class
    /// (<see cref="SawanDownloadPro.DownloadEngine.Throttling.BandwidthThrottle"/>).
    /// </summary>
    /// <remarks>
    /// <para>
    /// <c>BandwidthThrottle</c> is <c>internal sealed</c> and the production
    /// project does not expose it via <c>InternalsVisibleTo</c>. Worse, the
    /// key <c>RequestQuota</c> method is NOT on the public
    /// <see cref="SawanDownloadPro.Core.Interfaces.IBandwidthThrottle"/>
    /// interface, so even casting the reflected instance to the interface
    /// would not let us call it. We therefore invoke every method through
    /// reflection.
    /// </para>
    /// <para>
    /// The tests use a real <c>BandwidthThrottle</c> instance — no mocks —
    /// with short time windows and small limits so each test runs in well
    /// under a second. None of the tests should block indefinitely; if a
    /// bug causes the throttle to spin, the test runner's default timeout
    /// will surface it.
    /// </para>
    /// </remarks>
    public class BandwidthThrottleTests
    {
        // ---------------------------------------------------------------------
        // Reflection helpers
        // ---------------------------------------------------------------------

        private const string ThrottleFullName =
            "SawanDownloadPro.DownloadEngine.Throttling.BandwidthThrottle";

        /// <summary>
        /// Creates a BandwidthThrottle via reflection. The constructor takes
        /// an optional initial global limit (default 0 = unlimited).
        /// </summary>
        private static object CreateThrottle(long initialGlobalLimit = 0)
        {
            var asm = typeof(SawanDownloadPro.DownloadEngine.DownloadEngine).Assembly;
            var t = asm.GetType(ThrottleFullName, throwOnError: true)!;
            return Activator.CreateInstance(t, initialGlobalLimit)!;
        }

        private static void InvokeSetGlobalLimit(object throttle, long bytesPerSec)
        {
            var t = throttle.GetType();
            t.GetMethod("SetGlobalLimit")!.Invoke(throttle, new object[] { bytesPerSec });
        }

        private static void InvokeSetPerTaskLimit(object throttle, string taskId, long bytesPerSec)
        {
            var t = throttle.GetType();
            t.GetMethod("SetPerTaskLimit")!.Invoke(throttle, new object[] { taskId, bytesPerSec });
        }

        private static long InvokeGetConsumedBytes(object throttle, string taskId)
        {
            var t = throttle.GetType();
            var result = t.GetMethod("GetConsumedBytes")!.Invoke(throttle, new object[] { taskId });
            return (long)result!;
        }

        private static void InvokeReset(object throttle)
        {
            var t = throttle.GetType();
            t.GetMethod("Reset")!.Invoke(throttle, Array.Empty<object>());
        }

        /// <summary>
        /// Invokes <c>RequestQuota(string taskId, int bytesRequested, CancellationToken ct)</c>.
        /// Returns the number of bytes granted (always ≤ requested).
        /// </summary>
        private static int InvokeRequestQuota(object throttle, string taskId,
                                              int bytesRequested, CancellationToken ct)
        {
            var t = throttle.GetType();
            var m = t.GetMethod("RequestQuota",
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)!;
            var result = m.Invoke(throttle, new object[] { taskId, bytesRequested, ct });
            return (int)result!;
        }

        // ---------------------------------------------------------------------
        // Tests
        // ---------------------------------------------------------------------

        [Fact]
        public void SetGlobalLimit_EnforcesLimit()
        {
            // Start with no global limit; then impose a 100-byte/sec cap and
            // request 200. The granted amount must be bounded by the limit
            // (and the call must not block — there is plenty of capacity in
            // the current 1-second window).
            var throttle = CreateThrottle(initialGlobalLimit: 0);
            InvokeSetGlobalLimit(throttle, 100);

            // Use a CancellationToken that fails fast in case the throttle
            // erroneously blocks. The test should complete in milliseconds.
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));
            int granted = InvokeRequestQuota(throttle, "task1", 200, cts.Token);

            Assert.True(granted <= 100,
                $"Granted {granted} bytes exceeded the 100-byte/sec global limit.");
            // Since 200 > 100 and the window is fresh, we expect the full
            // limit to be granted.
            Assert.Equal(100, granted);
        }

        [Fact]
        public void SetPerTaskLimit_EnforcesPerTaskLimit()
        {
            var throttle = CreateThrottle(initialGlobalLimit: 0);
            InvokeSetPerTaskLimit(throttle, "task1", 100);

            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));
            int granted = InvokeRequestQuota(throttle, "task1", 200, cts.Token);

            Assert.True(granted <= 100,
                $"Granted {granted} bytes exceeded the 100-byte/sec per-task limit.");
            Assert.Equal(100, granted);
        }

        [Fact]
        public void Reset_ClearsState()
        {
            var throttle = CreateThrottle(initialGlobalLimit: 0);
            InvokeSetPerTaskLimit(throttle, "task1", 10000);

            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));
            int granted = InvokeRequestQuota(throttle, "task1", 500, cts.Token);
            Assert.Equal(500, granted);

            // Sanity: the bucket's ConsumedTotal is non-zero before Reset.
            long consumedBefore = InvokeGetConsumedBytes(throttle, "task1");
            Assert.Equal(500, consumedBefore);

            InvokeReset(throttle);

            // After Reset, the bucket is gone, so GetConsumedBytes returns 0.
            long consumedAfter = InvokeGetConsumedBytes(throttle, "task1");
            Assert.Equal(0, consumedAfter);
        }

        [Fact]
        public void GetConsumedBytes_TracksConsumption()
        {
            var throttle = CreateThrottle(initialGlobalLimit: 0);
            InvokeSetPerTaskLimit(throttle, "task1", 10000);

            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));

            int granted1 = InvokeRequestQuota(throttle, "task1", 500, cts.Token);
            Assert.Equal(500, granted1);
            Assert.Equal(500, InvokeGetConsumedBytes(throttle, "task1"));

            int granted2 = InvokeRequestQuota(throttle, "task1", 300, cts.Token);
            Assert.Equal(300, granted2);
            Assert.Equal(800, InvokeGetConsumedBytes(throttle, "task1"));

            // A different task has its own bucket.
            InvokeSetPerTaskLimit(throttle, "task2", 10000);
            int granted3 = InvokeRequestQuota(throttle, "task2", 100, cts.Token);
            Assert.Equal(100, granted3);
            Assert.Equal(100, InvokeGetConsumedBytes(throttle, "task2"));
            // task1's consumption is unaffected by task2's traffic.
            Assert.Equal(800, InvokeGetConsumedBytes(throttle, "task1"));
        }

        [Fact]
        public void GetConsumedBytes_ReturnsZeroForUnknownTask()
        {
            var throttle = CreateThrottle(initialGlobalLimit: 0);
            Assert.Equal(0, InvokeGetConsumedBytes(throttle, "never-seen"));
        }

        [Fact]
        public void GlobalLimitAppliesAcrossTasks()
        {
            // Two tasks share a single global bucket. After exhausting the
            // global budget for this second, the second task's request must
            // be bounded (or block until the next second — which the test
            // avoids by requesting a small enough amount that there's
            // capacity remaining, then verifying the totals add up).
            var throttle = CreateThrottle(initialGlobalLimit: 0);
            InvokeSetGlobalLimit(throttle, 1000);
            InvokeSetPerTaskLimit(throttle, "task1", 10000);
            InvokeSetPerTaskLimit(throttle, "task2", 10000);

            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));

            int g1 = InvokeRequestQuota(throttle, "task1", 400, cts.Token);
            int g2 = InvokeRequestQuota(throttle, "task2", 400, cts.Token);

            // Both requests fit comfortably under the 1000-byte global cap.
            Assert.Equal(400, g1);
            Assert.Equal(400, g2);

            // A third request that would exceed the global cap is bounded.
            int g3 = InvokeRequestQuota(throttle, "task1", 400, cts.Token);
            // 400 + 400 = 800 already consumed; only 200 remains this second.
            Assert.True(g3 <= 200,
                $"Granted {g3} bytes would have exceeded the remaining global budget.");
            Assert.Equal(200, g3);
        }

        [Fact]
        public void ZeroGlobalLimitMeansUnlimited()
        {
            // With no limit set, RequestQuota grants the full request.
            var throttle = CreateThrottle(initialGlobalLimit: 0);

            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));
            int granted = InvokeRequestQuota(throttle, "lonely", 5000, cts.Token);

            Assert.Equal(5000, granted);
        }
    }
}
