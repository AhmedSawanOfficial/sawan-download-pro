using System;
using System.Net;
using System.Reflection;
using SawanDownloadPro.DownloadEngine;
using SawanDownloadPro.Tests.TestInfrastructure;
using Xunit;

namespace SawanDownloadPro.Tests.DownloadEngine
{
    /// <summary>
    /// Unit tests for the internal <c>FileNameExtractor</c> class
    /// (<see cref="SawanDownloadPro.DownloadEngine.Http.FileNameExtractor"/>).
    /// </summary>
    /// <remarks>
    /// <para>
    /// <c>FileNameExtractor</c> is <c>internal static</c> and the production
    /// project does not expose it via <c>InternalsVisibleTo</c>. We invoke
    /// the <c>ExtractFromResponse</c> method through reflection.
    /// </para>
    /// <para>
    /// The method requires a real <see cref="HttpWebResponse"/> instance,
    /// which can only be obtained by making an HTTP request. We use the
    /// <see cref="LocalHttpServer"/> TCP-based helper (no admin rights /
    /// URL ACL needed) to spin up a local server, send a configured response,
    /// and capture the resulting <c>HttpWebResponse</c>.
    /// </para>
    /// <para>
    /// <b>Linux limitation:</b> The production projects target <c>net48</c>
    /// and cannot be compiled on Linux, so these tests cannot be executed
    /// here. They are written to compile and pass on Windows.
    /// </para>
    /// </remarks>
    public class FileNameExtractorTests : IDisposable
    {
        private const string ExtractorFullName =
            "SawanDownloadPro.DownloadEngine.Http.FileNameExtractor";

        private readonly LocalHttpServer _server = new LocalHttpServer();

        public void Dispose() => _server.Dispose();

        // ---------------------------------------------------------------------
        // Reflection helper
        // ---------------------------------------------------------------------

        /// <summary>
        /// Invokes the internal static
        /// <c>ExtractFromResponse(HttpWebResponse resp, string originalUrl)</c>
        /// method via reflection and returns the extracted filename.
        /// </summary>
        private static string InvokeExtractFromResponse(HttpWebResponse resp, string originalUrl)
        {
            var asm = typeof(SawanDownloadPro.DownloadEngine.DownloadEngine).Assembly;
            var t = asm.GetType(ExtractorFullName, throwOnError: true)!;
            var m = t.GetMethod("ExtractFromResponse",
                BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)!;
            var result = m.Invoke(null, new object[] { resp, originalUrl });
            return (string)result!;
        }

        /// <summary>
        /// Makes a GET request to the local server and returns the
        /// <see cref="HttpWebResponse"/>. The server must already be
        /// configured via <see cref="LocalHttpServer.ConfigureResponse"/>.
        /// </summary>
        private static HttpWebResponse GetResponse(string url)
        {
            var req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = "GET";
            req.Timeout = 5000;
            req.ReadWriteTimeout = 5000;
            // The body is irrelevant for these tests; the server always
            // returns Content-Length: 0.
            return (HttpWebResponse)req.GetResponse();
        }

        // ---------------------------------------------------------------------
        // Tests
        // ---------------------------------------------------------------------

        [Fact]
        public void ExtractFromResponse_PrefersContentDisposition()
        {
            // The server returns a Content-Disposition header; the extractor
            // must use it over the URL path segment.
            _server.ConfigureResponse(rb => rb
                .WithStatus(200, "OK")
                .WithHeader("Content-Disposition", "attachment; filename=\"report.pdf\""));

            string requestUrl = _server.BaseUrl + "ignored_segment.zip";
            using var resp = GetResponse(requestUrl);

            var result = InvokeExtractFromResponse(resp, requestUrl);

            Assert.Equal("report.pdf", result);
        }

        [Fact]
        public void ExtractFromResponse_PrefersContentDisposition_FilenameStar()
        {
            // RFC 5987 filename*=UTF-8''<percent-encoded> form.
            _server.ConfigureResponse(rb => rb
                .WithStatus(200, "OK")
                .WithHeader("Content-Disposition",
                    "attachment; filename*=UTF-8''%E2%82%AC%20rates.txt"));

            string requestUrl = _server.BaseUrl + "ignored.zip";
            using var resp = GetResponse(requestUrl);

            var result = InvokeExtractFromResponse(resp, requestUrl);

            // The percent-encoded "€ rates.txt" survives as the filename.
            Assert.EndsWith("rates.txt", result);
        }

        [Fact]
        public void ExtractFromResponse_FallsBackToUrlSegment()
        {
            // No Content-Disposition; the extractor falls back to the last
            // path segment of the request URL.
            _server.ConfigureResponse(rb => rb
                .WithStatus(200, "OK"));

            string requestUrl = _server.BaseUrl + "sawan_installer.zip";
            using var resp = GetResponse(requestUrl);

            var result = InvokeExtractFromResponse(resp, requestUrl);

            Assert.Equal("sawan_installer.zip", result);
        }

        [Fact]
        public void ExtractFromResponse_FallsBackToUrlSegment_UnescapesPercentEncoding()
        {
            // URL-encoded segments should be percent-decoded before being
            // used as the filename.
            _server.ConfigureResponse(rb => rb
                .WithStatus(200, "OK"));

            string requestUrl = _server.BaseUrl + "hello%20world.txt";
            using var resp = GetResponse(requestUrl);

            var result = InvokeExtractFromResponse(resp, requestUrl);

            Assert.Equal("hello world.txt", result);
        }

        [Fact]
        public void ExtractFromResponse_FallsBackToGuid()
        {
            // No Content-Disposition and no usable path segment (URL ends
            // with '/'). The extractor must produce a stable fallback name
            // of the form "sawan_download_<8 hex chars>".
            _server.ConfigureResponse(rb => rb
                .WithStatus(200, "OK"));

            string requestUrl = _server.BaseUrl;  // ends with '/'
            using var resp = GetResponse(requestUrl);

            var result = InvokeExtractFromResponse(resp, requestUrl);

            Assert.StartsWith("sawan_download_", result);
            // "sawan_download_" is 15 chars; the Guid suffix is 8 hex chars.
            Assert.Equal(15 + 8, result.Length);
            // The 8-char suffix must be a valid hex substring of a Guid ("N" format).
            string suffix = result.Substring(15);
            Assert.Matches("^[0-9a-f]{8}$", suffix);
        }

        [Fact]
        public void ExtractFromResponse_FallsBackToGuid_WhenSegmentIsRootOnly()
        {
            // URL with no path beyond the host — segments[0] is "/".
            _server.ConfigureResponse(rb => rb
                .WithStatus(200, "OK"));

            // Build a URL with no path (the helper's BaseUrl always ends
            // with '/', so requesting it directly exercises the root case).
            string requestUrl = _server.BaseUrl;
            using var resp = GetResponse(requestUrl);

            var result = InvokeExtractFromResponse(resp, requestUrl);

            Assert.StartsWith("sawan_download_", result);
            Assert.Equal(15 + 8, result.Length);
        }

        [Fact]
        public void ExtractFromResponse_SanitizesContentDispositionFilename()
        {
            // A Content-Disposition filename containing invalid filename
            // characters should be sanitized (replaced with '_') rather than
            // returned verbatim. We use a forward slash, which is invalid
            // in Windows filenames.
            _server.ConfigureResponse(rb => rb
                .WithStatus(200, "OK")
                .WithHeader("Content-Disposition", "attachment; filename=\"path/to/file.txt\""));

            string requestUrl = _server.BaseUrl + "anything";
            using var resp = GetResponse(requestUrl);

            var result = InvokeExtractFromResponse(resp, requestUrl);

            Assert.DoesNotContain("/", result);
            Assert.EndsWith("file.txt", result);
        }
    }
}
