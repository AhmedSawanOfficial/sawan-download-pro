using SawanDownloadPro.Storage.Schema;
using Xunit;

namespace SawanDownloadPro.Tests.Storage
{
    /// <summary>
    /// Smoke tests for the embedded SQLite schema in <see cref="SchemaV1"/>.
    /// </summary>
    /// <remarks>
    /// <para>
    /// These tests do not create a real SQLite database — that requires the
    /// <c>System.Data.SQLite.Core</c> native interop binary, which only
    /// loads on Windows (or with Mono's SQLite on Linux). Instead, we verify
    /// that the schema SQL constants contain the expected
    /// <c>CREATE TABLE IF NOT EXISTS</c> statements and the expected columns.
    /// </para>
    /// <para>
    /// Full database tests (insert / query / migrate) belong in a Windows-
    /// only integration test project that this smoke suite does not replace.
    /// </para>
    /// </remarks>
    public class SchemaTests
    {
        // ---------------------------------------------------------------------
        // downloads
        // ---------------------------------------------------------------------

        [Fact]
        public void SchemaV1_CreateDownloads_ContainsCreateTable()
        {
            Assert.Contains("CREATE TABLE IF NOT EXISTS downloads", SchemaV1.CreateDownloads);
        }

        [Fact]
        public void SchemaV1_CreateDownloads_HasExpectedColumns()
        {
            var sql = SchemaV1.CreateDownloads;

            // Primary key.
            Assert.Contains("id                   TEXT PRIMARY KEY", sql);
            // Required fields.
            Assert.Contains("url                  TEXT NOT NULL", sql);
            Assert.Contains("file_name            TEXT NOT NULL", sql);
            Assert.Contains("save_path            TEXT NOT NULL", sql);
            Assert.Contains("category             TEXT NOT NULL", sql);
            Assert.Contains("status               TEXT NOT NULL", sql);
            Assert.Contains("created_at           TEXT NOT NULL", sql);
            // Optional metadata.
            Assert.Contains("final_url            TEXT", sql);
            Assert.Contains("total_bytes          INTEGER", sql);
            Assert.Contains("etag                 TEXT", sql);
            Assert.Contains("last_modified        TEXT", sql);
            Assert.Contains("accept_ranges        INTEGER NOT NULL DEFAULT 0", sql);
            // Auth (password is encrypted at the storage boundary).
            Assert.Contains("auth_password_enc    BLOB", sql);
            Assert.Contains("custom_headers_json  TEXT", sql);
        }

        // ---------------------------------------------------------------------
        // segments
        // ---------------------------------------------------------------------

        [Fact]
        public void SchemaV1_CreateSegments_ContainsCreateTable()
        {
            Assert.Contains("CREATE TABLE IF NOT EXISTS segments", SchemaV1.CreateSegments);
        }

        [Fact]
        public void SchemaV1_CreateSegments_HasForeignKeyToDownloads()
        {
            Assert.Contains("FOREIGN KEY (download_id) REFERENCES downloads(id) ON DELETE CASCADE",
                SchemaV1.CreateSegments);
        }

        [Fact]
        public void SchemaV1_CreateSegments_HasIndexOnDownloadId()
        {
            Assert.Contains("CREATE INDEX IF NOT EXISTS idx_segments_download_id ON segments(download_id)",
                SchemaV1.CreateSegments);
        }

        [Fact]
        public void SchemaV1_CreateSegments_HasByteRangeColumns()
        {
            var sql = SchemaV1.CreateSegments;
            Assert.Contains("start_byte         INTEGER NOT NULL", sql);
            Assert.Contains("end_byte           INTEGER NOT NULL", sql);
            Assert.Contains("downloaded_bytes   INTEGER NOT NULL DEFAULT 0", sql);
            Assert.Contains("position           INTEGER NOT NULL", sql);
            Assert.Contains("status             TEXT NOT NULL", sql);
        }

        // ---------------------------------------------------------------------
        // settings
        // ---------------------------------------------------------------------

        [Fact]
        public void SchemaV1_CreateSettings_ContainsCreateTable()
        {
            Assert.Contains("CREATE TABLE IF NOT EXISTS settings", SchemaV1.CreateSettings);
        }

        [Fact]
        public void SchemaV1_CreateSettings_IsKeyValueStore()
        {
            var sql = SchemaV1.CreateSettings;
            Assert.Contains("key        TEXT PRIMARY KEY", sql);
            Assert.Contains("value      TEXT NOT NULL", sql);
            Assert.Contains("updated_at TEXT NOT NULL", sql);
        }

        // ---------------------------------------------------------------------
        // history
        // ---------------------------------------------------------------------

        [Fact]
        public void SchemaV1_CreateHistory_ContainsCreateTable()
        {
            Assert.Contains("CREATE TABLE IF NOT EXISTS history", SchemaV1.CreateHistory);
        }

        [Fact]
        public void SchemaV1_CreateHistory_HasIndexOnCompletedAt()
        {
            Assert.Contains("CREATE INDEX IF NOT EXISTS idx_history_completed_at ON history(completed_at DESC)",
                SchemaV1.CreateHistory);
        }

        [Fact]
        public void SchemaV1_CreateHistory_HasDeletedFlag()
        {
            Assert.Contains("deleted      INTEGER NOT NULL DEFAULT 0", SchemaV1.CreateHistory);
        }

        // ---------------------------------------------------------------------
        // schema_migrations
        // ---------------------------------------------------------------------

        [Fact]
        public void SchemaV1_CreateSchemaMigrations_ContainsCreateTable()
        {
            Assert.Contains("CREATE TABLE IF NOT EXISTS schema_migrations", SchemaV1.CreateSchemaMigrations);
        }

        [Fact]
        public void SchemaV1_CreateSchemaMigrations_HasVersionAndAppliedAt()
        {
            var sql = SchemaV1.CreateSchemaMigrations;
            Assert.Contains("version     INTEGER PRIMARY KEY", sql);
            Assert.Contains("applied_at  TEXT NOT NULL", sql);
        }

        // ---------------------------------------------------------------------
        // Aggregate smoke test
        // ---------------------------------------------------------------------

        [Fact]
        public void AllSchemaConstants_AreNonEmptyAndStartWithCreateTable()
        {
            var all = new[]
            {
                SchemaV1.CreateDownloads,
                SchemaV1.CreateSegments,
                SchemaV1.CreateSettings,
                SchemaV1.CreateHistory,
                SchemaV1.CreateSchemaMigrations
            };

            foreach (var sql in all)
            {
                Assert.False(string.IsNullOrWhiteSpace(sql));
                Assert.StartsWith("CREATE TABLE IF NOT EXISTS", sql.TrimStart());
            }
        }
    }
}
