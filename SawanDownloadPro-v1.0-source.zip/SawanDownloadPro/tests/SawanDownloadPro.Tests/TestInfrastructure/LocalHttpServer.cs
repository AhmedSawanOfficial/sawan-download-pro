using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace SawanDownloadPro.Tests.TestInfrastructure
{
    /// <summary>
    /// A tiny TCP-based HTTP/1.1 server used by tests that need a real
    /// <see cref="HttpWebResponse"/> instance (e.g. to exercise the
    /// <c>FileNameExtractor</c>).
    /// </summary>
    /// <remarks>
    /// <para>
    /// We deliberately avoid <see cref="HttpListener"/>: on Windows it
    /// requires either admin rights or a pre-registered URL ACL
    /// (<c>netsh http add urlacl</c>), which the test runner cannot assume.
    /// A bare <see cref="TcpListener"/> bound to <c>127.0.0.1</c> on an
    /// ephemeral port needs no special permissions and is enough to speak
    /// HTTP/1.1 for a single request/response pair.
    /// </para>
    /// <para>
    /// The server is single-threaded and serves one request at a time. Each
    /// call to <see cref="StartRequest"/> configures the response that will
    /// be sent to the next client connection. After the response is written,
    /// the connection is closed.
    /// </para>
    /// <para>
    /// This is a smoke-test helper: it does not support keep-alive, chunked
    /// encoding, or HTTPS. The tests in <c>FileNameExtractorTests</c> only
    /// need a status line, headers, and (optionally) a tiny body, which this
    /// helper provides.
    /// </para>
    /// </remarks>
    public sealed class LocalHttpServer : IDisposable
    {
        private readonly TcpListener _listener;
        private readonly Thread _serverThread;
        private volatile bool _running;
        private Action<ResponseBuilder> _configureResponse = _ => { };

        /// <summary>
        /// The base URL that clients should connect to (e.g.
        /// <c>http://localhost:54321/</c>).
        /// </summary>
        public string BaseUrl { get; }

        public LocalHttpServer()
        {
            _listener = new TcpListener(IPAddress.Loopback, 0);
            _listener.Start();
            var port = ((IPEndPoint)_listener.LocalEndpoint).Port;
            BaseUrl = $"http://localhost:{port}/";

            _running = true;
            _serverThread = new Thread(ServerLoop) { IsBackground = true, Name = "LocalHttpServer" };
            _serverThread.Start();
        }

        /// <summary>
        /// Configures the response that will be sent for the next request.
        /// The provided callback receives a <see cref="ResponseBuilder"/>
        /// and populates it with status code, headers, and optional body.
        /// </summary>
        public void ConfigureResponse(Action<ResponseBuilder> configure)
        {
            _configureResponse = configure ?? throw new ArgumentNullException(nameof(configure));
        }

        private void ServerLoop()
        {
            while (_running)
            {
                TcpClient? client = null;
                try
                {
                    client = _listener.AcceptTcpClient();
                }
                catch (SocketException)
                {
                    // Listener stopped.
                    break;
                }

                try
                {
                    HandleClient(client);
                }
                catch
                {
                    // Swallow per-client errors; the test will surface a
                    // timeout or assertion failure if the response was wrong.
                }
                finally
                {
                    try { client.Dispose(); } catch { }
                }
            }
        }

        private void HandleClient(TcpClient client)
        {
            using var stream = client.GetStream();
            // Read the request line and headers (we discard them — the test
            // does not assert on the request side).
            ReadRequestHeaders(stream);

            // Build and write the response.
            var builder = new ResponseBuilder();
            _configureResponse(builder);

            var sb = new StringBuilder();
            sb.Append("HTTP/1.1 ").Append(builder.StatusCode).Append(' ')
              .Append(builder.ReasonPhrase).Append("\r\n");
            foreach (var kv in builder.Headers)
            {
                sb.Append(kv.Key).Append(": ").Append(kv.Value).Append("\r\n");
            }
            // Always send a Content-Length so HttpWebRequest is happy.
            if (!builder.HasContentLength)
            {
                sb.Append("Content-Length: ").Append(builder.Body?.Length ?? 0).Append("\r\n");
            }
            sb.Append("\r\n");

            var headerBytes = Encoding.ASCII.GetBytes(sb.ToString());
            stream.Write(headerBytes, 0, headerBytes.Length);
            if (builder.Body != null && builder.Body.Length > 0)
            {
                stream.Write(builder.Body, 0, builder.Body.Length);
            }
            stream.Flush();
        }

        private static void ReadRequestHeaders(NetworkStream stream)
        {
            // Read byte-by-byte until we hit \r\n\r\n. We do not parse the
            // headers; we just consume them so the request side is clean.
            int prev = -1, cur = -1;
            int blankLineCount = 0;
            while (true)
            {
                int b = stream.ReadByte();
                if (b < 0) break;
                prev = cur;
                cur = b;
                if (prev == '\n' && cur == '\r')
                {
                    // Possibly the start of the final blank line. Peek the
                    // next byte; if it's \n, we're done.
                    // (Read the \n that follows the \r.)
                    int n = stream.ReadByte();
                    if (n == '\n') blankLineCount++;
                    cur = n;
                    if (blankLineCount >= 1) break;
                }
                else if (prev == '\n' && cur == '\n')
                {
                    // Bare \n\n terminator.
                    break;
                }
            }
        }

        public void Dispose()
        {
            _running = false;
            try { _listener.Stop(); } catch { }
            // The server thread will exit on the next AcceptTcpClient failure.
        }

        /// <summary>
        /// Fluent builder for a single HTTP response.
        /// </summary>
        public sealed class ResponseBuilder
        {
            public int StatusCode { get; set; } = 200;
            public string ReasonPhrase { get; set; } = "OK";
            public List<KeyValuePair<string, string>> Headers { get; } = new();
            public byte[]? Body { get; private set; }

            public bool HasContentLength =>
                Headers.Exists(kv => string.Equals(kv.Key, "Content-Length", StringComparison.OrdinalIgnoreCase));

            public ResponseBuilder WithStatus(int code, string reason)
            {
                StatusCode = code;
                ReasonPhrase = reason;
                return this;
            }

            public ResponseBuilder WithHeader(string name, string value)
            {
                Headers.Add(new KeyValuePair<string, string>(name, value));
                return this;
            }

            public ResponseBuilder WithBody(string body, Encoding? encoding = null)
            {
                Body = (encoding ?? Encoding.UTF8).GetBytes(body);
                return this;
            }
        }
    }
}
