using System;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace SawanDownloadPro.Tests.TestInfrastructure
{
    /// <summary>
    /// Builds no-op <see cref="ILogger"/> / <see cref="ILogger{TCategoryName}"/>
    /// instances for use by unit tests that need to satisfy a logger dependency
    /// but do not want to assert on log output.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <see cref="NullLogger"/> and <see cref="NullLogger{T}"/> come from
    /// <c>Microsoft.Extensions.Logging.Abstractions</c>, which is pulled in
    /// transitively by the <c>Microsoft.Extensions.Logging</c> 6.0.4 package
    /// referenced by this test project.
    /// </para>
    /// <para>
    /// For tests that DO want to assert on log output, swap in a capturing
    /// logger (e.g. a small <see cref="ILogger{T}"/> implementation backed by
    /// a <see cref="System.Collections.Generic.List{String}"/>).
    /// </para>
    /// </remarks>
    public static class LoggerFactory
    {
        /// <summary>
        /// Returns a no-op <see cref="ILogger{TCategoryName}"/>.
        /// </summary>
        public static ILogger<T> Create<T>() => NullLogger<T>.Instance;

        /// <summary>
        /// Returns a no-op non-generic <see cref="ILogger"/>. Useful for
        /// satisfying the <see cref="SawanDownloadPro.Security.Validation.PathSanitizer"/>
        /// constructor, which takes a plain <see cref="ILogger"/>.
        /// </summary>
        public static ILogger Create() => NullLogger.Instance;

        /// <summary>
        /// Returns a no-op <see cref="ILogger"/> typed for a specific category.
        /// Equivalent to <see cref="Create{T}"/> but usable via <c>typeof(T)</c>.
        /// </summary>
        public static ILogger Create(Type category) => NullLogger.Instance;
    }
}
