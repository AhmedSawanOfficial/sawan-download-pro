using System.Collections.Generic;
using System.Threading.Tasks;
using Moq;
using SawanDownloadPro.Core.Enums;
using SawanDownloadPro.Core.Interfaces;
using SawanDownloadPro.Core.Models;
using SawanDownloadPro.Scheduler;
using SawanDownloadPro.Tests.TestInfrastructure;
using Xunit;

namespace SawanDownloadPro.Tests.Scheduler
{
    /// <summary>
    /// Unit tests for <see cref="DownloadScheduler"/> state transitions.
    /// </summary>
    /// <remarks>
    /// <para>
    /// These tests exercise the scheduler's <c>Enqueue</c>, <c>Pause</c>,
    /// <c>Cancel</c>, <c>StopAll</c>, and <c>StartAll</c> methods in
    /// isolation. They are state-transition tests, not end-to-end downloads:
    /// <list type="bullet">
    ///   <item><see cref="IDownloadEngine"/> is mocked — no real HTTP is made.</item>
    ///   <item><see cref="IDownloadTaskStore"/> is mocked — no SQLite is used.</item>
    ///   <item><see cref="ISettingsStore"/> is mocked — no settings file is read.</item>
    /// </list>
    /// </para>
    /// <para>
    /// The scheduler's <c>InitializeAsync</c> method is intentionally NOT
    /// called — it wires up engine events and starts a 1-Hz poller timer
    /// that we do not need (and do not want running) for these unit tests.
    /// Without <c>InitializeAsync</c>, the scheduler's <c>_settings</c>
    /// field remains null, which causes <c>PollQueue</c> to early-return —
    /// exactly what we want so that <c>Enqueue</c> does not start tasks.
    /// </para>
    /// </remarks>
    public class DownloadSchedulerTests
    {
        private readonly Mock<IDownloadEngine> _engineMock = new Mock<IDownloadEngine>();
        private readonly Mock<IDownloadTaskStore> _storeMock = new Mock<IDownloadTaskStore>();
        private readonly Mock<ISettingsStore> _settingsMock = new Mock<ISettingsStore>();

        private DownloadScheduler CreateScheduler()
        {
            // Make every store call return a completed task so the
            // fire-and-forget pattern in the scheduler does not blow up
            // when the mock's default Task return value is null.
            _storeMock
                .Setup(s => s.UpdateStatusAsync(
                    It.IsAny<string>(),
                    It.IsAny<DownloadStatus>(),
                    It.IsAny<long>(),
                    It.IsAny<string?>()))
                .Returns(Task.CompletedTask);

            return new DownloadScheduler(
                _engineMock.Object,
                _storeMock.Object,
                _settingsMock.Object,
                LoggerFactory.Create<DownloadScheduler>());
        }

        private static DownloadTask MakeTask(DownloadStatus status = DownloadStatus.Stopped)
            => new DownloadTask
            {
                Id = "test-task-1",
                Url = "https://example.com/file.zip",
                FileName = "file.zip",
                SavePath = @"C:\Downloads",
                Status = status
            };

        // ---------------------------------------------------------------------
        // Enqueue
        // ---------------------------------------------------------------------

        [Fact]
        public void Enqueue_AddsToQueue()
        {
            var scheduler = CreateScheduler();
            var task = MakeTask(DownloadStatus.Stopped);

            scheduler.Enqueue(task);

            // The scheduler sets the status synchronously.
            Assert.Equal(DownloadStatus.Queued, task.Status);

            // The store is notified (fire-and-forget, but Moq records the
            // call synchronously when the method is invoked).
            _storeMock.Verify(
                s => s.UpdateStatusAsync(task.Id, DownloadStatus.Queued, task.DownloadedBytes, null),
                Times.Once);
        }

        [Fact]
        public void Enqueue_DoesNothing_WhenSchedulerIsStopped()
        {
            // StopAll flips _stopped=true; subsequent Enqueue must early-return
            // without touching the task's status.
            var scheduler = CreateScheduler();
            var task = MakeTask(DownloadStatus.Paused);

            scheduler.StopAll();
            scheduler.Enqueue(task);

            Assert.Equal(DownloadStatus.Paused, task.Status);
            _storeMock.Verify(
                s => s.UpdateStatusAsync(It.IsAny<string>(), It.IsAny<DownloadStatus>(),
                                         It.IsAny<long>(), It.IsAny<string?>()),
                Times.Never);
        }

        // ---------------------------------------------------------------------
        // Pause
        // ---------------------------------------------------------------------

        [Fact]
        public void Pause_SetsStatusToPaused()
        {
            var scheduler = CreateScheduler();
            var task = MakeTask(DownloadStatus.Downloading);

            scheduler.Pause(task);

            Assert.Equal(DownloadStatus.Paused, task.Status);
            _storeMock.Verify(
                s => s.UpdateStatusAsync(task.Id, DownloadStatus.Paused, task.DownloadedBytes, null),
                Times.Once);
        }

        // ---------------------------------------------------------------------
        // Cancel
        // ---------------------------------------------------------------------

        [Fact]
        public void Cancel_SetsStatusToStopped()
        {
            var scheduler = CreateScheduler();
            var task = MakeTask(DownloadStatus.Downloading);

            scheduler.Cancel(task);

            Assert.Equal(DownloadStatus.Stopped, task.Status);
            // Cancel stores an explicit error message.
            _storeMock.Verify(
                s => s.UpdateStatusAsync(task.Id, DownloadStatus.Stopped, task.DownloadedBytes, "Cancelled by user"),
                Times.Once);
        }

        // ---------------------------------------------------------------------
        // StopAll
        // ---------------------------------------------------------------------

        [Fact]
        public void StopAll_StopsRunningTasks()
        {
            // Strategy: schedule a task that's already running (we mock the
            // engine so it never actually downloads), call StopAll, and then
            // verify that the scheduler refuses to enqueue new tasks and
            // that the engine's ExecuteAsync was cancelled.
            //
            // However, since _settings is null (we never call InitializeAsync),
            // PollQueue early-returns and never starts tasks. We therefore
            // verify StopAll's observable effect via the Enqueue-no-op path:
            // after StopAll, Enqueue must be a no-op.
            var scheduler = CreateScheduler();
            var task1 = MakeTask(DownloadStatus.Paused);
            var task2 = MakeTask(DownloadStatus.Paused);

            scheduler.StopAll();

            // task1 was Paused; after StopAll+Enqueue it must remain Paused.
            scheduler.Enqueue(task1);
            Assert.Equal(DownloadStatus.Paused, task1.Status);

            // Even direct state changes via Enqueue are suppressed.
            scheduler.Enqueue(task2);
            Assert.Equal(DownloadStatus.Paused, task2.Status);

            _storeMock.Verify(
                s => s.UpdateStatusAsync(It.IsAny<string>(), It.IsAny<DownloadStatus>(),
                                         It.IsAny<long>(), It.IsAny<string?>()),
                Times.Never);
        }

        // ---------------------------------------------------------------------
        // StartAll
        // ---------------------------------------------------------------------

        [Fact]
        public async Task StartAll_ReEnqueuesPausedTasks()
        {
            // Arrange: the store returns one paused task. StartAll should
            // flip its status to Queued and notify the store.
            var pausedTask = MakeTask(DownloadStatus.Paused);
            var completedTask = MakeTask(DownloadStatus.Completed);
            completedTask.Id = "completed-task";

            _storeMock
                .Setup(s => s.GetAllAsync())
                .ReturnsAsync(new List<DownloadTask> { pausedTask, completedTask });

            var scheduler = CreateScheduler();

            // Act: StartAll fires off a Task.Run that reads the store and
            // re-enqueues resumable tasks. We need to await the
            // fire-and-forget work.
            scheduler.StartAll();

            // Wait for the fire-and-forget Task.Run to drain. The mock
            // GetAllAsync returns a completed task, so the only delay is
            // scheduling overhead.
            await WaitUntilAsync(() => pausedTask.Status == DownloadStatus.Queued,
                                 timeoutMs: 1000);

            // Assert: pausedTask was re-enqueued (status → Queued) but
            // completedTask was not (CanResume is false for Completed).
            Assert.Equal(DownloadStatus.Queued, pausedTask.Status);
            Assert.Equal(DownloadStatus.Completed, completedTask.Status);

            // The store was notified about the paused task transition only.
            _storeMock.Verify(
                s => s.UpdateStatusAsync(pausedTask.Id, DownloadStatus.Queued,
                                         pausedTask.DownloadedBytes, null),
                Times.Once);
            _storeMock.Verify(
                s => s.UpdateStatusAsync(completedTask.Id, It.IsAny<DownloadStatus>(),
                                         It.IsAny<long>(), It.IsAny<string?>()),
                Times.Never);
        }

        [Fact]
        public async Task StartAll_AlsoReEnqueuesFailedAndWaitingTasks()
        {
            // CanResume is true for Paused, Stopped, Failed, WaitingForRetry.
            var failedTask = MakeTask(DownloadStatus.Failed);
            failedTask.Id = "failed-1";
            var waitingTask = MakeTask(DownloadStatus.WaitingForRetry);
            waitingTask.Id = "waiting-1";
            var stoppedTask = MakeTask(DownloadStatus.Stopped);
            stoppedTask.Id = "stopped-1";

            _storeMock
                .Setup(s => s.GetAllAsync())
                .ReturnsAsync(new List<DownloadTask>
                {
                    failedTask, waitingTask, stoppedTask
                });

            var scheduler = CreateScheduler();
            scheduler.StartAll();

            await WaitUntilAsync(() =>
                failedTask.Status == DownloadStatus.Queued &&
                waitingTask.Status == DownloadStatus.Queued &&
                stoppedTask.Status == DownloadStatus.Queued,
                timeoutMs: 1000);

            Assert.Equal(DownloadStatus.Queued, failedTask.Status);
            Assert.Equal(DownloadStatus.Queued, waitingTask.Status);
            Assert.Equal(DownloadStatus.Queued, stoppedTask.Status);
        }

        [Fact]
        public async Task StartAll_ClearsStoppedFlag()
        {
            // After StopAll, Enqueue is a no-op. After StartAll, Enqueue
            // should work again.
            var scheduler = CreateScheduler();
            var task = MakeTask(DownloadStatus.Paused);

            // The store must return our task so StartAll's fire-and-forget
            // loop can flip its status.
            _storeMock
                .Setup(s => s.GetAllAsync())
                .ReturnsAsync(new List<DownloadTask> { task });

            scheduler.StopAll();
            scheduler.Enqueue(task);
            Assert.Equal(DownloadStatus.Paused, task.Status); // unchanged

            scheduler.StartAll();
            await WaitUntilAsync(() => task.Status == DownloadStatus.Queued,
                                 timeoutMs: 1000);
            Assert.Equal(DownloadStatus.Queued, task.Status);

            // Now a fresh Enqueue should also work — _stopped was cleared.
            var task2 = MakeTask(DownloadStatus.Stopped);
            scheduler.Enqueue(task2);
            Assert.Equal(DownloadStatus.Queued, task2.Status);

            _storeMock.Verify(
                s => s.UpdateStatusAsync(task2.Id, DownloadStatus.Queued,
                                         It.IsAny<long>(), null),
                Times.Once);
        }

        // ---------------------------------------------------------------------
        // Resume
        // ---------------------------------------------------------------------

        [Fact]
        public void Resume_SetsStatusToQueued()
        {
            var scheduler = CreateScheduler();
            var task = MakeTask(DownloadStatus.Paused);

            scheduler.Resume(task);

            Assert.Equal(DownloadStatus.Queued, task.Status);
            _storeMock.Verify(
                s => s.UpdateStatusAsync(task.Id, DownloadStatus.Queued, task.DownloadedBytes, null),
                Times.Once);
        }

        [Fact]
        public void Resume_DoesNothing_ForCompletedTask()
        {
            var scheduler = CreateScheduler();
            var task = MakeTask(DownloadStatus.Completed);

            scheduler.Resume(task);

            Assert.Equal(DownloadStatus.Completed, task.Status);
            _storeMock.Verify(
                s => s.UpdateStatusAsync(It.IsAny<string>(), It.IsAny<DownloadStatus>(),
                                         It.IsAny<long>(), It.IsAny<string?>()),
                Times.Never);
        }

        // ---------------------------------------------------------------------
        // Helpers
        // ---------------------------------------------------------------------

        /// <summary>
        /// Polls <paramref name="condition"/> until it returns true or the
        /// timeout elapses. Used to wait for the scheduler's fire-and-forget
        /// Task.Run work to complete.
        /// </summary>
        private static async Task WaitUntilAsync(System.Func<bool> condition, int timeoutMs)
        {
            var deadline = (long)System.Environment.TickCount + timeoutMs;
            while ((long)System.Environment.TickCount < deadline)
            {
                if (condition()) return;
                await Task.Delay(10);
            }
            // Final check — let the assertion in the caller surface the failure.
        }
    }
}
