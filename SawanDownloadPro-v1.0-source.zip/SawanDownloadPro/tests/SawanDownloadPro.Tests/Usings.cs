// ============================================================================
// Usings.cs — Intended home for global using directives.
// ============================================================================
//
// IMPORTANT: Global using directives are a C# 10 feature. This test project
// is configured with <LangVersion>9.0</LangVersion> per the Task 10 spec,
// which predates global usings. The directives below are therefore commented
// out so the project compiles cleanly under C# 9.
//
// Each test file in this project declares its own per-file `using` directives.
//
// To enable the global usings here, bump <LangVersion> in
// SawanDownloadPro.Tests.csproj to 10.0 (or later) and uncomment the lines
// below. The per-file usings can then be removed.
//
// Reference: https://learn.microsoft.com/dotnet/csharp/language-reference/proposals/csharp-10.0/globalusing-directive
//
// ----------------------------------------------------------------------------
//
// global using Xunit;
// global using Moq;
// global using Microsoft.Extensions.Logging;
// global using SawanDownloadPro.Core.Enums;
// global using SawanDownloadPro.Core.Exceptions;
// global using SawanDownloadPro.Core.Interfaces;
// global using SawanDownloadPro.Core.Models;
// global using SawanDownloadPro.Tests.TestInfrastructure;

// File intentionally has no executable code; it exists only as documentation
// for the global-using intent and to keep the test project layout symmetric
// with the production projects (each of which has its own implicit/usings file).
