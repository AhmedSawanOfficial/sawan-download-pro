using System;
using SawanDownloadPro.Security.Validation;
using Xunit;

namespace SawanDownloadPro.Tests.Security
{
    /// <summary>
    /// Unit tests for <see cref="UrlValidator"/>. Verifies scheme allow-listing,
    /// length limits, and the bare-domain normalization helper.
    /// </summary>
    public class UrlValidatorTests
    {
        private readonly UrlValidator _validator = new UrlValidator();

        // ---------------------------------------------------------------------
        // IsValid
        // ---------------------------------------------------------------------

        [Fact]
        public void IsValid_TrueForHttp()
        {
            Assert.True(_validator.IsValid("http://example.com/file.zip"));
        }

        [Fact]
        public void IsValid_TrueForHttps()
        {
            Assert.True(_validator.IsValid("https://example.com/file.zip"));
        }

        [Theory]
        [InlineData("file:///C:/Windows/System32/evil.dll")]
        [InlineData("FILE://localhost/etc/passwd")]
        public void IsValid_FalseForFileScheme(string url)
        {
            // Only http, https, ftp are allowed.
            Assert.False(_validator.IsValid(url));
        }

        [Theory]
        [InlineData("javascript:alert(1)")]
        [InlineData("javascript://%0Aalert(document.cookie)")]
        public void IsValid_FalseForJavascriptScheme(string url)
        {
            Assert.False(_validator.IsValid(url));
        }

        [Theory]
        [InlineData("data:text/plain;base64,SGVsbG8=")]
        [InlineData("data:text/html,<script>alert(1)</script>")]
        public void IsValid_FalseForDataScheme(string url)
        {
            Assert.False(_validator.IsValid(url));
        }

        [Theory]
        [InlineData("")]
        [InlineData(null)]
        [InlineData("   ")]
        public void IsValid_FalseForEmpty(string? url)
        {
            Assert.False(_validator.IsValid(url!));
        }

        [Fact]
        public void IsValid_FalseForTooLong()
        {
            // Build a URL that exceeds the 8192-char hard cap.
            // The scheme/host are valid so we exercise only the length check.
            var url = "https://example.com/" + new string('a', 8200);
            Assert.True(url.Length > 8192);
            Assert.False(_validator.IsValid(url));
        }

        [Fact]
        public void IsValid_FalseForMissingHost()
        {
            // "https://" with no host is rejected by the Uri.Host check.
            Assert.False(_validator.IsValid("https://"));
        }

        [Fact]
        public void IsValid_FalseForMalformed()
        {
            // Uri.TryCreate returns false for this garbage string.
            Assert.False(_validator.IsValid("ht!tp://%%%"));
        }

        [Fact]
        public void IsValid_TrueForFtp()
        {
            Assert.True(_validator.IsValid("ftp://ftp.example.com/file.tar.gz"));
        }

        // ---------------------------------------------------------------------
        // IsSchemeAllowed
        // ---------------------------------------------------------------------

        [Fact]
        public void IsSchemeAllowed_TrueForFtp()
        {
            Assert.True(_validator.IsSchemeAllowed("ftp://ftp.example.com"));
        }

        [Theory]
        [InlineData("http://x")]
        [InlineData("https://x")]
        [InlineData("ftp://x")]
        public void IsSchemeAllowed_TrueForAllowListedSchemes(string url)
        {
            Assert.True(_validator.IsSchemeAllowed(url));
        }

        [Theory]
        [InlineData("file://x")]
        [InlineData("javascript:x")]
        [InlineData("data:x")]
        [InlineData("mailto:test@example.com")]
        [InlineData("tel:+1234567890")]
        public void IsSchemeAllowed_FalseForDisallowedSchemes(string url)
        {
            Assert.False(_validator.IsSchemeAllowed(url));
        }

        [Theory]
        [InlineData("")]
        [InlineData(null)]
        [InlineData("noschemehere")]
        public void IsSchemeAllowed_FalseForMalformed(string? url)
        {
            // Either empty or no colon present.
            Assert.False(_validator.IsSchemeAllowed(url!));
        }

        // ---------------------------------------------------------------------
        // NormalizeOrNull
        // ---------------------------------------------------------------------

        [Fact]
        public void NormalizeOrNull_PrependsHttpsForBareDomain()
        {
            // A bare domain like "example.com" has no scheme; the validator
            // prepends "https://" so the result is a usable Uri.
            var result = _validator.NormalizeOrNull("example.com");

            Assert.NotNull(result);
            Assert.Equal("https", result!.Scheme, StringComparer.OrdinalIgnoreCase);
            Assert.Equal("example.com", result.Host);
        }

        [Fact]
        public void NormalizeOrNull_PreservesExplicitScheme()
        {
            var result = _validator.NormalizeOrNull("http://example.com/path");
            Assert.NotNull(result);
            Assert.Equal("http", result!.Scheme, StringComparer.OrdinalIgnoreCase);
        }

        [Fact]
        public void NormalizeOrNull_ReturnsNullForEmpty()
        {
            Assert.Null(_validator.NormalizeOrNull(""));
            Assert.Null(_validator.NormalizeOrNull("   "));
        }

        [Fact]
        public void NormalizeOrNull_ReturnsNullForUnparseable()
        {
            // Uri.TryCreate rejects this string even after the prepending
            // heuristic (because it already contains "://").
            Assert.Null(_validator.NormalizeOrNull("://nope"));
        }
    }
}
