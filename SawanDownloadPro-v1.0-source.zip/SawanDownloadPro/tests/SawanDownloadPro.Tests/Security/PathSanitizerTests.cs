using System;
using System.IO;
using System.Linq;
using SawanDownloadPro.Core.Exceptions;
using SawanDownloadPro.Security.Validation;
using SawanDownloadPro.Tests.TestInfrastructure;
using Xunit;

namespace SawanDownloadPro.Tests.Security
{
    /// <summary>
    /// Unit tests for <see cref="PathSanitizer"/>. Verifies traversal prevention,
    /// invalid-char replacement, reserved-name handling, length truncation, and
    /// dangerous-extension detection.
    /// </summary>
    /// <remarks>
    /// The tests assert behaviour that is observable on Windows. Two assertions
    /// rely on <see cref="Path.GetInvalidFileNameChars"/> returning the Windows
    /// invalid-char set (which includes <c>&lt;</c> and <c>&gt;</c>). On Linux
    /// / Mono, that set is smaller and those specific assertions would not
    /// hold — but the test project targets <c>net48</c> and is only expected
    /// to be compiled and run on Windows.
    /// </remarks>
    public class PathSanitizerTests
    {
        private readonly PathSanitizer _sanitizer = new PathSanitizer(LoggerFactory.Create());

        // ---------------------------------------------------------------------
        // SanitizeFileName
        // ---------------------------------------------------------------------

        [Fact]
        public void SanitizeFileName_StripsPathTraversal()
        {
            // The sanitizer replaces path separators with underscores and
            // trims leading dots. "../etc/passwd" must therefore not survive
            // as a traversal — no ".." sequence and no path separators.
            var result = _sanitizer.SanitizeFileName("../etc/passwd");

            Assert.DoesNotContain("..", result);
            Assert.DoesNotContain("/", result);
            Assert.DoesNotContain("\\", result);
            Assert.False(string.IsNullOrWhiteSpace(result));
        }

        [Fact]
        public void SanitizeFileName_ReplacesInvalidChars()
        {
            // On Windows, '<' and '>' are invalid filename characters and
            // get replaced with '_'. The trailing dot before "txt" is
            // preserved (Trim only strips leading/trailing dots — the dot
            // here is internal between "_" and "txt").
            var result = _sanitizer.SanitizeFileName("file<name>.txt");

            Assert.Equal("file_name_.txt", result);
        }

        [Theory]
        [InlineData("")]
        [InlineData("   ")]
        [InlineData("\t\n")]
        public void SanitizeFileName_RejectsEmpty(string input)
        {
            Assert.Throws<UnsafePathException>(() => _sanitizer.SanitizeFileName(input));
        }

        [Fact]
        public void SanitizeFileName_ReplacesReservedNames()
        {
            // Windows reserved names (CON, PRN, AUX, NUL, COM1-9, LPT1-9)
            // are detected by their stem and prefixed with "sawan_" to avoid
            // the OS silently swallowing them.
            var result = _sanitizer.SanitizeFileName("CON.txt");

            Assert.Equal("sawan_CON.txt", result);
        }

        [Theory]
        [InlineData("PRN", "sawan_PRN")]
        [InlineData("AUX.log", "sawan_AUX.log")]
        [InlineData("NUL", "sawan_NUL")]
        [InlineData("COM1.dat", "sawan_COM1.dat")]
        [InlineData("LPT9.bin", "sawan_LPT9.bin")]
        public void SanitizeFileName_ReplacesAllReservedNames(string input, string expected)
        {
            var result = _sanitizer.SanitizeFileName(input);
            Assert.Equal(expected, result);
        }

        [Fact]
        public void SanitizeFileName_TruncatesLongNames()
        {
            // 300-char input must be truncated to exactly 200 chars (the
            // hard cap in SanitizeFileName).
            var input = new string('a', 300);
            var result = _sanitizer.SanitizeFileName(input);

            Assert.Equal(200, result.Length);
            Assert.True(result.All(c => c == 'a'),
                "Truncation should not corrupt the surviving prefix.");
        }

        [Fact]
        public void SanitizeFileName_PreservesShortNames()
        {
            var result = _sanitizer.SanitizeFileName("document.pdf");
            Assert.Equal("document.pdf", result);
        }

        [Fact]
        public void SanitizeFileName_DefaultsWhenAllStripped()
        {
            // Input that is entirely invalid chars collapses to empty, then
            // to the default "sawan_download".
            var result = _sanitizer.SanitizeFileName("???");
            Assert.Equal("sawan_download", result);
        }

        // ---------------------------------------------------------------------
        // SanitizeAndCombinePath
        // ---------------------------------------------------------------------

        [Fact]
        public void SanitizeAndCombinePath_PreventsTraversal()
        {
            // The regex-based traversal detector examines both the sanitized
            // filename AND the raw directory. We pass the malicious pattern
            // as the directory argument (the production code treats the
            // directory as caller-controlled and does not sanitise it); the
            // regex matches ".." + "/" and throws UnsafePathException.
            //
            // Note: when "../../etc/passwd" is passed as the *fileName*, the
            // sanitization step replaces '/' with '_' and trims leading dots,
            // so the literal traversal does not survive — see
            // SanitizeFileName_StripsPathTraversal above. The traversal guard
            // in SanitizeAndCombinePath catches the pattern only when it
            // survives into either argument.
            Assert.Throws<UnsafePathException>(() =>
                _sanitizer.SanitizeAndCombinePath("../../etc/passwd", "placeholder.txt"));
        }

        [Fact]
        public void SanitizeAndCombinePath_StaysInsideRoot()
        {
            // Use the system temp directory so the test works regardless of
            // where the test runner is invoked from.
            var root = Path.GetTempPath();
            var result = _sanitizer.SanitizeAndCombinePath(root, "sawan_test_file.txt");

            var normalizedRoot = Path.GetFullPath(root.TrimEnd('\\', '/') + Path.DirectorySeparatorChar);
            Assert.StartsWith(normalizedRoot, result, StringComparison.OrdinalIgnoreCase);
            Assert.EndsWith("sawan_test_file.txt", result, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public void SanitizeAndCombinePath_RejectsEmptyDirectory()
        {
            Assert.Throws<UnsafePathException>(() =>
                _sanitizer.SanitizeAndCombinePath("", "file.txt"));
        }

        [Fact]
        public void SanitizeAndCombinePath_RejectsEmptyFileName()
        {
            Assert.Throws<UnsafePathException>(() =>
                _sanitizer.SanitizeAndCombinePath(Path.GetTempPath(), ""));
        }

        // ---------------------------------------------------------------------
        // IsDangerousExtension
        // ---------------------------------------------------------------------

        [Fact]
        public void IsDangerousExtension_TrueForExe()
        {
            Assert.True(_sanitizer.IsDangerousExtension("setup.exe"));
        }

        [Fact]
        public void IsDangerousExtension_FalseForTxt()
        {
            Assert.False(_sanitizer.IsDangerousExtension("notes.txt"));
        }

        [Theory]
        [InlineData(".exe")]
        [InlineData(".bat")]
        [InlineData(".cmd")]
        [InlineData(".ps1")]
        [InlineData(".vbs")]
        [InlineData(".js")]
        [InlineData(".jar")]
        [InlineData(".scr")]
        [InlineData(".msi")]
        [InlineData(".com")]
        [InlineData(".pif")]
        [InlineData(".lnk")]
        [InlineData(".reg")]
        [InlineData(".inf")]
        [InlineData(".hta")]
        [InlineData(".cpl")]
        public void IsDangerousExtension_TrueForAllDangerous(string ext)
        {
            // Use both lowercase and uppercase forms to confirm the check is
            // case-insensitive (Path.GetExtension preserves case; the
            // production code lowercases before comparing).
            var lower = "payload" + ext;
            var upper = "PAYLOAD" + ext.ToUpperInvariant();

            Assert.True(_sanitizer.IsDangerousExtension(lower),
                $"Expected '{lower}' to be flagged dangerous.");
            Assert.True(_sanitizer.IsDangerousExtension(upper),
                $"Expected '{upper}' to be flagged dangerous.");
        }

        [Theory]
        [InlineData("photo.jpg")]
        [InlineData("video.mp4")]
        [InlineData("song.mp3")]
        [InlineData("archive.zip")]
        [InlineData("document.pdf")]
        [InlineData("noextension")]
        [InlineData("")]
        public void IsDangerousExtension_FalseForSafeFiles(string fileName)
        {
            Assert.False(_sanitizer.IsDangerousExtension(fileName));
        }
    }
}
