@echo off
REM ==========================================================================
REM BuildInstaller.bat
REM Builds the Sawan Download Pro MSI installer in both x86 and x64
REM configurations, using the WiX Toolset v3.14 (candle.exe + light.exe).
REM
REM Usage:
REM   BuildInstaller.bat            - build both x86 and x64 MSIs
REM   BuildInstaller.bat x86        - build only x86
REM   BuildInstaller.bat x64        - build only x64
REM   BuildInstaller.bat clean      - remove obj/ and bin/ folders
REM
REM Output:
REM   installer\bin\x86\SawanDownloadProSetup.msi
REM   installer\bin\x64\SawanDownloadProSetup_x64.msi
REM ==========================================================================

setlocal enabledelayedexpansion

set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"
set "ROOT_DIR=%SCRIPT_DIR%\.."
set "PAYLOAD_DIR=%SCRIPT_DIR%\payload"
set "BIN_X86=%SCRIPT_DIR%\bin\x86"
set "BIN_X64=%SCRIPT_DIR%\bin\x64"

REM ---------------------------------------------------------------------------
REM Subcommand: clean
REM ---------------------------------------------------------------------------
if /i "%~1"=="clean" (
    echo Cleaning installer build outputs...
    if exist "%SCRIPT_DIR%\obj" rmdir /s /q "%SCRIPT_DIR%\obj"
    if exist "%SCRIPT_DIR%\bin" rmdir /s /q "%SCRIPT_DIR%\bin"
    if exist "%PAYLOAD_DIR%" rmdir /s /q "%PAYLOAD_DIR%"
    echo Done.
    exit /b 0
)

REM ---------------------------------------------------------------------------
REM Verify WiX toolset v3.14 is installed
REM ---------------------------------------------------------------------------
where candle.exe >nul 2>nul
if errorlevel 1 (
    set "WIX_HOME=%WIX%"
    if not exist "!WIX_HOME!\bin\candle.exe" (
        echo [ERROR] candle.exe was not found on PATH and WIX env var is not set.
        echo.
        echo Install WiX Toolset v3.14 from https://wixtoolset.org/releases/
        echo and either add its bin\ folder to PATH or set the WIX env var.
        exit /b 1
    )
    set "PATH=!WIX_HOME!\bin;%PATH%"
)

where light.exe >nul 2>nul
if errorlevel 1 (
    echo [ERROR] light.exe was not found on PATH. WiX install appears incomplete.
    exit /b 1
)

echo [OK] WiX toolset found:
for /f "delims=" %%v in ('candle.exe -nologo -? 2^>nul ^| findstr /r /c:"version"') do echo       %%v
echo.

REM ---------------------------------------------------------------------------
REM Harvest the App project's Release output into payload\<arch>\
REM The App project must be built first; this script expects:
REM   %ROOT_DIR%\src\SawanDownloadPro.App\bin\x86\Release\SawanDownloadPro.App.exe
REM   %ROOT_DIR%\src\SawanDownloadPro.App\bin\x64\Release\SawanDownloadPro.App.exe
REM ---------------------------------------------------------------------------
call :harvest "x86" || exit /b 1
if /i "%~1"=="x86" (
    call :build "x86" || exit /b 1
    echo.
    echo Success: %BIN_X86%\SawanDownloadProSetup.msi
    exit /b 0
)
if /i "%~1"=="x64" (
    call :build "x64" || exit /b 1
    echo.
    echo Success: %BIN_X64%\SawanDownloadProSetup_x64.msi
    exit /b 0
)

call :build "x86" || exit /b 1
call :build "x64" || exit /b 1
echo.
echo ==========================================================================
echo Build complete:
echo   %BIN_X86%\SawanDownloadProSetup.msi
echo   %BIN_X64%\SawanDownloadProSetup_x64.msi
echo ==========================================================================
exit /b 0

REM ==========================================================================
REM :harvest <arch>
REM Copies the App project's Release output into payload\<arch>\
REM ==========================================================================
:harvest
set "ARCH=%~1"
set "SRC=%ROOT_DIR%\src\SawanDownloadPro.App\bin\%ARCH%\Release"
set "DST=%PAYLOAD_DIR%\%ARCH%"
if not exist "%SRC%\SawanDownloadPro.App.exe" (
    echo [ERROR] App project Release output not found at:
    echo         %SRC%\SawanDownloadPro.App.exe
    echo         Build the solution first with:
    echo           msbuild SawanDownloadPro.sln /p:Configuration=Release /p:Platform=%ARCH%
    exit /b 1
)
echo Harvesting %ARCH% payload from %SRC%
if exist "%DST%" rmdir /s /q "%DST%"
mkdir "%DST%"
xcopy /y /q "%SRC%\*.exe" "%DST%\" >nul
xcopy /y /q "%SRC%\*.dll" "%DST%\" >nul
xcopy /y /q "%SRC%\*.config" "%DST%\" >nul
REM SQLite native interop is in a subfolder (x86 or x64) under the App output.
if exist "%SRC%\x86\SQLite.Interop.dll" xcopy /y /q "%SRC%\x86\SQLite.Interop.dll" "%DST%\" >nul
if exist "%SRC%\x64\SQLite.Interop.dll" xcopy /y /q "%SRC%\x64\SQLite.Interop.dll" "%DST%\" >nul
exit /b 0

REM ==========================================================================
REM :build <arch>
REM Invokes candle + light for one architecture.
REM ==========================================================================
:build
set "ARCH=%~1"
set "OBJ=%SCRIPT_DIR%\obj\%ARCH%\Release"
set "OUT=%SCRIPT_DIR%\bin\%ARCH%"
if /i "%ARCH%"=="x86" (
    set "MSI_NAME=SawanDownloadProSetup.msi"
) else (
    set "MSI_NAME=SawanDownloadProSetup_x64.msi"
)
echo.
echo ---- Building %ARCH% MSI ----
if not exist "%OBJ%" mkdir "%OBJ%"
if not exist "%OUT%" mkdir "%OUT%"

REM Candle: compile Product.wxs to a .wixobj in obj\<arch>\Release\
candle.exe -nologo -arch %ARCH% ^
    -dPlatform=%ARCH% ^
    -ext WixUIExtension ^
    -ext WixUtilExtension ^
    -ext WixNetFxExtension ^
    -out "%OBJ%\Product.wixobj" ^
    "%SCRIPT_DIR%\Product.wxs"
if errorlevel 1 (
    echo [ERROR] candle.exe failed for %ARCH%
    exit /b 1
)

REM Light: link to MSI in bin\<arch>\ with the architecture-specific name.
light.exe -nologo ^
    -ext WixUIExtension ^
    -ext WixUtilExtension ^
    -ext WixNetFxExtension ^
    -out "%OUT%\!MSI_NAME!" ^
    "%OBJ%\Product.wixobj"
if errorlevel 1 (
    echo [ERROR] light.exe failed for %ARCH%
    exit /b 1
)
exit /b 0
