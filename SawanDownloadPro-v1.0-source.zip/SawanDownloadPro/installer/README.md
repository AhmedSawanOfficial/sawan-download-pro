# Sawan Download Pro — WiX Installer

This folder contains the WiX Toolset v3.14 source for the Sawan Download Pro
MSI installer. The installer is produced in two configurations:

| Platform | Output file                              | Target folder                |
|----------|------------------------------------------|------------------------------|
| x86      | `SawanDownloadProSetup.msi`              | `installer/bin/x86/`         |
| x64      | `SawanDownloadProSetup_x64.msi`          | `installer/bin/x64/`         |

Both MSIs are built from the same `Product.wxs` source. The variant is
selected via the MSBuild `Platform` property.

---

## 1. Prerequisites

### 1.1 WiX Toolset v3.14

Install WiX Toolset v3.14 from <https://wixtoolset.org/releases/v3-14/>.
After installing, either:

- Add `<WiXInstallDir>\bin` to your `PATH` (so `candle.exe` and `light.exe`
  are discoverable), or
- Set the `WIX` environment variable to the WiX install directory
  (e.g. `set WIX=C:\Program Files (x86)\WiX Toolset v3.14`).

`BuildInstaller.bat` checks both locations and exits with a clear error if
neither is found.

> WiX v4 is **not** supported. v4 changed the toolchain significantly and
> is not yet as battle-tested for Win7 SP1 scenarios. Stick with v3.14.

### 1.2 Build the application first

The installer does **not** build the C# solution. You must build the
solution in **both** configurations before running `BuildInstaller.bat`:

```cmd
cd <repo-root>
nuget restore SawanDownloadPro.sln
msbuild SawanDownloadPro.sln /p:Configuration=Release /p:Platform=x86
msbuild SawanDownloadPro.sln /p:Configuration=Release /p:Platform=x64
```

`BuildInstaller.bat` harvests the App project's Release output
(`src/SawanDownloadPro.App/bin/<arch>/Release/`) into
`installer/payload/<arch>/` before invoking `candle` and `light`.

---

## 2. Building the installer

### 2.1 Both architectures (recommended)

```cmd
cd installer
BuildInstaller.bat
```

Outputs:

- `installer/bin/x86/SawanDownloadProSetup.msi`
- `installer/bin/x64/SawanDownloadProSetup_x64.msi`

### 2.2 One architecture only

```cmd
BuildInstaller.bat x86
BuildInstaller.bat x64
```

### 2.3 Clean

```cmd
BuildInstaller.bat clean
```

Removes `installer/obj/`, `installer/bin/`, and `installer/payload/`.

### 2.4 Building from Visual Studio

If you have the WiX v3.14 Visual Studio extension installed, you can open
`SawanDownloadPro.Installer.wixproj` directly in Visual Studio and build it
from the IDE. Select `Release` + `x86` or `Release` + `x64` from the
standard toolbar.

### 2.5 Building from the command line with MSBuild

```cmd
msbuild SawanDownloadPro.Installer.wixproj /p:Configuration=Release /p:Platform=x86
msbuild SawanDownloadPro.Installer.wixproj /p:Configuration=Release /p:Platform=x64
```

---

## 3. Code signing (optional, user-supplied certificate)

The MSI is not signed by default. Unsigned MSIs trigger a SmartScreen
warning on Windows 10/11 the first time a user runs them. To sign:

### 3.1 Obtain a code-signing certificate

You can purchase one from a public CA (DigiCert, Sectigo, GlobalSign, etc.)
or generate a self-signed certificate for internal testing only. The
Sawan project does **not** provide a code-signing certificate on your
behalf.

### 3.2 Sign with `signtool.exe`

```cmd
signtool sign /tr http://timestamp.digicert.com /td sha256 /fd sha256 ^
              /a /n "Your Common Name" ^
              bin\x64\SawanDownloadProSetup_x64.msi
```

Repeat for the x86 MSI. Use the `/a` flag to let `signtool` pick the best
certificate automatically, or specify `/sha1 <thumbprint>` to be explicit.

### 3.3 Dual-signing (SHA-1 + SHA-256) for Windows 7 SP1 compatibility

Windows 7 SP1 without **KB4474419** supports only SHA-1 code signing
verification. With KB4474419 installed, it supports SHA-256. To support
both populations, dual-sign:

```cmd
signtool sign /tr http://timestamp.digicert.com /td sha1  /fd sha1  ^
              /n "Your Common Name" ^
              bin\x64\SawanDownloadProSetup_x64.msi
signtool sign /tr http://timestamp.digicert.com /td sha256 /fd sha256 ^
              /n "Your Common Name" ^
              bin\x64\SawanDownloadProSetup_x64.msi
```

The SHA-256 signature is appended as a second signature. Windows 10/11
verifies the SHA-256 signature; Windows 7 SP1 without the SHA-2 update
falls back to the SHA-1 signature.

---

## 4. Windows 7 SP1 compatibility note — SHA-2 code signing

> **Important.** Windows 7 SP1 without **KB4474419** cannot verify SHA-256
> code-signing certificates. Microsoft shipped SHA-2 support as a
> standalone update in mid-2019 and rolled it into the convenience
> rollup later that year. Most Windows 7 SP1 machines that have been kept
> up to date already have KB4474419 installed, but a freshly deployed
> image will not.

The installer itself will run on Windows 7 SP1 regardless (the MSI is
structurally valid), but the installer's signature — if SHA-256-only —
will not verify, and Windows will warn the user that the publisher could
not be verified.

**Recommendation for distribution:**

1. Dual-sign the MSI (SHA-1 + SHA-256) so it works on both pre-KB4474419
   and post-KB4474419 Windows 7 SP1.
2. Document in your release notes that users on Windows 7 SP1 should
   install KB4474419 (and ideally the convenience rollup) before
   installing Sawan Download Pro.
3. If you distribute only a SHA-256 signature, the MSI still installs —
   the user just clicks through the SmartScreen warning. The
   `MajorUpgrade` element in `Product.wxs` ensures that reinstalling or
   upgrading an existing install works regardless of signature state.

---

## 5. Installer structure (what gets installed)

| Path on target machine                                          | Source                                                                                  |
|-----------------------------------------------------------------|-----------------------------------------------------------------------------------------|
| `C:\Program Files\Sawan\Sawan Download Pro\bin\`                | Main EXE, dependency DLLs, app config                                                   |
| `C:\Program Files\Sawan\Sawan Download Pro\native-host\`        | Python reference host, .bat launcher, native-messaging manifest template                |
| `C:\Program Files\Sawan\Sawan Download Pro\browser-extensions\` | `chrome/`, `edge/`, `firefox/` extension sources (load-unpacked)                        |
| `C:\Program Files\Sawan\Sawan Download Pro\docs\`               | Architecture, build, user guide, troubleshooting, security, license-inventory docs     |
| `%LOCALAPPDATA%\Sawan\Sawan Download Pro\`                      | Created on first run by the App: settings DB, logs, per-user native-messaging manifest  |

Registry entries installed (per-machine, in `HKLM`):

- `Software\Sawan\Sawan Download Pro\InstallPath`
- `Software\Sawan\Sawan Download Pro\Version`
- `Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro`
- `Software\Microsoft\Edge\NativeMessagingHosts\com.sawan.downloadpro`
- `Software\Classes\.sawanpart` (only if File Association feature is enabled)

Shortcuts:

- Start Menu: `Sawan\Sawan Download Pro\Sawan Download Pro.lnk`
- Desktop (optional): `Sawan Download Pro.lnk` (gated by UI checkbox)

---

## 6. MajorUpgrade behaviour

The installer uses `MajorUpgrade` with:

- `AllowSameVersionUpgrades="yes"` — the same MSI can be reinstalled to
  repair a broken install. The product `Id` is auto-generated per build
  (`Product Id="*"`), so reinstalling the same MSI rebuilds the
  product registration cleanly.
- `DowngradeErrorMessage` — if a user attempts to install an older MSI
  over a newer one, the installer refuses with a clear message.

The `UpgradeCode` is fixed at `7B7C7D7D-1234-4321-ABCD-1234567890AB`
across all versions. **Never change the UpgradeCode** after release —
doing so breaks upgrade detection for already-installed users.

---

## 7. Troubleshooting the build

### `candle.exe` errors out with `LGHT0216: The light.exe process failed`

Most often caused by a missing `payload\<arch>\` directory. Ensure
`BuildInstaller.bat`'s `:harvest` step found the App project's Release
output. Build the solution in the matching architecture first.

### `error LGHT0103: The system cannot find the file ...`

A `<File Source="...">` reference points to a file that does not exist
in `payload\<arch>\`. Open `Product.wxs`, find the offending component,
and either add the missing binary to the payload or remove the
component.

### `Unresolved reference to Symbol ...` from `light.exe`

A `<ComponentRef>` references a component that is not declared in any
`<DirectoryRef>`. Check the spelling of the `Id` attribute.

### WiX UI shows the wrong dialog set

`Product.wxs` references `WixUI_InstallDir` plus `WixUI_FeatureTree`.
If you want a simpler flow, remove the `<UIRef Id="WixUI_FeatureTree" />`
line.

---

## 8. Verifying the produced MSI

After building, verify the MSI's metadata with `orca.exe` (shipped with
the Windows SDK) or with PowerShell:

```powershell
$db = (New-Object -ComObject WindowsInstaller.Installer).OpenDatabase("bin\x64\SawanDownloadProSetup_x64.msi", 0)
$view = $db.OpenView("SELECT Value FROM Property WHERE Property = 'ProductVersion'")
$view.Execute()
$rec = $view.Fetch()
$rec.StringData(1)
```

This should print `1.0.0.0` for the current release.

To list every file the MSI will install:

```powershell
$db = (New-Object -ComObject WindowsInstaller.Installer).OpenDatabase("bin\x64\SawanDownloadProSetup_x64.msi", 0)
$view = $db.OpenView("SELECT File, Component_ FROM File")
$view.Execute()
while (($rec = $view.Fetch())) { $rec.StringData(1) }
```

---

## 9. License

The installer source code (this `installer/` folder) is licensed under
the Apache License, Version 2.0, consistent with the rest of the Sawan
Download Pro source tree. See the project's top-level `LICENSE` file.

WiX Toolset v3.14 itself is licensed under the Microsoft Reciprocal
License (MS-RL). You do not need to MS-RL-license your installer source
just because you use WiX to build it; MS-RL applies to the WiX source
code itself, not to your `.wxs` files.
