@echo off
REM ============================================================
REM  Sawan Download Pro - Build Script
REM  Usage: build.bat [Release|Debug] [AnyCPU|x86|x64]
REM ============================================================

setlocal enabledelayedexpansion

set CONFIG=%1
if "%CONFIG%"=="" set CONFIG=Release
set PLATFORM=%2
if "%PLATFORM%"=="" set PLATFORM=AnyCPU

echo ============================================================
echo  Building Sawan Download Pro
echo  Configuration: %CONFIG%
echo  Platform:      %PLATFORM%
echo ============================================================

REM Locate MSBuild
where msbuild >nul 2>nul
if errorlevel 1 (
    echo MSBuild not found on PATH. Trying Visual Studio 2022 default install location...
    set "MSBUILD=C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe"
    if not exist "!MSBUILD!" set "MSBUILD=C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe"
    if not exist "!MSBUILD!" set "MSBUILD=C:\Program Files\Microsoft Visual Studio\2022\Enterprise\MSBuild\Current\Bin\MSBuild.exe"
    if not exist "!MSBUILD!" set "MSBUILD=C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\MSBuild\Current\Bin\MSBuild.exe"
    if not exist "!MSBUILD!" set "MSBUILD=C:\Program Files (x86)\Microsoft Visual Studio\2019\Professional\MSBuild\Current\Bin\MSBuild.exe"
    if not exist "!MSBUILD!" (
        echo ERROR: MSBuild not found. Install Visual Studio 2019 or 2022 with the .NET desktop workload.
        exit /b 1
    )
) else (
    set "MSBUILD=msbuild"
)

echo Using MSBuild: !MSBUILD!

REM Restore NuGet packages
echo.
echo [1/3] Restoring NuGet packages...
nuget restore SawanDownloadPro.sln
if errorlevel 1 (
    echo NuGet restore failed. Trying dotnet restore...
    dotnet restore SawanDownloadPro.sln
    if errorlevel 1 (
        echo ERROR: Package restore failed.
        exit /b 1
    )
)

REM Build
echo.
echo [2/3] Building solution...
"!MSBUILD!" SawanDownloadPro.sln /p:Configuration=%CONFIG% /p:Platform="%PLATFORM%" /m /v:minimal
if errorlevel 1 (
    echo ERROR: Build failed.
    exit /b 1
)

REM Run tests
echo.
echo [3/3] Running tests...
"!MSBUILD!" tests\SawanDownloadPro.Tests\SawanDownloadPro.Tests.csproj /p:Configuration=%CONFIG% /p:Platform=AnyCPU /t:Test /v:minimal
if errorlevel 1 (
    echo WARNING: Some tests failed. Review the output above.
)

echo.
echo ============================================================
echo  Build complete.
echo  Output: src\SawanDownloadPro.App\bin\%CONFIG%\%PLATFORM%\
echo ============================================================

endlocal
