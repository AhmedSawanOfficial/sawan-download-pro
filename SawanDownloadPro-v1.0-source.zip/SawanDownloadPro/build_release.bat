@echo off
setlocal enabledelayedexpansion
REM ============================================================================
REM  Sawan Download Pro v1.0 — Windows Build Script
REM  Created by Ahmed Sawan
REM
REM  This script builds the full WPF application on Windows 10/11.
REM  It does NOT claim success unless the .exe file actually exists.
REM
REM  PREREQUISITES:
REM    - Visual Studio 2022 Community (free) with ".NET desktop development" workload
REM      Download: https://visualstudio.microsoft.com/downloads/
REM      OR Visual Studio 2019 with the same workload
REM      OR Build Tools for Visual Studio 2022 + .NET Framework 4.8 Developer Pack
REM
REM  USAGE:
REM    build_release.bat              Builds Release x64 (recommended for Win10/11)
REM    build_release.bat x86          Builds Release x86 (for Win7 32-bit)
REM    build_release.bat x64 msi      Also builds the WiX MSI installer
REM
REM  OUTPUT:
REM    src\SawanDownloadPro.App\bin\Release\x64\SawanDownloadPro.exe
REM ============================================================================

set PLATFORM=%1
if "%PLATFORM%"=="" set PLATFORM=x64
set BUILD_MSI=%2
set SOLUTION_DIR=%~dp0

echo ============================================================
echo  Sawan Download Pro v1.0 — Build Script
echo  Platform: %PLATFORM%
echo  Build MSI: %BUILD_MSI%
echo  Solution: %SOLUTION_DIR%
echo ============================================================
echo.

REM --- Step 0: Verify solution file exists ---
if not exist "%SOLUTION_DIR%SawanDownloadPro.sln" (
    echo [ERROR] SawanDownloadPro.sln not found in %SOLUTION_DIR%
    echo Make sure you are running this script from the project root.
    exit /b 1
)
echo [OK] Solution file found.

REM --- Step 1: Locate MSBuild ---
set "MSBUILD="
for %%P in (
    "C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe"
    "C:\Program Files\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe"
    "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\MSBuild\Current\Bin\MSBuild.exe"
    "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
    "C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\MSBuild\Current\Bin\MSBuild.exe"
    "C:\Program Files (x86)\Microsoft Visual Studio\2019\Professional\MSBuild\Current\Bin\MSBuild.exe"
    "C:\Program Files (x86)\Microsoft Visual Studio\2019\Enterprise\MSBuild\Current\Bin\MSBuild.exe"
    "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
) do (
    if exist %%P set "MSBUILD=%%~P"
)

if "%MSBUILD%"=="" (
    where msbuild >nul 2>nul
    if not errorlevel 1 set "MSBUILD=msbuild"
)

if "%MSBUILD%"=="" (
    echo.
    echo [ERROR] MSBuild not found.
    echo.
    echo Install one of the following:
    echo   1. Visual Studio 2022 Community (free) with ".NET desktop development" workload
    echo      https://visualstudio.microsoft.com/downloads/
    echo   2. Build Tools for Visual Studio 2022
    echo      https://visualstudio.microsoft.com/downloads/#build-tools-for-visual-studio-2022
    echo.
    exit /b 1
)
echo [OK] MSBuild found: %MSBUILD%

REM --- Step 2: Check .NET Framework 4.8 Developer Pack ---
set NET48_REF="C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8"
if not exist %NET48_REF% (
    echo.
    echo [WARNING] .NET Framework 4.8 Developer Pack not found.
    echo The build may fail. Download from:
    echo   https://dotnet.microsoft.com/download/dotnet-framework/net48
    echo.
) else (
    echo [OK] .NET Framework 4.8 reference assemblies found.
)

REM --- Step 3: Restore NuGet packages ---
echo.
echo [Step 1/4] Restoring NuGet packages...
where nuget >nul 2>nul
if not errorlevel 1 (
    nuget restore "%SOLUTION_DIR%SawanDownloadPro.sln"
    if errorlevel 1 goto :restore_failed
) else (
    where dotnet >nul 2>nul
    if not errorlevel 1 (
        dotnet restore "%SOLUTION_DIR%SawanDownloadPro.sln"
        if errorlevel 1 goto :restore_failed
    ) else (
        echo [WARNING] Neither nuget nor dotnet CLI found. Trying MSBuild restore...
        "%MSBUILD%" "%SOLUTION_DIR%SawanDownloadPro.sln" /t:Restore /p:Configuration=Release
        if errorlevel 1 goto :restore_failed
    )
)
echo [OK] NuGet packages restored.
goto :build

:restore_failed
echo.
echo [ERROR] NuGet package restore failed.
echo Install NuGet CLI from https://www.nuget.org/downloads
exit /b 1

REM --- Step 4: Build the solution ---
:build
echo.
echo [Step 2/4] Building solution (Release / %PLATFORM%)...
"%MSBUILD%" "%SOLUTION_DIR%SawanDownloadPro.sln" /p:Configuration=Release /p:Platform=%PLATFORM% /m /v:minimal /nologo
if errorlevel 1 goto :build_failed
echo [OK] Build completed without errors.

REM --- Step 5: Verify the .exe was actually produced ---
echo.
echo [Step 3/4] Verifying executable...
set "EXE_PATH=%SOLUTION_DIR%src\SawanDownloadPro.App\bin\Release\%PLATFORM%\SawanDownloadPro.exe"
if not exist "%EXE_PATH%" (
    echo.
    echo [ERROR] Build reported success but the .exe was NOT found at:
    echo   %EXE_PATH%
    echo This indicates a problem with the project configuration.
    echo.
    echo Listing what WAS produced:
    dir "%SOLUTION_DIR%src\SawanDownloadPro.App\bin\Release\%PLATFORM%\*.*" 2>nul
    goto :build_failed
)

echo [OK] Executable found:
echo   %EXE_PATH%
echo   Size: 
for %%F in ("%EXE_PATH%") do echo   %%~zF bytes

REM --- Step 6: List all runtime files ---
echo.
echo ============================================================
echo  BUILD SUCCEEDED
echo ============================================================
echo.
echo  Executable:
echo    %EXE_PATH%
echo.
echo  All runtime files in:
echo    %SOLUTION_DIR%src\SawanDownloadPro.App\bin\Release\%PLATFORM%\
echo.
echo  Required files to distribute (copy the entire folder):
echo    - SawanDownloadPro.exe          (the application)
echo    - SawanDownloadPro.dll           (app assembly)
echo    - SawanDownloadPro.*.dll         (all project libraries)
echo    - Microsoft.Extensions.*.dll     (logging + DI)
echo    - Newtonsoft.Json.dll            (JSON serialization)
echo    - CommunityToolkit.Mvvm.dll      (MVVM framework)
echo    - System.Data.SQLite.dll         (database engine)
echo    - x86\SQLite.Interop.dll         (SQLite native — 32-bit)
echo    - x64\SQLite.Interop.dll         (SQLite native — 64-bit)
echo    - SawanDownloadPro.dll.config    (app config)
echo    - Resources\*.*                  (logo + icon)
echo.
echo  Runtime requirement on target machine:
echo    .NET Framework 4.8 (pre-installed on Windows 10 1809+ and Windows 11)
echo    For Windows 7 SP1: download from
echo      https://dotnet.microsoft.com/download/dotnet-framework/net48
echo.

REM --- Step 7: Run tests ---
echo [Step 4/4] Running unit tests...
set "TEST_DLL=%SOLUTION_DIR%tests\SawanDownloadPro.Tests\bin\Release\SawanDownloadPro.Tests.dll"
if exist "%TEST_DLL%" (
    where dotnet >nul 2>nul
    if not errorlevel 1 (
        dotnet test "%SOLUTION_DIR%tests\SawanDownloadPro.Tests\SawanDownloadPro.Tests.csproj" --no-build -c Release --logger "console;verbosity=minimal" 2>nul
        if errorlevel 1 (
            echo [WARNING] Some tests failed. Review the output above.
        ) else (
            echo [OK] All tests passed.
        )
    ) else (
        echo [SKIP] dotnet CLI not found — cannot run tests. Use Visual Studio Test Explorer.
    )
) else (
    echo [SKIP] Test assembly not built — run a separate build for tests.
)

REM --- Optional: Build MSI installer ---
if /i "%BUILD_MSI%"=="msi" (
    echo.
    echo ============================================================
    echo  Building MSI Installer
    echo ============================================================
    where candle >nul 2>nul
    if errorlevel 1 (
        echo [WARNING] WiX Toolset (candle.exe) not found on PATH.
        echo Install WiX Toolset v3.14 from https://wixtoolset.org/releases/
        echo Then add C:\Program Files (x86)\WiX Toolset v3.14\bin to PATH.
        echo Skipping MSI build.
    ) else (
        cd /d "%SOLUTION_DIR%installer"
        call BuildInstaller.bat
        cd /d "%SOLUTION_DIR%"
        echo.
        echo MSI installer:
        echo   %SOLUTION_DIR%installer\bin\%PLATFORM%\SawanDownloadProSetup.msi
    )
)

echo.
echo ============================================================
echo  Build complete.
echo  To run: %EXE_PATH%
echo ============================================================
exit /b 0

:build_failed
echo.
echo ============================================================
echo  BUILD FAILED
echo ============================================================
echo.
echo Review the errors above. Common fixes:
echo   1. Install ".NET desktop development" workload in Visual Studio Installer
echo   2. Install .NET Framework 4.8 Developer Pack
echo   3. Run "nuget restore SawanDownloadPro.sln" manually
echo   4. Clean and rebuild: 
echo      "%MSBUILD%" "%SOLUTION_DIR%SawanDownloadPro.sln" /t:Clean /p:Configuration=Release /p:Platform=%PLATFORM%
echo      Then re-run this script.
echo.
exit /b 1
