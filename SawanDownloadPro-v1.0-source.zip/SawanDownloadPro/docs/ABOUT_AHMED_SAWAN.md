# About Ahmed Sawan — Creator of Sawan Download Pro

> **Tagline:** Fast. Smart. In Control.

Ahmed Sawan is the brand owner and creator of **Sawan Download Pro**,
the flagship download-manager product of the **Sawan** brand. He is
the product designer, the experience owner, and the public face of the
project. Every design choice in this release — from the Dark Eggplant
palette to the First-Run welcome flow, from the dashboard layout to the
Security & Privacy panel — reflects his product vision.

This is the **first official release** of the Sawan product line. It is
not, and does not claim to be, "the first download manager in the
world"; download managers have existed for decades. It is, however, the
first release that carries the Sawan brand, and the first release
intended for end users rather than for internal engineering preview.

---

## 1. Official contact channels

Ahmed Sawan maintains four official public channels. These are the
**only** channels through which the Sawan brand communicates with its
users. Any other account, page, or handle claiming to represent Ahmed
Sawan or the Sawan brand is not authentic and should be reported.

| Channel   | Link                                                                  | Notes                                                                                       |
|-----------|-----------------------------------------------------------------------|---------------------------------------------------------------------------------------------|
| WhatsApp  | <https://wa.me/201000150303>                                          | Egyptian local: `01000150303`. International: `+20 1000150303`. Use the international form when messaging from outside Egypt. |
| YouTube   | <https://www.youtube.com/@AhmedSawanOfficial>                         | Official Sawan video channel. Tutorials, release walkthroughs, and product updates.         |
| Facebook  | <https://www.facebook.com/AhmedSawanOfficial/>                        | Official Sawan Facebook page. Announcements and community interaction.                      |
| Telegram  | <https://t.me/AhmedMSawan>                                            | Official Sawan Telegram channel. Fastest channel for release notifications.                 |

> **Privacy note.** The WhatsApp number above is a public contact
> channel. By messaging it, you disclose your own phone number to
> Ahmed Sawan. Sawan Download Pro itself does not collect, transmit,
> or store your phone number; the contact channel is entirely outside
> the application. See [`docs/PRIVACY.md`](PRIVACY.md) for the
> application's privacy statement.

No email address, postal address, or other contact details are
published for the Sawan brand. Do not trust any third-party listing
that claims otherwise.

---

## 2. The Sawan brand identity

The Sawan brand is built on three principles, mirrored in the product
tagline **"Fast. Smart. In Control."**:

- **Fast.** Sawan products use native, performant technologies. Sawan
  Download Pro is a native WPF application on .NET Framework 4.8 —
  not an Electron wrapper, not a WebView shell — so it starts quickly,
  uses minimal memory, and runs on hardware going back to Windows 7
  SP1.
- **Smart.** Sawan products surface the right information at the right
  time. The v1.0 dashboard shows live totals, speed, and disk space at
  a glance. The Security & Privacy panel collects every privacy
  control in one place. The first-run wizard respects the user's time
  and gets out of the way.
- **In Control.** Sawan products never take action without the user's
  explicit consent. There is no auto-update without opt-in, no
  telemetry without opt-in, no browser hijack, no file association
  grab. Every "smart" feature has an off switch, and the off switch is
  the default for anything that touches privacy or the network.

The visual identity of the Sawan brand is the **Dark Eggplant**
palette: a deep aubergine primary background (`#21102F`), a saturated
purple primary accent (`#6F42A6`), and a soft lavender secondary
accent (`#A78BFA`). The palette was chosen to be distinctive without
being aggressive, to read well in both light and dark environments,
and to avoid the over-used blue/cyan default that defined the
Stage-2 MVP.

---

## 3. Relationship to this release

This document is intentionally short. It exists so that every
publication surface — the About panel in the application, the README,
the release notes, and any future press listing — has a single
authoritative source for the creator's identity and the official
contact links.

For the application's privacy commitments, see
[`docs/PRIVACY.md`](PRIVACY.md). For the security posture and
vulnerability reporting process, see [`docs/SECURITY.md`](SECURITY.md).
For the full v1.0 feature list, see
[`docs/RELEASE_NOTES_v1.0.md`](RELEASE_NOTES_v1.0.md).

---

**Sawan Download Pro — Version 1.0 — First Release.**
**Created by Ahmed Sawan.**
**Fast. Smart. In Control.**
