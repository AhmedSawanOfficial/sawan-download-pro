# Sawan Download Pro — Build Instructions

This document tells you exactly how to build Sawan Download Pro from
source on Windows. It assumes you are starting from a fresh clone of the
repository.

> **Status:** Source code complete. Compilation has not been verified in
> this Linux development environment. If you encounter a build error,
> please file an issue with the exact command and error text.

---

## 1. Prerequisites

### 1.1 Operating system

You must build on Windows. Sawan Download Pro targets .NET Framework 4.8
and WPF; neither is available on Linux or macOS. Windows 10 or Windows 11
is the recommended build host; Windows 8.1 with .NET Framework 4.8
Developer Pack also works.

> The repository's source code was authored on Linux for engineering
> reasons, but the build pipeline is Windows-only. The Linux build host
> cannot compile the C# projects.

### 1.2 Visual Studio

Install one of:

- **Visual Studio 2019** version 16.11 or later, with the **".NET desktop
  development"** workload and the **".NET Framework 4.8 SDK"** individual
  component, or
- **Visual Studio 2022** (any edition, including Community) with the same
  workload and individual component.

Both versions support .NET Framework 4.8, C# 9.0 (`LangVersion`), WPF,
and the WiX Visual Studio extension.

### 1.3 .NET Framework 4.8 Developer Pack

Install the **.NET Framework 4.8 Developer Pack** from
<https://dotnet.microsoft.com/download/dotnet-framework/thank-you/net48-developer-pack-offline-installer>.

This gives you the reference assemblies and the `msbuild` toolchain that
the solution requires. The Developer Pack is separate from the runtime
that ships with Windows; you need both.

### 1.4 NuGet

Visual Studio 2019+ ships with NuGet. To restore from the command line,
ensure `nuget.exe` (v5.11 or later) is on your `PATH`:

```cmd
nuget help
```

If `nuget.exe` is not installed, download it from
<https://www.nuget.org/downloads> and place it in a folder on your
`PATH`.

### 1.5 WiX Toolset v3.14 (required for the installer only)

If you intend to build the MSI installer (not required for building the
application itself):

1. Download WiX Toolset v3.14 from
   <https://wixtoolset.org/releases/v3-14/>.
2. Install it.
3. Set the `WIX` environment variable to the install directory
   (e.g. `setx WIX "C:\Program Files (x86)\WiX Toolset v3.14"`), or add
   `<WiXInstallDir>\bin` to your `PATH`.

WiX v4 is **not** supported — see `installer/README.md` for the
rationale.

### 1.6 Python 3.8+ (required for the optional Python native host)

The native-messaging host ships in two interchangeable implementations:
a C# executable (default) and a Python reference implementation. The
Python implementation is used only if you explicitly configure your
browser's native-messaging manifest to point at `sawan_native_host.bat`
instead of the C# `.exe`.

Install **Python 3.8 or later** (3.8 is the oldest version still
receiving security fixes; any 3.x ≥ 3.8 works) from
<https://www.python.org/downloads/windows/>.

Verify:

```cmd
python --version
```

If you only intend to use the C# native host (recommended for
Windows 7 SP1, where installing Python is extra work), you can skip
this prerequisite entirely.

### 1.7 Browser (for testing browser integration)

To test browser integration you need at least one of:

- Google Chrome 109 or earlier on Windows 7 SP1, or any current Chrome
  on Windows 10/11.
- Microsoft Edge (Chromium-based) on Windows 10/11.
- Mozilla Firefox 115 ESR on Windows 7 SP1, or any current Firefox on
  Windows 10/11.
- Opera 86 or earlier on Windows 7 SP1, or any current Opera on
  Windows 10/11. (Opera ≥ 87 dropped Windows 7 / 8.1.)
- Brave 1.45 or earlier on Windows 7 SP1, or any current Brave on
  Windows 10/11. (Brave ≥ 1.46 dropped Windows 7 / 8.1.)
- Vivaldi 5.5 or earlier on Windows 7 SP1, or any current Vivaldi on
  Windows 10/11. (Vivaldi ≥ 5.6 dropped Windows 7 / 8.1.)

Opera, Brave, and Vivaldi are all Chromium-based and accept the same
Manifest V3 extension as Chrome; see Section 4.4–4.6 for install
instructions and `browser-extensions/{opera,brave,vivaldi}/README.md`
for browser-specific notes.

---

## 2. Build the application

### 2.1 Clone and restore

```cmd
git clone https://github.com/sawan/downloadpro.git
cd downloadpro
nuget restore SawanDownloadPro.sln
```

`nuget restore` downloads all NuGet packages listed in the `.csproj`
files (xunit, Moq, Microsoft.Extensions.Logging.Abstractions,
CommunityToolkit.Mvvm, System.Data.SQLite.Core, Newtonsoft.Json, etc.)
into a per-user package cache.

### 2.2 Build with Visual Studio

1. Open `SawanDownloadPro.sln` in Visual Studio.
2. Select `Release` and `Any CPU` (or `x86` / `x64`) from the toolbar.
3. **Build → Build Solution** (Ctrl+Shift+B).

### 2.3 Build from the command line

For an `Any CPU` Release build (suitable for development and testing):

```cmd
msbuild SawanDownloadPro.sln /p:Configuration=Release /p:Platform="Any CPU"
```

For an `x86` Release build (suitable for the 32-bit MSI):

```cmd
msbuild SawanDownloadPro.sln /p:Configuration=Release /p:Platform=x86
```

For an `x64` Release build (suitable for the 64-bit MSI):

```cmd
msbuild SawanDownloadPro.sln /p:Configuration=Release /p:Platform=x64
```

Build output lands in `src\<Project>\bin\<Platform>\Release\`.

### 2.4 Run the application

After building, the main executable is at:

```
src\SawanDownloadPro.App\bin\Debug\SawanDownloadPro.App.exe
```

(or `Release` instead of `Debug` for a release build).

You can run it directly from File Explorer, or from the command line:

```cmd
src\SawanDownloadPro.App\bin\Debug\SawanDownloadPro.App.exe
```

### 2.5 Run the test suite

Open `Test → Test Explorer` in Visual Studio, then click **Run All**.

Or from the command line (Developer Command Prompt for VS):

```cmd
vstest.console.exe tests\SawanDownloadPro.Tests\bin\Debug\SawanDownloadPro.Tests.dll
```

Or, if `dotnet` is installed:

```cmd
dotnet test tests\SawanDownloadPro.Tests\SawanDownloadPro.Tests.csproj
```

> Tests target `net48` and use the xUnit test runner. They will not run
> on Linux even with Mono.

---

## 3. Build the installer

The installer requires the application to be built in the matching
architecture first. From the `installer/` folder:

```cmd
REM 1. Build the application in both architectures.
cd ..
nuget restore SawanDownloadPro.sln
msbuild SawanDownloadPro.sln /p:Configuration=Release /p:Platform=x86
msbuild SawanDownloadPro.sln /p:Configuration=Release /p:Platform=x64

REM 2. Build the installer.
cd installer
BuildInstaller.bat
```

This produces:

- `installer\bin\x86\SawanDownloadProSetup.msi`
- `installer\bin\x64\SawanDownloadProSetup_x64.msi`

See `installer/README.md` for code-signing instructions and the
Windows 7 SP1 SHA-2 update requirement.

---

## 4. Load the browser extensions

The browser extensions are in `browser-extensions/<browser>/`. They are
**not** packaged; you load them as unpacked (Chrome/Edge) or temporary
(Firefox) extensions during development.

### 4.1 Chrome (Manifest V3)

1. Open Chrome and navigate to `chrome://extensions`.
2. Toggle **Developer mode** on (top-right toggle).
3. Click **Load unpacked**.
4. Select the `browser-extensions/chrome/` folder.
5. The extension should appear with a generated ID. Copy that ID for
   the next step (the native-messaging manifest needs it).

To pin the toolbar button, click the puzzle-piece icon in Chrome's
toolbar and pin "Sawan Download Pro".

### 4.2 Edge (Manifest V3)

Edge is Chromium-based and accepts the same MV3 extension:

1. Open Edge and navigate to `edge://extensions`.
2. Toggle **Developer mode** on (left sidebar).
3. Click **Load unpacked**.
4. Select the `browser-extensions/edge/` folder.
5. Copy the generated extension ID.

### 4.3 Firefox (Manifest V2)

1. Open Firefox and navigate to `about:debugging#/runtime/this-firefox`.
2. Click **Load Temporary Add-on...**.
3. Select any file inside the `browser-extensions/firefox/` folder
   (e.g. `manifest.json`).
4. The extension loads for the current Firefox session only. To install
   it permanently, you must sign the extension via Mozilla's AMO or use
   an Enterprise Policy. See `browser-extensions/firefox/README.md` for
   details.

> Temporary Firefox extensions are unloaded when Firefox exits. For
> long-term use, sign the extension at
> <https://addons.mozilla.org/developers/> with `web-ext sign`.

### 4.4 Opera (Manifest V3, Chromium-based)

Opera accepts the same MV3 extension as Chrome. The only practical
differences are the URL of the extensions page and the registry path
used to register the native host — and Opera actually shares Chrome's
registry path, so if Chrome is already registered Opera picks up the
same manifest.

1. Open Opera and navigate to `opera://extensions`.
2. Toggle **Developer mode** on (top-right toggle).
3. Click **Load unpacked**.
4. Select the `browser-extensions/opera/` folder.
5. Copy the generated extension ID.
6. Add the Opera extension ID to the `allowed_origins` array of
   `native-host/com.sawan.downloadpro.json`, then re-run the Sawan
   installer with **Enable Opera integration** ticked (or re-register
   the manifest manually — see `browser-extensions/opera/README.md`).

### 4.5 Brave (Manifest V3, Chromium-based)

Brave accepts the same MV3 extension as Chrome. Brave ships its own
registry path (`HKCU\Software\BraveSoftware\Brave-Browser\...`)
and does **not** share Chrome's path.

1. Open Brave and navigate to `brave://extensions`.
2. Toggle **Developer mode** on (top-right toggle).
3. Click **Load unpacked**.
4. Select the `browser-extensions/brave/` folder.
5. Copy the generated extension ID.
6. Add the Brave extension ID to the `allowed_origins` array of
   `native-host/com.sawan.downloadpro.json`, then re-run the Sawan
   installer with **Enable Brave integration** ticked (or re-register
   the manifest manually — see `browser-extensions/brave/README.md`).

### 4.6 Vivaldi (Manifest V3, Chromium-based)

Vivaldi accepts the same MV3 extension as Chrome. Vivaldi ships its
own registry path (`HKCU\Software\Vivaldi\...`) and does **not**
share Chrome's path.

1. Open Vivaldi and navigate to `vivaldi://extensions`.
2. Toggle **Developer mode** on (top-right toggle).
3. Click **Load unpacked**.
4. Select the `browser-extensions/vivaldi/` folder.
5. Copy the generated extension ID.
6. Add the Vivaldi extension ID to the `allowed_origins` array of
   `native-host/com.sawan.downloadpro.json`, then re-run the Sawan
   installer with **Enable Vivaldi integration** ticked (or re-register
   the manifest manually — see `browser-extensions/vivaldi/README.md`).

---

## 5. Install the native messaging host

The native messaging host is the bridge between the browser extension
and the Sawan Download Pro desktop app. Sawan Download Pro ships **two**
host implementations; you only need one:

| Implementation | Path                                                           | When to use                                                          |
|----------------|----------------------------------------------------------------|----------------------------------------------------------------------|
| C# (default)   | `src\SawanDownloadPro.BrowserIntegration\bin\...\SawanDownloadPro.BrowserIntegration.exe` | Always. No runtime install needed.                                   |
| Python (ref)   | `browser-extensions\native-host\sawan_native_host.py` + `.bat`  | Debugging or when you want to hack on the host without recompiling.  |

### 5.1 Install the C# host automatically (recommended)

1. Build the solution (see Section 2).
2. Launch Sawan Download Pro.
3. Open **Settings → Browser Integration**.
4. Tick **Enable Chrome integration**, **Enable Edge integration**,
   and / or **Enable Firefox integration**, and / or **Enable Opera
   integration**, **Enable Brave integration**, **Enable Vivaldi
   integration** as needed.
5. Click **Apply**. The app calls `ExtensionInstaller.InstallForChrome()`
   (or `Edge` / `Firefox` / `Opera` / `Brave` / `Vivaldi`) which writes
   the JSON manifest to
   `%LOCALAPPDATA%\SawanDownloadPro\native-messaging\com.sawan.downloadpro.json`
   and registers it in the appropriate registry location
   (`HKCU\Software\Google\Chrome\NativeMessagingHosts\...` for
   Chrome and Opera — Opera shares Chrome's path —
   `HKCU\Software\Microsoft\Edge\NativeMessagingHosts\...` for Edge,
   `HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\...`
   for Brave, `HKCU\Software\Vivaldi\NativeMessagingHosts\...` for
   Vivaldi, or `%APPDATA%\Mozilla\NativeMessagingHosts\` for
   Firefox). All Chromium extension IDs that are set on the installer
   are written into the shared manifest's `allowed_origins` array, so
   a single manifest works for every Chromium browser at once.
6. Restart the browser.

### 5.2 Edit the JSON manifest to use your extension ID

The manifest template at
`browser-extensions/native-host/com.sawan.downloadpro.json` contains
placeholder strings for the extension IDs. After loading the extension
in Chrome / Edge / Firefox (Section 4), copy the generated ID and
replace the placeholders:

```json
{
  "name": "com.sawan.downloadpro",
  "description": "Sawan Download Pro native messaging host",
  "path": "C:\\Program Files\\Sawan\\Sawan Download Pro\\native-host\\sawan_native_host.bat",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://YOUR_CHROME_EXTENSION_ID/"
  ],
  "allowed_extensions": [
    "sawan@sawan.example"
  ]
}
```

The C# installer writes the correct IDs automatically when you toggle
the checkboxes in Settings; this manual step is only needed if you
prefer to write the manifest by hand.

### 5.3 Verify the host is registered

Open a terminal and run:

```cmd
REM Chrome (also used by Opera)
reg query "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro"

REM Edge
reg query "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.sawan.downloadpro"

REM Brave
reg query "HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\com.sawan.downloadpro"

REM Vivaldi
reg query "HKCU\Software\Vivaldi\NativeMessagingHosts\com.sawan.downloadpro"

REM Firefox (no registry; check the file)
dir "%APPDATA%\Mozilla\NativeMessagingHosts\com.sawan.downloadpro.json"
```

If the registry key's `(Default)` value points to the JSON manifest
file, the host is registered. (Opera shares Chrome's registry path,
so the Chrome query covers both.)

### 5.4 Self-test the host

The C# host supports a `--selftest` flag that the installer can use to
verify the host is reachable:

```cmd
"C:\Program Files\Sawan\Sawan Download Pro\bin\SawanDownloadPro.BrowserIntegration.exe" --selftest
```

A successful self-test prints `OK` and exits with code 0.

---

## 6. Build the Python native host (optional)

If you want to use the Python host instead of the C# host:

1. Install Python 3.8+ (see Section 1.6).
2. (Optional) Install `pywin32` for named-pipe I/O:
   ```cmd
   python -m pip install pywin32
   ```
3. Edit `browser-extensions/native-host/sawan_native_host.bat` and set
   `SAWAN_PYTHON_EXE` to the absolute path of your `python.exe` if it
   is not on `PATH`.
4. Edit the JSON manifest's `path` field to point at
   `sawan_native_host.bat` (the .bat wraps `python.exe -u -B
   sawan_native_host.py`).
5. Reload the browser extension.

The Python host writes to
`%LOCALAPPDATA%\SawanDownloadPro\logs\native-host.log`. Check this log
if the host is not responding.

---

## 7. Verify everything works end-to-end

A complete verification checklist (mirrors the test cases in
`docs/TEST_REPORT.md`):

1. Launch the app from the Start Menu shortcut. It should open on the
   Downloads view.
2. Click **Add Download**, paste a small direct file URL (e.g.
   `https://speed.hetzner.de/100MB.bin`), and click **Start**.
3. The download should appear in the list with a progress bar.
4. Click **Pause**, then **Resume**. The download should continue from
   where it paused.
5. Click **Cancel**. The partial file should be removed (unless
   "Keep partial files on cancel" is enabled in Settings).
6. With the browser extension installed and the native host registered,
   open Chrome, right-click a link to a downloadable file, and choose
   **Download with Sawan Download Pro**. The URL should appear in the
   Sawan app within 1–2 seconds.
7. In Settings → Media, configure the path to `yt-dlp.exe` (you must
   obtain it yourself from <https://github.com/yt-dlp/yt-dlp/releases>).
   Open the Video Downloader window, paste a YouTube URL, and verify
   that probing returns a list of formats. Pick one and download a
   short clip.

If any step fails, consult `docs/TROUBLESHOOTING.md`.

---

## 8. Common build pitfalls

### 8.1 `nuget restore` fails with `401 Unauthorized` behind a proxy

Set the `HTTP_PROXY` and `HTTPS_PROXY` environment variables, or
configure a `nuget.config` with the proxy:

```cmd
nuget config set http_proxy http://user:pass@proxy.company.com:8080
```

### 8.2 `msbuild` not found on PATH

Open **Developer Command Prompt for VS 2019/2022** instead of a plain
`cmd.exe`. The Developer Command Prompt sets up the MSBuild environment
for you.

### 8.3 `System.Data.SQLite.Core` native binaries not copied to the output

The `System.Data.SQLite.Core` NuGet package ships the managed
`System.Data.SQLite.dll` plus a native `SQLite.Interop.dll` in an
`x86\` or `x64\` subfolder. If the native binary is missing, your app
will crash with `DllNotFoundException: SQLite.Interop.dll`. Build with
an explicit `Platform=x86` or `Platform=x64` (not `AnyCPU`) to ensure
the correct native binary is copied.

### 8.4 `WPF` designer errors in Visual Studio

The XAML designer occasionally fails to load the App's main window if
the App project's references are not restored. Close the designer, run
`nuget restore`, rebuild, and reopen.

### 8.5 WiX build fails with `candle.exe` not found

Install WiX v3.14 and either add its `bin\` folder to `PATH` or set the
`WIX` environment variable. See Section 1.5.
