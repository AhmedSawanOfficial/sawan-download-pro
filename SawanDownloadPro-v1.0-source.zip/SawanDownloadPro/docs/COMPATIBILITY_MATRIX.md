# Sawan Download Pro — Compatibility Matrix

This document is a focused, single-purpose extract of the architecture
document's compatibility section. It tells you exactly which Windows
versions and architectures Sawan Download Pro is designed to run on,
what runtimes they require, which browser versions are supported for
integration, and — critically — **whether each combination has been
verified on physical hardware**.

> **Status discipline.** Every cell is labelled with one of:
> - **Verified** — tested on physical hardware or a VM by the Sawan
>   engineering team. The combination is known to work.
> - **Designed for, not yet verified** — the source code targets this
>   combination and the architecture supports it, but no physical
>   test has been performed.
> - **Not supported** — the combination is intentionally not supported
>   and will not be made to work.
> - **Degraded** — the combination works but with known limitations
>   (documented in the "Notes" column).

As of this build, **no combination has been verified** because the
project has not yet been compiled or run on Windows. Every cell that
is not "Not supported" is therefore **Designed for, not yet verified**.

---

## 1. Operating system × architecture

| OS                       | Architecture | Runtime requirement                                          | Browser support                                | Tested?                              | Notes                                                                                                            |
|--------------------------|--------------|--------------------------------------------------------------|------------------------------------------------|--------------------------------------|------------------------------------------------------------------------------------------------------------------|
| Windows 7 SP1 (32-bit)   | x86          | .NET Framework 4.8 (KB4055001); TLS 1.2 via KB4019276; SHA-2 via KB4474419 (for installer signature) | Chrome ≤ 109, Firefox ≤ 115 ESR, Opera ≤ 86, Brave ≤ 1.45, Vivaldi ≤ 5.5 | Designed for, not yet verified       | No TLS 1.3. Modern browsers unavailable. Modern AV may not install.                                              |
| Windows 7 SP1 (64-bit)   | x64          | .NET Framework 4.8 (KB4055001); TLS 1.2 via KB4019276; SHA-2 via KB4474419 | Chrome ≤ 109, Firefox ≤ 115 ESR, Opera ≤ 86, Brave ≤ 1.45, Vivaldi ≤ 5.5 | Designed for, not yet verified       | Same as above. 64-bit builds can use more memory for very large files.                                           |
| Windows 8.1              | x86 / x64    | .NET Framework 4.8                                           | Chrome / Edge / Firefox / Opera / Brave / Vivaldi current | Designed for, not yet verified       | Not officially targeted; should work because the Win7 SP1 and Win10 builds overlap. Not a release blocker.       |
| Windows 10 (any build)   | x86          | .NET Framework 4.8 (preinstalled on 1903+)                   | Chrome / Edge / Firefox / Opera / Brave / Vivaldi current                | Designed for, not yet verified       | Pre-1607 builds may lack PowerShell 5.1 (used by optional post-download scripts).                                |
| Windows 10 (any build)   | x64          | .NET Framework 4.8 (preinstalled on 1903+)                   | Chrome / Edge / Firefox / Opera / Brave / Vivaldi current                | Designed for, not yet verified       | Recommended target for most users.                                                                               |
| Windows 11               | x64          | .NET Framework 4.8 (preinstalled)                            | Chrome / Edge / Firefox / Opera / Brave / Vivaldi current | Designed for, not yet verified       | Recommended target. ARM64 is not supported (no .NET Framework 4.8 ARM64 build exists).                           |
| Windows 11               | ARM64        | n/a                                                          | n/a                                            | Not supported                        | .NET Framework 4.8 has no ARM64 build. Use a .NET 6+ rewrite (out of scope for v1.x).                            |
| Windows Server 2012 R2   | x64          | .NET Framework 4.8                                           | N/A (server)                                   | Designed for, not yet verified       | Should work as a side effect of Win8.1 compatibility; not a target.                                              |
| Windows Server 2016+     | x64          | .NET Framework 4.8                                           | N/A (server)                                   | Designed for, not yet verified       | Should work as a side effect of Win10 compatibility; not a target.                                               |
| Windows Vista / 7 (no SP1) | any        | n/a                                                          | n/a                                            | Not supported                        | .NET Framework 4.8 requires Windows 7 SP1.                                                                       |
| Linux / macOS            | any          | n/a                                                          | n/a                                            | Not supported                        | The architecture is .NET Framework 4.8 + WPF, neither available on Linux / macOS.                                |

---

## 2. Runtime requirements (detail)

### 2.1 .NET Framework 4.8

Required on every supported Windows version. The installer's launch
condition checks for `NETFRAMEWORK45 >= #528040` (the registry value
that corresponds to .NET Framework 4.8 RTM). If the framework is not
present, the installer refuses with a clear message directing the user
to <https://dotnet.microsoft.com/download/dotnet-framework>.

On Windows 7 SP1, .NET Framework 4.8 must be installed manually via
the standalone installer. On Windows 10 1903+ and Windows 11, it is
preinstalled.

The reference assemblies (Developer Pack) are required only on the
build host, not on the user's machine.

### 2.2 TLS 1.2

Forced by default (`AppSettings.ForceTls12 = true`). On Windows 7 SP1
this requires KB4019276 to be installed; without it, HTTPS downloads
will fail with a TLS handshake error. See `docs/TROUBLESHOOTING.md`
Section 1.1.

### 2.3 SHA-2 code signing (Windows 7 SP1 only)

Required only to verify the installer's digital signature. Without
KB4474419, Windows 7 SP1 cannot verify SHA-256 signatures and shows
a "publisher could not be verified" warning when the user runs the
MSI. The MSI still installs if the user clicks through the warning.

### 2.4 SQLite native binary

`SQLite.Interop.dll` is bundled in both x86 and x64 variants. The
correct variant is loaded at runtime based on the host process's
bitness. The installer ships both variants; the user does not need
to do anything.

---

## 3. Browser support

| Browser                     | Windows 7 SP1                 | Windows 10 / 11                  | Extension type              | Tested?                              |
|-----------------------------|-------------------------------|-----------------------------------|-----------------------------|--------------------------------------|
| Google Chrome               | ≤ 109 only                    | Current                           | Manifest V3 (Chrome MV3)    | Designed for, not yet verified       |
| Microsoft Edge (Chromium)   | Not available                 | Current                           | Manifest V3 (same as Chrome)| Designed for, not yet verified       |
| Mozilla Firefox             | ≤ 115 ESR only                | Current                           | Manifest V2 (Firefox MV2)   | Designed for, not yet verified       |
| Opera                       | ≤ 86 only                     | Current                           | Manifest V3 (same as Chrome)| Designed for, not yet verified       |
| Brave                       | ≤ 1.45 only                   | Current                           | Manifest V3 (same as Chrome)| Designed for, not yet verified       |
| Vivaldi                     | ≤ 5.5 only                    | Current                           | Manifest V3 (same as Chrome)| Designed for, not yet verified       |
| Microsoft Edge (EdgeHTML)   | Not supported                 | Not supported (deprecated)        | n/a                         | Not supported                        |
| Internet Explorer           | Not supported                 | Not supported                     | n/a                         | Not supported                        |
| Safari (Windows)            | Not supported (deprecated)    | Not supported                     | n/a                         | Not supported                        |

### 3.1 Why Chrome ≥ 110 is not supported on Windows 7 SP1

Google dropped Windows 7 support in Chrome 110 (released February
2023). The last Chrome version that installs on Windows 7 SP1 is
109.0.5414.120. Users on Windows 7 SP1 who want Chrome integration
must stay on Chrome 109 or move to Firefox 115 ESR.

### 3.2 Why Firefox 115 ESR is the minimum

Mozilla extended Windows 7 / 8.1 support through Firefox 115 ESR
(released August 2023). Firefox 116+ dropped Windows 7 / 8.1. Users
on Windows 7 SP1 who want Firefox integration must use Firefox 115
ESR, available from <https://www.mozilla.org/firefox/all/#product-desktop-esr>.

### 3.3 Why the Firefox extension uses Manifest V2

Mozilla has committed to supporting Manifest V2 indefinitely and has
not finalized a Manifest V3 schedule that matches Chrome's. To avoid
forking the extension, the Sawan Firefox extension stays on MV2. If
Mozilla finalizes MV3 in a way that's incompatible with MV2, the
extension will be ported; until then, MV2 is the right choice for
Firefox compatibility.

### 3.4 Opera, Brave, and Vivaldi Windows 7 cutoffs

Opera, Brave, and Vivaldi are all Chromium-based and accept the same
Manifest V3 extension as Chrome. They each have their own Windows 7
support cutoff, however:

- **Opera** ≥ 87 dropped Windows 7 / 8.1. The last Opera version that
  installs on Windows 7 SP1 is in the 86 range.
- **Brave** ≥ 1.46 dropped Windows 7 / 8.1. The last Brave version
  that installs on Windows 7 SP1 is in the 1.45 range.
- **Vivaldi** ≥ 5.6 dropped Windows 7 / 8.1. The last Vivaldi version
  that installs on Windows 7 SP1 is in the 5.5 range.

Users on Windows 7 SP1 who want integration with one of these
browsers must pin the browser to the listed version or earlier. The
Sawan native host itself runs on Windows 7 SP1 — only the browser is
the limiting factor.

> **Verification status:** Designed for, not yet verified. The
> extensions are written to the standard Chrome MV3 surface and the
> installer registers the host under each browser's documented
> native-messaging registry path (Opera shares Chrome's path; Brave
> and Vivaldi use their own). End-to-end testing on physical hardware
> with each browser installed has not been performed by the Sawan
> team.

---

## 4. Architecture × installer matrix

| Architecture | Installer file                          | Default install folder                                    | Tested?                              |
|--------------|-----------------------------------------|-----------------------------------------------------------|--------------------------------------|
| x86          | `SawanDownloadProSetup.msi`             | `C:\Program Files\Sawan\Sawan Download Pro\`             | Designed for, not yet verified       |
| x64          | `SawanDownloadProSetup_x64.msi`         | `C:\Program Files\Sawan\Sawan Download Pro\`             | Designed for, not yet verified       |
| ARM64        | (not produced)                          | n/a                                                       | Not supported                        |

> **Note on x64-on-Wow64.** The x86 MSI runs fine on 64-bit Windows
> via the WoW64 subsystem. The x64 MSI produces a slightly faster
> binary and avoids WoW64 context-switch overhead, but the difference
> is negligible for a download manager. Users who don't know which to
> pick should use x64 on 64-bit Windows and x86 on 32-bit Windows.

---

## 5. Hardware requirements

| Resource            | Minimum                       | Recommended                   |
|---------------------|-------------------------------|-------------------------------|
| CPU                 | 1 GHz (Win7 SP1 minimum)      | 2 GHz dual-core              |
| RAM                 | 1 GB (Win7 SP1 32-bit)        | 4 GB                         |
|                     | 2 GB (Win7 SP1 64-bit)        |                              |
| Disk space (install)| 80 MB                         | 100 MB                       |
| Disk space (data)   | Varies with download volume    | 1 GB free for temp files     |
| Display             | 1024 × 768                    | 1920 × 1080                  |
| Network             | Any TCP/IP                    | Broadband                    |

The app is DPI-aware and supports high-DPI displays. On Windows 7 SP1
without DPI awareness patches, the UI may appear slightly blurry at
150% scaling; this is a Windows limitation, not a Sawan bug.

---

## 6. Localization matrix

| Language | UI | Help docs | Installer | Tested?                              |
|----------|----|-----------|-----------|--------------------------------------|
| Arabic   | Yes | Yes (`USER_GUIDE_AR.md`) | Yes (installer includes RTL strings) | Designed for, not yet verified |
| English  | Yes | Yes (`USER_GUIDE_EN.md`) | Yes                                   | Designed for, not yet verified |

Arabic is the default UI language; English is fully supported. The
language toggle in Settings switches both UI text and layout direction
(RTL ↔ LTR). The installer's license agreement is in English; an
Arabic translation is in `USER_GUIDE_AR.md` Section 1.2.

---

## 7. Update path compatibility

| From version | To version | Supported? | Notes                                                                                                            |
|--------------|------------|------------|------------------------------------------------------------------------------------------------------------------|
| 1.0          | 1.0.x      | Yes        | Patch upgrades via the same MSI; `MajorUpgrade AllowSameVersionUpgrades=yes` permits in-place reinstall.         |
| 1.0          | 1.1        | Yes (planned) | Settings and DB schema forward-compatible.                                                                       |
| 1.1          | 1.0        | No         | Downgrades are blocked by `MajorUpgrade DowngradeErrorMessage`.                                                  |
| 1.x          | 2.0        | Yes (planned) | DB schema may require a migration; the migration runner handles it automatically.                                |
| 2.x          | 1.x        | No         | Downgrades are blocked.                                                                                          |

The `UpgradeCode` in `installer/Product.wxs` is fixed at
`7B7C7D7D-1234-4321-ABCD-1234567890AB` and will never change. This
guarantees that every future version detects and upgrades every past
version cleanly.

---

## 8. What to do if your combination is "not yet verified"

If you are running a combination marked "Designed for, not yet
verified":

1. Install the MSI.
2. Run through the manual checklist in `docs/TEST_REPORT.md` Section 6.
3. If something breaks, file an issue at the project's tracker with:
   - The exact OS version (run `winver`).
   - The architecture (run `echo %PROCESSOR_ARCHITECTURE%`).
   - The .NET Framework version (run
     `reg query "HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" /v Release`).
   - The Sawan version (from Settings → About).
   - The exact steps to reproduce the issue.
   - The contents of `%LOCALAPPDATA%\SawanDownloadPro\logs\sawan.log`.

The Sawan engineering team will update this matrix as combinations are
verified.
