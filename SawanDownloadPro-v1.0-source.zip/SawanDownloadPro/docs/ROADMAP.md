# Sawan Download Pro — Roadmap

This document outlines the planned evolution of Sawan Download Pro
after the v1.0 first release. It is a forward-looking statement of
intent, **not** a commitment: priorities may shift based on user
feedback, platform changes, and engineering capacity.

> **Status discipline.** Items in this roadmap are labelled "Released"
> (shipped in the named version), "Planned" (we intend to ship them
> in the named release), "Investigating" (we are researching
> feasibility but have not committed), or "Future" (on the long-term
> wishlist). Anything not yet released is subject to change or
> cancellation.

---

## 1. Release timeline

| Version | Theme                                          | Target window    | Status                                                                |
|---------|------------------------------------------------|------------------|-----------------------------------------------------------------------|
| 1.0     | First release: Dark Eggplant identity          | October 2026     | Released (source complete; binary compilation and Windows testing pending) |
| 1.1     | Scheduler UI, batch operations, plugin SDK foundation | Q1 2027    | Planned                                                               |
| 1.2     | HLS/DASH, BitTorrent, cloud sync, integrated media player | Q2 2027 | Investigating                                                         |
| Future  | Plugin marketplace, mobile companion, extractor hardening, perf dashboard | 2028+ | Future                                                                |

---

## 2. v1.0 (current) — First Release

v1.0 is the first official release of the Sawan product line. It
introduces:

- **Dark Eggplant identity.** Rebrand from the Stage-2 MVP blue/cyan
  palette to the new Dark Eggplant palette (`#21102F` primary
  background, `#6F42A6` primary accent, `#A78BFA` secondary accent).
  Default theme changed from "System" to **Dark Eggplant**.
- **Real-time dashboard.** Live totals (active, queued, completed,
  failed), aggregate download speed, free disk space, recent
  notifications, quick actions. Replaces the empty Home placeholder
  from the MVP.
- **About Sawan page.** Creator credit (Ahmed Sawan) and the four
  official contact channels: WhatsApp, YouTube, Facebook, Telegram.
- **First-run welcome screen.** A guided wizard that walks new users
  through language, theme, default download folder, browser
  integration (all six supported browsers), and Private Downloads
  consent.
- **Private Downloads mode.** Separate in-memory session for sensitive
  downloads; isolated from the regular queue and history; Clear
  Private Session action; optional auto-clear-on-exit; optional
  secure-delete of private partial files.
- **Security & Privacy dashboard.** A single panel collecting DPAPI
  status, telemetry status (always off), log management, antivirus
  integration, native-messaging host status, private-mode status,
  update check status, and a one-click security self-check.
- **Six-browser integration.** Opera, Brave, and Vivaldi added to the
  existing Chrome, Edge, and Firefox support. All three new browsers
  ship the Chrome MV3 extension byte-for-byte.
- **SawanDownloadPro.Themes module.** A new project dedicated to
  theme management (palette, accent overrides, theme import/export).
- **Honest release status.** Source code is complete and reviewed.
  Binary compilation on Windows and end-to-end testing on physical
  Windows 7 / 10 / 11 hardware are the next milestone.

See [`docs/RELEASE_NOTES_v1.0.md`](RELEASE_NOTES_v1.0.md) for the full
release notes.

### 2.1 What v1.0 does NOT include (intentionally)

- **No auto-update by default.** The optional updater is off and
  requires explicit opt-in plus Ed25519 signature verification.
- **No telemetry, no analytics, no crash reporting.** This is a
  binding commitment for the entire 1.x release line.
- **No bundled FFmpeg or yt-dlp.** Users supply their own binaries.
- **No mobile companion app.** v1.0 is desktop-only.
- **No cloud sync.** Scheduled for v1.2.
- **No BitTorrent support.** Scheduled for v1.2.
- **No integrated media player.** Scheduled for v1.2.

---

## 3. v1.1 (planned) — Scheduler UI, batch operations, plugin SDK foundation

### 3.1 Improved scheduler window UI

**Planned.** The v1.0 scheduler window is functional but visually
dated. v1.1 introduces:

- **Calendar view.** A month calendar overlay showing scheduled
  queue starts and stops, with drag-to-move and click-to-edit.
- **Schedule templates.** Save a schedule as a named template (e.g.
  "Weekend overnight", "Work hours") and apply it with one click.
- **Conflict detection.** Warns when a new schedule overlaps an
  existing one and offers to merge or replace.
- **Recurring patterns.** Beyond daily: weekly, weekdays-only,
  weekends-only, custom day-of-week patterns.
- **Visual timeline.** A horizontal timeline showing the next 24
  hours of scheduled events, with the current time marked.

### 3.2 Batch operations

**Planned.** A new `IBatchOperations` interface in Core:

```csharp
public interface IBatchOperations
{
    Task<BatchResult> PauseAllAsync(IEnumerable<string> taskIds);
    Task<BatchResult> ResumeAllAsync(IEnumerable<string> taskIds);
    Task<BatchResult> CancelAllAsync(IEnumerable<string> taskIds);
    Task<BatchResult> RetryAllAsync(IEnumerable<string> taskIds);
    Task<BatchResult> RecategorizeAllAsync(IEnumerable<string> taskIds, DownloadCategory category);
    Task<BatchResult> MoveAllAsync(IEnumerable<string> taskIds, string newDirectory);
}
```

The `BatchResult` carries per-task success/failure so the UI can show
which tasks in the batch succeeded and which failed (and why). The
v1.0 main window's DataGrid will gain multi-select support; the
context menu will surface the batch actions when more than one row is
selected.

### 3.3 Import / export task lists

**Planned.**

- **Export to JSON.** Exports the entire queue (active + history) to a
  single `.json` file. Useful for backups and for moving a download
  set between machines.
- **Export to Metalink / .meta4.** Exports the queue to a Metalink v4
  file (RFC 5854) for interop with other download managers.
- **Import from JSON.** Imports an exported JSON file back into the
  queue. Downloaded files are not re-downloaded; only the queue
  entries are restored.
- **Import from text file.** Already in v1.0; v1.1 adds support for
  `# comment` lines and `URL | filename | category` triplets.
- **Import from clipboard.** Paste a list of URLs (one per line) into
  a dialog and add them all to the queue.

### 3.4 FTP downloads

**Planned.** v1.0 supports HTTP/HTTPS only. v1.1 adds FTP and FTPS
support:

- FTP credentials sent in plaintext over the network (warned in the
  UI).
- FTP does not support segmented downloads; the engine falls back to
  a single-connection download for FTP URLs.
- FTP pause/resume depends on the server's `REST` command support.
- SFTP (SSH File Transfer Protocol) is **not** planned for v1.1; it
  is on the Future list.

### 3.5 Custom categories UI

**Planned.** v1.0 ships with six built-in categories (Compressed,
Videos, Music, Documents, Programs, Other). v1.1 lets the user
define their own categories with custom names, colours, subfolders,
and extension mappings.

### 3.6 Plugin SDK foundation

**Planned.** v1.1 introduces the foundational types and contracts
for a plugin SDK, without shipping a stable public API:

- `SawanDownloadPro.PluginSdk` project with interfaces
  (`IVideoExtractor`, `IUrlHandler`, `IPostDownloadAction`, `IUiPanel`).
- A plugin discovery mechanism that scans
  `%LOCALAPPDATA%\SawanDownloadPro\plugins\` on startup.
- A permissions manifest format (network, filesystem read, filesystem
  write, native process launch) with first-load user consent.
- No public documentation and no compatibility promise in v1.1. The
  SDK stabilizes in v1.2 or later.

### 3.7 Other v1.1 items

- **Fake clock abstraction.** `ISchedulerClock` so the scheduler's
  timers can be unit-tested without real-time delays. Closes the
  TC-018 gap in `docs/TEST_REPORT.md`.
- **Per-download bandwidth limit.** Extends `IBandwidthThrottle` to
  allow a user-settable per-task limit, surfaced in the Add Download
  dialog.
- **Better large-file UX.** Throttles UI updates for files >50 GB
  (closes the M-06 hang in `docs/TROUBLESHOOTING.md`).
- **Improved retry visibility.** Shows the retry count and next-retry
  timestamp in the download row.

---

## 4. v1.2 (planned) — Streaming media, BitTorrent, cloud sync, integrated player

### 4.1 HLS / DASH streaming media support

**Investigating.** v1.2 adds support for HTTP Live Streaming (HLS,
`.m3u8` master playlists) and MPEG-DASH (`.mpd` manifests) as
first-class download sources. Sawan will:

- Parse the master playlist and list available variants (resolution,
  bitrate, codec).
- Download the chosen variant's segments in parallel using the
  existing segmented-download engine.
- Optionally invoke FFmpeg to mux the segments into a single MP4 file.

This unlocks downloads from streaming sites that publish HLS or DASH
manifests but do not publish a single-file MP4. The user remains
responsible for ensuring they are authorized to download the content
under the source platform's Terms of Service.

### 4.2 BitTorrent protocol

**Investigating.** v1.2 adds BitTorrent as a first-class download
source. Users can add `.torrent` files or magnet links to the queue,
and Sawan will fetch the file via the BitTorrent protocol. Features:

- Add `.torrent` file or magnet link to the queue.
- Per-torrent file selection (choose which files inside a multi-file
  torrent to download).
- Sequential download mode (useful for media playback while
  downloading).
- Peer counter and per-peer statistics in the download details panel.
- DHT support for magnet links without a tracker.
- Optional upload limit and seeding ratio.

The leading library candidate is **MonoTorrent** (MIT licensed, pure
C#, works on .NET Framework 4.8). The user guide will include a clear
"use only for lawful content" notice, matching the existing notice
for the media downloader.

### 4.3 Cloud sync (opt-in)

**Investigating.** Cloud sync lets users synchronize their download
queue and history across multiple machines. The feature is **opt-in**
and **off by default**. When enabled, only metadata (URL, filename,
category, status, timestamps) is synced — never the downloaded file
bytes themselves.

- **Provider-agnostic.** v1.2 ships with two providers: WebDAV (works
  with Nextcloud, ownCloud, etc.) and a local folder (which can be a
  Dropbox / OneDrive / Google Drive sync folder).
- **Conflict resolution.** Last-write-wins per task. Conflicts are
  logged but not auto-resolved.
- **Encryption.** The sync file is encrypted with a user-supplied
  passphrase (Argon2id key derivation + AES-GCM). The cloud provider
  sees only ciphertext.
- **No Sawan-hosted backend.** Sawan does not run a sync server. The
  user picks their own provider.

### 4.4 Pro edition feature gates

**Investigating.** A "Pro" edition (paid, one-time purchase or
per-major-version license) may be introduced with these features:

- **Cloud sync** (described above) — free in v1.2; may move to Pro in
  a future version. We commit to never moving a feature from free to
  Pro within a minor version: any feature that's free in vN.x stays
  free through vN.x+.
- **Concurrent queue profiles.** Define named sets of queue settings
  (max-simultaneous, speed limits, per-domain rules) and switch
  between them with one click.
- **Per-domain rules.** Automatically route URLs from specific
  domains to specific folders, categories, or speed limits.
- **Site-specific extractors.** Additional video extractors beyond
  YouTube.

The free edition remains fully functional for HTTP/HTTPS/FTP
downloads, browser integration, scheduling, and the YouTube
extractor.

### 4.5 Integrated media player

**Investigating.** A built-in media player window (based on
`libvlc` via `Vlc.DotNet`, or on Windows Media Foundation's
`IMFMediaEngine` for a lighter dependency) lets users play downloaded
media without leaving the app. Features:

- Playback at 0.25x–4x speed.
- Subtitle track selection (for files with embedded subs).
- A/B loop on a selected range.
- "Trim and save" — invokes the existing FFmpeg integration to save a
  clip of the current playback range.

`libvlc` is LGPL; `Vlc.DotNet` is MIT. Both can be bundled under the
same terms as FFmpeg (i.e. not bundled — user supplies the binary).

---

## 5. Future — Plugin marketplace, mobile companion, hardening

### 5.1 Plugin marketplace

**Future.** Once the plugin SDK (v1.1) has stabilized, a community
plugin marketplace could let users discover and install third-party
extractors, URL handlers, and post-download actions. The marketplace
would be a static site listing plugins with their manifest, source
URL, and signature; Sawan would verify signatures before install.

This is a long-term goal and depends on the SDK reaching a stable API
surface and on community uptake.

### 5.2 Mobile companion app

**Future.** Sawan is a Windows desktop download manager. A mobile
companion app (Android and/or iOS) could:

- Monitor the desktop queue from a phone on the same network.
- Add URLs to the desktop queue by sharing from the phone's browser.
- Receive notifications when downloads complete.

This is not a port of Sawan to mobile. The desktop app remains the
sole download engine; the mobile app is a remote control. No
release window is committed.

### 5.3 Edge-case extractor hardening

**Future.** The v1.0 YouTube extractor depends on `yt-dlp` and can
break when YouTube changes its player API. Future work will
investigate:

- A built-in fallback extractor that handles the most common YouTube
  player response shapes without depending on yt-dlp.
- A subscription model where the user can configure multiple
  extractors per source and Sawan tries them in order.
- Optional yt-dlp auto-update (with explicit user consent).

### 5.4 Performance dashboard

**Future.** The v1.0 dashboard shows live totals and speed. A
performance dashboard would add:

- Historical throughput graphs (last hour, last day, last week).
- Per-host speed breakdown (which servers are slow).
- Per-category size totals.
- Disk I/O utilisation on the download drive.

This depends on collecting local historical data; we will not collect
this data without explicit user opt-in.

---

## 6. What this roadmap does NOT promise

To stay honest, the following items are **not** on the roadmap:

- **macOS / Linux native ports.** The architecture is .NET Framework
  4.8 + WPF, neither of which is available on macOS / Linux. A
  cross-platform rewrite would be a different product.
- **A built-in VPN.** Use a real VPN. Sawan is not a privacy VPN
  product.
- **Ad injection or sponsored downloads.** Never.
- **Telemetry, even "anonymized".** Never. See `docs/SECURITY.md`
  Section 7 and `docs/PRIVACY.md` Section 1.
- **Auto-update without explicit user opt-in.** The updater checks a
  URL the user configures and verifies an Ed25519 signature before
  applying. We will never push an update silently.
- **DRM bypass.** Sawan will not bypass DRM, login walls, or
  members-only restrictions on any source platform. This is a binding
  commitment.
- **Bundling FFmpeg, yt-dlp, or any other GPL/LGPL binary.** Users
  supply their own.
- **A Sawan-hosted sync server or account system.** Cloud sync, when
  it ships, will be provider-agnostic and client-side encrypted.

---

## 7. How to influence this roadmap

File an issue at the project's tracker with the prefix `[roadmap]`.
Roadmap issues are triaged monthly. The most upvoted requests are
folded into the next planning cycle. We commit to responding to every
roadmap issue within 30 days, even if the response is "not planned".

For private contact with the creator, use the official Sawan channels
listed in [`docs/ABOUT_AHMED_SAWAN.md`](ABOUT_AHMED_SAWAN.md):
WhatsApp, YouTube, Facebook, and Telegram.
