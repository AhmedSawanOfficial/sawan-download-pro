# Sawan Download Pro — Privacy Statement (v1.0)

> **Tagline:** Fast. Smart. In Control.
>
> **Created by:** Ahmed Sawan
>
> **Release:** Version 1.0 — First Release (October 2026)

This document describes exactly what Sawan Download Pro v1.0 collects,
what it stores, what it transmits, and what it deliberately does not
do. It is the authoritative privacy statement for the v1.0 release
line. If any other document in this project appears to contradict this
statement, this statement prevails for the v1.0 release line.

Sawan Download Pro is a **desktop application** that runs entirely on
the user's machine. It is not a SaaS product. It does not have a
backend. It does not have a user account system. The only network
traffic it generates is the traffic the user explicitly asks it to
generate (downloads, URL probes) and the optional update check the
user must opt into.

---

## 1. Data collection — NONE

Sawan Download Pro v1.0 does **not** collect any of the following:

- **Telemetry** — no usage events, no feature-use counters, no
  session-length tracking.
- **Analytics** — no Google Analytics, no Application Insights, no
  PostHog, no Mixpanel, no Matomo, no custom analytics.
- **Crash reporting** — no Sentry, no Crashpad, no Breakpad, no
  Windows Error Reporting opt-in. If the app crashes, the crash is
  written to a local log file (see Section 6); the user decides
  whether to share it.
- **Hardware fingerprints** — no CPU ID, no motherboard serial, no
  MAC address, no Windows Machine ID is read or transmitted.
- **Usage fingerprints** — no install ID, no anonymous client ID, no
  per-user GUID is generated or stored.

The only exception is the **optional update check** (Section 7), which
is off by default and which, when enabled, sends only an HTTP GET to a
URL the user configures — no identifying information is included in
the request.

This is a **binding commitment** for the entire 1.x release line. Any
future version that intends to introduce telemetry, analytics, or
crash reporting will require an explicit opt-in dialog at first launch
and will be documented in this file.

---

## 2. Local data

Sawan Download Pro stores all of its state on the user's local machine
in a single directory tree rooted at:

```
%LOCALAPPDATA%\SawanDownloadPro\
```

The default layout is:

| Path                                          | Contents                                                                  |
|-----------------------------------------------|---------------------------------------------------------------------------|
| `data\sawan.db`                               | SQLite database: download tasks, segments, settings, history.             |
| `data\sawan.db-wal`, `data\sawan.db-shm`      | SQLite WAL-mode journal files (transient).                                |
| `data\settings.json`                          | Application settings (mirrored from the `settings` table in the DB).      |
| `logs\sawan.log`                              | Application log (rotated at 10 MB; previous 5 kept).                       |
| `logs\media.log`                              | Media extractor + FFmpeg invocations.                                     |
| `logs\native-host.log`                        | Native messaging host events.                                             |
| `temp\`                                       | `.part` and `.sawanmeta` files for in-progress downloads.                  |
| `native-messaging\com.sawan.downloadpro.json` | Native messaging host manifest (written by the per-browser installer).    |

The user can inspect or delete any of these files at any time. Sawan
does not lock the database while the app is not running. The user can
open `sawan.db` with any SQLite browser (e.g. DB Browser for SQLite)
and inspect every table and every row.

The database file is **not** encrypted. If the user wants at-rest
encryption for the entire database, they should enable BitLocker (or
equivalent) on the drive that hosts `%LOCALAPPDATA%`. Sawan does not
implement its own database encryption because DPAPI per-cell encryption
is reserved for credentials (Section 5) and per-file encryption would
prevent the user from inspecting their own data with standard tools.

### 2.1 What's in the database

The SQLite database contains the following tables. Full schema is in
`src/SawanDownloadPro.Storage/Schema/SchemaV1.cs`.

- **`downloads`** — one row per download task. Columns: URL, save path,
  size, status, category, priority, retry count, timestamps, optional
  `auth_password_enc` (DPAPI-encrypted, see Section 5), `is_private`
  (set to 1 for tasks added in Private mode, see Section 4).
- **`segments`** — one row per segment of a segmented download. Columns:
  byte range, status, bytes downloaded.
- **`settings`** — key-value table mirroring `settings.json`.
- **`history`** — completed (and optionally deleted) downloads.
  Retains URL, filename, size, completion timestamp.
- **`schema_migrations`** — applied migration versions.

### 2.2 User can delete at any time

To remove all Sawan Download Pro data from a machine:

1. Close the app.
2. Delete `%LOCALAPPDATA%\SawanDownloadPro\` recursively.
3. (Optional) Delete the user's download folder, typically
   `%USERPROFILE%\Downloads\Sawan\`, if you also want to remove the
   actual downloaded files.

This is also what the uninstaller does **not** do by default — the
uninstaller removes application binaries but preserves user data, so
that re-installing restores the user's queue, history, and settings.
To remove user data on uninstall, the user must explicitly delete the
directory above.

---

## 3. Private Downloads mode

Private Downloads mode is a v1.0 feature that lets the user isolate
sensitive downloads from Sawan's regular queue. When the user enables
Private mode from the sidebar or from the Security & Privacy panel:

- A separate in-memory session is created. Private tasks live in this
  session and do not appear in the All, Active, Today, Failed, or
  History smart views.
- Private tasks **are** persisted to the SQLite database, but in a
  separate partition identified by `is_private=1` on the `downloads`
  row. They survive an app restart, but only become visible again
  when the user re-enters Private mode.
- The user can clear the private session at any time with the **Clear
  Private Session** action in the Security & Privacy panel. Clearing
  removes every private task row, every private segment row, every
  private `.part` and `.sawanmeta` file, and every private entry from
  the history table — atomically, in a single SQLite transaction.
- An optional **Auto-clear private session on exit** setting (Settings
  → Private Downloads) destroys the private partition when the app
  exits, so a fresh launch always starts with an empty private
  session.
- An optional **Secure-delete private partial files** setting
  overwrites the bytes of every private `.part` file with zeros before
  unlinking, so the files cannot be recovered from the Recycle Bin or
  by simple undelete tools. (This is not a defence against forensic
  tools that read the raw disk; see Section 4.1.)

### 3.1 What Private mode ISOLATES

- Sawan's main queue (private tasks don't appear in the regular
  sidebar smart views).
- Sawan's history (private tasks don't appear in the regular History
  view; they have their own private history).
- Sawan's notifications (private-task toasts are suppressed unless the
  user is currently in Private mode).
- Sawan's clipboard monitor (URLs captured by the clipboard monitor
  while Private mode is active are routed to the private session, not
  the regular queue).

### 3.2 What Private mode DOES NOT isolate

- **Browser history.** Sawan has no control over the user's browser.
  If the user reached the download URL via the browser, the URL
  remains in the browser's history, downloads list, and address-bar
  autocomplete. The user must clear those separately (browser settings
  → Clear browsing data).
- **Operating-system file system.** If the user has chosen to save
  private downloads into a regular folder (e.g. the Desktop), the
  completed file remains in that folder even after Clear Private
  Session — Clear Private Session only removes the Sawan task entry
  and the partial file, not the completed download. The user should
  either save private downloads into a folder they manage separately,
  or use the secure-delete option to destroy partial files.
- **NTFS file system journal and USN journal.** The Windows NTFS
  driver records file create/rename/delete events in the USN journal
  and in the $MFT. Sawan does not clear these journals. A forensic
  tool with raw-disk access can recover metadata about private
  downloads even after Clear Private Session.
- **Windows event log.** Sawan does not write to the Windows event
  log by default, but Windows itself may log process start/stop
  events, network connection events, and file-system events that
  indirectly reveal that a private download occurred.
- **DNS cache.** The Windows DNS client caches resolved hostnames. A
  private download's hostname remains in the DNS cache until the
  cache expires or the user runs `ipconfig /flushdns`.
- **Network logs.** Sawan does not route private downloads through a
  VPN or proxy automatically. The user's ISP, employer, school, or
  any party operating the download URL's server can see the network
  connection. Use a VPN or Tor if network-level anonymity is required.
- **Recycle Bin.** If the secure-delete option is off, deleted private
  files may be moved to the Recycle Bin rather than permanently
  deleted, depending on the user's Windows settings. The user should
  empty the Recycle Bin manually if this is a concern.

### 3.3 Bottom line on Private mode

Private Downloads mode is a **convenience feature** that keeps
sensitive downloads out of Sawan's regular UI and out of the main
history. It is **not** a forensic anonymity tool. If the user needs
strong anonymity, they should use a VPN, the Tor Browser, or a
dedicated privacy-focused OS like Tails — none of which Sawan
integrates with or claims to replace.

---

## 4. Private browsing limitations (cross-cutting)

The limitations listed in Section 3.2 apply to **every** Sawan
download, not just private-mode ones. Even in regular mode, Sawan
cannot:

- Clear the user's browser history, cookies, or session tokens.
- Hide the download URL from the user's ISP, employer, or the
  download server's operator.
- Clear the NTFS USN journal, the Windows event log, or the DNS cache.
- Prevent the user's antivirus from logging the downloaded file.
- Prevent cloud-sync clients (Dropbox, OneDrive, Google Drive) from
  uploading the downloaded file if the user's download folder is
  inside a synced location.

The user is the sole operator of their machine. Sawan is one tool
among many; it cannot and does not promise to be the only tool that
records information about the user's activity.

---

## 5. Credentials

If the user configures HTTP Basic or Digest authentication for a
download, the credentials are:

1. **Encrypted with Windows DPAPI** (Data Protection API), using
   `DataProtectionScope.CurrentUser`. DPAPI is per-user, per-machine:
   the ciphertext can only be decrypted by a process running as the
   same user on the same machine. Another user on the same machine
   cannot decrypt it. A different machine cannot decrypt it even if
   the database file is copied across.
2. **Stored in the SQLite database** in the `auth_password_enc` column
   of the `downloads` table. The column is NULL when no credentials
   are configured.
3. **Never logged.** The application log scrubs the `Authorization`
   header and any URL with embedded credentials before writing. The
   log scrubber is implemented in
   `src/SawanDownloadPro.App/Services/SawanFileLoggerProvider.cs`.
4. **Never transmitted** anywhere other than to the download URL's
   origin server, as the actual HTTP `Authorization` header (encrypted
   by TLS in transit). Sawan does not "phone home" credentials to any
   Sawan-operated server, because no Sawan-operated server exists.
5. **Decrypted only at download time** and held in memory only for the
   duration of the HTTP request. The plaintext is discarded
   immediately after the request is sent.

### 5.1 What DPAPI does NOT protect against

- **Live process compromise.** If malware is already running as the
  user, it can call `ProtectedData.Unprotect` itself and read the
  plaintext. DPAPI is an at-rest defence, not a runtime defence.
- **Roaming profiles.** If the user's Windows profile roams between
  machines (e.g. a domain-joined corporate machine), the DPAPI key may
  roam with it. Sawan does not configure DPAPI roaming; the default
  Windows behaviour applies.
- **Domain-admin compromise.** A domain admin can reset the user's
  password, which by default invalidates DPAPI keys. Recovery is
  outside Sawan's scope.

### 5.2 Default: store nothing

If the user does not configure HTTP auth for a download, no
credentials are stored. The `auth_password_enc` column is NULL. This
is the default state for every download.

---

## 6. Logs

Sawan Download Pro writes three log files in
`%LOCALAPPDATA%\SawanDownloadPro\logs\`:

| File               | Contents                                                                                          |
|--------------------|---------------------------------------------------------------------------------------------------|
| `sawan.log`        | Application log: UI events, scheduler events, engine events, download start/stop/fail.            |
| `media.log`        | Media extractor events: yt-dlp invocations (binary path, arguments, exit code, first stderr line). |
| `native-host.log`  | Native messaging host events: extension connection, message receipt, schema validation, pipe forward. |

### 6.1 What we scrub from logs

Before any line is written, the log provider scrubs:

- HTTP `Authorization` headers (replaced with `Authorization: <redacted>`).
- URLs with embedded credentials (`https://user:pass@host/` →
  `https://<redacted>@host/`).
- The `password` and `secret` JSON fields in any logged message.
- Cookie values, session tokens, and Bearer tokens.

The scrubber is intentionally conservative: if in doubt, redact. The
scrubber does not redact filenames, URLs without credentials, host
names, or HTTP status codes — these are needed for debugging.

### 6.2 What we do NOT log

- File contents (only file paths and sizes).
- The full text of HTTP response bodies.
- The full text of HTTP request bodies.
- Cookies, session identifiers, or auth tokens.
- The user's Windows password or DPAPI master key.

### 6.3 Log retention

Logs are rotated when they exceed 10 MB. The previous 5 rotations are
kept. The user can clear all logs at any time from **Settings →
Security & Privacy → Clear logs now**, or by deleting the `logs\`
directory directly.

### 6.4 Cloud-synced folders

If the user has placed `%LOCALAPPDATA%` on a cloud-synced folder
(Dropbox, OneDrive, Google Drive, etc.), log files may be uploaded to
the cloud provider. Sawan does not detect or prevent this. The user
should exclude the `logs\` folder from cloud sync if this is a
concern.

---

## 7. Browser integration

When the user enables browser integration (Settings → Browser
Integration), Sawan writes a native-messaging manifest to
`%LOCALAPPDATA%\SawanDownloadPro\native-messaging\com.sawan.downloadpro.json`
and registers it in the browser's per-user native-messaging registry
path. The manifest declares:

- `path`: the absolute path to the Sawan native-messaging host
  executable.
- `allowed_origins` (Chrome/Edge/Opera/Brave/Vivaldi): the extension
  IDs of the Sawan extension loaded into each browser.
- `allowed_extensions` (Firefox): the extension ID of the Sawan
  Firefox extension.

The native-messaging host **only** accepts messages matching this
strict schema:

```json
{
  "type": "download",
  "url": "https://example.com/file.zip",
  "source": "contextmenu" | "popup" | "toolbar",
  "tabUrl": "https://example.com/page"
}
```

The host rejects:

- Any other `type` value (no `execute`, no `read`, no `delete`).
- Missing or non-string `url`.
- URLs with disallowed schemes (only `http`, `https`, `ftp` allowed).
- URLs with embedded credentials (`https://user:pass@host/`).
- URLs longer than 8192 characters.
- Unknown top-level keys (strict schema; no extra fields allowed).
- Messages larger than 1 MiB total.
- Non-ASCII control characters in any field.

### 7.1 What the browser extension sends to Sawan

- The URL the user right-clicked, or the URL the user typed in the
  popup.
- The source of the action (`contextmenu`, `popup`, or `toolbar`).
- Optionally, the URL of the page the user was on (`tabUrl`), so Sawan
  can show it in the Add Download dialog as a courtesy.

### 7.2 What the browser extension does NOT send

- **Cookies.** The browser extension does not read the browser's
  cookie store. Sawan does not have access to the user's logged-in
  session on any site.
- **Auth tokens.** The extension does not read `localStorage`,
  `sessionStorage`, or `IndexedDB`. Sawan does not have access to the
  user's Bearer tokens, CSRF tokens, or any other auth state.
- **Form data.** The extension does not read form fields.
- **Browsing history.** The extension does not call `chrome.history`
  or its Firefox equivalent. Sawan has no access to the user's
  browsing history.
- **The full page DOM.** The content script only inspects `<a>`
  elements the user clicks; it does not serialize the page.

### 7.3 What Sawan does with the URL

The native-messaging host forwards the URL to the Sawan app via a
local named pipe. The Sawan app then opens the Add Download dialog
with the URL pre-filled. **No third party receives the URL.** The
native-messaging host does not re-transmit the URL to any external
service.

---

## 8. Updates

Sawan Download Pro does **not** auto-update by default. The optional
update check is off by default and must be explicitly enabled in
Settings → Advanced → Update checks.

When update checks are enabled:

1. The app issues an HTTP GET to a URL the user configures. The
   request contains no identifying information — no user ID, no
   machine ID, no install ID, no telemetry. The request is a plain
   GET for a static JSON file.
2. The JSON file declares the latest version, the download URL, and
   an Ed25519 signature of the MSI file.
3. If the latest version is newer than the installed version, the app
   shows a toast notification prompting the user to download the
   update.
4. The user must click "Download update" to download the MSI. The
   download goes through the same download engine as any other
   download — no special network path.
5. After the MSI downloads, the app verifies the Ed25519 signature
   against a public key compiled into the app. If verification fails,
   the MSI is refused and the existing version continues to run.
6. The user must click "Install update" to launch the MSI. The app
   does not silently install updates.

No version information is sent to any server. The update-check
request is a plain GET; the server has no way to know which version
the user is currently running.

---

## 9. Antivirus integration

Sawan Download Pro offers an optional antivirus scan on completed
downloads (Settings → Security & Privacy → Scan with antivirus). When
enabled:

1. After a download completes, Sawan invokes the user-supplied
   antivirus scanner (configured by absolute path in Settings →
   Security & Privacy → Antivirus path).
2. The scanner is invoked via `SafeProcessLauncher`, which manually
   constructs the argument list with Windows-style quoting. No shell
   interpretation occurs. The scanner receives only the file path of
   the completed download.
3. Sawan records the scanner's exit code and stdout/stderr (first
   line) in the application log.
4. Sawan does **not** claim the file is virus-free. A clean exit code
   from the scanner is reported to the user as "scanner reported
   clean", not as "file is safe". Sawan is not an antivirus product
   and makes no warranty about file safety.

The user picks the scanner binary. Sawan does not bundle or recommend
a specific scanner. Common choices include the Windows Defender
command-line interface (`MpCmdRun.exe`), ClamAV, or a commercial
antivirus CLI.

---

## 10. Children's privacy

Sawan Download Pro is a general-purpose download manager. It is not
directed at children under 13 (or the applicable age of digital
consent in the user's jurisdiction). Sawan does not knowingly collect
any personal information from children, because Sawan does not
collect any personal information from anyone.

If a parent or guardian becomes aware that a child has provided
personal information to Sawan through any of the official contact
channels (WhatsApp, YouTube, Facebook, Telegram — see
[`docs/ABOUT_AHMED_SAWAN.md`](ABOUT_AHMED_SAWAN.md)), they should
contact the creator via the same channel to request deletion. The
application itself stores no information that would identify the user
as a child.

---

## 11. User rights

Because Sawan Download Pro stores all data locally and collects no
identifying information, the user's rights are exercised by direct
file manipulation:

| Right                                       | How to exercise                                                                                       |
|---------------------------------------------|-------------------------------------------------------------------------------------------------------|
| **Access** all data Sawan holds about you.  | Open `%LOCALAPPDATA%\SawanDownloadPro\data\sawan.db` with any SQLite browser.                          |
| **Export** all data.                         | Copy the `data\` and `logs\` directories to a backup location. Use `File → Export → JSON` for a portable queue export. |
| **Delete** all data.                         | Delete `%LOCALAPPDATA%\SawanDownloadPro\` recursively. (See Section 2.2 for what survives.)            |
| **Object** to processing.                    | Sawan processes nothing on your behalf without an explicit user action. To stop processing, close the app. |
| **Rectify** inaccurate data.                 | Edit the SQLite database directly, or use Settings to change any stored preference.                    |
| **Portability**.                             | The SQLite database and JSON settings are open formats. Export them at any time.                       |
| **Withdraw consent** for update checks.      | Settings → Advanced → Update checks → off.                                                              |
| **Withdraw consent** for browser integration. | Settings → Browser integration → untick each browser.                                                  |
| **Withdraw consent** for clipboard monitoring. | Settings → Clipboard → Monitor clipboard → off.                                                     |

Because Sawan has no backend, there is no server-side account to
delete and no remote data to retrieve. The user is in full control.

---

## 12. Contact for privacy inquiries

For privacy inquiries specific to the Sawan Download Pro application,
contact the creator via WhatsApp:

- **WhatsApp:** <https://wa.me/201000150303>
  (Egyptian local: `01000150303`, International: `+20 1000150303`)

For bug reports and feature requests, use the project's public issue
tracker. For security vulnerability reports, see
[`docs/SECURITY.md`](SECURITY.md) Section 9 for the
responsible-disclosure process — do not file a public issue for
security vulnerabilities.

We commit to acknowledging privacy inquiries within 30 days. We do
not operate a Data Protection Officer (DPO) because we do not process
personal data on behalf of users (there is no backend). The creator,
Ahmed Sawan, is the contact for all privacy matters.

---

**Sawan Download Pro — Privacy Statement — Version 1.0.**
**Fast. Smart. In Control.**
