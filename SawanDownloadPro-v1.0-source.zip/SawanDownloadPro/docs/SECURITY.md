# Sawan Download Pro v1.0 — Security Overview

> **Tagline:** Fast. Smart. In Control.
>
> **Created by:** Ahmed Sawan
>
> **Release:** Version 1.0 — First Release (October 2026)

This document describes Sawan Download Pro v1.0's security posture:
what we protect, how we protect it, what we deliberately do not do,
how the new Private Downloads mode changes the data flow, and how to
report vulnerabilities. It is the authoritative security document for
the v1.0 release line.

> **TL;DR.** Sawan Download Pro runs entirely on the user's machine.
> It does not collect telemetry. It does not transmit credentials. It
> validates every URL and every path. It does not bundle any
> third-party binary whose license could impose itself on the product.
> It is designed to fail safe: when in doubt, refuse and explain. The
> v1.0 release adds Private Downloads mode (which isolates Sawan's
> own state but is not an anonymity tool), a Security & Privacy
> dashboard, a six-browser native-messaging validation pipeline, and
> a first-run consent gate for private-browsing permissions.

---

## 1. Threat model summary

### 1.1 Assets we protect

1. **The user's downloaded files.** A malicious URL or a path traversal
   attack must not be able to overwrite files outside the user's
   chosen download folder.
2. **The user's credentials.** HTTP Basic / Digest credentials, when
   the user explicitly configures them, must not be recoverable by
   another user or by an attacker who steals the database file.
3. **The user's machine.** A malicious server response must not be
   able to execute arbitrary code on the user's machine.
4. **The browser ↔ Sawan bridge.** A malicious web page must not be
   able to invoke Sawan's native messaging host without the user's
   explicit action, nor smuggle malicious URLs through the bridge.
5. **The user's private downloads.** (New in v1.0.) A user who uses a
   shared machine, or who shares the regular Sawan queue with a
   colleague, must be able to keep sensitive downloads out of the
   regular UI and out of the regular history.

### 1.2 Threats we consider

| Threat                                                                                | Mitigation                                                                                            |
|---------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------|
| Malicious server returns a `Content-Disposition: filename="..\..\..\system32\evil.exe"` | `PathSanitizer.SanitizeAndCombinePath` strips `..`, enforces the file is inside the root, and rejects dangerous extensions. |
| Browser extension (compromised or malicious) tries to send a `file://` URL            | `MessageSchema.TryValidate` rejects non-http/https/ftp schemes and URLs with embedded credentials.    |
| Browser extension tries to send a 10 MB payload to crash the host                     | `MessageSchema.TryValidate` rejects messages > 1 MiB and URLs > 8192 chars.                           |
| Malicious Opera/Brave/Vivaldi extension attempts to invoke the host                   | Same manifest, same `allowed_origins` allow-list, same schema. The new browsers share Chrome's MV3 security model. |
| Attacker steals the SQLite database, tries to read credentials                         | Credentials are DPAPI-encrypted per-user. Stealing the DB file alone is insufficient.                 |
| Malicious update is pushed to the user's update URL                                   | Updater verifies an Ed25519 signature against a public key compiled into the app. Tampered updates are refused. |
| yt-dlp / FFmpeg binary on the user's PATH is trojaned                                 | Sawan invokes the binary by absolute path configured in Settings, not by `PATH` lookup. The user picks the binary. |
| Drive-by download from a web page invokes Sawan via the native host                   | The native host only accepts messages framed by the browser's native-messaging protocol; a web page cannot frame such messages directly. |
| User shares the machine; colleague opens Sawan and sees private downloads             | (New in v1.0.) Private Downloads mode stores private tasks in a separate partition; they only become visible when the user explicitly enters Private mode. |
| Attacker recovers private download files from the Recycle Bin after Clear Private Session | (New in v1.0.) Optional secure-delete overwrites the bytes of every private `.part` file with zeros before unlinking. |
| Malicious browser extension sends an unrecognized command type (`execute`, `delete`)   | `MessageSchema.TryValidate` rejects any `type` other than `download`.                                  |
| Phishing: user pastes a URL that looks like a download but is a phishing page         | Out of scope. Sawan downloads bytes; it does not render HTML. The user is responsible for verifying URLs. |

### 1.3 Threats we explicitly do NOT mitigate

- **The user themselves.** If the user explicitly downloads and runs
  malware, Sawan cannot stop them. The dangerous-extension warning is
  a confirmation, not a block.
- **Compromise of the user's machine by another process.** If malware
  is already running as the user, it can read the Sawan database, the
  in-memory queue, and the configured credentials. DPAPI protects
  against offline database theft, not against live process
  compromise.
- **Compromise of the user's browser.** If the user's browser is
  compromised at the extension-API level (e.g. another extension
  hijacks the Sawan extension's `chrome.runtime` messages), Sawan
  cannot detect this. The native host re-validates URLs but cannot
  verify the originating extension's identity beyond the
  `allowed_origins` manifest entry.
- **Server-side deception.** If a server returns the right bytes for
  a file the user expected, Sawan has no way to verify the file's
  authenticity. The optional `ScanWithAntivirus` setting is a
  belt-and-braces defence, not a guarantee.
- **Forensic recovery of private-mode data.** Private Downloads mode
  isolates Sawan's own state. It does not clear browser history, NTFS
  USN journal, Windows event log, DNS cache, or Recycle Bin. A
  forensic tool with raw-disk access can recover metadata about
  private downloads even after Clear Private Session. See Section 6.

---

## 2. Path traversal protection

### 2.1 The sanitizer

`SawanDownloadPro.Security.Validation.PathSanitizer` is the single
chokepoint through which every user-supplied filename and save path
must pass. It:

1. **Replaces path separators.** `/` and `\` in the filename component
   are replaced with `_`. This defeats `..\..\` traversal in the
   filename.
2. **Strips parent-directory references.** Any `..` segment in the
   combined path is removed.
3. **Removes Windows-invalid characters.** `< > : " / \ | ? *` and
   control characters (0x00–0x1F) are replaced with `_`.
4. **Rejects reserved names.** `CON`, `PRN`, `AUX`, `NUL`, `COM1`–
   `COM9`, `LPT1`–`LPT9` are rejected or suffixed with `_`.
5. **Truncates to 200 characters.** Windows' path-component limit is
   255; we leave headroom for the file extension.
6. **Validates the combined path.** `SanitizeAndCombinePath(directory,
   fileName)` produces a path that is guaranteed to be inside
   `directory`. If the sanitized path escapes the directory (e.g.
   because `directory` is itself malformed), the call throws.
7. **Flags dangerous extensions.** `.exe`, `.bat`, `.cmd`, `.ps1`,
   `.vbs`, `.js`, `.jar`, `.scr`, `.msi` trigger a confirmation
   dialog before the download starts. The user can override, but
   cannot be silent-surprised.

### 2.2 The two-call pattern

The download engine calls `SanitizeAndCombinePath` twice per download:

1. Once at queue time, with the user-chosen directory and the
   server-supplied filename. The result is stored on the
   `DownloadTask.SavePath`.
2. Once at download start time, with the same inputs, to defend
   against a stale task object. If the two calls produce different
   paths, the download aborts with a "path drift detected" error.

### 2.3 What the sanitizer does NOT do

- It does not validate the directory argument. The UI is responsible
  for ensuring the directory exists and is writable. If the directory
  is malformed, `SanitizeAndCombinePath` throws rather than guess.
- It does not canonicalize case. Windows filesystems are case-
  insensitive; we accept this and do not normalize.
- It does not enforce an extension allow-list. The dangerous-extension
  warning is a confirmation, not a block, by design.

---

## 3. URL validation

### 3.1 The validator

`SawanDownloadPro.Security.Validation.UrlValidator` is the chokepoint
through which every URL must pass. It:

1. **Parses the URL.** `Uri.TryCreate` with `UriKind.Absolute`. If
   parsing fails, the URL is rejected.
2. **Allow-lists schemes.** Only `http`, `https`, `ftp` are accepted.
   `file`, `javascript`, `data`, `blob`, `vbscript`, and any custom
   scheme are rejected.
3. **Requires a host.** URLs without a host (e.g. `https:///path`)
   are rejected.
4. **Length-limits.** URLs > 8192 characters are rejected. This
   matches the limit enforced by the native-messaging schema.
5. **Rejects embedded credentials.** `https://user:pass@host/` is
   rejected. The user must configure HTTP Basic / Digest auth in the
   Add Download dialog (where it's DPAPI-encrypted at rest), not in
   the URL.
6. **Optionally prepends `https://`.** A bare domain like
   `example.com/foo` is normalized to `https://example.com/foo` if
   the user typed it without a scheme.

### 3.2 FTP specifics

FTP is allowed but treated specially:

- FTP credentials are sent in plaintext over the network. The UI
  warns the user before allowing an FTP download.
- FTP doesn't support segmented downloads. The engine falls back to
  a single-connection download for FTP URLs.
- FTP doesn't support `Range` headers. Pause/resume may not work
  depending on the server's `REST` command support.

### 3.3 What the validator does NOT do

- It does not verify the URL is reachable. That's the engine's job.
- It does not check the URL against a blocklist. The user is
  responsible for the URLs they download.
- It does not validate the host's TLS certificate chain. That's
  delegated to Windows' SChannel / Schannel.

---

## 4. Credential storage (DPAPI)

### 4.1 The protector

`SawanDownloadPro.Security.Process.DpapiSecretProtector` wraps
`System.Security.Cryptography.ProtectedData.Protect` /
`Unprotect`. It uses `DataProtectionScope.CurrentUser`, which means
the ciphertext can only be decrypted by a process running as the same
user on the same machine.

### 4.2 Lifecycle

1. The user enters HTTP Basic / Digest credentials in the Add
   Download dialog.
2. The dialog calls `DpapiSecretProtector.Protect(plaintext)` to get
   a ciphertext byte array.
3. The byte array is stored in the `auth_password_enc` column of the
   `downloads` table.
4. At download time, the engine calls `Unprotect(byteArray)` to get
   the plaintext, uses it for the HTTP request, and discards it.
5. The plaintext is never logged, never serialized to disk, never
   sent over the network except as the actual HTTP Authorization
   header (encrypted by TLS in transit).

### 4.3 What DPAPI does NOT protect against

- **Live process compromise.** If malware is running as the user, it
  can call `Unprotect` itself and read the plaintext. DPAPI is an
  at-rest defence, not a runtime defence.
- **A user with roaming profiles.** If the user's profile roams
  between machines, the DPAPI key may roam with it. Sawan does not
  configure DPAPI roaming; the default Windows behaviour applies.
- **Domain-admin compromise.** A domain admin can reset the user's
  password, which invalidates DPAPI keys (by default). Recovery
  requires the user's password reset disk, which is outside Sawan's
  scope.

### 4.4 Default: store nothing

If the user does not configure HTTP auth for a download, no
credentials are stored. The `auth_password_enc` column is NULL. This
is the default state.

---

## 5. Native messaging validation

### 5.1 The schema (v1.0 — six-browser)

`SawanDownloadPro.BrowserIntegration.NativeMessaging.MessageSchema.TryValidate`
is the chokepoint for every message from any of the six supported
browser extensions (Chrome, Edge, Firefox, Opera, Brave, Vivaldi). It
accepts only this shape:

```json
{
  "type": "download",
  "url": "https://example.com/file.zip",
  "source": "contextmenu" | "popup" | "toolbar",
  "tabUrl": "https://example.com/page"   // optional
}
```

It rejects:

- Any other `type` value (no `execute`, no `read`, no `delete`, no
  `shell`, no `eval`).
- Missing `url` or non-string `url`.
- URLs with disallowed schemes (only http/https/ftp allowed).
- URLs with embedded credentials.
- URLs > 8192 characters.
- Unknown top-level keys (strict schema; no extra fields allowed).
- Messages > 1 MiB total size.
- Non-ASCII control characters in any field.

The `Timestamp` field, if sent by the browser, is **ignored**. The
host sets its own timestamp on the server side. This prevents a
malicious extension from forging a timestamp.

### 5.2 Allowlist of commands (v1.0)

The native host implements an allowlist of exactly one command:
`download`. Any other command sent by a (compromised or malicious)
extension is rejected at the schema-validation layer before any
file-system, network, or process action is taken. There is no
"extensibility hook" that would let a future command bypass the
schema check.

The host does not, and will not, accept commands to:

- Read arbitrary files from the user's machine.
- Write arbitrary files to arbitrary paths.
- Execute arbitrary shell commands.
- Read the user's browser cookies, history, or saved passwords.
- Read the user's clipboard, screen, or microphone.
- Open arbitrary URLs in the user's default browser.
- Modify the user's Sawan settings without UI confirmation.

### 5.3 Message size limits

The native messaging protocol is:

- 4-byte little-endian length prefix.
- UTF-8 JSON body of the declared length.

The host reads exactly the declared number of bytes. If the declared
length is > 1 MiB, the host closes the connection without reading. If
the JSON is malformed, the host responds with
`{"ok": false, "error": "schema violation"}` and exits cleanly.

These limits are defence-in-depth against memory-exhaustion attacks
and against a malicious extension trying to flood the host with a
multi-gigabyte payload.

### 5.4 URL validation

The host re-runs `UrlValidator` on the `url` field of every inbound
message, even though the browser extension already validates. This is
defence-in-depth: a compromised extension cannot smuggle a
disallowed-scheme URL past the host.

The host also re-runs `PathSanitizer` on the filename if the
extension includes one (it typically does not — Sawan derives the
filename from the URL or the `Content-Disposition` header). A
compromised extension cannot smuggle a traversal path.

### 5.5 File path validation

When the host forwards a download request to the Sawan app via the
named pipe, the request contains only the URL, the source, and the
optional tab URL. It does **not** contain a file path. The Sawan app
computes the save path at queue time using `PathSanitizer`, with the
user-configured default download directory and the filename derived
from the URL or `Content-Disposition`. A compromised extension cannot
choose an arbitrary save path.

### 5.6 No arbitrary command execution

The native messaging host never invokes `Process.Start` with
extension-supplied arguments. The only `Process.Start` calls in the
codebase go through `SafeProcessLauncher`, which manually constructs
the argument list with Windows-style quoting. No `--shell-execute`,
no `cmd.exe /c`, no `powershell.exe -Command`, no `bash -c`. The host
cannot be tricked into running arbitrary commands.

### 5.7 The extension manifest

The native-messaging manifest declares `allowed_origins` (Chrome /
Edge / Opera / Brave / Vivaldi) and `allowed_extensions` (Firefox).
Only the Sawan extension's ID is listed per browser. A different
extension attempting to talk to the host is rejected by the browser
before the host is even launched.

The manifest's `path` field is an absolute path to the host
executable. Sawan writes this manifest to
`%LOCALAPPDATA%\SawanDownloadPro\native-messaging\com.sawan.downloadpro.json`
and registers it in:

- `HKCU\Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro`
  (also discovered by Opera — Opera shares Chrome's registry path).
- `HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.sawan.downloadpro`
- `HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\com.sawan.downloadpro`
- `HKCU\Software\Vivaldi\Vivaldi\NativeMessagingHosts\com.sawan.downloadpro`
- `%APPDATA%\Mozilla\NativeMessagingHosts\com.sawan.downloadpro.json` (Firefox)

### 5.8 No auto-submission

Both the extension and the host enforce this. The browser extension
only sends a `download` message when the user explicitly:

- Right-clicks a link and chooses "Download with Sawan Download Pro", or
- Clicks the toolbar button, types a URL in the popup, and clicks
  "Send to Sawan".

The content script in the extension sends only `suggest` messages
(which set a toolbar badge). It never sends a `download` message
without an explicit user action.

The native host re-validates the URL and the schema. Even a
compromised extension cannot smuggle a bad URL through.

---

## 6. Private Downloads mode (new in v1.0)

### 6.1 What it does

Private Downloads mode isolates Sawan's own state for sensitive
downloads. When the user enables Private mode:

- A separate in-memory session holds private tasks. They do not appear
  in the All, Active, Today, Failed, or History smart views.
- Private tasks are persisted to the SQLite database with `is_private=1`
  on the `downloads` row. They survive an app restart but only become
  visible when the user re-enters Private mode.
- The Clear Private Session action (sidebar button in the Security &
  Privacy panel) deletes every private task and its partial files
  atomically, in a single SQLite transaction.
- An optional **Auto-clear private session on exit** setting destroys
  the private partition when the app exits.
- An optional **Secure-delete private partial files** setting
  overwrites the bytes of every private `.part` file with zeros before
  unlinking, so the files cannot be recovered from the Recycle Bin or
  by simple undelete tools.

### 6.2 What it does NOT protect

Private Downloads mode is **not** an anonymity tool. It does **not**:

- Clear the user's browser history, cookies, or session tokens. Sawan
  has no control over browser state.
- Clear the NTFS file-system journal or the USN journal. The Windows
  NTFS driver records file create/rename/delete events; Sawan does
  not clear these journals. A forensic tool with raw-disk access can
  recover metadata about private downloads even after Clear Private
  Session.
- Clear the Windows event log. Sawan does not write to the event log
  by default, but Windows itself may log process start/stop and
  network events that indirectly reveal that a private download
  occurred.
- Clear the DNS cache. The Windows DNS client caches resolved
  hostnames. A private download's hostname remains in the DNS cache
  until the cache expires or the user runs `ipconfig /flushdns`.
- Hide network traffic. Sawan does not route private downloads
  through a VPN or proxy automatically. The user's ISP, employer, or
  any party operating the download URL's server can see the network
  connection. Use a VPN or Tor if network-level anonymity is required.
- Prevent the user's antivirus from logging the downloaded file.
- Prevent cloud-sync clients from uploading the downloaded file if
  the user's download folder is inside a synced location.

### 6.3 Data flow

The Private Downloads data flow is identical to the regular flow
except for the `is_private` flag:

```
[Browser extension] → [Native messaging host] → [Sawan app named pipe]
        ↓                       ↓                          ↓
   schema validate       schema validate            Private mode check
   (Section 5)           (Section 5)                → if Private mode:
                                                    store with is_private=1
                                                    → else:
                                                    store with is_private=0
                                                             ↓
                                                    [SQLite database]
                                                    [Partial file on disk]
                                                    [In-memory session]
```

The native messaging host has no knowledge of Private mode. It
forwards every URL to the Sawan app, which decides at queue time
whether to store it as private or regular based on the user's current
Private mode toggle.

### 6.4 Threats Private mode mitigates

- **Casual snooping by a colleague.** A colleague who opens Sawan on
  the user's machine will not see private tasks in the regular UI.
  They would need to enter Private mode explicitly, which requires
  the user's Windows session (so the colleague must already be logged
  in as the user).
- **Accidental disclosure in screenshots.** A screenshot of the
  regular Sawan UI does not reveal private downloads.
- **History pollution.** Private downloads do not appear in the
  regular History view, so they don't pollute future searches.

### 6.5 Threats Private mode does NOT mitigate

- **Forensic recovery by an attacker with raw-disk access.** See
  Section 6.2.
- **Live process compromise by malware running as the user.** The
  malware can read the in-memory private session and the SQLite
  database.
- **Network-level surveillance.** The user's ISP and the download
  server's operator can see the network connection.
- **A colleague with the user's Windows password.** Private mode is
  not password-protected. Anyone who can log in as the user can enter
  Private mode and see private downloads.

---

## 7. Security & Privacy dashboard (new in v1.0)

The new Security & Privacy sidebar item collects every
privacy-sensitive control in the application in one panel:

- **DPAPI status.** Reads `DataProtectionScope.CurrentUser` and
  verifies per-machine binding by round-tripping a test ciphertext.
  Display: "DPAPI: OK (Current User scope, per-machine binding
  verified)" or "DPAPI: FAILED — see logs".
- **Telemetry status.** Always displays "Off". The toggle is
  intentionally read-only — this is a binding commitment for the
  entire 1.x release line.
- **Log directory.** Shows the configured log path. "Open log
  folder" button opens Explorer at that path. "Clear logs now"
  button deletes every file in the directory except the current
  in-use log.
- **Antivirus integration.** Toggle plus the user-supplied scanner
  path. "Run scan now" button invokes the scanner on the most
  recently completed download.
- **Native-messaging host status.** Shows which of the six supported
  browsers are registered, with the manifest file path. "Re-register
  all" button re-writes the manifest and the registry entries.
- **Private Downloads status.** Shows active / inactive, auto-clear
  state, secure-delete state. "Clear Private Session" button (see
  Section 6).
- **Update check status.** Shows off (default) or on with the
  configured URL and the Ed25519 public key fingerprint.
- **Run security self-check.** A one-click button that re-validates
  the path sanitizer, URL validator, DPAPI round-trip, and
  native-messaging schema in one pass. Also exposed as a CLI flag:
  `SawanDownloadPro.App.exe --selftest`.

### 7.1 Self-check scope

The self-check is a smoke test, not a full audit. It verifies:

- `PathSanitizer.SanitizeAndCombinePath` rejects a known traversal
  payload.
- `UrlValidator` rejects a known disallowed-scheme URL.
- `DpapiSecretProtector` round-trips a known plaintext.
- `MessageSchema.TryValidate` rejects a known bad message and accepts
  a known good one.

The self-check does **not** verify the download engine, the
scheduler, the FFmpeg integration, or the browser extensions
end-to-end. Those are covered by the test cases in
`docs/TEST_REPORT.md`.

---

## 8. First-run consent (new in v1.0)

The v1.0 first-run wizard includes a Private Downloads consent step.
The step explains, in plain language, what Private mode does and does
not protect (mirroring Section 6.2 above). The user must explicitly
tick "I understand" before the Enable Private Downloads checkbox
becomes available.

If the user does not consent, Private Downloads mode is disabled and
the Security & Privacy panel hides the Private Downloads status
section. The user can re-run the wizard at any time from Settings →
General → Run first-run wizard again to grant consent later.

### 8.1 Why explicit consent

Private Downloads mode introduces a new data flow (the `is_private`
partition) and a new on-disk artifact (the private history). The
consent step ensures the user is aware that:

- Private mode isolates Sawan's own state, not the browser's or the
  OS's.
- Clearing Private Session does not clear browser history, NTFS
  journal, or DNS cache.
- Auto-clear on exit may delete downloads the user wanted to keep.
- Secure-delete overwrites the bytes of partial files but does not
  securely delete completed downloads (the user must delete those
  manually).

This consent gate is the security equivalent of the dangerous-
extension warning: a confirmation, not a block. The user can enable
Private mode and immediately disable every protective option if they
choose.

---

## 9. Update verification (signature)

### 9.1 The updater

The optional updater (off by default; the user must enable it in
Settings → Advanced) checks a user-configured URL for a new version
metadata file. The metadata file is a small JSON document:

```json
{
  "version": "1.0.1.0",
  "url": "https://download.sawan.example/SawanDownloadProSetup_x64.msi",
  "signature": "base64-ed25519-signature-of-the-msi"
}
```

### 9.2 The signature

The `signature` field is a Base64-encoded Ed25519 signature of the
MSI file (not of the metadata file). The public key is compiled into
the Sawan app as a constant; it cannot be replaced at runtime.

When the updater downloads the MSI, it:

1. Reads the entire MSI into memory.
2. Computes the Ed25519 verification against the compiled public key.
3. If verification fails, refuses to install and shows a clear error.
4. If verification succeeds, launches the MSI with the user's
   permission.

### 9.3 Why Ed25519

Ed25519 is fast, has small signatures (64 bytes), small public keys
(32 bytes), and is widely considered secure against classical
attacks. It's the same algorithm used by `minisign`, `signify`, and
`apt` (via `minisign`).

### 9.4 Why no auto-update

Auto-update (download and install without user consent) is disabled
by design. The user must click "Install update" in the toast
notification. Sawan will never restart itself or install an update
without an explicit click.

---

## 10. No telemetry commitment

Sawan Download Pro v1.0 does **not**:

- Collect telemetry, analytics, or usage data.
- Send crash reports to a remote server.
- Phone home with version information.
- Include tracking pixels or remote images in any UI.
- Bundle any SDK that does any of the above.

The only network traffic the app generates is:

- The downloads the user explicitly adds.
- HEAD / Range probes against URLs the user explicitly adds.
- (Optional, off by default) Update checks against a URL the user
  explicitly configures.

This is a binding commitment for the 1.x release line. Any future
version that intends to introduce telemetry will require an explicit
opt-in dialog at first launch and will be documented in this file.

### 10.1 How to verify

To verify that Sawan is not making unexpected network connections:

1. Open `Resource Monitor` (Windows) → Network tab.
2. Filter by `SawanDownloadPro.App.exe`.
3. Watch the "TCP Connections" and "Network Connections" panels.
4. Add a download. You should see connections only to the URL's host.
5. With no downloads in progress, you should see zero connections.

If you see unexpected connections, file a security issue (Section 12).

---

## 11. Logging and PII

### 11.1 What we log

Sawan logs to `%LOCALAPPDATA%\SawanDownloadPro\logs\`:

- `sawan.log` — application log (UI events, scheduler events, engine
  events).
- `media.log` — media extractor and FFmpeg invocations (binary path,
  arguments, exit code, first line of stderr).
- `native-host.log` — native messaging host events (extension
  connection, message receipt, message validation, forward to pipe).

### 11.2 What we do NOT log

- HTTP credentials, auth tokens, or passwords.
- Cookies or session identifiers.
- The full content of HTTP headers (only selected headers like
  Content-Length, Content-Type, ETag, Last-Modified).
- The full URL with embedded credentials (we log the URL without the
  userinfo component).
- File contents (only file paths and sizes).
- Private-mode task URLs when the user is not in Private mode. (The
  log scrubber suppresses any line that references a private task
  unless the user is currently in Private mode.)

### 11.3 Log retention

Logs are rotated when they exceed 10 MB; the previous 5 rotations are
kept. The user can clear logs from Settings → Security & Privacy →
Clear logs now.

### 11.4 Cloud-synced folders

If the user has placed `%LOCALAPPDATA%` on a cloud-synced folder
(Dropbox, OneDrive, etc.), logs may be uploaded to the cloud. Sawan
does not detect or prevent this. The user should exclude the logs
folder from cloud sync if this is a concern.

---

## 12. How to report vulnerabilities

### 12.1 Where to report

File a private security report at the project's issue tracker with
the prefix `[security]`. Mark the issue as confidential (the issue
tracker supports this). Do not file a public issue for security
vulnerabilities.

Alternatively, contact the creator via the official Sawan channels
listed in [`docs/ABOUT_AHMED_SAWAN.md`](ABOUT_AHMED_SAWAN.md).
WhatsApp is preferred for time-sensitive reports.

### 12.2 What to include

- A clear description of the vulnerability.
- The exact Sawan version (from Settings → About).
- The OS version and architecture.
- The steps to reproduce.
- A proof-of-concept if possible.
- Your assessment of the impact.

### 12.3 What to expect

- We acknowledge receipt within 48 hours.
- We provide an initial assessment within 7 days.
- We coordinate a fix and disclosure timeline with you.
- We credit you in the release notes unless you prefer to remain
  anonymous.

### 12.4 What we do NOT offer

- A bug bounty. We are not a for-profit project.
- A SLA on fixes. We will fix critical issues as fast as we can, but
  we cannot promise a specific turnaround.
- Legal safe harbour beyond what the project's jurisdiction provides.
  We will not sue good-faith reporters, but we cannot waive rights we
  do not hold.

### 12.5 Out of scope

- Vulnerabilities in third-party binaries (FFmpeg, yt-dlp) that Sawan
  invokes. Report those to the upstream project.
- Vulnerabilities in the browser itself.
- Vulnerabilities that require the attacker to already have code
  execution on the user's machine.
- Vulnerabilities that require the user to deliberately bypass the
  path sanitizer or URL validator (e.g. by modifying the source and
  recompiling).
- Vulnerabilities that require bypassing Private Downloads mode by
  directly reading the SQLite database with an external tool (this
  is documented behaviour; Private mode is not a forensic defence).

---

## 13. Security review checklist (for contributors)

Before submitting a change that touches security-sensitive code,
verify:

- [ ] No new file path is constructed without `PathSanitizer`.
- [ ] No new URL is accepted without `UrlValidator`.
- [ ] No new credential is stored without `DpapiSecretProtector`.
- [ ] No new `Process.Start` is added that does not go through
      `SafeProcessLauncher` (or that mirrors its quoting algorithm).
- [ ] No new network call is added that does not go through the
      `IDownloadEngine` (which forces TLS 1.2).
- [ ] No new telemetry or analytics is added (this is a binding
      commitment; see Section 10).
- [ ] No new dependency is added without updating
      `docs/LICENSE_INVENTORY.md`.
- [ ] No new native messaging message type is added without updating
      `MessageSchema.TryValidate` and the browser extensions' send
      paths. The allowlist of commands must remain exactly `{download}`.
- [ ] No new file is written outside `%LOCALAPPDATA%\SawanDownloadPro\`
      without explicit user consent in the UI.
- [ ] No new feature that handles sensitive data (URLs, filenames,
      credentials) bypasses the log scrubber.
- [ ] No new feature changes the Private Downloads data flow without
      updating Section 6 of this document.
- [ ] No new browser is added to the integration without updating
      the manifest's `allowed_origins` allowlist and Section 5 of
      this document.

A pull request that fails any of these checks will be rejected until
the issue is resolved.
