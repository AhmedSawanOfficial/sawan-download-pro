# Sawan Download Pro v1.0 — User Guide (English)

> **Tagline:** Fast. Smart. In Control.
>
> **Created by:** Ahmed Sawan
>
> **Release:** Version 1.0 — First Release (October 2026)

Welcome to Sawan Download Pro v1.0. This guide explains how to install,
configure, and use the application, and how to stay safe while doing
so. The v1.0 release introduces a new Dark Eggplant visual identity, a
real-time dashboard, a dedicated About page, a first-run welcome
wizard, a Private Downloads mode for sensitive downloads, and a
Security & Privacy center that collects every privacy-sensitive
control in one place.

---

## Table of contents

1. [Installation](#1-installation)
2. [First-run welcome screen](#2-first-run-welcome-screen)
3. [The Dark Eggplant theme](#3-the-dark-eggplant-theme)
4. [The Dashboard](#4-the-dashboard)
5. [Adding a download](#5-adding-a-download)
6. [Pausing, resuming, cancelling](#6-pausing-resuming-cancelling)
7. [Categories and the sidebar](#7-categories-and-the-sidebar)
8. [Private Downloads mode](#8-private-downloads-mode)
9. [The Security & Privacy center](#9-the-security--privacy-center)
10. [The About Sawan page](#10-the-about-sawan-page)
11. [Settings window](#11-settings-window)
12. [Scheduler](#12-scheduler)
13. [Video downloader](#13-video-downloader)
14. [Browser integration setup](#14-browser-integration-setup)
15. [Troubleshooting](#15-troubleshooting)
16. [Privacy and security](#16-privacy-and-security)

---

## 1. Installation

### 1.1 System requirements

- Windows 7 SP1, Windows 10, or Windows 11.
- .NET Framework 4.8 (installed by default on Windows 10 1903+ and
  Windows 11; on Windows 7 SP1 you must install it manually from
  <https://dotnet.microsoft.com/download/dotnet-framework>).
- For browser integration: Chrome 109 or earlier on Windows 7 SP1, or
  any current Chrome / Edge / Firefox / Opera / Brave / Vivaldi on
  Windows 10/11. Note that Chrome ≥ 110, Edge ≥ 110, Opera ≥ 87,
  Brave ≥ 1.46, and Vivaldi ≥ 5.6 dropped Windows 7 support; users on
  Windows 7 must use legacy ESR builds or the last Win7-compatible
  browser release.

### 1.2 Install the MSI

1. Download the MSI that matches your Windows architecture:
   - `SawanDownloadProSetup.msi` for 32-bit Windows.
   - `SawanDownloadProSetup_x64.msi` for 64-bit Windows.
   Most modern PCs are 64-bit.
2. Double-click the MSI. Windows may show a User Account Control
   prompt — accept it.
3. The installer wizard opens. Click **Next**.
4. Read the license agreement. Tick **I accept the terms in the License
   Agreement** and click **Next**.
5. Choose the install folder (the default is recommended) and click
   **Next**.
6. Choose which features to install:
   - **Application files** (required)
   - **Browser integration** (recommended if you want one-click
     downloads from any of the six supported browsers)
   - **Documentation** (optional)
   - **Associate .sawanpart files** (optional)
7. Click **Install**. Wait for the progress bar to finish.
8. Click **Finish**.

### 1.3 Windows 7 SP1: install KB4474419 first

If you are on Windows 7 SP1 and the installer shows a "publisher could
not be verified" warning, install Microsoft's SHA-2 code-signing
update **KB4474419** before retrying. Download it from the Microsoft
Update Catalog: <https://www.catalog.update.microsoft.com/Search.aspx?q=KB4474419>.

### 1.4 Uninstall

Use **Settings → Apps → Installed apps → Sawan Download Pro → Uninstall**,
or run the MSI again and choose **Remove**.

Uninstalling removes the application files and the Start Menu shortcut.
Your download history, settings, and partial downloads in your user
profile are preserved. To remove them too, delete:

- `%LOCALAPPDATA%\SawanDownloadPro\`
- `%USERPROFILE%\Downloads\Sawan\`

---

## 2. First-run welcome screen

The first time you launch Sawan Download Pro v1.0, a redesigned
welcome wizard walks you through the essentials. The wizard has seven
steps:

1. **Welcome.** A splash card introducing the Sawan brand, the
   "Fast. Smart. In Control." tagline, and the four official contact
   links (WhatsApp, YouTube, Facebook, Telegram). Click **Next** to
   proceed.
2. **Language.** Choose Arabic (default) or English. You can change
   this later in Settings → Appearance.
3. **Theme.** Choose **Dark Eggplant** (the new v1.0 default), Light,
   or System. System follows Windows' dark-mode setting and resolves
   to Dark Eggplant when the OS is in dark mode.
4. **Default download folder.** Defaults to
   `C:\Users\<you>\Downloads\Sawan\`. You can pick any folder you have
   write access to.
5. **Browser integration.** Tick the boxes for the browsers you use.
   v1.0 supports six browsers: Chrome, Edge, Firefox, Opera, Brave,
   and Vivaldi. The app automatically registers the native-messaging
   host for each ticked browser.
6. **Private Downloads consent.** The wizard explains what Private
   mode does and does not protect. You must tick "I understand"
   before the Enable Private Downloads checkbox becomes available.
   You can enable or disable Private mode later from the sidebar.
7. **Finish.** Lands you on the new Dashboard view.

Click **Finish** to land on the main window's Dashboard tab.

> You can run the first-run wizard again at any time from **Settings →
> General → Run first-run wizard again**. This is useful if you want
> to re-consent to Private Downloads, re-register browser integration,
> or reset your theme to the v1.0 default.

---

## 3. The Dark Eggplant theme

The v1.0 release ships with a new visual identity called **Dark
Eggplant**. The palette is:

- **Primary background:** `#21102F` (deep aubergine)
- **Primary accent:** `#6F42A6` (saturated purple)
- **Secondary accent:** `#A78BFA` (soft lavender)
- **Foreground text:** `#F5F0FA` (warm white)
- **Muted text:** `#9D8FB8` (dimmed lavender)
- **Surface (cards, panels):** `#2A1840` (lighter eggplant)
- **Border:** `#3D2657` (border eggplant)

The previous Stage-2 MVP used a default blue/cyan palette. The Dark
Eggplant identity is a deliberate rebrand: it is distinctive without
being aggressive, it reads well in both light and dark environments,
and it avoids the over-used blue that defined the engineering preview.

### 3.1 Switching themes

Open **Settings → Themes** (or **Settings → Appearance** in earlier
builds). You can pick from:

- **Dark Eggplant** (default for v1.0 new installs).
- **Light.** A light-on-dark palette using the same accent hues.
- **System.** Follows Windows' dark-mode setting; resolves to Dark
  Eggplant when the OS is in dark mode and to Light when the OS is in
  light mode.

### 3.2 Custom accent

Below the theme selector is a **Custom accent** picker. You can type
any HEX colour value (e.g. `#FF5733`) and the accent buttons, links,
and selected-row highlights across the app will use your custom colour.
The custom accent overrides the theme's default accent; the rest of
the palette (background, surface, foreground) is unchanged.

> **Note.** Some elements (notably the dashboard's sparkline and the
> tray icon) cache the accent colour at app launch. If your custom
> accent does not appear in those elements, restart the app. This is
> tracked as a known minor issue and will be fixed in v1.1.

### 3.3 Theme import / export

The **Export theme** button writes the current theme + custom accent
to a `.sawantheme.json` file. The **Import theme** button reads such a
file and applies it. This lets you share themes across machines or
back them up.

### 3.4 Restart needed for full apply

Most theme changes apply instantly. The following elements require an
app restart to fully reflect a theme or accent change:

- The tray icon (rebuilt at launch).
- The Windows jumplist (rebuilt at launch).
- The native-messaging host's icon cache (used by browser extensions
  for their toolbar button).

If you switch themes and the tray icon still shows the old colour,
restart the app.

---

## 4. The Dashboard

The new **Dashboard** sidebar item is the default landing view on first
launch. It replaces the empty Home placeholder from the Stage-2 MVP.
The dashboard shows the following panels, all driven by live data from
the download engine and the scheduler:

- **Totals card.** Active, queued, paused, completed (today), failed,
  and history counts. Updated on every scheduler tick (1 Hz).
- **Speed card.** Aggregate bytes/sec across all active downloads,
  plus the configured global speed limit. A small sparkline shows the
  last 60 seconds of throughput.
- **Disk space card.** Free bytes and total bytes on the drive that
  hosts `DefaultDownloadDirectory`. Turns amber below 1 GB free, red
  below 100 MB.
- **Recent notifications card.** The last 10 toast notifications
  (download complete, download failed, queue complete, etc.) with
  timestamps.
- **Quick actions.** One-click buttons for Add Download, Pause All,
  Resume All, Open Default Folder, and Open Settings.

The dashboard is the default landing view on first launch. Users who
prefer the old behaviour can pin the All-downloads view from the
sidebar's context menu (right-click the sidebar → "Pin to top").

### 4.1 Reading the speed card

The speed card's sparkline shows aggregate throughput over the last 60
seconds. The line is purple (the primary accent colour) on Dark
Eggplant and on the Light theme. The horizontal axis is time (newest
on the right); the vertical axis is bytes/sec, auto-scaled to the
peak value in the window.

If you have a global speed limit configured, the limit is drawn as a
dashed horizontal line at the limit value. The current throughput is
shown numerically below the sparkline, e.g. "12.4 MB/s of 50 MB/s
limit".

### 4.2 Reading the disk-space card

The disk-space card queries `DriveInfo` for the drive that hosts
`DefaultDownloadDirectory`. The card shows free bytes, total bytes,
and a coloured bar:

- Green: more than 1 GB free.
- Amber: between 100 MB and 1 GB free.
- Red: less than 100 MB free.

When the bar is red, the card also shows a "Pause All" quick-link so
you can stop downloads before the disk fills up.

---

## 5. Adding a download

There are four ways to add a download.

### 5.1 By URL

1. Click the **+ Add Download** button in the toolbar (or press
   `Ctrl+N`).
2. The Add Download dialog opens. Paste the URL into the **URL** field.
3. Sawan probes the URL. After a few seconds the dialog shows:
   - The final file name (after redirects).
   - The total size (if the server reports it).
   - Whether the server supports resuming (Accept-Ranges).
   - The category auto-detected from the file extension.
4. Optionally change the **Save to** folder, the file name, the
   category, and the priority.
5. Click **Start now** to begin immediately, or **Add to queue** to
   queue the download without starting it.

### 5.2 From the browser

With browser integration installed, you have two options:

- **Right-click a link** in Chrome / Edge / Firefox / Opera / Brave /
  Vivaldi and choose **Download with Sawan Download Pro**. The URL is
  forwarded to the Sawan app and appears in the Add Download dialog
  automatically.
- **Click the Sawan toolbar button** in your browser. A small popup
  appears with a URL field. Paste a URL and click **Send to Sawan**.

Either way, the Sawan app comes to the foreground with the Add Download
dialog pre-filled.

### 5.3 From the clipboard

If **Settings → Clipboard → Monitor clipboard for URLs** is on (the
default), copying a URL to the clipboard (Ctrl+C) opens a small toast
notification in the corner of the screen asking whether to add the
download. Click **Add** to send it to the Add Download dialog.

If **ClipboardAutoAddDirectDownloads** is also on (off by default), URLs
ending in known file extensions (`.zip`, `.mp4`, `.exe`, etc.) are
added directly to the queue without asking.

### 5.4 Importing a list

**File → Import → From .txt file** lets you import a list of URLs (one
per line) into the queue. Lines starting with `#` are ignored. Each
URL becomes its own download task; you can multi-select them and bulk
edit priority, category, or save folder.

---

## 6. Pausing, resuming, cancelling

### 6.1 Pause

Click the **Pause** button (⏸) on a download row, or right-click the
row and choose **Pause**. The download stops at its current byte
position; partial data is kept on disk in a `.part` file with a
`.sawanmeta` sidecar. Pause is instant.

If the server does not support `Accept-Ranges`, pause is still allowed
but resume will restart the download from the beginning. The app warns
you before pausing such a download.

### 6.2 Resume

Click **Resume** (▶) on a paused download. Sawan sends an HTTP `Range`
request to continue from where it left off. If the server reports the
file has changed (different `ETag` or `Last-Modified`), Sawan warns you
and asks whether to restart from scratch.

### 6.3 Cancel

Click **Cancel** (✖) to stop a download permanently. By default the
partial file is deleted; if **Settings → Downloads → Keep partial files
on cancel** is on, the partial file is kept on disk for manual resuming.

### 6.4 Pause all / Resume all / Stop all

The toolbar has three bulk buttons:

- **Pause All** — pauses every active download.
- **Resume All** — resumes every paused download.
- **Stop All** — cancels every active download. Use with care.

### 6.5 Retry

Failed downloads show a **Retry** button (🔄). Click it to retry with
the same URL and save path. The retry policy (delay between attempts,
max attempts) is configurable in Settings → Downloads → Retry policy.

---

## 7. Categories and the sidebar

The left sidebar organizes downloads by category:

| Category   | Default subfolder | Typical extensions                                    |
|------------|-------------------|-------------------------------------------------------|
| Compressed | `Compressed`      | `.zip`, `.rar`, `.7z`, `.tar`, `.gz`                  |
| Videos     | `Videos`          | `.mp4`, `.mkv`, `.avi`, `.mov`, `.webm`, `.flv`       |
| Music      | `Music`           | `.mp3`, `.flac`, `.wav`, `.aac`, `.ogg`, `.m4a`       |
| Documents  | `Documents`       | `.pdf`, `.doc(x)`, `.xls(x)`, `.ppt(x)`, `.txt`, `.csv` |
| Programs   | `Programs`        | `.exe`, `.msi`, `.iso`                                |
| Other      | (root)            | Anything not matching the above                       |

### 7.1 Auto-categorization

With **Settings → Downloads → Auto-categorize by extension** on (the
default), every new download is sorted into the matching category and
saved to that category's subfolder under your default download folder.

### 7.2 Manual category

You can change a download's category at any time from the Add Download
dialog, from the right-click context menu, or by dragging the row onto
a sidebar category.

### 7.3 Custom subfolders

**Settings → Downloads → Category subfolders** lets you change where
each category lands. For example, you can route Videos to
`D:\Media\Videos` while keeping Documents in the default location.

### 7.4 Custom extension mappings

**Settings → Downloads → Extension categories** lets you add your own
extension → category mappings. For example, you can map `.psd` to
Documents or `.unitypackage` to Programs.

### 7.5 Smart views

Above the categories, the sidebar has smart views:

- **Dashboard** — the v1.0 default landing view (see Section 4).
- **All** — every download, including history.
- **Today** — downloads started today.
- **Active** — currently downloading or paused.
- **Failed** — failed downloads awaiting retry or user action.
- **History** — completed (and optionally deleted) downloads.
- **Private** — visible only when Private mode is enabled (see
  Section 8).
- **Security & Privacy** — the v1.0 privacy and security center (see
  Section 9).

Click a smart view to filter the list.

---

## 8. Private Downloads mode

Private Downloads mode is a v1.0 feature that lets you isolate
sensitive downloads from Sawan's regular queue. When Private mode is
enabled:

- A separate in-memory session holds private tasks. They do not appear
  in the All, Active, or History smart views.
- Private tasks are persisted to the SQLite database in a separate
  `is_private=1` partition so they survive an app restart, but they
  are only visible when you re-enter Private mode.
- The Clear Private Session action (sidebar button in the Security &
  Privacy panel) deletes every private task and its partial files
  atomically.
- An optional **Auto-clear private session on exit** setting destroys
  the private partition when the app exits, so a fresh launch always
  starts with an empty private session.

### 8.1 Enable Private mode

1. Click the **Private** item in the sidebar, or press `Ctrl+Shift+P`.
2. If this is your first time enabling Private mode in this profile,
   the app shows a one-time consent dialog explaining what Private
   mode does and does not protect. Tick **I understand** to continue.
3. The sidebar highlights the Private item; the main list now shows
   only private tasks (initially empty).

### 8.2 Add a private download

With Private mode active, every download you add — by URL, from the
browser, from the clipboard, or by import — is added to the private
session instead of the regular queue. The Add Download dialog shows a
"Private" badge in the top-right corner so you know the task will be
isolated.

### 8.3 Clear Private Session

To wipe the private session:

1. Click **Security & Privacy** in the sidebar.
2. Click **Clear Private Session**.
3. The app asks for confirmation: "This will delete N private tasks
   and their partial files. Completed private downloads on disk are
   NOT deleted. Continue?"
4. Click **Yes**. The app deletes every private task row, every
   private segment row, every private `.part` and `.sawanmeta` file,
   and every private entry from the history table — atomically, in a
   single SQLite transaction.

### 8.4 What remains after clearing

- **Sawan's regular queue and history are unaffected.** Clear Private
  Session touches only the private partition.
- **Completed private downloads on disk are NOT deleted.** If you
  saved a private download into a regular folder (e.g. the Desktop),
  the file remains there. Use Windows Explorer to delete it manually,
  or enable the optional **Secure-delete private partial files**
  setting to destroy partial files (not completed files).
- **Browser history is NOT cleared.** Sawan has no control over your
  browser. Use your browser's "Clear browsing data" feature.
- **NTFS journal, DNS cache, Windows event log, and Recycle Bin are
  NOT cleared.** See `docs/PRIVACY.md` Section 3.2 for the full list
  of what Private mode does and does not isolate.
- **Network logs from your ISP / employer / the download server's
  operator are NOT cleared.** Sawan does not route private downloads
  through a VPN or proxy automatically.

### 8.5 Auto-clear on exit

If you tick **Settings → Private Downloads → Auto-clear private
session on exit**, the app destroys the private partition when it
exits. This means a fresh launch always starts with an empty private
session. Use this if you share the machine and want to ensure no
private tasks survive a restart.

If you also tick **Secure-delete private partial files**, the bytes of
every private `.part` file are overwritten with zeros before unlinking,
so the files cannot be recovered from the Recycle Bin or by simple
undelete tools. (This is not a defence against forensic tools that
read the raw disk.)

### 8.6 Limitations

Private Downloads mode is a **convenience feature**. It is **not** a
forensic anonymity tool. If you need strong anonymity, use a VPN, the
Tor Browser, or a dedicated privacy-focused OS like Tails — none of
which Sawan integrates with or claims to replace.

---

## 9. The Security & Privacy center

The new **Security & Privacy** sidebar item is a single dashboard for
every privacy-sensitive control in the application. It surfaces:

- **DPAPI status.** Reads `DataProtectionScope.CurrentUser` and
  verifies per-machine binding by round-tripping a test ciphertext.
  Display: "DPAPI: OK (Current User scope, per-machine binding
  verified)" or "DPAPI: FAILED — see logs".
- **Telemetry status.** Always displays "Off". The toggle is
  intentionally read-only — this is a binding commitment for the
  entire 1.x release line.
- **Log directory.** Shows the configured log path. "Open log folder"
  button opens Explorer at that path. "Clear logs now" button deletes
  every file in the directory except the current in-use log.
- **Antivirus integration.** Toggle plus the user-supplied scanner
  path. "Run scan now" button invokes the scanner on the most
  recently completed download.
- **Native-messaging host status.** Shows which of the six supported
  browsers are registered, with the manifest file path. "Re-register
  all" button re-writes the manifest and the registry entries.
- **Private Downloads status.** Shows active / inactive, auto-clear
  state, secure-delete state. "Clear Private Session" button (see
  Section 8).
- **Update check status.** Shows off (default) or on with the
  configured URL and the Ed25519 public key fingerprint.
- **Run security self-check.** A one-click button that re-validates
  the path sanitizer, URL validator, DPAPI round-trip, and
  native-messaging schema in one pass. Also exposed as a CLI flag:
  `SawanDownloadPro.App.exe --selftest`.

### 9.1 Running the self-check

Click **Run security self-check**. The app runs four checks in
sequence:

1. Path sanitizer rejects a known traversal payload.
2. URL validator rejects a known disallowed-scheme URL.
3. DPAPI round-trips a known plaintext.
4. Native-messaging schema rejects a known bad message and accepts a
   known good one.

The result panel shows a green check or a red cross for each check.
If any check fails, the panel shows a "Copy error to clipboard"
button so you can paste the failure into a bug report.

---

## 10. The About Sawan page

The new **About** sidebar item introduces the creator and surfaces the
official Sawan contact channels. The page shows:

- The Sawan brand mark and the "Fast. Smart. In Control." tagline.
- The application version, build hash, and target runtime.
- The creator credit: "Created by Ahmed Sawan".
- The four official contact links (no others):
  - WhatsApp — <https://wa.me/201000150303>
  - YouTube — <https://www.youtube.com/@AhmedSawanOfficial>
  - Facebook — <https://www.facebook.com/AhmedSawanOfficial/>
  - Telegram — <https://t.me/AhmedMSawan>
- A short biography pointer to `docs/ABOUT_AHMED_SAWAN.md`.
- The full license text (Apache 2.0) and the third-party license
  inventory pointer.

> **Note.** These four links are the only official Sawan contact
> channels. Any other account, page, or handle claiming to represent
> Ahmed Sawan or the Sawan brand is not authentic.

---

## 11. Settings window

Open with **File → Settings** or `Ctrl+,`. Settings are grouped into
sections in the left pane.

### 11.1 General

- **Start with Windows** — adds a Run registry entry.
- **Minimize to tray** — minimizes to the system tray instead of the
  taskbar.
- **Start minimized** — starts the app hidden in the tray.
- **Close to tray** — closes the window without exiting the app.
- **Confirm before exit** — shows a confirmation dialog when you click
  Exit.
- **Confirm before deleting file** — shows a confirmation dialog when
  you delete a download's file from disk.
- **Run first-run wizard again** — re-runs the v1.0 welcome wizard.
  Useful for re-consenting to Private Downloads, re-registering
  browser integration, or resetting your theme.

### 11.2 Downloads

- **Default download directory** — where new downloads land by default.
- **Temp directory** — where `.part` files live during download.
- **Max simultaneous downloads** — queue concurrency limit.
- **Max connections per download** — segmented-connection count
  (1–16). Higher = faster on fast servers, slower on slow ones.
- **Auto-categorize by extension** — see Section 7.
- **Avoid duplicate URLs** — refuses to add a URL already in the queue
  or history.
- **Keep partial files on cancel** — see Section 6.3.

### 11.3 Retry policy

- **Max retry attempts** — default 5.
- **Initial delay** — delay before the first retry (default 1 s).
- **Backoff multiplier** — exponential growth factor (default 2.0).
- **Max delay** — cap on retry delay (default 60 s).

The retry policy honours `Retry-After` headers from the server when
present.

### 11.4 Network

- **Global speed limit (KB/s)** — 0 = unlimited.
- **Connection timeout (s)** — default 30.
- **Read/write timeout (s)** — default 120.
- **Use proxy** — HTTP/HTTPS proxy host:port with optional bypass list.
- **Force TLS 1.2** — required on Windows 7 SP1 (on by default).

### 11.5 Clipboard

- **Monitor clipboard for URLs** — see Section 5.3.
- **Auto-add direct downloads** — see Section 5.3.

### 11.6 Browser integration

v1.0 supports six browsers. Tick the box for each browser you want to
integrate:

- **Enable Chrome integration**
- **Enable Edge integration**
- **Enable Firefox integration**
- **Enable Opera integration** (new in v1.0)
- **Enable Brave integration** (new in v1.0)
- **Enable Vivaldi integration** (new in v1.0)

Ticking a box writes the native-messaging manifest and registers it in
the correct location. Unticking removes the registration.

### 11.7 Appearance

- **Theme** — Dark Eggplant / Light / System.
- **Language** — Arabic / English.
- **Font size (pt)** — 10–24, default 14.

### 11.8 Themes (new in v1.0)

- **Palette selector.** Dark Eggplant / Light / System.
- **Custom accent.** HEX colour picker.
- **Export theme.** Writes current theme + accent to a
  `.sawantheme.json` file.
- **Import theme.** Reads a `.sawantheme.json` file and applies it.

### 11.9 Notifications

- **Notify on complete** — toast notification when a download finishes.
- **Notify on failure** — toast notification when a download fails.
- **Notify on queue complete** — toast when the entire queue is done.
- **Play sound on complete / failure** — audible alert.

### 11.10 Media

- **Enable video downloader** — shows/hides the Video Downloader
  window.
- **yt-dlp path** — absolute path to a user-supplied `yt-dlp.exe`.
  Required for YouTube downloads. See Section 13.
- **FFmpeg path** — absolute path to a user-supplied `ffmpeg.exe` or
  to a folder containing it. Required for media conversion.
- **Default video format** — `mp4`, `webm`, etc.
- **Default audio format** — `mp3`, `aac`, etc.

### 11.11 Private Downloads (new in v1.0)

- **Enable Private Downloads** — enables the Private sidebar item and
  the Private mode toggle.
- **Auto-clear private session on exit** — destroys the private
  partition when the app exits.
- **Secure-delete private partial files** — overwrites the bytes of
  every private `.part` file with zeros before unlinking.

### 11.12 Security & Privacy (new in v1.0)

- **Warn on dangerous extensions** — confirms before downloading
  `.exe`, `.bat`, `.ps1`, `.vbs`, `.js`, `.jar`, `.scr`, `.msi` files.
- **Scan with antivirus** — invokes your antivirus binary on completed
  downloads (optional, requires Antivirus path).
- **Antivirus path** — path to your antivirus scanner's command-line
  interface.
- **Clear logs now** — empties the `logs\` directory.
- **Run security self-check** — see Section 9.1.

### 11.13 Advanced

- **Log directory** — where the app writes log files.
- **Verbose logging** — debug-level log entries (use only when filing
  a bug report).
- **Update checks** — off by default. When on, requires a URL the user
  configures; verifies Ed25519 signatures before applying.

---

## 12. Scheduler

The scheduler runs the download queue automatically at times you
define.

### 12.1 Schedule queue start

1. Open **View → Scheduler**.
2. Click **Add schedule**.
3. Choose **Start queue at** and pick a date/time.
4. (Optional) Tick **Repeat daily** to start the queue at the same time
   every day.
5. Click **Save**.

At the scheduled time, Sawan resumes all paused downloads and starts
all queued downloads, respecting the max-simultaneous limit.

### 12.2 Schedule queue stop

Same flow, but choose **Stop queue at**. The stop schedule pauses all
active downloads (it does not cancel them).

### 12.3 Shutdown after queue completes

In the Scheduler window, tick **Shut down computer when queue
completes**. When every download in the queue finishes (success or
failure), Sawan shows a 60-second countdown dialog. You can cancel the
shutdown during that window. After 60 seconds the computer shuts down.

This is useful for overnight downloads: queue everything, schedule a
2 AM start, tick "shut down when complete", and go to bed.

> The scheduler window's UI is on the v1.1 roadmap for an overhaul.
> The current implementation is functional but visually dated; see
> `docs/ROADMAP.md` Section 3.1 for the planned improvements.

---

## 13. Video downloader

The video downloader is a separate window for downloading media from
supported sources. Currently supported:

- **YouTube** (via a user-supplied `yt-dlp.exe`)
- **Facebook** (stub — see 13.3)
- **TikTok** (stub — see 13.3)

> **Authorization reminder.** v1.0 adds a clear authorization banner
> at the top of the Video Downloader window, restating your
> responsibility to comply with the source platform's Terms of Service
> and applicable copyright law. The app will not bypass DRM, login
> walls, or members-only restrictions. The banner is dismissible per
> session.

### 13.1 Configure yt-dlp

1. Download `yt-dlp.exe` from
   <https://github.com/yt-dlp/yt-dlp/releases>. Sawan does **not**
   bundle it.
2. In Sawan, open **Settings → Media**.
3. Set **yt-dlp path** to the absolute path of `yt-dlp.exe`.
4. (Optional) Set **FFmpeg path** if you want yt-dlp to be able to
   merge separate audio + video streams into a single MP4.
5. Click **Apply**.

### 13.2 Download a YouTube video

1. Open **View → Video Downloader** (or press `Ctrl+Shift+V`).
2. Paste the YouTube URL into the URL field.
3. Click **Probe**. Sawan invokes `yt-dlp -J` and lists the available
   formats with their resolution, codec, and file size.
4. Pick a format. For highest quality, pick the topmost format that
   has both audio and video. For audio-only, pick an audio-only
   format (it will be tagged "audio" in the list).
5. Choose a save path. The default is your Videos category folder.
6. Click **Download**. Progress is shown in the Video Downloader
   window (not the main download list, because yt-dlp manages its own
   progress reporting).
7. When the download completes, the file appears at the chosen path.
   The history entry is added to your download history.

### 13.3 Facebook and TikTok — intentional stubs

Facebook and TikTok restrict automated media access. The Sawan video
downloader **does not bypass** Facebook login, private-group
restrictions, or DRM. It **does not strip watermarks** from third-party
TikTok content.

If you paste a Facebook or TikTok URL into the Video Downloader, you
will see a clear explanation of what the app will and will not do, and
a suggestion to use the platform's official "Save video" feature
instead.

### 13.4 Convert with FFmpeg

After downloading a video, you can convert it (e.g. to MP3) if FFmpeg
is configured:

1. Right-click a completed video download and choose **Convert with
   FFmpeg**.
2. Pick the output format (MP3, AAC, WAV, FLAC, OGG, MP4, WebM).
3. (Optional) Set audio bitrate, trim start/end, target resolution.
4. Click **Convert**.
5. The converted file is saved next to the original.

Sawan invokes the user-supplied `ffmpeg.exe` with safe argument
construction; no shell interpretation occurs. See
`src/SawanDownloadPro.Media/LICENSE_NOTICES.md` for FFmpeg and yt-dlp
licensing details.

---

## 14. Browser integration setup

v1.0 supports six browsers. All three new browsers (Opera, Brave,
Vivaldi) accept the Chrome MV3 extension byte-for-byte; only the
install page and the registry discovery path differ.

### 14.1 Chrome

1. In Sawan: **Settings → Browser integration → Enable Chrome
   integration**.
2. In Chrome: navigate to `chrome://extensions`.
3. Toggle **Developer mode** on (top-right).
4. Click **Load unpacked**.
5. Select `C:\Program Files\Sawan\Sawan Download Pro\browser-extensions\chrome\`.
6. Copy the generated extension ID and paste it into the Sawan settings
   page (the page prompts you for it the first time).

### 14.2 Edge

Same flow as Chrome, but:

1. In Edge: navigate to `edge://extensions`.
2. Toggle **Developer mode** on (left sidebar).
3. Click **Load unpacked**.
4. Select `...\browser-extensions\edge\`.

### 14.3 Firefox

1. In Sawan: **Settings → Browser integration → Enable Firefox
   integration**.
2. In Firefox: navigate to `about:debugging#/runtime/this-firefox`.
3. Click **Load Temporary Add-on...**.
4. Select `...\browser-extensions\firefox\manifest.json`.

Firefox temporary extensions are unloaded when Firefox exits. For a
permanent install, sign the extension via Mozilla's AMO or use an
Enterprise Policy. See `browser-extensions/firefox/README.md`.

### 14.4 Opera (new in v1.0)

1. In Sawan: **Settings → Browser integration → Enable Opera
   integration**.
2. In Opera: navigate to `opera://extensions`.
3. Toggle **Developer mode** on (top-right).
4. Click **Load unpacked**.
5. Select `...\browser-extensions\opera\`.
6. Copy the generated extension ID and paste it into the Sawan
   settings page.

Opera shares Chrome's native-messaging registry discovery path, so the
Sawan installer writes only one manifest entry that covers both
browsers.

### 14.5 Brave (new in v1.0)

1. In Sawan: **Settings → Browser integration → Enable Brave
   integration**.
2. In Brave: navigate to `brave://extensions`.
3. Toggle **Developer mode** on (top-right).
4. Click **Load unpacked**.
5. Select `...\browser-extensions\brave\`.
6. Copy the generated extension ID and paste it into the Sawan
   settings page.

Brave uses its own registry path
(`HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\...`).
Note that Brave Shields may block the content-script's click listener
on some sites; if the right-click "Download with Sawan" menu does not
appear, try disabling Shields for that site.

### 14.6 Vivaldi (new in v1.0)

1. In Sawan: **Settings → Browser integration → Enable Vivaldi
   integration**.
2. In Vivaldi: navigate to `vivaldi://extensions`.
3. Toggle **Developer mode** on (top-right).
4. Click **Load unpacked**.
5. Select `...\browser-extensions\vivaldi\`.
6. Copy the generated extension ID and paste it into the Sawan
   settings page.

Vivaldi uses its own registry path
(`HKCU\Software\Vivaldi\Vivaldi\NativeMessagingHosts\...`). Note that
Vivaldi's built-in tracker blocker may interfere with the content
script on some sites; if the right-click "Download with Sawan" menu
does not appear, try disabling the tracker blocker for that site.

### 14.7 What gets sent to the app

When you click the context menu or the toolbar button in your browser,
the browser extension sends:

- The URL of the link you right-clicked, or the URL you typed in the
  popup.
- The source ("contextmenu", "popup", or "toolbar").
- The URL of the page you were on (so Sawan can show it in the Add
  Download dialog).

It does **not** send cookies, auth headers, form data, or any private
information. The native host validates the URL scheme (http/https/ftp
only) and rejects embedded credentials (`https://user:pass@host/`).

### 14.8 What does NOT get sent

- The browser never sends your cookies.
- The browser never sends your auth tokens.
- The browser never auto-submits a URL — you must explicitly click.
- The native host never re-transmits the URL to any third-party
  service. It only forwards it to the Sawan app via a local named
  pipe.

---

## 15. Troubleshooting

See `docs/TROUBLESHOOTING.md` for the full list. The most common
issues:

- **TLS errors on Windows 7** → install KB4019276 and enable TLS 1.2.
- **Downloads not resuming** → the server does not support
  `Accept-Ranges`. Sawan shows this in the Add Download dialog.
- **Browser integration not working** → check the registry entries
  and the native-host manifest path.
- **FFmpeg not found** → configure the path in Settings → Media.
- **Slow downloads** → check the global speed limit, the per-download
  connection limit, and whether your antivirus is scanning each
  write.
- **SQLite database locked** → another instance of Sawan is running.
  Close it.
- **Custom accent not applying** → restart the app. Some elements
  (tray icon, jumplist) cache the accent at launch.
- **Private tasks visible after restart** → re-enter Private mode from
  the sidebar. Private tasks are persisted but only become visible
  when you explicitly enter Private mode.
- **Opera/Brave/Vivaldi right-click menu missing** → check the
  browser's tracker blocker / Shields settings; the content script
  may be blocked on the current site.

---

## 16. Privacy and security

### 16.1 No telemetry, ever

Sawan Download Pro does not collect, transmit, or sell any telemetry,
analytics, or usage data. There are no tracking pixels, no remote
loggers, no crash reporters phoning home. The only network traffic
the app generates is:

- The downloads you explicitly add.
- HEAD / Range probes the engine makes against the URLs you add.
- (Optional) Update checks against a URL you configure in Settings.
  The update check is **opt-in**; by default it is off.

### 16.2 Credentials

If you configure HTTP Basic or Digest auth for a download, the
credentials are encrypted with Windows DPAPI (per-user, per-machine)
and stored in the SQLite database. They never leave the machine. They
cannot be decrypted by another user or on another machine.

### 16.3 Path safety

Every filename and save path passes through `PathSanitizer` which:

- Strips `..` traversal.
- Removes Windows-invalid characters.
- Refuses absolute paths in the filename component.
- Flags dangerous extensions (`.exe`, `.bat`, `.ps1`, `.vbs`, `.js`,
  `.jar`, `.scr`, `.msi`) for confirmation.

### 16.4 URL safety

Only `http`, `https`, and `ftp` schemes are accepted. `file://`,
`javascript:`, `data:`, and UNC paths (`\\server\share`) are rejected
by default.

### 16.5 Browser extension safety

The native-messaging host validates every incoming message against a
strict schema. It rejects:

- URLs with disallowed schemes.
- URLs with embedded credentials.
- Messages over 1 MiB.
- URLs over 8192 characters.
- Messages with unknown top-level keys.
- Any `type` other than `download` (no `execute`, no `read`, no
  `delete`).

### 16.6 Private Downloads safety

Private Downloads mode isolates Sawan's own state. It does not clear
browser history, NTFS journal, DNS cache, or Recycle Bin. See
`docs/PRIVACY.md` Section 3.2 for the full list of what Private mode
does and does not isolate.

### 16.7 Update safety

If you enable update checks, Sawan downloads only after verifying an
Ed25519 signature against a public key compiled into the app. A
tampered update is refused; the existing version continues to run.

### 16.8 Reporting a vulnerability

See `docs/SECURITY.md` Section 12 for the responsible-disclosure
process. We do not operate a bug bounty, but we do acknowledge every
reporter in the release notes.

---

## 17. Where to go next

- **`docs/USER_GUIDE_AR.md`** — full Arabic translation of this guide.
- **`docs/TROUBLESHOOTING.md`** — common issues and fixes.
- **`docs/SECURITY.md`** — full security and privacy posture.
- **`docs/PRIVACY.md`** — comprehensive privacy statement.
- **`docs/RELEASE_NOTES_v1.0.md`** — full v1.0 release notes.
- **`docs/ABOUT_AHMED_SAWAN.md`** — about the creator.
- **`docs/ARCHITECTURE.md`** — engineering design document.
- **`docs/ROADMAP.md`** — what's coming in v1.1, v1.2, and beyond.

Enjoy using Sawan Download Pro v1.0. Fast. Smart. In Control.
