# Sawan Download Pro — License Inventory

This document lists every third-party dependency that Sawan Download Pro
relies on, the license under which it is distributed, whether it is
bundled with the official Sawan Download Pro distribution, and where to
obtain the source.

> **Bundled?** "Yes" means the binary is shipped inside the official
> MSI installer. "No" means the user must obtain the binary themselves
> and configure its path in Settings → Media. Sawan Download Pro never
> bundles GPL/LGPL/Unlicensed binaries.

---

## 1. Summary table

| # | Component                             | Version     | License                                          | Bundled? | Source URL                                                                                                  |
|---|---------------------------------------|-------------|--------------------------------------------------|----------|-------------------------------------------------------------------------------------------------------------|
| 1 | .NET Framework 4.8                    | 4.8.x       | Microsoft Software License (EULA)                | No (OS)  | <https://dotnet.microsoft.com/download/dotnet-framework>                                                    |
| 2 | System.Data.SQLite (managed)          | 1.0.118     | Public domain (SQLite) + MIT (managed wrapper)   | Yes      | <https://system.data.sqlite.org>                                                                            |
| 3 | SQLite (native engine)                | 3.42.0      | Public domain                                    | Yes      | <https://www.sqlite.org>                                                                                    |
| 4 | Newtonsoft.Json                       | 13.0.3      | MIT                                              | Yes      | <https://www.newtonsoft.com/json> / <https://github.com/JamesNK/Newtonsoft.Json>                            |
| 5 | Microsoft.Extensions.Logging          | 6.0.4       | MIT                                              | Yes      | <https://github.com/dotnet/runtime>                                                                         |
| 6 | Microsoft.Extensions.Logging.Abstractions | 6.0.4   | MIT                                              | Yes      | <https://github.com/dotnet/runtime>                                                                         |
| 7 | Microsoft.Extensions.DependencyInjection | 6.0.2     | MIT                                              | Yes      | <https://github.com/dotnet/runtime>                                                                         |
| 8 | CommunityToolkit.Mvvm                 | 8.2.2       | MIT                                              | Yes      | <https://github.com/CommunityToolkit/dotnet>                                                                |
| 9 | xUnit                                 | 2.5.3       | Apache 2.0                                       | No (test)| <https://github.com/xunit/xunit>                                                                            |
| 10| xUnit Runner Visual Studio            | 2.5.3       | Apache 2.0                                       | No (test)| <https://github.com/xunit/visualstudio.xunit>                                                               |
| 11| Microsoft.NET.Test.Sdk                | 17.8.0      | MIT                                              | No (test)| <https://github.com/microsoft/vstest>                                                                       |
| 12| Moq                                   | 4.20.70     | BSD-3-Clause                                     | No (test)| <https://github.com/moq/moq>                                                                                |
| 13| WiX Toolset                           | 3.14        | Microsoft Reciprocal License (MS-RL)             | No (build)| <https://wixtoolset.org/releases/v3-14/>                                                                   |
| 14| FFmpeg                                | any         | LGPL 2.1+ (or GPL, build-dependent)              | **No**   | <https://ffmpeg.org>                                                                                        |
| 15| yt-dlp                                | any         | The Unlicense                                    | **No**   | <https://github.com/yt-dlp/yt-dlp>                                                                          |
| 16| Python                                | 3.8+        | PSF License (BSD-compatible)                     | No       | <https://www.python.org>                                                                                    |
| 17| pywin32 (optional, Python host)       | 306+        | PSF License                                      | No       | <https://github.com/mhammond/pywin32>                                                                       |

---

## 2. Detailed notes

### 2.1 .NET Framework 4.8 — Microsoft EULA

The .NET Framework 4.8 runtime is a Windows system component, not a
redistributable that Sawan ships. The installer requires it as a
prerequisite (see the `NETFRAMEWORK45` launch condition in
`installer/Product.wxs`). The end-user must accept Microsoft's EULA
when installing the framework; Sawan does not modify the runtime or
redistribute it.

Source code for the .NET Framework reference assemblies is not
published; the API surface is documented at
<https://learn.microsoft.com/dotnet/api/>.

### 2.2 System.Data.SQLite — public domain + MIT

`System.Data.SQLite` is the managed ADO.NET provider that Sawan's
Storage project uses to talk to SQLite. It is a dual-licensed work:

- The native SQLite engine is **public domain** (see SQLite's
  <https://www.sqlite.org/copyright.html>).
- The C# wrapper (`System.Data.SQLite.dll`) is **MIT licensed** by
  Robert Simpson and contributors.

Sawan bundles both binaries in the MSI. The MIT license requires
attribution; this document constitutes that attribution. The license
text is at <https://github.com/sqlite-net/System.Data.SQLite/blob/master/LICENSE>.

### 2.3 SQLite — public domain

SQLite is the embedded SQL engine. Its source code is in the public
domain; the project explicitly disclaims copyright. See
<https://www.sqlite.org/copyright.html>.

Sawan bundles `SQLite.Interop.dll` (the native engine) in the MSI,
in both x86 and x64 variants. The native binary is loaded at runtime
based on the host process's bitness.

### 2.4 Newtonsoft.Json — MIT

Newtonsoft.Json (`Newtonsoft.Json.dll`) is used for JSON serialization
of settings, history exports, and the native-messaging wire protocol
in the C# host. It is bundled with the MSI.

License: <https://github.com/JamesNK/Newtonsoft.Json/blob/master/LICENSE>

The MIT license requires preserving the copyright notice. This
document is the Sawan project's compliance with that requirement.

### 2.5 Microsoft.Extensions.Logging (and Abstractions) — MIT

Used for structured logging throughout the C# projects. Bundled with
the MSI. The Microsoft.Extensions.Logging package depends on
Microsoft.Extensions.DependencyInjection and Microsoft.Extensions
.Logging.Abstractions, all MIT-licensed, all bundled.

Source: <https://github.com/dotnet/runtime>

### 2.6 Microsoft.Extensions.DependencyInjection — MIT

The DI container the App project uses to wire up the engine, storage,
scheduler, security, and media modules. Bundled. MIT-licensed.

### 2.7 CommunityToolkit.Mvvm — MIT

Source-generator-based MVVM framework used by the WPF UI. Bundled.

License: <https://github.com/CommunityToolkit/dotnet/blob/main/License.md>

### 2.8 xUnit — Apache 2.0

The test framework. Used only at build time; **not bundled** in the
MSI. The Apache 2.0 license is at
<https://www.apache.org/licenses/LICENSE-2.0>.

### 2.9 xUnit Runner Visual Studio — Apache 2.0

The test adapter that lets Visual Studio's Test Explorer discover and
run xUnit tests. Build-time only; not bundled.

### 2.10 Microsoft.NET.Test.Sdk — MIT

The test host that runs the test assembly. Build-time only; not
bundled.

### 2.11 Moq — BSD-3-Clause

Mocking library used by the test project. Build-time only; not
bundled.

License: <https://github.com/moq/moq/blob/main/LICENSE>

> **Note.** Moq 4.20.x introduced a telemetry / SponsorLink feature
> that was controversial. Sawan's test project pins Moq at 4.20.70
> and disables SponsorLink by not setting the
> `MOQ_TELEMETRY_PARTITION` environment variable. The tests run
> offline; no telemetry is sent. If you want to avoid Moq entirely,
> swap to NSubstitute (MIT) — the test surface is small enough that
> the migration is mechanical.

### 2.12 WiX Toolset — MS-RL

WiX v3.14 is the build tool used to produce the MSI installer. It is
**not bundled** in the MSI; it is only installed on the build host.

License: <https://github.com/wixtoolset/wix3/blob/develop/LICENSE.TXT>

The Microsoft Reciprocal License (MS-RL) requires that any
modifications to WiX source be released under the same license. Sawan
does not modify WiX source; it only consumes WiX as a build tool.

### 2.13 FFmpeg — LGPL 2.1+ or GPL (build-dependent)

FFmpeg is **NOT bundled**. The user must obtain an FFmpeg binary
themselves and configure its path in Settings → Media.

The license applicable to a particular FFmpeg binary depends on its
build configuration:

- Builds that include only LGPL-licensed libraries are **LGPL 2.1+**.
- Builds that include GPL-licensed libraries (e.g. `libx264`,
  `libx265`, `libfdk-aac`, `libmp3lame` in some configs) are
  **GPL 2+**.

The user is responsible for ensuring their FFmpeg binary's license
complies with their use case. Sawan invokes FFmpeg as an external
process; it does not link against it, redistribute it, or modify it.

Full notice: <https://ffmpeg.org/legal.html>

See `src/SawanDownloadPro.Media/LICENSE_NOTICES.md` for the complete
FFmpeg notice, including the patent-licensing caveat.

### 2.14 yt-dlp — The Unlicense

yt-dlp is **NOT bundled**. The user must obtain it themselves and
configure its path in Settings → Media.

yt-dlp is released into the public domain under The Unlicense:

> This is free and unencumbered software released into the public domain.
> Anyone is free to copy, modify, publish, use, compile, sell, or
> distribute this software, either in source code form or as a compiled
> binary, for any purpose, commercial or non-commercial, and by any
> means.

Full text: <https://github.com/yt-dlp/yt-dlp/blob/master/LICENSE>

Sawan does not redistribute yt-dlp, modify it, or pass any
authentication material (cookies, browser profiles, session tokens)
to it. The user is solely responsible for using yt-dlp in compliance
with the source platform's Terms of Service and applicable copyright
law.

### 2.15 Python — PSF License

Python is **NOT bundled**. It is required only if you choose to use
the Python reference native-messaging host instead of the default C#
host.

The Python Software Foundation License is BSD-compatible and
permissive. See <https://docs.python.org/3/license.html>.

### 2.16 pywin32 — PSF License

pywin32 is an optional dependency of the Python native-messaging host
(it provides the named-pipe API the host uses to talk to the Sawan
app). Not bundled; install via `pip install pywin32` if you want to
use the Python host.

---

## 3. Why we do not bundle FFmpeg or yt-dlp

See `src/SawanDownloadPro.Media/LICENSE_NOTICES.md` for the full
rationale. The short version:

1. **License incompatibility.** Bundling LGPL/GPL FFmpeg with a
   closed-source product requires either permitting end-user
   relinking (LGPL) or releasing the entire product under GPL.
   Neither is acceptable.
2. **Build-matrix complexity.** Each FFmpeg build has a different
   license based on its included codecs. We can't pick one license
   that's appropriate for every user's jurisdiction.
3. **Volatile binaries.** Both FFmpeg and yt-dlp are updated
   frequently. Bundling a version would freeze users on a stale
   version; letting them supply their own lets them update at will.
4. **User-agency framing.** Downloading media from third-party
   platforms carries ToS and copyright considerations. Requiring the
   user to obtain yt-dlp themselves makes their agency explicit.

---

## 4. Attribution text reproduced from each license

### MIT (used by Newtonsoft.Json, Microsoft.Extensions.*, CommunityToolkit.Mvvm, Microsoft.NET.Test.Sdk)

> Permission is hereby granted, free of charge, to any person obtaining
> a copy of this software and associated documentation files (the
> "Software"), to deal in the Software without restriction, including
> without limitation the rights to use, copy, modify, merge, publish,
> distribute, sublicense, and/or sell copies of the Software, and to
> permit persons to whom the Software is furnished to do so, subject to
> the following conditions:
>
> The above copyright notice and this permission notice shall be
> included in all copies or substantial portions of the Software.

### Apache 2.0 (used by xUnit)

> Licensed under the Apache License, Version 2.0 (the "License");
> you may not use this file except in compliance with the License.
> You may obtain a copy of the License at
>
>     http://www.apache.org/licenses/LICENSE-2.0

### BSD-3-Clause (used by Moq)

> Redistribution and use in source and binary forms, with or without
> modification, are permitted provided that the following conditions
> are met: (1) Redistributions of source code must retain the above
> copyright notice. (2) Redistributions in binary form must reproduce
> the above copyright notice. (3) Neither the name of the copyright
> holder nor the names of its contributors may be used to endorse or
> promote products derived from this software without specific prior
> written permission.

### Public domain (SQLite, System.Data.SQLite managed wrapper source, yt-dlp)

> This is free and unencumbered software released into the public
> domain. Anyone is free to copy, modify, publish, use, compile, sell,
> or distribute this software, either in source code form or as a
> compiled binary, for any purpose, commercial or non-commercial, and
> by any means.

### LGPL 2.1+ / GPL 2+ (FFmpeg, build-dependent)

> This program is free software; you can redistribute it and/or modify
> it under the terms of the GNU Lesser General Public License as
> published by the Free Software Foundation; either version 2.1 of the
> License, or (at your option) any later version.
>
> [For GPL builds:] This program is free software; you can redistribute
> it and/or modify it under the terms of the GNU General Public License
> as published by the Free Software Foundation; either version 2 of the
> License, or (at your option) any later version.

### Microsoft Reciprocal License (WiX Toolset)

> This license governs use of the accompanying software. If you use the
> software, you accept this license. If you do not accept the license,
> do not use the software. [...] If you file a patent application
> relating to the software, you must license the patent under MS-RL.

### PSF License (Python, pywin32)

> PYTHON SOFTWARE FOUNDATION LICENSE VERSION 2
> 1. This LICENSE AGREEMENT is between the Python Software Foundation
> ("PSF"), and the Individual or Organization ("Licensee") accessing
> and otherwise using this software ("Python") in source or binary
> form and its associated documentation.

---

## 5. Sawan Download Pro's own license

The Sawan Download Pro source code (all projects in this repository) is
licensed under the **Apache License, Version 2.0**. The Apache 2.0
license is compatible with every license listed above (MIT, BSD-3,
Apache 2.0, MS-RL, public domain, LGPL, GPL, Unlicense, PSF), so users
may combine Sawan Download Pro with user-supplied FFmpeg and yt-dlp
binaries without license conflict, provided the terms of all licenses
are honoured.

The full Apache 2.0 license text is at
<https://www.apache.org/licenses/LICENSE-2.0>.
