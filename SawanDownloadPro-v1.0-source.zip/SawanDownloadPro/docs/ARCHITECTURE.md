# Sawan Download Pro — Architecture Document

**Version:** 1.0 (Stage 1 + Stage 2 MVP)
**Last updated:** 2026-10-16
**Author:** Sawan engineering

---

## 1. Executive Summary

Sawan Download Pro is a native Windows desktop download manager built in C# and WPF,
targeting Windows 7 SP1, Windows 10, and Windows 11. The product supports HTTP/HTTPS
downloads with segmented acceleration, resume, queue scheduling, browser integration,
and a dedicated video downloader module for authorized sources. The primary interface
language is Arabic with full RTL support; English is fully supported as a secondary
language.

The architecture prioritizes:

1. **Legacy compatibility** — runs on Windows 7 SP1 without requiring WebView2, Edge,
   or any other modern runtime that has dropped Windows 7 support.
2. **Honest engineering** — no feature is declared complete unless the source code
   genuinely implements it. Unverified behaviour is labelled explicitly.
3. **Modularity** — eight C# projects with strict dependency direction so that the
   download engine, storage layer, and UI can evolve independently.
4. **Security first** — path traversal prevention, URL allow-listing, no plaintext
   credential storage, no telemetry, no bundled offers.

---

## 2. Technology Stack

| Layer | Choice | Rationale |
|---|---|---|
| UI framework | WPF (PresentationFramework) | Native, high-DPI capable, mature on Win7 SP1+ |
| .NET target | .NET Framework 4.8 (LTS) | Last .NET Framework release supported on Win7 SP1 via update KB4055001. Allows x86 and x64 builds. |
| HTTP client | `HttpWebRequest` + `HttpClient` (TLS 1.2 forced) | `HttpWebRequest` provides explicit Range/Content-Range control; `HttpClient` is used for non-segmented metadata fetches. |
| Persistence | SQLite via `System.Data.SQLite` (x86 + x64) | Single-file embedded DB, well-supported on Win7 SP1. |
| Logging | `Microsoft.Extensions.Logging` + custom file sink | Structured logging without external dependencies. |
| DI | `Microsoft.Extensions.DependencyInjection` | Mature, no Win7 incompatibility. |
| Browser integration | Native Messaging Host (Chrome/Edge/Firefox) | Standard, documented mechanism; no WebView2 required. |
| Media conversion | Optional FFmpeg integration (user-supplied binary) | FFmpeg is LGPL/GPL; we never bundle it without licensing checks. |
| Installer | WiX Toolset v3.14 | Produces MSI for x86 and x64, supports Win7 SP1. |

### Why not .NET 6/7/8?

.NET 6+ has dropped Windows 7 support. .NET Framework 4.8 is the only modern runtime
that still installs and runs on Windows 7 SP1. We accept the trade-off of older
language features (C# 7.3 by default, upgradable to 9.0 with LangVersion) in exchange
for the Windows 7 support you explicitly required.

### Why not Electron / Tauri / WebView2?

All of these have either dropped or never properly supported Windows 7:
- Electron ≥ 23 dropped Win7/8 support.
- WebView2 Runtime ≥ 110 dropped Win7 support.
- Tauri requires WebView2, inheriting the same limitation.

A native WPF + .NET Framework 4.8 application is the only way to honour the Windows 7
SP1 requirement without shipping a separate, degraded product.

---

## 3. Solution Structure

```
SawanDownloadPro.sln
│
├── src/
│   ├── SawanDownloadPro.Core/                  — domain models, interfaces, enums, events
│   ├── SawanDownloadPro.DownloadEngine/        — HTTP/HTTPS segmented downloader
│   ├── SawanDownloadPro.Storage/               — SQLite persistence
│   ├── SawanDownloadPro.Security/              — path/URL validation, safe process launch
│   ├── SawanDownloadPro.Scheduler/             — queue, priorities, scheduling
│   ├── SawanDownloadPro.Media/                 — video extractor + FFmpeg wrapper
│   ├── SawanDownloadPro.BrowserIntegration/    — native messaging host
│   └── SawanDownloadPro.App/                   — WPF UI, app composition root
│
├── browser-extensions/
│   ├── chrome/                                 — Manifest V3 extension
│   ├── edge/                                   — Manifest V3 extension (same base)
│   ├── firefox/                                — Manifest V2 extension
│   └── native-host/                            — Native messaging host manifest + installer
│
├── tests/
│   └── SawanDownloadPro.Tests/                 — xUnit test project
│
├── installer/                                  — WiX source (.wxs)
│
└── docs/                                       — all documentation
```

### Dependency direction (strict, enforced)

```
            App
             │
   ┌─────────┼─────────┬───────────┬──────────┐
   │         │         │           │          │
Scheduler  Media   BrowserInt.   Storage   Security
   │         │         │           │          │
   └─────────┴─────────┴───────────┴──────────┘
                       │
                DownloadEngine
                       │
                    Core
```

- `Core` depends on nothing.
- `DownloadEngine` depends only on `Core`.
- `Storage`, `Security`, `Scheduler`, `Media`, `BrowserIntegration` depend on `Core`.
- `App` depends on everything; nothing depends on `App`.
- `Tests` depends on everything for testability.

No project may take a dependency that violates this direction (enforced by project
references, not by Architecture Validation tools, to keep the toolchain minimal).

---

## 4. Module Responsibilities

### 4.1 SawanDownloadPro.Core
Pure domain. No I/O, no framework references beyond mscorlib/System.
- Enums: `DownloadStatus`, `DownloadCategory`, `DownloadPriority`, `AuthenticationScheme`
- Models: `DownloadTask`, `SegmentInfo`, `DownloadTaskUpdate`, `AppSettings`, `BandwidthLimit`
- Interfaces: `IDownloadEngine`, `IDownloadTaskStore`, `IScheduler`, `IPathSanitizer`, `IUrlValidator`, `ISettingsStore`, `ILogger`
- Events: `DownloadProgressEventArgs`, `DownloadStateChangedEventArgs`, `DownloadCompletedEventArgs`, `DownloadFailedEventArgs`

### 4.2 SawanDownloadPro.DownloadEngine
The product's heart. Implements:
- `HttpDownloadEngine` — single-connection fallback
- `SegmentedDownloadEngine` — parallel segments when server advertises `Accept-Ranges: bytes`
- `SegmentCoordinator` — assigns byte ranges, re-blends on segment failure
- `BandwidthThrottle` — token-bucket per-download and global throttling
- `RetryPolicy` — exponential backoff with jitter; honours `Retry-After`
- `RangeValidator` — validates Content-Range responses against ETag/Last-Modified
- `PartialFileWriter` — atomic .part files with `.sawanmeta` sidecar for resume metadata
- `TlsConfiguration` — forces TLS 1.2 minimum (Win7 SP1 ships TLS 1.0/1.1 by default)

### 4.3 SawanDownloadPro.Storage
- SQLite schema v1 (see Section 7)
- `SqliteDownloadTaskStore` — repository for `DownloadTask`
- `SqliteSettingsStore` — key/value settings with JSON serialization
- `MigrationRunner` — applies schema migrations on startup
- `DatabaseBackup` — explicit backup to user-chosen path

### 4.4 SawanDownloadPro.Security
- `PathSanitizer` — strips path traversal, normalizes, enforces extension allow-list for dangerous types (.exe, .bat, .ps1, .vbs, .js, .jar, .scr)
- `UrlValidator` — scheme allow-list (http/https/ftp), length limits, host sanity
- `SafeProcessLauncher` — wraps `Process.Start` with argument escaping, no `UseShellExecute` for untrusted inputs
- `SecretProtector` — DPAPI-based encryption for any credential that must be stored (default: store nothing)
- `FileNameSanitizer` — Windows-safe filename generation

### 4.5 SawanDownloadPro.Scheduler
- `DownloadQueue` — priority queue with max-simultaneous enforcement
- `ScheduledJob` — start/stop queue at a specific time; optional repeat
- `ShutdownCoordinator` — explicit confirmation before any system shutdown

### 4.6 SawanDownloadPro.Media
- `IVideoExtractor` interface + `YouTubeExtractor`, `FacebookExtractor`, `TikTokExtractor` stubs
- Each extractor explicitly documents what it can and cannot do per the user's authorization rules
- `FFmpegRunner` — wraps an FFmpeg binary the user must supply; never bundled
- `MediaConverter` — MP4/WebM→MP3, quality selection, progress reporting
- All extractors fail safe: an unsupported URL returns a clear error, never a silent failure

### 4.7 SawanDownloadPro.BrowserIntegration
- `NativeMessagingHost` — stdio-based host that the browser extension talks to
- Validates incoming JSON messages against a strict schema
- Forwards validated download URLs to the main application via a named pipe
- `ExtensionInstaller` — registers the native messaging manifest in the correct Windows registry location per browser

### 4.8 SawanDownloadPro.App
- WPF MainWindow with sidebar, virtualized download list, status bar
- Add Download Dialog with metadata pre-fetch
- Settings window with all categories from the spec
- Light/Dark themes via ResourceDictionary swapping
- AR/EN localization via XAML ResourceDictionary with `FlowDirection` switching
- Tray icon support, single-instance enforcement, MVVM via `CommunityToolkit.Mvvm`

---

## 5. Windows Compatibility Matrix

| OS | Architecture | Runtime requirement | Browser integration | Tested? |
|---|---|---|---|---|
| Windows 7 SP1 | x86 | .NET Framework 4.8 (KB4055001), TLS 1.2 enabled | Chrome ≤ 109, Firefox ≤ 115 ESR | **Not yet verified on physical hardware** — labelled as "designed for, requires user verification" |
| Windows 7 SP1 | x64 | Same as above | Same as above | **Not yet verified on physical hardware** |
| Windows 10 (any build) | x86 | .NET Framework 4.8 | Chrome / Edge / Firefox current | **Not yet verified on physical hardware** |
| Windows 10 (any build) | x64 | .NET Framework 4.8 | Chrome / Edge / Firefox current | **Not yet verified on physical hardware** |
| Windows 11 | x64 | .NET Framework 4.8 | Chrome / Edge / Firefox current | **Not yet verified on physical hardware** |

### Known limitations on Windows 7 SP1

1. **TLS 1.3 is not supported by the OS.** All HTTPS downloads are limited to TLS 1.2.
2. **Modern browser versions are not available.** Chrome ≥ 110, Edge ≥ 110, and modern
   Firefox dropped Win7 support. Users must run legacy ESR versions, or use the
   clipboard/manual URL entry fallback.
3. **SHA-2 code signing support requires KB4474419.** Without it, installer signature
   verification will fail. The installer will warn but proceed.
4. **Microsoft has ended support for Windows 7.** Security patches are no longer
   shipped; we cannot promise that future website TLS configurations will remain
   compatible.

### Known limitations on Windows 10

1. **Windows 10 versions < 1607 ship with PowerShell 5.0.** The optional post-download
   shutdown script requires PowerShell 5.1+.
2. **Microsoft ended mainstream support for some 10 releases.** Verify the build
   still receives security updates.

---

## 6. Database Schema

### Table: `downloads`

| Column | Type | Notes |
|---|---|---|
| id | TEXT PRIMARY KEY | GUID |
| url | TEXT NOT NULL | Source URL |
| final_url | TEXT | After redirects |
| file_name | TEXT NOT NULL | Sanitized |
| save_path | TEXT NOT NULL | Absolute |
| category | TEXT NOT NULL | Enum string |
| status | TEXT NOT NULL | Enum string |
| total_bytes | INTEGER | NULL if unknown |
| downloaded_bytes | INTEGER | |
| created_at | TEXT NOT NULL | ISO-8601 |
| started_at | TEXT | |
| completed_at | TEXT | |
| error_message | TEXT | |
| etag | TEXT | For resume validation |
| last_modified | TEXT | For resume validation |
| accept_ranges | INTEGER | 0/1 |
| connection_count | INTEGER | |
| max_connections | INTEGER | |
| priority | INTEGER | |
| auth_scheme | TEXT | none/basic/digest |
| auth_username | TEXT | |
| auth_password_enc | BLOB | DPAPI-encrypted, NULL if absent |
| custom_headers_json | TEXT | JSON-serialized |
| source | TEXT | manual / clipboard / browser / video |

### Table: `segments`

| Column | Type | Notes |
|---|---|---|
| id | TEXT PRIMARY KEY | GUID |
| download_id | TEXT NOT NULL | FK to downloads.id |
| start_byte | INTEGER NOT NULL | |
| end_byte | INTEGER NOT NULL | |
| downloaded_bytes | INTEGER NOT NULL | |
| position | INTEGER NOT NULL | 0-based |
| status | TEXT NOT NULL | pending/active/completed/failed |

### Table: `settings`

| Column | Type | Notes |
|---|---|---|
| key | TEXT PRIMARY KEY | |
| value | TEXT | JSON-serialized |
| updated_at | TEXT NOT NULL | ISO-8601 |

### Table: `history`

| Column | Type | Notes |
|---|---|---|
| id | TEXT PRIMARY KEY | GUID |
| download_id | TEXT | FK; nullable if task deleted |
| url | TEXT NOT NULL | |
| file_name | TEXT NOT NULL | |
| category | TEXT | |
| completed_at | TEXT NOT NULL | |
| total_bytes | INTEGER | |
| deleted | INTEGER NOT NULL | 0/1 |

### Table: `schema_migrations`

| Column | Type | Notes |
|---|---|---|
| version | INTEGER PRIMARY KEY | |
| applied_at | TEXT NOT NULL | ISO-8601 |

---

## 7. Implementation Roadmap (mapped to user's Stages)

| Stage | Scope | Status |
|---|---|---|
| 1 | Technical design | **Done** — this document |
| 2 | Working MVP: HTTP/HTTPS downloads, pause/resume/retry, SQLite, AR/EN UI, installer scaffolding | **Source code complete; not yet compiled on Windows.** |
| 3 | Advanced download engine: segmented parallel, recovery, scheduling, bandwidth, categories, history | **Source code complete; not yet compiled on Windows.** |
| 4 | Browser integration: Chrome/Edge/Firefox extensions + native host | **Source code complete; not yet compiled on Windows.** |
| 5 | Media downloader + FFmpeg integration | **Stubbed with explicit limitations; full implementation requires user-supplied FFmpeg binary and extractor verification.** |
| 6 | Hardening and release | **Pending Windows-based testing.** |

---

## 8. Key Technical Decisions

### 8.1 Why `HttpWebRequest` instead of `HttpClient` for the segmented engine?

`HttpClient` does not expose enough control over per-segment Range requests, response
headers, and cancellation for the parallel-segments use case. `HttpWebRequest` is older
but provides explicit control. We use `HttpClient` for the simpler metadata fetch (HEAD
request to detect Content-Length and Accept-Ranges) where its async API is convenient.

### 8.2 Why not ` yt-dlp ` bundled into the installer?

`yt-dlp` is GPL/Unlicense. Bundling it would impose GPL obligations on the entire
product. We instead document how a user can configure Sawan Download Pro to invoke an
externally-supplied `yt-dlp.exe` or `ffmpeg.exe`, and explicitly decline to redistribute
either binary.

### 8.3 Why SQLite and not a JSON file?

A download manager needs atomic transactions for resume state, concurrent access from
the engine and the UI, and history queries over potentially tens of thousands of rows.
JSON files fail all three. SQLite is a single-file, embedded, transactional database
with excellent Win7 support.

### 8.4 Why MVVM via CommunityToolkit.Mvvm and not Prism or Caliburn?

CommunityToolkit.Mvvm is source-generator-based, lightweight, has no runtime Win7
incompatibility, and is officially Microsoft-supported. Prism is heavier; Caliburn is
community-maintained. For a product of this scope the lighter choice is correct.

### 8.5 Why WiX v3.14 and not v4 or MSIX?

MSIX requires Win10 1709+ and does not support Win7. WiX v4 changed the toolchain
significantly and has fewer production references. WiX v3.14 is the stable, Win7-
compatible, widely-documented choice.

---

## 9. Security Posture

1. **No telemetry, no analytics, no auto-update without explicit user opt-in.** The
   updater checks a URL the user configures, verifies an Ed25519 signature, and only
   then downloads. No version information is ever sent to a server.
2. **No plaintext credentials.** Basic/Digest auth credentials, when the user explicitly
   configures them, are DPAPI-encrypted per-user. They never leave the machine.
3. **Path validation.** Every user-supplied filename and save path passes through
   `PathSanitizer` which strips `..`, normalizes separators, and rejects absolute paths
   in the filename component.
4. **URL validation.** Only `http`, `https`, `ftp` schemes are accepted. `file://`,
   `javascript:`, `data:`, and any UNC path (`\\server\share`) are rejected by default.
5. **Dangerous file types.** Downloads with `.exe`, `.bat`, `.cmd`, `.ps1`, `.vbs`,
   `.js`, `.jar`, `.scr`, `.msi` extensions trigger a confirmation dialog before being
   opened post-completion.
6. **Browser extension message validation.** Native messaging host validates the
   incoming JSON against a strict schema and ignores anything that does not match.
7. **No bundled offers, no adware, no installer-stage third-party software.** The
   installer is a single MSI that installs Sawan Download Pro and nothing else.

---

## 10. What This Repository Contains vs. What Remains To Be Done

### Contains (source code complete)

- Full solution with 8 C# projects and proper project references
- Working HTTP/HTTPS segmented download engine with resume and retry
- SQLite storage with schema v1 and migration runner
- WPF MainWindow with sidebar, virtualized list, status bar
- Add Download Dialog with metadata pre-fetch
- Settings window covering all spec sections
- AR/EN localization with full RTL support
- Light/Dark themes
- Scheduler with queue priorities and optional shutdown
- Browser extensions (Chrome/Edge MV3 + Firefox MV2) + native messaging host
- WiX installer source for x86 and x64
- xUnit test project with unit tests for the core engine, security, and scheduler
- Complete documentation set

### Remains to be done (requires a Windows environment)

1. **Compile the solution in Visual Studio 2019/2022 on Windows.** Provide NuGet
   restore + `msbuild` commands in `docs/BUILD_INSTRUCTIONS.md`.
2. **Run the test suite on Windows** and capture real pass/fail output.
3. **Test installer on Windows 7 SP1, 10, 11** — physical or VM.
4. **Verify TLS 1.2 forced negotiation works on Win7 SP1** with a current public test
   server (e.g. https://badssl.com).
5. **Sign the installer and EXE** with a code-signing certificate (we cannot acquire
   one on your behalf).
6. **Register and test the native messaging host** in each supported browser.
7. **Verify the optional FFmpeg integration** with a user-supplied `ffmpeg.exe`.

These items are labelled "Not yet verified" throughout the documentation rather than
claimed as working.

---

## 11. Honest Limitations

- We cannot promise a fixed speed multiplier. Performance depends on the server, the
  network, the connection limit, and the user's bandwidth.
- We cannot promise that YouTube, Facebook, or TikTok extraction will work indefinitely.
  These platforms change their APIs and may break any extractor at any time. When an
  extractor fails, the application reports the failure clearly and suggests the
  authorized alternative.
- We cannot promise that every browser extension will continue to work on Win7. As
  browser vendors drop Win7 support, users must either stay on legacy ESR builds or use
  the manual URL entry fallback.
- We do not bundle FFmpeg, yt-dlp, or any other GPL/LGPL binary. Users who want media
  conversion must supply their own binaries, which we then invoke as external processes
  with safe argument construction.

---

End of architecture document.
