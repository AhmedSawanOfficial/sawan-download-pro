# دليل بناء تطبيق Sawan Download Pro v1.0 على نظام Windows

**الإصدار:** 1.0 — الإصدار الأول
**المنشئ:** Ahmed Sawan
**العلامة التجارية:** Sawan

---

## المتطلبات الأساسية

### 1. نظام التشغيل
- Windows 10 (الإصدار 1809 أو أحدث) — موصى به
- Windows 11 — موصى به
- Windows 7 SP1 — مدعوم مع تثبيت .NET Framework 4.8

### 2. Visual Studio 2022 (مجاني)

**التحميل:** https://visualstudio.microsoft.com/downloads/

اختر إصدار **Community** (مجاني للأفراد).

أثناء التثبيت، يجب تحديد الحزمة التالية:
- ✅ **.NET desktop development** (تطوير تطبيقات سطح المكتب بـ .NET)

هذه الحزمة تتضمن:
- MSBuild
- .NET Framework 4.8 targeting pack
- أدوات بناء WPF و WinForms
- محرر XAML

### 3. .NET Framework 4.8 Developer Pack (اختياري)

إذا لم يثبت Visual Studio حزمة المراجع تلقائيًا، حمّلها من:
https://dotnet.microsoft.com/download/dotnet-framework/net48

### 4. NuGet CLI (اختياري)

إذا لم يكن `nuget.exe` متاحًا، حمّله من:
https://www.nuget.org/downloads

ضعه في مجلد ضمن متغير البيئة PATH (مثل `C:\Tools\`).

### 5. WiX Toolset v3.14 (اختياري — لبناء المثبّت MSI)

إذا كنت تريد بناء ملف `.msi`:
- التحميل: https://wixtoolset.org/releases/
- أضف `C:\Program Files (x86)\WiX Toolset v3.14\bin` إلى متغير PATH

---

## خطوات البناء

### الطريقة الأولى: استخدام سكربت البناء (الأسهل)

1. **فك ضغط الحزمة:**
   - فك ضغط `SawanDownloadPro-v1.0-source.zip` في مجلد، مثلاً `C:\Projects\SawanDownloadPro\`

2. **افتح موجه الأوامر المطوّر:**
   - قائمة ابدأ → ابحث عن "Developer Command Prompt for VS 2022"
   - أو: افتح موجه أوامر عادي ثم نفّذ:
     ```
     "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat"
     ```

3. **انتقل إلى مجلد المشروع:**
   ```
   cd C:\Projects\SawanDownloadPro
   ```

4. **شغّل سكربت البناء:**
   ```
   build_release.bat
   ```
   أو لبناء نسخة 32-bit (لـ Windows 7 32-bit):
   ```
   build_release.bat x86
   ```
   أو لبناء المثبّت MSI أيضًا:
   ```
   build_release.bat x64 msi
   ```

5. **النتيجة:**
   - الملف التنفيذي: `src\SawanDownloadPro.App\bin\Release\x64\SawanDownloadPro.exe`
   - جميع ملفات التشغيل في نفس المجلد

### الطريقة الثانية: استخدام Visual Studio IDE

1. افتح Visual Studio 2022
2. اختر **Open a project or solution**
3. افتح الملف: `C:\Projects\SawanDownloadPro\SawanDownloadPro.sln`
4. في شريط الأدوات العلوي:
   - اختر التكوين: **Release**
   - اختر المنصة: **x64**
5. اضغط `Ctrl + Shift + B` لبناء الحل
6. انتظر حتى يكتمل البناء (قد يستغرق 1-3 دقائق)
7. الملف التنفيذي سيكون في:
   ```
   src\SawanDownloadPro.App\bin\Release\x64\SawanDownloadPro.exe
   ```

### الطريقة الثالثة: سطر الأوامر (بدون Visual Studio)

إذا ثبّت **Build Tools for Visual Studio 2022** فقط:

```
cd C:\Projects\SawanDownloadPro
nuget restore SawanDownloadPro.sln
msbuild SawanDownloadPro.sln /p:Configuration=Release /p:Platform=x64
```

---

## ملفات الإخراج

بعد البناء الناجح، ستجد في المجلد:
```
src\SawanDownloadPro.App\bin\Release\x64\
```

الملفات التالية (جميعها مطلوبة للتشغيل):

| الملف | الوصف |
|------|-------|
| `SawanDownloadPro.exe` | الملف التنفيذي الرئيسي |
| `SawanDownloadPro.dll` | تجميع التطبيق |
| `SawanDownloadPro.Core.dll` | النماذج والواجهات الأساسية |
| `SawanDownloadPro.DownloadEngine.dll` | محرك التنزيل |
| `SawanDownloadPro.Storage.dll` | طبقة قاعدة البيانات |
| `SawanDownloadPro.Security.dll` | الأمان والتحقق |
| `SawanDownloadPro.Scheduler.dll` | المجدول وقائمة الانتظار |
| `SawanDownloadPro.Media.dll` | محمل الوسائط |
| `SawanDownloadPro.BrowserIntegration.dll` | تكامل المتصفح |
| `SawanDownloadPro.Themes.dll` | نظام السمات |
| `Microsoft.Extensions.*.dll` | مكتبات التسجيل وحقن التبعيات |
| `Newtonsoft.Json.dll` | تسلسل JSON |
| `CommunityToolkit.Mvvm.dll` | إطار MVVM |
| `System.Data.SQLite.dll` | محرك قاعدة البيانات |
| `x86\SQLite.Interop.dll` | مكتبة SQLite الأصلية (32-bit) |
| `x64\SQLite.Interop.dll` | مكتبة SQLite الأصلية (64-bit) |
| `SawanDownloadPro.exe.config` | إعدادات التطبيق |
| `Resources\sawan-icon.ico` | أيقونة التطبيق |
| `Resources\sawan-logo.svg` | شعار سوان |

---

## متطلبات التشغيل على جهاز المستخدم

### .NET Framework 4.8

- **Windows 10 (1809+):** مثبّت مسبقًا ✅
- **Windows 11:** مثبّت مسبقًا ✅
- **Windows 7 SP1:** يجب التثبيت من:
  https://dotnet.microsoft.com/download/dotnet-framework/net48

### لا حاجة لأي مكتبات إضافية

جميع التبعيات مضمّنة في مجلد الإخراج. لا يحتاج المستخدم إلى تثبيت:
- ❌ .NET Core / .NET 5+ / .NET 6+ / .NET 7+ / .NET 8+
- ❌ Visual C++ Redistributable
- ❌ WebView2 Runtime
- ❌ أي حزمة NuGet إضافية

---

## إنشاء نسخة قابلة للتوزيع

### نسخة محمولة (Portable)

انسخ المجلد بأكمله:
```
xcopy /E /I "src\SawanDownloadPro.App\bin\Release\x64" "SawanDownloadPro-Portable"
```

ثم ضع المجلد `SawanDownloadPro-Portable` في أرشيف ZIP. يمكن للمستخدم تشغيل `SawanDownloadPro.exe` مباشرةً دون تثبيت.

### مثبّت MSI (يتطلب WiX)

```
build_release.bat x64 msi
```

النتيجة:
```
installer\bin\x64\SawanDownloadProSetup.msi
```

---

## استكشاف الأخطاء وإصلاحها

### خطأ: "MSBuild not found"
- تأكد من تثبيت Visual Studio 2022 مع حزمة ".NET desktop development"
- أو ثبّت Build Tools for Visual Studio 2022

### خطأ: "Could not find 'Microsoft.NET.Sdk.Windows'"
- هذا يعني أن SDK الخاص بـ WPF غير مثبّت
- أعد تشغيل Visual Studio Installer وحدد حزمة ".NET desktop development"

### خطأ: "The type or namespace 'HttpWebRequest' could not be found"
- تأكد من أن المشروع يستهدف `net48` وليس `netcoreapp` أو `net6.0`

### خطأ: "NuGet restore failed"
- تأكد من وجود اتصال بالإنترنت (NuGet يحتاج للوصول إلى nuget.org)
- أو استخدم مصدر NuGet محلي/مرآة

### خطأ: "Could not load file or assembly 'System.Data.SQLite'"
- تأكد من وجود المجلدين `x86\` و `x64\` بجانب الملف التنفيذي
- يحتويان على `SQLite.Interop.dll` الخاص بكل معمارية

### البناء ناجح لكن التطبيق لا يعمل
- تحقق من سجلات التطبيق في:
  ```
  %LOCALAPPDATA%\SawanDownloadPro\logs\
  ```
- تأكد من تثبيت .NET Framework 4.8

---

## التحقق من نجاح البناء

بعد تشغيل `build_release.bat`، يجب أن ترى:

```
============================================================
 BUILD SUCCEEDED
============================================================

 Executable:
   C:\Projects\SawanDownloadPro\src\SawanDownloadPro.App\bin\Release\x64\SawanDownloadPro.exe
```

للتحقق يدويًا:
```
dir "src\SawanDownloadPro.App\bin\Release\x64\SawanDownloadPro.exe"
```

يجب أن يظهر ملف بحجم تقريبي 300-500 كيلوبايت.

---

## توافق Windows 7

- استخدم منصة `x86` لبناء نسخة تعمل على Windows 7 32-bit:
  ```
  build_release.bat x86
  ```
- يجب تثبيت .NET Framework 4.8 على Windows 7 SP1
- مكاملات المتصفح قد لا تعمل مع الإصدارات الحديثة من Chrome/Edge/Firefox
  (استخدم إصدارات ESR القديمة أو إدخال الرابط يدويًا)

---

## الدعم والتواصل

- **واتساب:** https://wa.me/201000150303
- **يوتيوب:** https://www.youtube.com/@AhmedSawanOfficial
- **فيسبوك:** https://www.facebook.com/AhmedSawanOfficial/
- **تيليجرام:** https://t.me/AhmedMSawan

---

*تم إنشاء هذا الدليل بواسطة Ahmed Sawan — الإصدار 1.0 — First Release*
