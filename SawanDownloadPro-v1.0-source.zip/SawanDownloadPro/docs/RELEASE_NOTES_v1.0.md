# Sawan Download Pro — Version 1.0 — First Release

> **Tagline:** Fast. Smart. In Control.
>
> **Created by:** Ahmed Sawan
>
> **Release date:** October 2026
>
> **Brand:** Sawan
>
> **License:** Apache License, Version 2.0

This is the first official release of **Sawan Download Pro**, the
flagship download manager product of the Sawan brand. Version 1.0
replaces the earlier Stage-2 MVP engineering milestone with a polished,
product-grade build that introduces a new visual identity, a real-time
dashboard, dedicated privacy tooling, six-browser integration, and a
first-run experience that walks new users through the essentials.

The Stage-2 MVP was an internal engineering preview shared only with the
development team; it deliberately used the default blue palette, had no
dashboard, and shipped with no first-run wizard. Version 1.0 is the
release intended for end users, and it is the version against which all
future releases will be compared.

---

## 1. Highlights

The following capabilities are new or materially changed versus the
Stage-2 MVP and are the headline features of this release:

- **Dark Eggplant visual identity.** The default theme has been rebranded
  from the Stage-2 blue/cyan palette to the new Dark Eggplant palette
  (`#21102F` primary background, `#6F42A6` primary accent, `#A78BFA`
  secondary accent). The Light and System themes are still selectable;
  the System theme now follows Windows dark-mode and resolves to Dark
  Eggplant when the OS is in dark mode.
- **New dashboard view.** A first-class dashboard tab shows live totals
  (active, queued, completed, failed), aggregate download speed, free
  disk space on the default download drive, and the most recent
  notifications. The dashboard replaces the empty "Home" placeholder
  from the MVP.
- **About Sawan page.** A dedicated About panel introduces the creator,
  Ahmed Sawan, and surfaces all four official Sawan contact channels
  (WhatsApp, YouTube, Facebook, Telegram). No invented contact details,
  no third-party social links.
- **First-run welcome screen.** New installs walk the user through
  language, theme (defaulting to Dark Eggplant), default download
  folder, browser-integration selection across all six supported
  browsers, and a Private Downloads consent toggle. The wizard can be
  re-run at any time from Settings → General.
- **Private Downloads mode.** A separate session that isolates private
  downloads from the main queue, hides them from the regular sidebar,
  and can be cleared on demand. An optional auto-cleanup setting
  destroys the private session on app exit.
- **Security & Privacy dashboard.** A new sidebar item collects every
  privacy-sensitive setting and every security toggle in one place:
  DPAPI status, telemetry status (always off), log directory, antivirus
  integration, native-messaging host status, and the Clear Private
  Session action.
- **Six-browser integration.** Opera, Brave, and Vivaldi have been
  added to the existing Chrome, Edge, and Firefox support. All three
  new browsers are Chromium-based and ship the same Manifest V3
  extension as Chrome.
- **SawanDownloadPro.Themes module.** A new project dedicated to theme
  management (palette, accent overrides, theme import/export) cleanly
  separates theming from the rest of the App.
- **Honest release status.** Source code is complete and reviewed, but
  binary compilation on Windows and end-to-end testing on physical
  Windows 7 / 10 / 11 hardware are still pending. Every testable claim
  in the documentation is labelled explicitly.

---

## 2. Detailed feature list

### 2.1 Branding

The product is now branded **Sawan Download Pro** under the **Sawan**
brand, created and owned by **Ahmed Sawan**. The visual identity has
been refreshed end-to-end: installer artwork, in-app icons, splash
screen, about box, tray icon, browser-extension store listings, and the
documentation site all use the Dark Eggplant palette. The tagline
"Fast. Smart. In Control." appears on the splash screen, the About
page, and the README header. The brand mark (a stylized downward chevron
inside an eggplant-coloured rounded square) is rendered from the SVG
assets in `browser-extensions/<browser>/icons/`.

The previous Stage-2 MVP used a placeholder brand ("SawanDownloadPro"
in monospaced text) and the default WPF colour palette. v1.0 is the
first release that is genuinely Sawan-branded.

### 2.2 Dashboard

The new **Dashboard** sidebar item replaces the MVP's empty Home tab.
It surfaces the following panels, all driven by live data from the
download engine and the scheduler:

- **Totals card** — active, queued, paused, completed (today), failed,
  and history counts. Updated on every scheduler tick (1 Hz).
- **Speed card** — aggregate bytes/sec across all active downloads,
  plus the configured global speed limit. A small sparkline shows the
  last 60 seconds of throughput.
- **Disk space card** — free bytes and total bytes on the drive that
  hosts `DefaultDownloadDirectory`. Turns amber below 1 GB free, red
  below 100 MB.
- **Recent notifications card** — the last 10 toast notifications
  (download complete, download failed, queue complete, etc.) with
  timestamps.
- **Quick actions** — one-click buttons for Add Download, Pause All,
  Resume All, Open Default Folder, and Open Settings.

The dashboard is the default landing view on first launch. Users who
prefer the old behaviour can pin the All-downloads view from the
sidebar's context menu.

### 2.3 Download engine

The download engine is unchanged in scope from the Stage-2 MVP, but it
has been re-validated against the v1.0 dashboard's data contracts. It
continues to offer:

- Single-segment and segmented parallel HTTP/HTTPS downloads with
  `Accept-Ranges` negotiation.
- Per-segment pause and byte-accurate resume backed by a SHA-256-signed
  `.sawanmeta` sidecar.
- Exponential backoff retry with `Retry-After` honouring.
- Global and per-task token-bucket bandwidth throttling.
- TLS 1.2 minimum enforcement (Windows 7 SP1 compatible).
- Optional HTTP Basic / Digest authentication with DPAPI-encrypted
  credential storage.

The v1.0 release adds a new **Private Downloads session** data path
(see Section 2.5) and a new event channel that feeds the dashboard's
totals and speed cards.

### 2.4 Browser integration

v1.0 ships browser extensions for **six** browsers, all driven by a
single native-messaging host (`com.sawan.downloadpro`):

| Browser  | Manifest version | Native-messaging registry path                          | Win 7 SP1 cutoff |
|----------|------------------|----------------------------------------------------------|-------------------|
| Chrome   | MV3              | `HKCU\Software\Google\Chrome\NativeMessagingHosts\...`   | Chrome ≥ 110 dropped Win7 |
| Edge     | MV3              | `HKCU\Software\Microsoft\Edge\NativeMessagingHosts\...`  | Edge ≥ 110 dropped Win7  |
| Firefox  | MV2              | `%APPDATA%\Mozilla\NativeMessagingHosts\...json`         | Firefox ESR only on Win7 |
| Opera    | MV3              | `HKCU\Software\Google\Chrome\NativeMessagingHosts\...` (shared with Chrome) | Opera ≥ 87 dropped Win7 |
| Brave    | MV3              | `HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\...` | Brave ≥ 1.46 dropped Win7 |
| Vivaldi  | MV3              | `HKCU\Software\Vivaldi\Vivaldi\NativeMessagingHosts\...` | Vivaldi ≥ 5.6 dropped Win7 |

All three new browsers (Opera, Brave, Vivaldi) accept the Chrome MV3
extension byte-for-byte; only the install page (`opera://extensions`,
`brave://extensions`, `vivaldi://extensions`) and the registry
discovery path differ. The `ExtensionInstaller` writes a single shared
manifest whose `allowed_origins` array lists every Chromium extension
ID the user has configured, plus the Firefox `allowed_extensions` entry.

The native-messaging host accepts only messages matching the strict
schema `{type:"download", url, source, tabUrl?}` and rejects every
other shape (see `docs/SECURITY.md` Section 5 for the full validation
rules).

### 2.5 Private browsing (Private Downloads mode)

Private Downloads mode is a new privacy feature that lets the user
isolate sensitive downloads from the regular queue. When Private mode
is enabled:

- A separate in-memory session holds private tasks. They do not appear
  in the All, Active, or History smart views.
- Private tasks are persisted to the SQLite database in a separate
  `is_private=1` partition so they survive an app restart, but they
  are only visible when the user re-enters Private mode.
- The Clear Private Session action (sidebar button in the Security &
  Privacy panel) deletes every private task and its partial files
  atomically.
- An optional **Auto-clear private session on exit** setting destroys
  the private partition when the app exits.

What Private Downloads mode does **not** do:

- It does **not** clear the browser's history, cookies, or session
  tokens. Sawan has no control over browser state.
- It does **not** clear the operating-system file-system journal or
  the NTFS USN journal. Deleted private files may be recoverable from
  the Recycle Bin or by forensic tools unless the user enables the
  optional secure-delete toggle.
- It does **not** hide network traffic from the user's ISP, employer,
  or any party operating the download URL's server. Sawan does not
  route private downloads through a VPN or proxy automatically.
- It does **not** clear the Windows event log, the DNS cache, or the
  router's connection log.

See `docs/PRIVACY.md` for the full explanation of what Private mode
isolates and what it does not.

### 2.6 Security & Privacy

The new **Security & Privacy** sidebar item is a single dashboard for
every privacy-sensitive control in the application. It surfaces:

- DPAPI status (Current User scope; per-machine binding verified).
- Telemetry status (always **Off** — this is a binding commitment for
  the entire 1.x release line; the toggle is intentionally a read-only
  display).
- Log directory and a "Clear logs now" button.
- Antivirus integration toggle plus the user-supplied scanner path.
- Native-messaging host status (registered for which browsers; manifest
  file path).
- Private Downloads status (active / inactive; auto-clear-on-exit
  state; Clear Private Session button).
- Update check status (off by default; if on, the configured URL and
  the Ed25519 public key fingerprint are shown).
- A "Run security self-check" button that re-validates the path
  sanitizer, URL validator, DPAPI round-trip, and native-messaging
  schema in one pass.

The self-check is also exposed as a CLI flag for the release engineer:
`SawanDownloadPro.App.exe --selftest`.

### 2.7 Media

The optional media downloader is unchanged in scope from the Stage-2
MVP. It continues to support:

- YouTube extraction via a user-supplied `yt-dlp.exe`.
- FFmpeg post-download conversion (MP4 → MP3, trim, transcode) via a
  user-supplied `ffmpeg.exe`.
- Facebook and TikTok are intentional stubs that explain what the app
  will and will not do.

v1.0 adds a **clear authorization reminder** banner at the top of the
Video Downloader window, restating the user's responsibility to comply
with the source platform's Terms of Service and applicable copyright
law. The banner is dismissible per session.

### 2.8 Scheduler

The scheduler is unchanged in scope. It continues to offer queue-start
and queue-stop schedules, daily repeat, and an optional "Shut down
computer when queue completes" with a 60-second cancellation window.
The scheduler window's UI is on the v1.1 roadmap for an overhaul; the
current implementation is functional but visually dated.

### 2.9 Settings

The Settings window gains three new sections in v1.0:

- **Settings → Private Downloads** — enable/disable Private mode,
  enable/disable auto-clear-on-exit, enable/disable secure-delete of
  private partial files.
- **Settings → Security & Privacy** — antivirus integration, native
  messaging host management, log management, security self-check.
- **Settings → Themes** — palette selector (Dark Eggplant / Light /
  System), custom accent colour picker (HEX input), theme export and
  import (JSON).

The existing Settings sections (General, Downloads, Network, Clipboard,
Browser integration, Appearance, Notifications, Media, Advanced) are
unchanged. The first-run wizard can be re-run from **Settings →
General → Run first-run wizard again**.

### 2.10 First-run

The first-run wizard has been redesigned for v1.0. New installs walk
the user through:

1. **Welcome** — splash card introducing the Sawan brand, the tagline,
   and the four official contact links.
2. **Language** — Arabic (default) or English.
3. **Theme** — Dark Eggplant (default), Light, or System.
4. **Default download folder** — defaults to
   `%USERPROFILE%\Downloads\Sawan\`.
5. **Browser integration** — checkboxes for all six supported browsers;
  the manifest and registry entries are written as the user ticks each
   box.
6. **Private Downloads consent** — explains what Private mode does and
   does not protect, and asks for explicit consent before enabling the
   feature.
7. **Finish** — lands the user on the new Dashboard view.

The wizard writes its completion state to `settings.json` and will not
re-appear on subsequent launches unless the user re-runs it from
Settings → General.

### 2.11 About

The new About panel introduces the creator and surfaces the official
Sawan contact channels. The panel shows:

- The Sawan brand mark and the "Fast. Smart. In Control." tagline.
- The application version, build hash, and target runtime.
- The creator credit: "Created by Ahmed Sawan".
- The four official contact links (no others):
  - WhatsApp — <https://wa.me/201000150303>
  - YouTube — <https://www.youtube.com/@AhmedSawanOfficial>
  - Facebook — <https://www.facebook.com/AhmedSawanOfficial/>
  - Telegram — <https://t.me/AhmedMSawan>
- A short biography pointer to `docs/ABOUT_AHMED_SAWAN.md`.
- The full license text (Apache 2.0) and the third-party license
  inventory pointer.

---

## 3. Known limitations

This is the first official release. The following limitations are real
and documented honestly so users and downstream packagers can plan
around them:

- **Not yet compiled on Windows.** The source was authored on Linux
  for engineering reasons but targets .NET Framework 4.8 and WPF. The
  solution has not yet been compiled on a Windows host. Compilation is
  expected to succeed with Visual Studio 2022 and the WiX v3.14
  toolset, but minor source-level fixes may be required at first
  compile.
- **Not yet tested on physical Windows 7 / 10 / 11 hardware.** Every
  test case in `docs/TEST_REPORT.md` is marked "Implemented but not
  fully tested" or "Not implemented" because no Windows host was
  available during the source-authoring phase. End-to-end testing on
  physical hardware is the next milestone.
- **Modern browsers dropped Windows 7.** Chrome ≥ 110, Edge ≥ 110, and
  current Firefox releases no longer install on Windows 7 SP1. Users
  on Windows 7 must use legacy ESR builds of Firefox or the last
  Win7-compatible Chrome / Edge release (109 / 109 respectively) and
  accept that those browsers will not receive security updates.
  Opera ≥ 87, Brave ≥ 1.46, and Vivaldi ≥ 5.6 also dropped Windows 7.
- **FFmpeg and yt-dlp are not bundled.** Users who want media
  conversion or YouTube extraction must download `ffmpeg.exe` and
  `yt-dlp.exe` themselves from the official sources and point Sawan
  at them in Settings → Media. Sawan never bundles either binary, for
  licensing reasons (FFmpeg is LGPL/GPL; yt-dlp is Unlicense).
- **YouTube, Facebook, and TikTok support depends on authorized
  sources.** Sawan will not bypass DRM, login walls, or members-only
  restrictions. Facebook and TikTok are intentional stubs. YouTube
  extraction can break at any time if YouTube changes its player API;
  users should keep `yt-dlp.exe` up to date.
- **Private Downloads mode is not a VPN and not a Tor substitute.** It
  isolates Sawan's own state; it does not hide network traffic, does
  not clear browser state, and does not securely delete files unless
  the secure-delete toggle is enabled.
- **No auto-update by default.** The optional updater is off by
  default and requires explicit opt-in. Even when enabled, the updater
  verifies an Ed25519 signature before applying any downloaded MSI.

---

## 4. Breaking changes from the Stage-2 MVP

Users who installed the Stage-2 MVP (an internal engineering preview,
not a public release) should be aware of the following breaking
changes in v1.0:

| Change                                                | Impact on existing installs                                                                 |
|-------------------------------------------------------|----------------------------------------------------------------------------------------------|
| Theme palette changed from blue/cyan to Dark Eggplant. | User theme selection is migrated to the closest equivalent in the new palette. The previously-selected blue accent is replaced with the default eggplant accent. |
| Default theme is now **Dark Eggplant** (not "System").  | New installs land in Dark Eggplant. Existing installs that explicitly chose "System" or "Light" keep their selection. |
| New sidebar items added (Dashboard, Security & Privacy). | The sidebar order has changed. Pinned sidebar items from the MVP are unpinned and must be re-pinned. |
| `AppTheme` enum unchanged but the default value of `AppSettings.Theme` changed from `System` to `Dark` for new installs. | Existing installs preserve their stored theme. |
| New `SawanDownloadPro.Themes` project added.           | The solution now has 9 projects (was 8). Build scripts that enumerate projects must be updated. |
| Native-messaging manifest's `allowed_origins` now lists all six Chromium browsers. | Existing Chrome/Edge/Firefox installs continue to work; Opera/Brave/Vivaldi only appear if the user enables them in Settings. |
| Database schema v2 adds `is_private` column to `downloads`. | The migration runner upgrades v1 databases automatically on first launch of v1.0. A backup of the v1 database is written to `sawan.db.v1backup` before the migration. |

No user data is lost in any of these changes. The migration runner is
transactional and idempotent.

---

## 5. Documentation index

The following documents ship with this release. All are Markdown; all
are in the `docs/` directory unless noted otherwise.

| Document | Description |
|----------|-------------|
| [`BUILD_INSTRUCTIONS.md`](BUILD_INSTRUCTIONS.md) | Exact commands to build the app, run tests, build the installer, and load browser extensions. |
| [`USER_GUIDE_EN.md`](USER_GUIDE_EN.md) | Comprehensive English user guide for v1.0. |
| [`USER_GUIDE_AR.md`](USER_GUIDE_AR.md) | Comprehensive Arabic (MSA, RTL) user guide for v1.0. |
| [`TROUBLESHOOTING.md`](TROUBLESHOOTING.md) | Common issues and fixes grouped by category. |
| [`SECURITY.md`](SECURITY.md) | Threat model, path/URL/credential protection, Private Downloads security, native-messaging validation. |
| [`PRIVACY.md`](PRIVACY.md) | Comprehensive privacy statement covering data collection, local data, Private Downloads, credentials, logs, browser integration, updates, antivirus, children's privacy, and user rights. |
| [`COMPATIBILITY_MATRIX.md`](COMPATIBILITY_MATRIX.md) | OS × architecture × runtime × browser support matrix. |
| [`LICENSE_INVENTORY.md`](LICENSE_INVENTORY.md) | Table of all third-party dependencies with their licenses. |
| [`ROADMAP.md`](ROADMAP.md) | v1.0 → v1.1 → v1.2 → Future roadmap. |
| [`RELEASE_NOTES_v1.0.md`](RELEASE_NOTES_v1.0.md) | This document. |
| [`ABOUT_AHMED_SAWAN.md`](ABOUT_AHMED_SAWAN.md) | Short biographical note about the creator, with the four official contact links. |
| [`TEST_REPORT.md`](TEST_REPORT.md) | Honest test-status report. |
| [`ARCHITECTURE.md`](ARCHITECTURE.md) | Engineering design document (tech stack, modules, schema, dependency direction). |

---

## 6. Acknowledgments

Sawan Download Pro stands on the shoulders of the following projects
and people. Without them this release would not have been possible:

- **Ahmed Sawan** — creator of the Sawan brand, lead designer and
  product owner of Sawan Download Pro, and the author of the user
  experience vision behind the Dark Eggplant identity and the
  First-Run welcome flow.
- **The FFmpeg team** — for the FFmpeg multimedia framework
  (<https://ffmpeg.org>), which Sawan invokes (but does not bundle)
  for media conversion. FFmpeg is licensed under LGPL v2.1 (or,
  depending on build configuration, GPL v2+); users supply their own
  binary.
- **The yt-dlp team** — for the `yt-dlp` command-line extractor
  (<https://github.com/yt-dlp/yt-dlp>), which Sawan invokes (but does
  not bundle) for YouTube media probing and downloading. `yt-dlp` is
  released under the Unlicense.
- **The SQLite team** — for the SQLite embedded database engine
  (<https://www.sqlite.org>), which Sawan bundles (via the
  `System.Data.SQLite.Core` NuGet package) for download-task,
  settings, and history persistence. SQLite is in the public domain.
- **James Newton-King and the Newtonsoft.Json contributors** — for
  `Newtonsoft.Json`, used throughout the codebase for JSON
  serialization. Licensed under the MIT license.
- **The Microsoft .NET team** — for the .NET Framework 4.8 runtime,
  the WPF UI framework, the BCL, and the C# 9.0 compiler. .NET
  Framework 4.8 is the only modern runtime that still installs and
  runs on Windows 7 SP1, which is a non-negotiable requirement for
  this product.

The full third-party license inventory, including exact versions and
source URLs, is in [`docs/LICENSE_INVENTORY.md`](LICENSE_INVENTORY.md).

---

**Tagline:** Fast. Smart. In Control.

**Status:** Source code complete; binary compilation and Windows-based
testing pending. This is the first official release of the Sawan
product line.

**Connect with Sawan:**

- WhatsApp — <https://wa.me/201000150303>
- YouTube — <https://www.youtube.com/@AhmedSawanOfficial>
- Facebook — <https://www.facebook.com/AhmedSawanOfficial/>
- Telegram — <https://t.me/AhmedMSawan>
