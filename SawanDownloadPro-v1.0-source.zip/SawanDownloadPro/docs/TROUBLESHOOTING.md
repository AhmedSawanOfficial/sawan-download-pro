# Sawan Download Pro v1.0 — Troubleshooting

> **Tagline:** Fast. Smart. In Control.
>
> **Created by:** Ahmed Sawan
>
> **Release:** Version 1.0 — First Release (October 2026)

This document lists the most common issues users hit and the exact
steps to fix each one. Issues are grouped by category. If your issue
is not listed here, file a report at the project's issue tracker with
the contents of `%LOCALAPPDATA%\SawanDownloadPro\logs\sawan.log`
attached. For private contact, use the official Sawan channels listed
in [`docs/ABOUT_AHMED_SAWAN.md`](ABOUT_AHMED_SAWAN.md).

---

## 1. Network and TLS

### 1.1 TLS errors on Windows 7 SP1

**Symptom.** Downloads fail immediately with errors like:

- `The request was aborted: Could not create SSL/TLS secure channel.`
- `Authentication failed because the remote party sent a TLS alert: 'Protocol version'.`

**Cause.** Windows 7 SP1 ships with TLS 1.0 and TLS 1.1 enabled by
default. Most modern servers require TLS 1.2 or later and refuse TLS
1.0/1.1 handshakes.

**Fix.**

1. Install **KB4019276** ("Update for addition of TLS v1.1 and TLS v1.2
   support for WinHTTP on Windows 7 SP1 / Server 2008 R2 SP1"). Download
   from the Microsoft Update Catalog:
   <https://www.catalog.update.microsoft.com/Search.aspx?q=KB4019276>.
2. In Sawan, ensure **Settings → Network → Force TLS 1.2** is ticked
   (it is on by default).
3. As an optional belt-and-braces step, enable TLS 1.2 in the Windows
   registry:
   ```reg
   Windows Registry Editor Version 5.00
   [HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client]
   "DisabledByDefault"=dword:00000000
   "Enabled"=dword:00000001
   ```
4. Restart the computer.

**Note.** Windows 7 SP1 does not support TLS 1.3 at the OS level. All
HTTPS downloads from Sawan will be limited to TLS 1.2.

### 1.2 Downloads not resuming

**Symptom.** After pausing a download and resuming it, the download
restarts from 0% instead of continuing from where it paused.

**Cause.** The server does not advertise `Accept-Ranges: bytes` in its
response headers. Without range support, resuming is impossible; the
client must restart from the beginning. Sawan warns you in the Add
Download dialog when this is the case (look for "Resumable: No" in the
metadata panel).

**Fix.** There is no client-side fix. Either:

- Don't pause the download (let it run to completion), or
- Choose a different mirror that supports ranges (most CDN-backed
  URLs do; some legacy PHP-download scripts do not).

### 1.3 Slow downloads despite a fast connection

**Symptom.** Sawan tops out at a fraction of your connection speed even
though other tools (browser, curl) hit full speed.

**Causes and fixes.**

| Cause                                                | Fix                                                                                              |
|------------------------------------------------------|--------------------------------------------------------------------------------------------------|
| Global speed limit is set in Settings                | Settings → Network → Global speed limit = 0 (unlimited).                                         |
| Max connections per download = 1                     | Settings → Downloads → Max connections per download: try 4–8.                                    |
| Max simultaneous downloads too low                   | Increase in Settings → Downloads.                                                                |
| Antivirus real-time scan on the temp folder          | Add `%LOCALAPPDATA%\SawanDownloadPro\temp\` to your AV exclusions.                               |
| Server is the bottleneck (slow origin)               | No client-side fix; try a different mirror.                                                      |
| Proxy is configured but you don't need one           | Settings → Network → Use proxy: off.                                                             |
| Wi-Fi / VPN interference                              | Test on a wired connection with the VPN disabled.                                                |

### 1.4 Connection timeout on a slow server

**Symptom.** Downloads fail with `The operation has timed out` even
though the server is reachable.

**Fix.** Increase **Settings → Network → Read/write timeout (s)** from
the default 120 to 300 or 600. Slow servers with bursty behaviour can
trigger false timeouts.

---

## 2. Browser integration

### 2.1 Browser extension cannot connect to the native host

**Symptom.** Right-click → "Download with Sawan Download Pro" does
nothing (or shows a "native host not found" toast in the browser's
devtools console).

**Causes and fixes.**

1. **Native-messaging manifest not registered.** In Sawan, open
   Settings → Browser Integration and tick the box for your browser.
   If that fails, check the registry:
   ```cmd
   reg query "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro"
   reg query "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\com.sawan.downloadpro"
   reg query "HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\com.sawan.downloadpro"
   reg query "HKCU\Software\Vivaldi\Vivaldi\NativeMessagingHosts\com.sawan.downloadpro"
   ```
   (Opera shares Chrome's path; a single `reg query` covers both.)
   The `(Default)` value must point at
   `%LOCALAPPDATA%\SawanDownloadPro\native-messaging\com.sawan.downloadpro.json`.
   If it doesn't, re-toggle the checkbox or run the Sawan installer's
   Repair option.

2. **Extension ID mismatch.** The manifest's `allowed_origins` array
   must include your extension's ID. Open `chrome://extensions` (or
   `opera://`, `brave://`, `vivaldi://`, `edge://`),
   enable Developer mode, and copy the ID under the Sawan extension
   card. Edit the JSON manifest and replace the placeholder with your
   ID. Save. Restart the browser.

3. **Wrong manifest path.** Open the JSON manifest in a text editor.
   The `path` field must point at the absolute path of the host
   executable (or `.bat` launcher). If you moved the Sawan install
   folder, the path is stale; reinstall Sawan or update the path.

4. **Host executable missing.** Verify the host file exists:
   ```cmd
   dir "C:\Program Files\Sawan\Sawan Download Pro\bin\SawanDownloadPro.BrowserIntegration.exe"
   ```
   If not, reinstall Sawan.

5. **Host crashes on launch.** Run the host directly to see its stderr:
   ```cmd
   "C:\Program Files\Sawan\Sawan Download Pro\bin\SawanDownloadPro.BrowserIntegration.exe" --selftest
   ```
   A healthy self-test prints `OK` and exits 0. If it prints an error,
   the error message tells you what's wrong.

### 2.2 Browser extension loads but the Sawan app doesn't receive URLs

**Symptom.** The browser extension loads, the popup opens, you click
"Send to Sawan", but no URL appears in the app.

**Cause.** The Sawan app is not running, or it's running but the named
pipe server is not started.

**Fix.**

1. Launch Sawan Download Pro.
2. Check that **Settings → Browser integration → Enable <browser>
   integration** is ticked for the browser you're using.
3. Look at `%LOCALAPPDATA%\SawanDownloadPro\logs\native-host.log`. The
   last lines should show the bridge receiving your URL. If the log
   shows "pipe not found" or "access denied", the main app is not
   running its pipe server — restart Sawan.
4. The Sawan app must be running for the bridge to forward URLs. The
   bridge does not queue URLs.

### 2.3 Firefox temporary extension unloads on every restart

**Symptom.** Every time you restart Firefox, you have to re-load the
Sawan extension.

**Cause.** Firefox temporary extensions are unloaded when the browser
exits. This is by design.

**Fix.** Sign the extension permanently via Mozilla's AMO:

```cmd
npm install -g web-ext
cd browser-extensions\firefox
web-ext sign --api-key YOUR_API_KEY --api-secret YOUR_API_SECRET
```

The signed `.xpi` lands in `web-ext-artifacts/`. Install it via
`about:addons → Install Add-on From File`.

Alternatively, use a Firefox Enterprise Policy to load the unpacked
extension permanently. See `browser-extensions/firefox/README.md` for
the policy file.

---

## 3. Opera, Brave, and Vivaldi integration (new in v1.0)

### 3.1 Right-click "Download with Sawan" menu missing in Opera

**Symptom.** In Opera, right-clicking a link does not show the
"Download with Sawan Download Pro" context menu entry, even though the
extension is loaded.

**Cause.** Opera does not display context-menu entries from extensions
on certain internal pages (`opera://*`, `chrome://*`, the Opera news
page). It also suppresses context-menu entries on pages where Opera's
built-in ad blocker has intervened.

**Fix.**

1. Test the extension on a regular `https://` page (e.g.
   <https://example.com>). If the menu appears there but not on
   internal pages, the extension is working correctly; Opera's
   behaviour on internal pages is by design.
2. If the menu does not appear on regular `https://` pages either,
   check that the context-menu permission is granted:
   `opera://extensions` → Sawan → Details → check "Site access: On
   all sites".
3. Disable Opera's built-in ad blocker on the affected site as a
   diagnostic step. If the menu reappears, you can leave the ad
   blocker disabled for that site or add an exception.

### 3.2 Brave Shields block the content script

**Symptom.** In Brave, the Sawan content script's click listener does
not fire on certain sites, so the right-click menu does not appear.

**Cause.** Brave Shields (Brave's built-in privacy protection) blocks
third-party content scripts on sites where Shields is set to "Aggressive"
or where the user has enabled per-site script blocking.

**Fix.**

1. Click the Brave Shields icon in the address bar.
2. Lower the Shields level for the affected site from "Aggressive" to
   "Standard" or "Disabled".
3. Reload the page.
4. The right-click menu should now appear.

This is a Brave-side restriction, not a Sawan bug. Sawan does not
request any permission that bypasses Shields; the user must lower
Shields for sites where they want the content script to run.

### 3.3 Vivaldi tracker blocker interferes with the content script

**Symptom.** In Vivaldi, the Sawan content script's click listener
does not fire on certain sites.

**Cause.** Vivaldi's built-in tracker blocker blocks known tracker
domains, and on some configurations it also blocks third-party content
scripts that look like they could be trackers.

**Fix.**

1. Click the shield icon in Vivaldi's address bar.
2. Disable the tracker blocker for the affected site.
3. Reload the page.

As with Brave, this is a Vivaldi-side restriction. Sawan does not
bypass the tracker blocker.

### 3.4 Native-messaging manifest not discovered by Brave or Vivaldi

**Symptom.** The extension loads, but right-clicking → "Download with
Sawan" produces a "native host not found" error in the devtools
console, even though Chrome's integration works.

**Cause.** Brave and Vivaldi use their own registry paths for
native-messaging host discovery; they do not consult Chrome's path.
If the Sawan installer only registered the manifest under Chrome's
path, Brave and Vivaldi will not find it.

**Fix.**

1. In Sawan, open Settings → Browser integration.
2. Tick **Enable Brave integration** and **Enable Vivaldi
   integration** (even if you previously ticked them — re-ticking
   re-writes the manifest).
3. Click **Apply**.
4. Verify with `reg query`:
   ```cmd
   reg query "HKCU\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\com.sawan.downloadpro"
   reg query "HKCU\Software\Vivaldi\Vivaldi\NativeMessagingHosts\com.sawan.downloadpro"
   ```
5. Restart Brave and Vivaldi.

### 3.5 Opera shows "native host not found" despite Chrome working

**Symptom.** Chrome integration works, but Opera shows "native host
not found".

**Cause.** Opera shares Chrome's native-messaging registry discovery
path. If Chrome integration works, Opera should also work — unless
Opera is running with a different user profile or elevated privileges.

**Fix.**

1. Make sure Opera is running as the same user that installed Sawan
   (do not run Opera as administrator).
2. Make sure Opera and Chrome are both closed when you re-toggle the
   integration checkbox in Sawan. Some Opera versions cache the
   native-messaging discovery result; restarting Opera forces a
   re-query.
3. Verify the registry value with:
   ```cmd
   reg query "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.sawan.downloadpro"
   ```
   This same path is used by Opera.

---

## 4. Theme switching (new in v1.0)

### 4.1 Custom accent not applying

**Symptom.** You change the custom accent colour in Settings → Themes,
but some elements (the tray icon, the Windows jumplist, the browser
extension toolbar button) still show the old colour.

**Cause.** Some elements cache the accent colour at app launch and do
not refresh it live when the user changes the accent in Settings. This
is a known minor issue tracked for v1.1.

**Fix.** Restart Sawan Download Pro. On launch, the app reads the
current accent from settings and rebuilds the tray icon, jumplist, and
extension icon cache.

### 4.2 Dark Eggplant theme does not match screenshots

**Symptom.** After upgrading from the Stage-2 MVP, the app's colours
look different from the v1.0 screenshots, even though Dark Eggplant is
selected.

**Cause.** The Stage-2 MVP used a blue/cyan palette. The migration
from Stage-2 to v1.0 attempts to preserve the user's selected theme
name, but if the user had explicitly chosen "Dark" or "System" in the
MVP, the v1.0 installer maps those to the new Dark Eggplant palette.
If the user had chosen "Light", the Light theme is preserved.

**Fix.**

1. Open Settings → Themes.
2. Explicitly select **Dark Eggplant** (not "System").
3. Click **Apply**.
4. Restart Sawan.

If the colours still look wrong, the theme dictionary may be stale.
Run the first-run wizard again (Settings → General → Run first-run
wizard again) and pick Dark Eggplant on the Theme step.

### 4.3 Theme export/import fails

**Symptom.** Clicking "Export theme" produces an empty file, or
"Import theme" shows an "invalid file" error.

**Cause.** The export writes the theme JSON to the path you choose. If
the path is not writable (e.g. you selected a read-only folder, or
the file is open in another program), the export will fail silently
or with an error.

**Fix.**

1. Export to a writable location you own, e.g. `%USERPROFILE%\Downloads\`.
2. Make sure the file you're importing is a `.sawantheme.json` file
   produced by Sawan's Export button. The importer does not accept
   arbitrary JSON.
3. If the file is valid but the import fails, check
   `%LOCALAPPDATA%\SawanDownloadPro\logs\sawan.log` for the error
   message.

---

## 5. Private Downloads mode (new in v1.0)

### 5.1 Private tasks visible in regular smart views

**Symptom.** You enabled Private mode, added a private task, then
exited Private mode — but the private task still appears in the All or
History smart views.

**Cause.** The Private mode toggle is per-session. If you exit Private
mode (click the Private sidebar item again, or press `Ctrl+Shift+P`),
the sidebar switches back to the regular smart views. Private tasks
should NOT appear there. If they do, the private session filter has
not been applied — usually because the app was restarted while Private
mode was active but the user has not re-entered Private mode.

**Fix.**

1. Click the **Private** item in the sidebar, or press `Ctrl+Shift+P`.
2. The sidebar highlights the Private item; the main list now shows
   only private tasks.
3. Exit Private mode (click the Private item again). The regular smart
   views should now NOT show private tasks.

If private tasks still appear in regular views after exiting Private
mode, this is a bug. Please file an issue with the contents of
`%LOCALAPPDATA%\SawanDownloadPro\logs\sawan.log`.

### 5.2 Clear Private Session did not delete the file on disk

**Symptom.** You clicked Clear Private Session. The private task
disappeared from the app. But the downloaded file (a completed
download) is still on disk.

**Cause.** By design, Clear Private Session only removes the Sawan
task entry, the partial file (if any), and the history row. It does
NOT delete the completed download file — because the user may have
intentionally saved it to a regular folder (e.g. the Desktop) and
may want to keep it.

**Fix.** Manually delete the file from its saved location using
Windows Explorer. If you want partial files securely deleted in the
future, enable **Settings → Private Downloads → Secure-delete private
partial files**. (This affects partial files only, not completed
downloads.)

### 5.3 Auto-clear on exit did not clear the private session

**Symptom.** You enabled Auto-clear on exit. You added a private task.
You exited Sawan. You relaunched Sawan — and the private task is still
there.

**Cause.** Possible causes:

1. **The app did not exit cleanly.** If the app crashed or was killed
   via Task Manager, the exit hook that runs auto-clear did not fire.
2. **The setting was not saved.** If you changed the setting but did
   not click Apply, the setting was not persisted.
3. **The private task was added after the exit hook registered.**
   Unlikely, but possible if a browser-extension URL arrived during
   the shutdown sequence.

**Fix.**

1. Open Settings → Private Downloads. Verify **Auto-clear private
   session on exit** is ticked.
2. Click **Apply** (not just OK).
3. Close the Settings window.
4. Add a private task. Then close Sawan via File → Exit (not via Task
   Manager).
5. Relaunch Sawan. The private task should be gone.

If the task persists, this is a bug. File an issue with the log.

### 5.4 What remains after clearing

After Clear Private Session, the following remain (by design — see
`docs/PRIVACY.md` Section 3.2):

- Completed private downloads on disk (in their saved location).
- Browser history, cookies, session tokens (in the browser).
- NTFS USN journal, Windows event log, DNS cache (in Windows).
- Network logs from the user's ISP / employer / the download server.
- Recycle Bin entries (unless secure-delete was enabled).

If you need stronger guarantees, use a VPN, the Tor Browser, or a
dedicated privacy-focused OS. Sawan's Private Downloads mode is a
convenience feature, not a forensic anonymity tool.

---

## 6. First-run wizard (new in v1.0)

### 6.1 How to re-run the first-run wizard

**Symptom.** You want to re-run the v1.0 welcome wizard — for example,
to re-consent to Private Downloads, to re-register browser integration
after a browser reinstall, or to reset your theme to the v1.0 default.

**Fix.**

1. Open Settings → General.
2. Click **Run first-run wizard again**.
3. The wizard opens with the welcome card. Walk through the seven
   steps (Welcome, Language, Theme, Default download folder, Browser
   integration, Private Downloads consent, Finish).
4. Click **Finish** to return to the Dashboard.

Re-running the wizard does NOT delete your existing settings, queue,
or history. It only overwrites the settings you explicitly change in
the wizard.

### 6.2 First-run wizard appears every launch

**Symptom.** Every time you launch Sawan, the first-run wizard
appears, even though you completed it on the previous launch.

**Cause.** The wizard writes `first_run_complete=true` to
`settings.json` on completion. If the settings file is read-only, or
if the path is not writable, the flag is not persisted and the wizard
re-appears on every launch.

**Fix.**

1. Check that `%LOCALAPPDATA%\SawanDownloadPro\data\settings.json` is
   writable by your user. Right-click → Properties → Security.
2. If the file is read-only, untick the Read-only attribute.
3. If the path is in a synced location (Dropbox, OneDrive), the sync
   client may be locking the file. Pause sync, run the wizard, then
   resume sync.
4. If the issue persists, delete the `first_run_complete` key from
   `settings.json` (or delete the whole file — Sawan will recreate it
   with defaults on next launch) and run the wizard once more.

### 6.3 First-run wizard did not register browser integration

**Symptom.** You ticked "Enable Chrome integration" in the wizard,
but the native-messaging manifest was not written.

**Cause.** The wizard writes the manifest only for browsers whose
extension ID you provided. If you ticked the box but did not provide
the extension ID (because you had not yet loaded the unpacked
extension in the browser), the manifest is written with a placeholder
ID, and the browser will refuse to talk to the host.

**Fix.**

1. Load the unpacked extension in the browser (e.g.
   `chrome://extensions` → Load unpacked → select
   `...\browser-extensions\chrome\`).
2. Copy the extension ID shown on the extension's card.
3. Open Settings → Browser integration.
4. Untick and re-tick **Enable Chrome integration**. The Sawan
   settings page will prompt you for the extension ID.
5. Paste the ID and click Apply.

---

## 7. Media downloader

### 7.1 "FFmpeg/yt-dlp path not configured" error in the Video Downloader

**Symptom.** Pasting a YouTube URL and clicking Probe shows:

> FFmpeg/yt-dlp path not configured. Open Settings → Media to configure.

**Cause.** Sawan has no path to `yt-dlp.exe` (or `ffmpeg.exe`, depending
on the operation) in its settings.

**Fix.**

1. Download `yt-dlp.exe` from
   <https://github.com/yt-dlp/yt-dlp/releases>.
2. In Sawan: Settings → Media → yt-dlp path → browse to `yt-dlp.exe`.
3. (Optional) Download `ffmpeg.exe` (or an FFmpeg build folder) from
   <https://ffmpeg.org/download.html>. Set FFmpeg path to either the
   `.exe` directly or to the folder containing it.
4. Click Apply.
5. Retry the probe.

Sawan does **not** bundle either binary. You must obtain them yourself.

### 7.2 yt-dlp "no downloadable formats" or "DRM-protected content"

**Symptom.** Probe succeeds but the format list is empty, with an error
explaining the video may be DRM-protected.

**Cause.** The video is DRM-protected (e.g. a YouTube Premium music
video, a paid movie, or a paid live stream). yt-dlp itself refuses such
content. Sawan surfaces the refusal.

**Fix.** There is no fix. Sawan will not bypass DRM. Use a different
video that is not DRM-protected.

### 7.3 yt-dlp "Unable to extract" or "client not available"

**Symptom.** Probe fails with an error like `Unable to extract IE:
youtube`. The video is a normal public video.

**Cause.** YouTube changed its player API and your `yt-dlp.exe` is too
old to handle the new API.

**Fix.** Update yt-dlp:

```cmd
"C:\path\to\yt-dlp.exe" -U
```

If `-U` doesn't work (some builds can't self-update), re-download the
latest release from <https://github.com/yt-dlp/yt-dlp/releases> and
overwrite your old `yt-dlp.exe`. Retry the probe.

### 7.4 FFmpeg conversion fails with "encoder not found"

**Symptom.** Converting a video to MP3 fails with `Unknown encoder
'libmp3lame'`.

**Cause.** Your FFmpeg build does not include the MP3 encoder. This is
common with minimal FFmpeg builds.

**Fix.** Use a full FFmpeg build. The "essentials" or "full" builds from
<https://www.gyan.dev/ffmpeg/builds/> include `libmp3lame`. Set
**Settings → Media → FFmpeg path** to the new build's `ffmpeg.exe` and
retry.

### 7.5 Video has no audio after download

**Symptom.** A downloaded MP4 plays back without audio.

**Cause.** YouTube often serves high-resolution video and high-quality
audio as separate streams. yt-dlp merges them into a single MP4 using
FFmpeg. If FFmpeg is not configured (or the build lacks the required
muxer), yt-dlp downloads the video stream only.

**Fix.** Configure **Settings → Media → FFmpeg path**. Sawan passes
`--ffmpeg-location` to yt-dlp automatically. Re-download the video.

---

## 8. Database and storage

### 8.1 "database is locked" error

**Symptom.** Sawan shows a toast: `SQLite error: database is locked`.

**Cause.** Another Sawan instance (or another process) has the database
open with an exclusive lock. Sawan uses a single instance check to
prevent this, but a crashed Sawan can leave a stale lock file.

**Fix.**

1. Check Task Manager for any `SawanDownloadPro.App.exe` processes. End
   them all.
2. Delete the stale lock file:
   ```cmd
   del "%LOCALAPPDATA%\SawanDownloadPro\data\sawan.db-shm"
   del "%LOCALAPPDATA%\SawanDownloadPro\data\sawan.db-wal"
   ```
3. Restart Sawan.

### 8.2 "no such table" error after a database backup restore

**Symptom.** After restoring `sawan.db` from a backup, Sawan fails with
`SQLite error: no such table: downloads`.

**Cause.** The backup is from a different schema version than the
installed Sawan. The migration runner should upgrade it on first run;
if it didn't, the schema mismatch persists.

**Fix.**

1. Quit Sawan.
2. Move the existing database aside:
   ```cmd
   move "%LOCALAPPDATA%\SawanDownloadPro\data\sawan.db" "%LOCALAPPDATA%\SawanDownloadPro\data\sawan.db.broken"
   ```
3. Launch Sawan. It creates a fresh database with the current schema.
4. Use Settings → Storage → Import to import your old downloads list
   (if you have one in JSON form).

If you don't have a JSON export, the broken DB can sometimes be
recovered by manually running the migration SQL. See
`src/SawanDownloadPro.Storage/Migrations/MigrationRunner.cs` for the
schema versions.

### 8.3 Migration from Stage-2 MVP fails

**Symptom.** You had the Stage-2 MVP installed. You install v1.0 over
it. On first launch, Sawan shows a migration error.

**Cause.** v1.0 adds the `is_private` column to the `downloads` table
(schema v2). The migration runner attempts to upgrade v1 databases to
v2 automatically on first launch of v1.0. If the migration fails, the
runner writes a backup of the v1 database to `sawan.db.v1backup` and
exits.

**Fix.**

1. Quit Sawan.
2. Verify the backup exists at
   `%LOCALAPPDATA%\SawanDownloadPro\data\sawan.db.v1backup`.
3. Move the (failed) v2 database aside:
   ```cmd
   move "%LOCALAPPDATA%\SawanDownloadPro\data\sawan.db" "%LOCALAPPDATA%\SawanDownloadPro\data\sawan.db.failed-v2"
   ```
4. Restore the v1 backup as the live database:
   ```cmd
   copy "%LOCALAPPDATA%\SawanDownloadPro\data\sawan.db.v1backup" "%LOCALAPPDATA%\SawanDownloadPro\data\sawan.db"
   ```
5. Launch Sawan. The migration runner will try again. If it fails
   again, file an issue with the contents of
   `%LOCALAPPDATA%\SawanDownloadPro\logs\sawan.log` (the log will
   contain the exact SQL error that caused the migration to fail).
6. As a last resort, delete `sawan.db` and start with a fresh
   database. Your history will be lost; your downloads on disk will
   not be affected.

---

## 9. Installer

### 9.1 "A newer version is already installed"

**Symptom.** Running an older MSI shows this message and exits.

**Cause.** The `MajorUpgrade` element in `Product.wxs` refuses
downgrades. Sawan's upgrade code is fixed; once a version is installed,
older versions cannot overwrite it.

**Fix.** Either:

- Install the newer MSI (recommended), or
- Uninstall the newer version first via Settings → Apps → Sawan
  Download Pro → Uninstall, then install the older MSI.

### 9.2 Installer signature warning on Windows 7 SP1

**Symptom.** Windows shows "The publisher could not be verified" when
you run the MSI.

**Cause.** The MSI is signed with a SHA-256 certificate. Windows 7 SP1
without KB4474419 cannot verify SHA-256 signatures.

**Fix.** Install **KB4474419** (SHA-2 code signing update) from the
Microsoft Update Catalog:
<https://www.catalog.update.microsoft.com/Search.aspx?q=KB4474419>.

After installing KB4474419, restart the computer. The MSI signature
will verify cleanly.

### 9.3 "This app can't run on your PC" on Windows 10/11

**Symptom.** SmartScreen blocks the MSI with "Windows protected your
PC".

**Cause.** The MSI is not signed at all (release builds should be
signed; unsigned builds are intended for development only).

**Fix.** Click **More info → Run anyway** to proceed. For a permanent
fix, use a signed release MSI from the project's releases page.

### 9.4 Installer rolls back at the very end

**Symptom.** The install progress bar reaches the end and then rolls
back, leaving nothing installed.

**Causes and fixes.**

1. **Antivirus interference.** Disable real-time protection temporarily
   and retry.
2. **Custom action failure.** Look at the install log:
   ```cmd
   msiexec /i SawanDownloadProSetup.msi /l*v install.log
   ```
   Open `install.log` and search for `Return value 3` — that line
   identifies the failing action.
3. **Insufficient disk space.** Sawan needs ~80 MB; check the target
   drive.
4. **Per-machine install without admin rights.** Right-click the MSI
   → Run as administrator.

---

## 10. Application crashes

### 10.1 App crashes on launch with `DllNotFoundException: SQLite.Interop.dll`

**Symptom.** The app shows a crash dialog immediately on launch.

**Cause.** The SQLite native binary (`SQLite.Interop.dll`) is missing
from the install folder. This is almost always a packaging bug.

**Fix.** Reinstall Sawan. If you're running from a debug build, ensure
the `System.Data.SQLite.Core` NuGet package restored correctly:

```cmd
nuget restore SawanDownloadPro.sln
msbuild SawanDownloadPro.sln /p:Configuration=Debug /p:Platform=x86
```

If you build with `Any CPU`, the native binary may not be copied to the
right subfolder. Build with an explicit `Platform=x86` or `x64`.

### 10.2 App crashes when adding a download with a non-ASCII filename

**Symptom.** Adding a download whose filename contains Arabic, CJK, or
emoji characters crashes the app.

**Fix.** This is a bug. Please file an issue at the project's tracker
with the exact URL and the crash log from
`%LOCALAPPDATA%\SawanDownloadPro\logs\sawan.log`.

### 10.3 App hangs when downloading a very large file (>50 GB)

**Symptom.** The UI becomes unresponsive while a very large download is
in progress.

**Cause.** The progress UI updates per-segment, and very large files
with many segments can flood the UI thread.

**Fix.** Reduce **Settings → Downloads → Max connections per download**
to 4 or fewer. This reduces the update frequency. A proper fix is on
the v1.1 roadmap (see `docs/ROADMAP.md`).

### 10.4 App crashes when entering Private mode

**Symptom.** Clicking the Private sidebar item or pressing
`Ctrl+Shift+P` crashes the app.

**Cause.** The Private Downloads consent dialog depends on
`Settings.json` containing the `private_mode_consented` key. If the
settings file is from an older build that did not have this key, the
consent dialog may fail to load.

**Fix.**

1. Quit Sawan.
2. Open `%LOCALAPPDATA%\SawanDownloadPro\data\settings.json` in a text
   editor.
3. Add the key `"private_mode_consented": false` at the top level (or
   set it to `true` if you want to skip the consent dialog).
4. Save, restart Sawan.

If the crash persists, file an issue with the log.

---

## 11. Settings and persistence

### 11.1 Settings revert after restart

**Symptom.** You change settings, click Apply, restart Sawan, and the
settings are back to defaults.

**Cause.** The settings file is being written to a location that Sawan
can't read on the next launch — usually because the `LogDirectory` or
`TempDirectory` was set to a path that doesn't exist or isn't writable.

**Fix.**

1. Quit Sawan.
2. Open `%LOCALAPPDATA%\SawanDownloadPro\data\settings.json` in a text
   editor.
3. Find the `LogDirectory` and `TempDirectory` entries. Set them to:
   ```json
   "LogDirectory": "C:\\Users\\<you>\\AppData\\Local\\SawanDownloadPro\\logs",
   "TempDirectory": "C:\\Users\\<you>\\AppData\\Local\\SawanDownloadPro\\temp"
   ```
4. Save, restart Sawan.

### 11.2 Tray icon disappears after explorer.exe restart

**Symptom.** After Windows Explorer restarts (e.g. after a crash), the
Sawan tray icon is gone, but the app is still running.

**Fix.** Sawan listens for the `TaskbarCreated` Windows message and
re-creates its tray icon automatically. If it doesn't, exit Sawan via
Task Manager and relaunch.

### 11.3 Custom accent not persisting

**Symptom.** You set a custom accent in Settings → Themes, click
Apply, restart Sawan — and the accent is back to the default eggplant.

**Cause.** The custom accent is stored in the `custom_accent_hex` key
of `settings.json`. If the settings file is read-only or the path is
synced (Dropbox, OneDrive), the write may fail silently.

**Fix.**

1. Verify `%LOCALAPPDATA%\SawanDownloadPro\data\settings.json` is
   writable.
2. Open the file in a text editor and verify the `custom_accent_hex`
   key is present with your chosen value.
3. If the key is missing, set it manually:
   ```json
   "custom_accent_hex": "#FF5733"
   ```
4. Save, restart Sawan.

---

## 12. Where to get more help

- **`docs/USER_GUIDE_EN.md`** and **`docs/USER_GUIDE_AR.md`** — full
  user guides in English and Arabic.
- **`docs/SECURITY.md`** — security and privacy posture, including how
  to report vulnerabilities.
- **`docs/PRIVACY.md`** — comprehensive privacy statement, including
  what Private Downloads mode isolates and what it does not.
- **`docs/ARCHITECTURE.md`** — engineering design, useful for
  understanding logs.
- **`docs/TEST_REPORT.md`** — what has been tested and what hasn't.
- **`docs/RELEASE_NOTES_v1.0.md`** — full v1.0 release notes.
- **Project issue tracker** — file a bug report with the contents of
  `%LOCALAPPDATA%\SawanDownloadPro\logs\sawan.log` and a clear
  description of the steps to reproduce.
- **Official Sawan contact channels** — see
  [`docs/ABOUT_AHMED_SAWAN.md`](ABOUT_AHMED_SAWAN.md) for the four
  official links (WhatsApp, YouTube, Facebook, Telegram). Do not
  trust any other channel claiming to represent Ahmed Sawan or the
  Sawan brand.
