# Sawan Download Pro v1.0 — Test Report

> **Version:** 1.0 — First Release
> **Created by:** Ahmed Sawan
> **Tagline:** Fast. Smart. In Control.

This document is an honest accounting of the Sawan Download Pro v1.0
test status. It lists every test case defined in the project
specification (architecture document Section 17, "Test Cases") plus
the additional v1.0 test cases for the dashboard, Private Downloads,
Security & Privacy, first-run wizard, and the new three browsers
(Opera, Brave, Vivaldi). For each test, this report classifies the
status using one of five labels:

- **Implemented and tested successfully** — the test ran on Windows
  and passed.
- **Implemented but not fully tested** — the source code is complete
  and reviewed, but the test has not yet been executed on a Windows
  host (because the development environment is Linux).
- **Partially implemented** — the source code for the feature is
  incomplete; the test cannot pass because the feature is not yet
  finished.
- **Not implemented** — neither the feature nor the test exists yet.
- **Blocked by platform or dependency limitations** — the test cannot
  run because a prerequisite is missing (e.g. no FFmpeg binary
  configured, no Windows 7 SP1 host available, no physical Android
  device for the mobile companion).

> **Bottom line.** The development environment for v1.0 is Linux.
> .NET Framework 4.8 + WPF applications cannot be compiled or run on
> Linux. **Every test case below is classified "Implemented but not
> fully tested" (when the source is complete) or "Not implemented"
> (when it is not).** No test has been executed on Windows. When the
> project is compiled and run on a Windows host, this document must
> be updated with the actual pass/fail status of each case.

---

## 1. Test environment

| Property             | Value                                                                  |
|----------------------|------------------------------------------------------------------------|
| Source authored on   | Linux (development environment)                                        |
| Target runtime       | .NET Framework 4.8                                                     |
| Test framework       | xUnit 2.5.3 + Microsoft.NET.Test.Sdk 17.8.0                            |
| Mocking library      | Moq 4.20.70                                                            |
| Build host (target)  | Windows 10 or 11 with Visual Studio 2019 16.11+ or 2022                |
| Compilation status   | **Not yet verified on Windows**                                        |
| Test run status      | **Not yet run**                                                        |

### 1.1 Why not run on Linux

xUnit tests targeting `net48` cannot run on Linux even with Mono or
Wine because the tests exercise Windows-specific APIs (`HttpWebResponse`,
`System.Data.SQLite` native interop, DPAPI, `Registry`, WPF dispatch).
The xUnit test assembly will load on Mono but the production-code
dependencies will not. The test project must be built and run on
Windows.

### 1.2 How to run on Windows

```cmd
nuget restore SawanDownloadPro.sln
msbuild SawanDownloadPro.sln /p:Configuration=Debug /p:Platform=AnyCPU
vstest.console.exe tests\SawanDownloadPro.Tests\bin\Debug\SawanDownloadPro.Tests.dll
REM or:
dotnet test tests\SawanDownloadPro.Tests\SawanDownloadPro.Tests.csproj
```

The application self-check can be run from a command prompt:

```cmd
"SawanDownloadPro.App.exe" --selftest
```

The self-check re-validates the path sanitizer, URL validator, DPAPI
round-trip, and native-messaging schema in one pass, and prints `OK`
or the first failing assertion.

---

## 2. Test case inventory

The architecture spec defines 24 test cases (TC-001 through TC-024)
across six categories. The v1.0 release adds 14 new test cases
(TC-025 through TC-038) for the new features:

- TC-001 – TC-006: Download engine (HTTP, segments, resume, retry)
- TC-007 – TC-010: Storage (SQLite, migrations, settings)
- TC-011 – TC-014: Security (path sanitization, URL validation, DPAPI)
- TC-015 – TC-018: Scheduler (queue, priorities, scheduling)
- TC-019 – TC-021: Browser integration (native messaging, schema)
- TC-022 – TC-024: Media (extractor dispatch, FFmpeg conversion)
- TC-025 – TC-028: Dashboard (totals, speed, disk space, notifications)
- TC-029 – TC-032: Private Downloads (enable, isolate, clear, auto-clear)
- TC-033 – TC-035: Security & Privacy panel (self-check, log clear, AV)
- TC-036 – TC-038: First-run wizard (completion, theme default, re-run)

### 2.1 Legend

- **Implemented and tested successfully** — Test ran on Windows and
  passed.
- **Implemented but not fully tested** — Source code for the feature
  is complete; the test has not yet been executed because no Windows
  host was available. (This is the status of every complete feature
  in this report.)
- **Partially implemented** — Source code for the feature is
  incomplete; the test cannot pass because the feature is not yet
  finished.
- **Not implemented** — Neither the feature nor the test exists yet.
- **Blocked by platform or dependency limitations** — Test cannot run
  because a prerequisite is missing (no Windows 7 SP1 host, no
  FFmpeg, etc.).

---

## 3. Test case status

### 3.1 Download engine (TC-001 – TC-006)

| ID     | Title                                                              | Status                              | Notes                                                                                                |
|--------|--------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------------------------|
| TC-001 | Single-segment HTTP download completes successfully                | Implemented but not fully tested    | `DownloadEngine` source complete. `LocalHttpServer` test helper present. Requires Windows to run.    |
| TC-002 | Segmented download uses parallel ranges when server supports them  | Implemented but not fully tested    | `DownloadEngine` source complete. Requires a range-supporting test server.                          |
| TC-003 | Pause and resume: download continues from paused byte position     | Implemented but not fully tested    | `PartialFileWriter` + SHA-256 `.sawanmeta` sidecar source complete. Requires Windows + SQLite interop. |
| TC-004 | Retry with exponential backoff honours Retry-After                 | Implemented but not fully tested    | `RetryPolicyTests.cs` reflection-based test written. Pure logic; should pass on Windows.             |
| TC-005 | Bandwidth throttle enforces global limit                           | Implemented but not fully tested    | `BandwidthThrottleTests.cs` written. Pure logic.                                                    |
| TC-006 | File name extraction from Content-Disposition and URL fallback     | Implemented but not fully tested    | `FileNameExtractorTests.cs` written. Uses `LocalHttpServer`.                                        |

### 3.2 Storage (TC-007 – TC-010)

| ID     | Title                                                              | Status                              | Notes                                                                                                |
|--------|--------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------------------------|
| TC-007 | SQLite schema v1 creates tables on first run                       | Implemented but not fully tested    | `SchemaTests.cs` smoke-test (string-only). Full DB round-trip needs Windows + `SQLite.Interop.dll`.  |
| TC-008 | Migration runner upgrades from v0 to v1                            | Implemented but not fully tested    | `MigrationRunner.cs` source complete. Migration v1→v2 (adding `is_private`) is also implemented.     |
| TC-009 | Settings round-trip: save and reload preserves all fields          | Implemented but not fully tested    | `SqliteSettingsStore` source complete. v1.0 adds Private Downloads and Themes settings.             |
| TC-010 | History store adds and retrieves recent entries                    | Implemented but not fully tested    | `SqliteHistoryStore` source complete.                                                                |

### 3.3 Security (TC-011 – TC-014)

| ID     | Title                                                              | Status                              | Notes                                                                                                |
|--------|--------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------------------------|
| TC-011 | Path sanitizer strips `..` traversal and rejects absolute paths    | Implemented but not fully tested    | `PathSanitizerTests.cs` written. Pure logic.                                                         |
| TC-012 | URL validator rejects `file:`, `javascript:`, `data:` schemes      | Implemented but not fully tested    | `UrlValidatorTests.cs` written.                                                                      |
| TC-013 | DPAPI secret protector round-trips a string per-user               | Implemented but not fully tested    | `DpapiSecretProtector` source complete. DPAPI is Windows-only; test must be written and run on Win. |
| TC-014 | Dangerous extension detection warns on `.exe`, `.bat`, `.ps1`...   | Implemented but not fully tested    | `PathSanitizerTests.cs` extension-detection tests written.                                          |

### 3.4 Scheduler (TC-015 – TC-018)

| ID     | Title                                                              | Status                              | Notes                                                                                                |
|--------|--------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------------------------|
| TC-015 | Scheduler enqueues and starts a task respecting max-simultaneous   | Implemented but not fully tested    | `DownloadSchedulerTests.cs` (Moq-based) written.                                                     |
| TC-016 | Pause and resume change task state and stop the engine             | Implemented but not fully tested    | `DownloadSchedulerTests.cs` covers this indirectly.                                                  |
| TC-017 | StopAll cancels all running tasks                                  | Implemented but not fully tested    | `DownloadSchedulerTests.cs` verifies this via no-op-after-stop check.                               |
| TC-018 | ScheduleQueueStart fires at the configured time                    | Not implemented                     | Scheduler timer is hard to mock without a fake-clock abstraction. `ISchedulerClock` is on the v1.1 roadmap. |

### 3.5 Browser integration (TC-019 – TC-021)

| ID     | Title                                                              | Status                              | Notes                                                                                                |
|--------|--------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------------------------|
| TC-019 | Native-messaging host validates a strict JSON schema               | Implemented but not fully tested    | `MessageSchema.TryValidate` source complete. A unit test must be written and run on Windows.        |
| TC-020 | Native-messaging host rejects URLs with disallowed schemes         | Implemented but not fully tested    | Same as TC-019.                                                                                       |
| TC-021 | Extension installer writes manifest to the correct registry path   | Implemented but not fully tested    | `ExtensionInstaller` source complete for all six browsers. Registry-write test with cleanup must be written. |

### 3.6 Media (TC-022 – TC-024)

| ID     | Title                                                              | Status                              | Notes                                                                                                |
|--------|--------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------------------------|
| TC-022 | Video extractor registry dispatches YouTube URLs to YouTubeExtractor| Implemented but not fully tested    | `VideoExtractorRegistry.FindExtractor` source complete. Pure-logic unit test must be written.      |
| TC-023 | FFmpeg runner converts an MP4 to an MP3 with correct duration      | Blocked by platform or dependency limitations | Requires Windows **plus a user-supplied `ffmpeg.exe`**. Test must be tagged `[Trait("Category","RequiresExternalBinaries")]`. |
| TC-024 | yt-dlp probe returns formats for a public-domain YouTube video     | Blocked by platform or dependency limitations | Requires Windows **plus a user-supplied `yt-dlp.exe`** plus a network connection. Tag as above.    |

### 3.7 Dashboard (TC-025 – TC-028) — new in v1.0

| ID     | Title                                                              | Status                              | Notes                                                                                                |
|--------|--------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------------------------|
| TC-025 | Dashboard totals card reflects scheduler state in real time        | Implemented but not fully tested    | Dashboard view-model source complete. Live-data binding must be verified on Windows.                |
| TC-026 | Dashboard speed card shows aggregate bytes/sec across active tasks | Implemented but not fully tested    | Speed aggregation source complete. Sparkline rendering requires WPF; must be visually verified.    |
| TC-027 | Dashboard disk-space card turns amber below 1 GB free              | Implemented but not fully tested    | `DriveInfo` integration source complete. Threshold colour logic must be verified on Win.           |
| TC-028 | Dashboard recent-notifications card updates on toast events        | Implemented but not fully tested    | Notification history buffer source complete. Must be verified against the toast service on Win.    |

### 3.8 Private Downloads (TC-029 – TC-032) — new in v1.0

| ID     | Title                                                              | Status                              | Notes                                                                                                |
|--------|--------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------------------------|
| TC-029 | Enabling Private mode hides private tasks from regular smart views | Implemented but not fully tested    | Private session source complete. Sidebar filter logic must be verified on Windows.                 |
| TC-030 | Private tasks survive app restart only when re-entering Private mode | Implemented but not fully tested    | `is_private=1` partition logic source complete. Round-trip must be verified on Win.                |
| TC-031 | Clear Private Session removes private tasks, segments, and partial files atomically | Implemented but not fully tested | Atomic-clear transaction source complete. File-deletion must be verified on Win.                  |
| TC-032 | Auto-clear private session on exit destroys the private partition  | Implemented but not fully tested    | Exit-hook source complete. Must be verified by launching, adding a private task, exiting, relaunching. |

### 3.9 Security & Privacy panel (TC-033 – TC-035) — new in v1.0

| ID     | Title                                                              | Status                              | Notes                                                                                                |
|--------|--------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------------------------|
| TC-033 | Security self-check validates path, URL, DPAPI, and native-messaging schema | Implemented but not fully tested | `--selftest` CLI flag and self-check method source complete. Must be run on Win.                    |
| TC-034 | Clear logs action empties the `logs\` directory                    | Implemented but not fully tested    | Clear-logs command source complete. Must be verified on Win (file locks may interfere).             |
| TC-035 | Antivirus scan invokes user-supplied scanner and records exit code | Implemented but not fully tested    | `SafeProcessLauncher` integration source complete. Requires a scanner binary to test end-to-end.    |

### 3.10 First-run wizard (TC-036 – TC-038) — new in v1.0

| ID     | Title                                                              | Status                              | Notes                                                                                                |
|--------|--------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------------------------|
| TC-036 | First-run wizard completes and writes `first_run_complete=true`    | Implemented but not fully tested    | Wizard source complete. Must be verified by launching on a clean Windows profile.                   |
| TC-037 | First-run wizard defaults theme to Dark Eggplant                   | Implemented but not fully tested    | Default value of `AppSettings.Theme` updated to `Dark`. Must be verified on Win.                    |
| TC-038 | Re-run first-run wizard from Settings → General                    | Implemented but not fully tested    | "Run first-run wizard again" command source complete. Must be verified on Win.                      |

### 3.11 Additional browser integration (TC-039 – TC-041) — new in v1.0

| ID     | Title                                                              | Status                              | Notes                                                                                                |
|--------|--------------------------------------------------------------------|-------------------------------------|------------------------------------------------------------------------------------------------------|
| TC-039 | Opera extension loads and forwards URLs to the native host         | Not implemented                     | Opera shares Chrome's registry path; manual test on Opera ≥ 87 (Win10/11) required. No automated test. |
| TC-040 | Brave extension loads and forwards URLs to the native host         | Not implemented                     | Brave uses its own registry path (`HKCU\Software\BraveSoftware\Brave-Browser\...`). Manual test on Brave ≥ 1.46 required. |
| TC-041 | Vivaldi extension loads and forwards URLs to the native host       | Not implemented                     | Vivaldi uses its own registry path (`HKCU\Software\Vivaldi\Vivaldi\...`). Manual test on Vivaldi ≥ 5.6 required. |

---

## 4. Summary by category

| Category                       | Impl. + tested | Impl. but not fully tested | Partially impl. | Not impl. | Blocked | Total |
|--------------------------------|----------------|----------------------------|-----------------|-----------|---------|-------|
| Download engine                | 0              | 6                          | 0               | 0         | 0       | 6     |
| Storage                        | 0              | 4                          | 0               | 0         | 0       | 4     |
| Security                       | 0              | 4                          | 0               | 0         | 0       | 4     |
| Scheduler                      | 0              | 3                          | 0               | 1         | 0       | 4     |
| Browser integration            | 0              | 3                          | 0               | 0         | 0       | 3     |
| Media                          | 0              | 1                          | 0               | 0         | 2       | 3     |
| Dashboard                      | 0              | 4                          | 0               | 0         | 0       | 4     |
| Private Downloads              | 0              | 4                          | 0               | 0         | 0       | 4     |
| Security & Privacy panel       | 0              | 3                          | 0               | 0         | 0       | 3     |
| First-run wizard               | 0              | 3                          | 0               | 0         | 0       | 3     |
| Additional browser integration | 0              | 0                          | 0               | 3         | 0       | 3     |
| **Total**                      | **0**          | **35**                     | **0**           | **4**     | **2**   | **41**|

---

## 5. What's already written vs. what's missing

### 5.1 Already written (in `tests/SawanDownloadPro.Tests/`)

| Test file                                   | Covers TC IDs                  |
|---------------------------------------------|--------------------------------|
| `Security/PathSanitizerTests.cs`            | TC-011, TC-014                 |
| `Security/UrlValidatorTests.cs`             | TC-012                         |
| `DownloadEngine/RetryPolicyTests.cs`        | TC-004                         |
| `DownloadEngine/BandwidthThrottleTests.cs`  | TC-005                         |
| `DownloadEngine/FileNameExtractorTests.cs`  | TC-006                         |
| `Storage/SchemaTests.cs` (smoke)            | TC-007 (partial — string match)|
| `Scheduler/DownloadSchedulerTests.cs`       | TC-015, TC-016, TC-017         |

### 5.2 Missing — must be written before final release

| TC IDs       | What's missing                                                            |
|--------------|---------------------------------------------------------------------------|
| TC-001       | A real HTTP download round-trip against `LocalHttpServer`.                |
| TC-002       | A real segmented-download round-trip against a range-supporting server.   |
| TC-003       | A real pause/resume round-trip.                                            |
| TC-008       | A migration-runner test that creates a v0 DB and upgrades to v1.           |
| TC-009       | A `SqliteSettingsStore` round-trip test.                                  |
| TC-010       | An `IHistoryStore` round-trip test.                                        |
| TC-013       | A `DpapiSecretProtector` round-trip test. Windows-only.                   |
| TC-018       | A scheduler timer test (may need a fake-clock abstraction).               |
| TC-019       | A `MessageSchema.TryValidate` unit test.                                   |
| TC-020       | A `MessageSchema` scheme-rejection unit test (could be folded into TC-019).|
| TC-021       | An `ExtensionInstaller` registry-write test with cleanup.                 |
| TC-022       | A `VideoExtractorRegistry.FindExtractor` unit test.                       |
| TC-023       | An `FFmpegRunner.ConvertAsync` integration test (requires FFmpeg on PATH). |
| TC-024       | A `YouTubeExtractor.ProbeAsync` integration test (requires yt-dlp + network). |
| TC-025–028   | Dashboard view-model tests with a mock scheduler/engine.                  |
| TC-029–032   | Private Downloads session tests with a mock store.                        |
| TC-033–035   | Security & Privacy panel tests with a mock self-check pipeline.           |
| TC-036–038   | First-run wizard tests with a mock settings store.                        |
| TC-039–041   | Opera/Brave/Vivaldi end-to-end manual tests on real browser installs.     |

---

## 6. Manual test checklist for the release engineer

In addition to the automated tests, the release engineer should run the
following manual checks on each supported platform before publishing a
release. Each check should be run on **both x86 and x64** builds and on
**Windows 7 SP1, Windows 10, and Windows 11** (where supported).

| #    | Manual check                                                                                  | Status                              |
|------|-----------------------------------------------------------------------------------------------|-------------------------------------|
| M-01 | Install MSI; verify Start Menu shortcut, Desktop shortcut, Add/Remove Programs entry.         | Implemented but not fully tested    |
| M-02 | Launch app; verify first-run wizard appears and completes; verify Dark Eggplant theme is default. | Implemented but not fully tested    |
| M-03 | Add a small HTTP download; verify it completes and lands in the right category folder.        | Implemented but not fully tested    |
| M-04 | Add an HTTPS download; verify TLS 1.2 negotiation succeeds.                                   | Implemented but not fully tested    |
| M-05 | Pause and resume a download; verify byte-perfect resume.                                      | Implemented but not fully tested    |
| M-06 | Cancel a download; verify partial file is removed (or kept, per setting).                     | Implemented but not fully tested    |
| M-07 | Trigger a retry: kill the server mid-download; verify exponential backoff fires.              | Implemented but not fully tested    |
| M-08 | Configure browser integration for Chrome; verify right-click → "Download with Sawan" works.   | Implemented but not fully tested    |
| M-09 | Same for Edge.                                                                                | Implemented but not fully tested    |
| M-10 | Same for Firefox (temporary extension).                                                       | Implemented but not fully tested    |
| M-11 | Same for Opera (load unpacked in `opera://extensions`).                                       | Not implemented                     |
| M-12 | Same for Brave (load unpacked in `brave://extensions`).                                       | Not implemented                     |
| M-13 | Same for Vivaldi (load unpacked in `vivaldi://extensions`).                                   | Not implemented                     |
| M-14 | Configure yt-dlp + FFmpeg paths; probe a public-domain YouTube video; download a short clip.  | Blocked by platform or dependency limits |
| M-15 | Convert the clip to MP3 via the FFmpeg integration.                                           | Blocked by platform or dependency limits |
| M-16 | Schedule a queue start 1 minute in the future; verify the queue starts automatically.         | Implemented but not fully tested    |
| M-17 | Schedule a queue stop; verify it pauses active downloads.                                     | Implemented but not fully tested    |
| M-18 | Tick "Shut down when queue completes"; verify the 60-second shutdown dialog appears.          | Implemented but not fully tested    |
| M-19 | Toggle theme between Dark Eggplant, Light, System; verify UI updates without restart.         | Implemented but not fully tested    |
| M-20 | Toggle language between Arabic and English; verify RTL/LTR flow direction switches.           | Implemented but not fully tested    |
| M-21 | Open Dashboard; verify totals, speed, disk space, and notifications update in real time.      | Implemented but not fully tested    |
| M-22 | Enable Private mode; add a private task; verify it does not appear in regular smart views.    | Implemented but not fully tested    |
| M-23 | Clear Private Session; verify private tasks, segments, and partial files are removed.         | Implemented but not fully tested    |
| M-24 | Open Security & Privacy panel; run self-check; verify it prints OK.                           | Implemented but not fully tested    |
| M-25 | Verify no network traffic is generated when idle (no telemetry). Use Wireshark or netstat.    | Implemented but not fully tested    |
| M-26 | Uninstall the app; verify Start Menu shortcut, Desktop shortcut, and install folder are gone. | Implemented but not fully tested    |
| M-27 | Reinstall; verify upgrade preserves user data (settings, history).                            | Implemented but not fully tested    |
| M-28 | Re-run first-run wizard from Settings → General; verify it completes and resets selected defaults. | Implemented but not fully tested |

---

## 7. Known issues and risks

1. **No Windows host was available during v1.0 development.** Every
   test case is "Implemented but not fully tested" (or worse) because
   the development environment is Linux. This is the single largest
   risk to the v1.0 release.
2. **Schema tests are smoke-only.** `Storage/SchemaTests.cs` only
   string-matches the schema SQL. It does not exercise the SQLite
   engine. A full DB round-trip test should be added for v1.1.
3. **No DPAPI test.** TC-013 is not yet implemented. DPAPI is
   Windows-only and requires a unit test that runs on Windows.
4. **No scheduler timer test.** TC-018 is not implemented. The
   scheduler uses a 1 Hz `System.Timers.Timer` that is hard to mock
   without a fake-clock abstraction. A `ISchedulerClock` abstraction
   is on the v1.1 roadmap.
5. **No browser-integration unit tests.** TC-019, TC-020, TC-021 are
   not yet implemented. They are pure-logic tests that should be
   straightforward to add.
6. **Media integration tests depend on external binaries.** TC-023 and
   TC-024 cannot run without user-supplied FFmpeg and yt-dlp. They
   should be marked `[Trait("Category", "RequiresExternalBinaries")]`
   and skipped in CI by default.
7. **No end-to-end browser test.** There is no automated way to verify
   that any of the six browser extensions actually talks to the native
   host. Manual checklist M-08 through M-13 cover this.
8. **No automated tests for the new v1.0 features.** Dashboard,
   Private Downloads, Security & Privacy panel, and First-run wizard
   all have source code complete but no automated tests. Tests must
   be written before v1.0 can claim full test coverage.
9. **No performance tests.** Download speed is highly server-dependent
   and not suitable for automated testing in CI. The release engineer
   should manually verify download speed on a known fast server (e.g.
   `https://speed.hetzner.de/100MB.bin`) before each release.
10. **Opera/Brave/Vivaldi not tested at all.** The three new browser
    extensions are byte-identical to Chrome's MV3 extension, but no
    automated test exercises them. Manual checklist M-11 through M-13
    must be run on a Windows host with each browser installed.

---

## 8. How to update this report

When the project is first built and tested on Windows, the release
engineer should:

1. Run the full test suite: `dotnet test` or Test Explorer → Run All.
2. Run the application self-check: `SawanDownloadPro.App.exe --selftest`.
3. Update Section 3 with the actual pass/fail status of each test case.
4. Run the manual checklist (Section 6) on each supported platform.
5. Update Section 6 with the actual pass/fail status of each manual
   check.
6. Update Section 4 summary table.
7. Commit the updated report with a clear commit message:
   `docs(test-report): update with first Windows test run results`.

Until then, **no test cell in this report shows "Implemented and tested
successfully"** — that is the honest status of the v1.0 release as of
the source-authoring phase.
